# -*- coding: utf-8 -*-
r"""superviseur_boucle.py -- GARANTIT que la boucle de nuit tourne jusqu'a 03h00.

POURQUOI CE FICHIER EXISTE
La boucle s'est arretee toute seule vers 01:50, apres avoir traite XAUUSD. Une boucle qui
meurt en silence ne respecte aucune consigne : si elle tombe a 02h00, la nuit est perdue.
Ce superviseur est un chien de garde :
  - toutes les 60 s, il verifie que la boucle est vivante ;
  - si elle est morte ET qu'on est DANS la plage horaire, il la relance ;
  - si on est HORS plage (03h00 -> 12h00), il ne relance RIEN et attend ;
  - il tient son propre journal.

PLAGE HORAIRE (consigne de l'utilisateur)
  travaille de 12h00 a 03h00 ; NE FAIT RIEN de 03h00 a 12h00.

USAGE : python superviseur_boucle.py
"""
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

RECH = Path(r"C:\EAFarm\HISTORY - Copy\research")
BOUCLE = RECH / "boucle_nuit_locale.py"
PYTHON = r"C:\Program Files\Python314\python.exe"
JOURNAL = RECH / "superviseur.log"
VERROU = RECH / "boucle_verrou.txt"

HEURE_STOP = 3
HEURE_REPRISE = 12
# marqueur present dans la ligne de commande de la boucle, pour la reconnaitre
MARQUEUR = "boucle_nuit_locale.py"


def log(msg):
    ligne = "[%s] %s" % (datetime.now().strftime("%d/%m %H:%M:%S"), msg)
    print(ligne, flush=True)
    with open(JOURNAL, "a", encoding="utf-8") as fh:
        fh.write(ligne + "\n")


def dans_la_plage(m=None):
    """Travaille si heure >= 12 OU heure < 3. Sinon dort."""
    h = (m or datetime.now()).hour
    return h >= HEURE_REPRISE or h < HEURE_STOP


def secondes_avant_reprise():
    m = datetime.now()
    cible = m.replace(hour=HEURE_REPRISE, minute=0, second=0, microsecond=0)
    if cible <= m:
        cible += timedelta(days=1)
    return int((cible - m).total_seconds())


def boucle_vivante():
    """Une boucle tourne-t-elle ? On interroge WMI (fiable sous Windows)."""
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "(Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
             "Where-Object { $_.CommandLine -like '*%s*' } | Measure-Object).Count" % MARQUEUR],
            capture_output=True, text=True, timeout=30)
        return int((r.stdout or "0").strip() or 0) > 0
    except Exception:
        # repli : marqueur de fraicheur ecrit par la boucle
        try:
            if VERROU.exists():
                age = time.time() - VERROU.stat().st_mtime
                return age < 300
        except OSError:
            pass
        return False


def relancer():
    """Relance la boucle, detachee, avec une redirection vers un fichier (pas un pipe :
    un pipe non lu finit par bloquer ou tuer le fils)."""
    out = RECH / "boucle_nuit_locale.out"
    err = RECH / "boucle_nuit_locale.out.err"
    with open(out, "ab") as fo, open(err, "ab") as fe:
        p = subprocess.Popen(
            [PYTHON, "-X", "utf8", "-u", str(BOUCLE)],
            cwd=str(RECH), stdout=fo, stderr=fe,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | 0x00000008)  # DETACHED_PROCESS
    log("BOUCLE RELANCEE (PID %d)" % p.pid)
    return p


def main():
    log("=" * 80)
    log("SUPERVISEUR DEMARRE")
    log("  plage : 12h00 -> 03h00 | dort : 03h00 -> 12h00")
    log("  maintenant : %s -> %s" % (
        datetime.now().strftime("%H:%M"),
        "plage active" if dans_la_plage() else "hors plage"))
    log("=" * 80)

    relances = 0
    while True:
        if not dans_la_plage():
            attente = secondes_avant_reprise()
            log("HORS PLAGE (%s) : rien ne tourne, reprise a 12h00 dans %.1f h"
                % (datetime.now().strftime("%H:%M"), attente / 3600.0))
            while attente > 0 and not dans_la_plage():
                time.sleep(min(300, attente))
                attente = secondes_avant_reprise()
            if dans_la_plage():
                log("12h00 : reprise autorisee")
            continue

        if boucle_vivante():
            # on rafraichit le marqueur de fraicheur
            try:
                VERROU.write_text(datetime.now().isoformat(), encoding="utf-8")
            except OSError:
                pass
            time.sleep(60)
            continue

        # la boucle est morte et on a le droit de travailler
        relances += 1
        log("!! la boucle est MORTE (relance n°%d) -> on la relance" % relances)
        try:
            relancer()
        except Exception as e:
            log("   echec du relancement : %s" % e)
        time.sleep(30)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        log("superviseur interrompu")
