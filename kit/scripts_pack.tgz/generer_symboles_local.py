# -*- coding: utf-8 -*-
r"""generer_symboles_local.py -- generer les symboles personnalises depuis le CACHE PROFOND.

CORRECTIF MAJEUR (16/10, 02:05)
-------------------------------
La premiere version avait un BUG SILENCIEUX : elle croyait changer de marche en ecrivant
`Symbol=<marche>` dans l'ini. Or **`Symbol=` dans `[StartUp]` ne choisit QUE le symbole du
GRAPHIQUE**. Le marche SOURCE vient de l'input COMPILE `input string InpMarches = "XAUUSD"`.

Consequence MESUREE : le journal affichait
    === USA500.IDX : fenetre 2011.01.01 -> 2026.11.01 ===
    GEN_WIDE (USA500.IDX,M1)  barres PERIOD_M1 : 3367159 lues (XAUUSD) -> XAUUSD_C
    -> USA500.IDX : OK en 80s
c'est-a-dire **XAUUSD regenere a chaque fois, en annoncant un autre marche** : un faux succes.
Apres 15 minutes de boucle, le disque ne contenait QUE XAUUSD_C.

LE CORRECTIF
Pour chaque marche on ecrit une VARIANTE de la source avec :
  - `InpMarches = "<marche>"` (le marche SOURCE)
  - `InpDebut` / `InpFin`     (la fenetre propre a ce marche)
  - la ligne `#property script_show_inputs` SUPPRIMEE
    (la renommer => error 288 ; la commenter => error 109)
puis on la compile et on lance CE script. Un script par marche : aucune ambiguite possible.

LA VERIFICATION QUI MANQUAIT
On ne se contente plus de « FIN === ». On relit le journal et on exige la ligne
    barres PERIOD_M1 : N lues (<MARCHE>)
avec LE marche demande. Un succes annonce sans cette ligne est un ECHEC.
"""
import re
import subprocess
import sys
import time
from pathlib import Path

D = Path(r"C:\EAFarm\MT5\HCCLAB")            # LE laboratoire depuis la fusion du 16/10
SCRIPTS = D / "MQL5" / "Scripts"
CONFIG = D / "config"
MLOG = D / "MQL5" / "logs"
SOURCE = Path(r"C:\EAFarm\HISTORY - Copy\research\csym\gabarits\GEN_GBRIDX.mq5")
RAPPORT = Path(r"C:\EAFarm\HISTORY - Copy\research\generation_locale.log")

# Les 6 marches dont le cache source porte 2026 mais dont le _C s'arrete au 31/12/2025
# (mesure du 16/10, INVENTAIRE_SYMBOLES.md §3.3.1). EURUSD en est EXCLU : sa source 2026
# est vide (252 barres).
MARCHES = [
    ("AUDUSD",     "1993.01.01"),
    ("USA500.IDX", "2011.01.01"),
    ("XAGUSD",     "2008.01.01"),
    ("DEU.IDX",    "2013.01.01"),
    ("EUS.IDX",    "2014.01.01"),
    ("FRA.IDX",    "2020.06.01"),
]
FIN = "2026.11.01"


def log(msg):
    ligne = "[%s] %s" % (time.strftime("%H:%M:%S"), msg)
    print(ligne, flush=True)
    RAPPORT.parent.mkdir(parents=True, exist_ok=True)
    with open(RAPPORT, "a", encoding="utf-8") as fh:
        fh.write(ligne + "\n")


def nom_script(marche):
    return "GEN_" + re.sub(r"[^A-Za-z0-9_]", "_", marche)


def dans_la_plage(t=None):
    h = (t or time.localtime()).tm_hour
    return h >= 12 or h < 3


def fabriquer_et_compiler(marche, debut):
    nom = nom_script(marche)
    src = SOURCE.read_text(encoding="utf-8", errors="replace")
    src = re.sub(r'(input\s+string\s+InpMarches\s*=\s*)"[^"]*"', r'\1"%s"' % marche, src)
    src = re.sub(r'(input\s+string\s+InpDebut\s*=\s*)"[^"]*"',   r'\1"%s"' % debut, src)
    src = re.sub(r'(input\s+string\s+InpFin\s*=\s*)"[^"]*"',     r'\1"%s"' % FIN, src)
    src = "\n".join(l for l in src.splitlines() if "script_show_inputs" not in l)

    cible = SCRIPTS / (nom + ".mq5")
    cible.write_text(src, encoding="utf-8")

    m = re.search(r'InpMarches\s*=\s*"([^"]*)"', src)
    if not m or m.group(1) != marche:
        log("   !! le marche ecrit ne correspond pas a %s" % marche)
        return None
    log("   variante %s : marche SOURCE = %s" % (nom, m.group(1)))

    ex5 = SCRIPTS / (nom + ".ex5")
    try:
        ex5.unlink()
    except OSError:
        pass
    subprocess.run([str(D / "MetaEditor64.exe"),
                    "/compile:MQL5\\Scripts\\%s.mq5" % nom,
                    "/log:MQL5\\Scripts\\%s.log" % nom],
                   cwd=str(D), capture_output=True)
    time.sleep(6)
    jl = SCRIPTS / (nom + ".log")
    if jl.exists():
        for ligne in jl.read_bytes().decode("utf-16-le", errors="replace").splitlines():
            if "error" in ligne.lower() or "Result" in ligne:
                log("     compile : %s" % ligne.strip()[:130])
    if not ex5.exists():
        log("   !! COMPILATION ECHOUEE : pas de %s.ex5" % nom)
        return None
    return nom


def lire_resultat(marche, depuis):
    """Le journal nomme-t-il BIEN ce marche ? C'est la verification qui manquait."""
    lues = verif = None
    for f in sorted(MLOG.glob("*.log")):
        try:
            if f.stat().st_mtime < depuis - 5:
                continue
            txt = f.read_bytes().decode("utf-16-le", errors="replace")
        except OSError:
            continue
        for ligne in txt.splitlines():
            m = re.search(r"barres PERIOD_M1\s*:\s*(\d+)\s*lues\s*\(([^)]+)\)", ligne)
            if m and m.group(2).strip() == marche:
                lues = int(m.group(1))
            m2 = re.search(r"VERIF %s_C PERIOD_M1\s*:\s*(\d+) barres, ([^|]+)"
                           % re.escape(marche), ligne)
            if m2:
                verif = (int(m2.group(1)), m2.group(2).strip())
    return lues, verif


def generer(marche, debut, timeout=3600):
    log("=== %s : fenetre %s -> %s ===" % (marche, debut, FIN))
    nom = fabriquer_et_compiler(marche, debut)
    if not nom:
        return False

    ini = CONFIG / ("gen_%s.ini" % re.sub(r"[^A-Za-z0-9_]", "_", marche))
    ini.write_text(
        "[Common]\nLogin=798154993\nPassword=x\nServer=Dukascopy-demo-mt5-1\n"
        "[StartUp]\nScript=%s\nSymbol=%s\nPeriod=M1\n" % (nom, marche), encoding="utf-8")

    MLOG.mkdir(parents=True, exist_ok=True)
    for f in MLOG.glob("*.log"):
        try:
            f.unlink()
        except OSError:
            pass
    t0 = time.time()

    p = subprocess.Popen([str(D / "terminal64.exe"), "/portable",
                          "/config:config\\%s" % ini.name],
                         cwd=str(D), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    fini = False
    while time.time() - t0 < timeout:
        time.sleep(10)
        for f in MLOG.glob("*.log"):
            try:
                if f.stat().st_mtime < t0:
                    continue
                if "FIN ===" in f.read_bytes().decode("utf-16-le", errors="replace"):
                    fini = True
                    break
            except OSError:
                continue
        if fini:
            break
        if p.poll() is not None and time.time() - t0 > 90:
            break
    duree = int(time.time() - t0)

    # ARRET PROPRE (sinon le symbole n'est pas ecrit sur disque)
    subprocess.run(["taskkill", "/IM", "terminal64.exe"], capture_output=True)
    time.sleep(12)

    lues, verif = lire_resultat(marche, t0)
    if lues:
        log("   barres M1 lues depuis %s : %s" % (marche, format(lues, ",")))
    else:
        log("   !! AUCUNE ligne 'barres PERIOD_M1 ... (%s)' -- ce marche n'a PAS ete traite" % marche)
    if verif:
        log("   VERIF %s_C : %s barres, %s" % (marche, format(verif[0], ","), verif[1]))
    ok = bool(lues) and fini
    log("   -> %s : %s en %ss" % (marche, "OK" if ok else "ECHEC", duree))
    return ok


def derniere_annee(marche):
    """(derniere annee REELLE, barres estimees) — un .hcc de vraie annee pese > 1 Mo.

    PIEGE MESURE (16/10) : les 6 marches en retard ont un `2026.hcc` VIDE de 15 Ko
    contre 20 Mo pour une vraie annee. Se fier au nom du fichier ferait sauter la
    regeneration exactement comme l'ancien bug.
    """
    d = D / "bases" / "Custom" / "history" / (marche + "_C")
    if not d.exists():
        return None, 0
    fichiers = sorted(d.glob("*.hcc"), key=lambda f: f.stem)
    for f in reversed(fichiers):
        if f.stat().st_size > 1024 * 1024:
            return int(f.stem[:4]), int(f.stat().st_size // 60)
    return None, 0


def source_ok(marche):
    """Le cache source du labo porte-t-il une vraie annee FIN ? (piege du 16/10 :
    HCCLAB avait un 2026.hcc VIDE pour 4 marches -> generation -> coquille vide
    -> fausse couverture). Exige > 1 Mo sur le fichier source de l'annee cible."""
    f = D / "bases" / "Dukascopy-demo-mt5-1" / "history" / marche / ("%d.hcc" % int(FIN[:4]))
    if not f.exists():
        return False, "absent du cache source du labo"
    if f.stat().st_size < 1024 * 1024:
        return False, "VIDE (%d octets) dans le cache source du labo" % f.stat().st_size
    return True, "%.1f Mo" % (f.stat().st_size / 1048576)


def main():
    if not SOURCE.exists():
        log("!! source absente : %s" % SOURCE)
        return 1
    force = "--force" in sys.argv
    if force:
        log("=== REGENERATION FORCEE demandee (--force) ===")
    log("=== GENERATION LOCALE DEPUIS LE CACHE PROFOND (labo %s) ===" % D.name)
    ok = 0
    for marche, debut in MARCHES:
        d = D / "bases" / "Custom" / "history" / (marche + "_C")
        n = 0
        if d.exists():
            n = sum(int(f.stat().st_size // 60) for f in d.glob("*.hcc"))
        der, der_barres = derniere_annee(marche)
        cible = int(FIN[:4])                    # 2026 : l'annee qui doit EXISTRE et PESER
        if not force and der is not None and der >= cible:
            log("  %s : couvert jusqu'en %d (%s barres au total, %s en %d) -- on saute"
                % (marche, der, format(n, ","), format(der_barres, ","), der))
            ok += 1
            continue
        if der is not None and der < cible:
            log("  %s : derniere annee REELLE %d (%s barres) < %d -> regeneration"
                % (marche, der, format(der_barres, ","), cible))
        if not dans_la_plage():
            log("  %s : hors plage horaire (03h-12h) -- on s'arrete" % marche)
            break
        ok_src, pourquoi = source_ok(marche)
        if not ok_src and not force:
            log("  %s : SOURCE SANS %s (%s) -- generation inutile, on saute"
                % (marche, FIN[:4], pourquoi))
            continue
        if not ok_src and force:
            log("  %s : !! source sans %s (%s) -- --force impose, on tente quand meme"
                % (marche, FIN[:4], pourquoi))
        try:
            if generer(marche, debut):
                ok += 1
        except Exception as e:
            log("  !! %s : %s" % (marche, e))
    log("=== BILAN : %d / %d marche(s) ===" % (ok, len(MARCHES)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
