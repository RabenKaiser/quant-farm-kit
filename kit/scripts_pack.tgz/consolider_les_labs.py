# -*- coding: utf-8 -*-
r"""consolider_les_labs.py -- UN SEUL laboratoire avec les 23 symboles.

LE PROBLEME MESURE
Deux laboratoires complementaires, aucun complet :
  HCCLAB   14 symboles, 14,0 Go, definition 8192 o   <- les 14 d'origine (10 ans chacun)
  CSYMLAB   9 symboles REELLEMENT nouveaux (6-7 ans) + 13 coquilles VIDES (1 annee, M1=0)
           definition 12288 o
Et `symbols.custom.dat` est **portable mais INERTE sans les .hcc** : une definition sans donnees
ne sert a rien. Il faut donc **les donnees des deux, sous UNE SEULE definition**.

CE QUE FAIT CE SCRIPT
 1. inventorie les deux labos et n'accepte de copier que les symboles dont les donnees sont
    REELLES (plus d'un fichier d'annee, ou une seule annee non vide de plusieurs Mo) ;
 2. copie ces symboles dans HCCLAB (le labo qui a le plus de donnees), en **ne dupliquant pas**
    ceux qui y sont deja plus complets (on CALCULE l'espace necessaire avant de copier) ;
 3. copie la definition de CSYMLAB **par-dessus** celle de HCCLAB seulement si elle est plus
    riche (12288 o > 8192 o) — sinon on garde celle de HCCLAB ;
 4. VERIFIE l'espace libre AVANT et PENDANT (l'instance est morte d'une saturation disque ;
    on ne refait pas l'erreur).
"""
import shutil
import sys
from pathlib import Path

HCC = Path(r"C:\EAFarm\MT5\HCCLAB")
CSY = Path(r"C:\EAFarm\MT5\CSYMLAB")
SEUIL_MO = 20          # un symbole "reel" pese au moins ca


def taille(d):
    return sum(f.stat().st_size for f in d.rglob("*") if f.is_file())


def symboles_reels(lab):
    """{nom: (octets, nb_annees)} pour les symboles dont les donnees ne sont pas vides."""
    out = {}
    h = lab / "bases" / "Custom" / "history"
    if not h.exists():
        return out
    for d in sorted(h.glob("*_C")):
        hcc = list(d.glob("*.hcc"))
        o = sum(f.stat().st_size for f in hcc)
        if o >= SEUIL_MO * 1024 * 1024:
            out[d.name] = (o, len(hcc))
    return out


def libre_go():
    return shutil.disk_usage("C:\\").free / (1024 ** 3)


def main():
    print("=== 1. INVENTAIRE ===")
    a = symboles_reels(HCC)
    b = symboles_reels(CSY)
    print("  HCCLAB  : %d symboles reels" % len(a))
    print("  CSYMLAB : %d symboles reels" % len(b))
    print("  disque libre : %.2f Go" % libre_go())

    # ceux a copier : reels dans CSYMLAB et absents ou plus petits dans HCCLAB
    a_copier = []
    for nom, (o, n) in sorted(b.items()):
        if nom not in a:
            a_copier.append((nom, o, n, "absent de HCCLAB"))
        elif o > a[nom][0] * 1.2:
            a_copier.append((nom, o, n, "plus gros que dans HCCLAB"))
        # sinon : HCCLAB a deja mieux -> on ne copie pas

    print()
    print("=== 2. A COPIER (donnees reelles, non redondantes) ===")
    besoin = 0
    for nom, o, n, pourquoi in a_copier:
        print("  %-16s %6.0f Mo  %d annee(s)  (%s)" % (nom, o / 1048576, n, pourquoi))
        besoin += o
    print("  besoin total : %.2f Go" % (besoin / (1024 ** 3)))

    if besoin / (1024 ** 3) > libre_go() - 1.0:
        print()
        print("  !! PAS ASSEZ DE PLACE (il faut garder ~1 Go de marge)")
        print("     -> on ne copie RIEN. Liberer d'abord (cf. section 4).")
        return 1

    print()
    print("=== 3. COPIE ===")
    dest_h = HCC / "bases" / "Custom" / "history"
    dest_h.mkdir(parents=True, exist_ok=True)
    faits = []
    for nom, o, n, _ in a_copier:
        src = CSY / "bases" / "Custom" / "history" / nom
        dst = dest_h / nom
        if dst.exists():
            # on remplace : la version de CSYMLAB est plus grosse
            shutil.rmtree(dst, ignore_errors=True)
        try:
            shutil.copytree(src, dst)
            faits.append(nom)
            print("  %-16s copie  (libre : %.2f Go)" % (nom, libre_go()))
        except Exception as e:
            print("  !! %s : %s" % (nom, e))

    print()
    print("=== 4. LA DEFINITION ===")
    dh, ds = HCC / "bases" / "symbols.custom.dat", CSY / "bases" / "symbols.custom.dat"
    if dh.exists() and ds.exists():
        if ds.stat().st_size > dh.stat().st_size:
            shutil.copy2(ds, dh)
            print("  definition de CSYMLAB copiee (plus riche : %d > %d o)"
                  % (ds.stat().st_size, dh.stat().st_size))
        else:
            print("  definition de HCCLAB conservee (%d o >= %d o)"
                  % (dh.stat().st_size, ds.stat().st_size))
    elif ds.exists() and not dh.exists():
        shutil.copy2(ds, dh)
        print("  definition de CSYMLAB copiee")

    print()
    print("=== 5. ETAT FINAL DE HCCLAB ===")
    fin = symboles_reels(HCC)
    print("  %d symboles reels" % len(fin))
    for nom, (o, n) in sorted(fin.items()):
        print("    %-16s %6.0f Mo  %d annee(s)" % (nom, o / 1048576, n))
    print("  disque libre : %.2f Go" % libre_go())
    return 0


if __name__ == "__main__":
    sys.exit(main())
