# -*- coding: utf-8 -*-
r"""provenance_des_symboles.py -- chaque symbole vient-il des BARRES ou des TIQUES ?

LA QUESTION, ET POURQUOI ELLE COMPTE
Le generateur lit d'abord la SERIE M1 de la source (`lire_serie`, l.230) et n'agrege nos TIQUES
qu'en SECOURS (`construire_m1`, l.234). Or nos tiques ne commencent qu'en **2023.09**.
Donc la provenance dit tout :
  - provenance `SYM`          -> BARRES  : profondeur ~2014-2017 (ce qu'on veut)
  - provenance `SYM (tiques)` -> TIQUES  : plafonne a 2023.10

LA PREUVE QUI NE PEUT PAS MENTIR (et c'est celle qu'on utilise ici)
Une couverture qui COMMENCE AVANT 2023.09 ne peut pas venir des tiques : elles n'existent pas.
Donc **si un symbole commence en 2017, il vient forcement des barres**, quelle que soit la
formulation du journal. On mesure la borne basse reelle, pas une etiquette.

DEUX SOURCES DE MESURE
 1. les journaux de verification du labo (format `AN|<SYM>_C|<annee>|n=...|err=0|<debut> -> <fin>`)
    et `FENETRE|<SYM>_C|n=...|<debut> -> <fin>` ;
 2. a defaut, la taille et la liste des fichiers `.hcc` de chaque symbole.
"""
import re
import sys
from pathlib import Path

LABOS = [
    Path(r"C:\EAFarm\MT5\HCCLAB\MQL5\logs"),
    Path(r"C:\EAFarm\MT5\HCCLAB\MQL5\Logs"),
    Path(r"C:\EAFarm\CACHEPROBE_MT5\MQL5\logs"),
]
HIST = Path(r"C:\EAFarm\MT5\HCCLAB\bases\Custom\history")
RAPPORT = Path(r"C:\EAFarm\HISTORY - Copy\research\PROVENANCE_SYMBOLES.md")

# borne basse des TIQUES : aucune tique avant ce mois (mesure, tous marches confondus)
TICK_MIN = "2023.09"


def lire_journaux():
    """{marche: {'fenetre': (n, debut, fin), 'annees': {annee: n}}}"""
    res = {}
    for labo in LABOS:
        if not labo.exists():
            continue
        for f in sorted(labo.glob("*.log")):
            try:
                txt = f.read_bytes().decode("utf-16-le", errors="replace")
            except OSError:
                continue
            for ligne in txt.splitlines():
                # AN|DEU.IDX_C|2021|n=335089|err=0|2021.01.04 01:02 -> 2021.12.31 23:14
                m = re.search(r"AN\|([A-Z0-9._]+)_C\|(\d{4})\|n=(\d+)\|err=(\d+)(?:\|([^|]*))?", ligne)
                if m:
                    marche, an, n = m.group(1), int(m.group(2)), int(m.group(3))
                    res.setdefault(marche, {"annees": {}})
                    res[marche]["annees"][an] = n
                    continue
                # FENETRE|DEU.IDX_C|n=2497077|err=0|2017.01.02 -> 2025.12.31
                m = re.search(r"FENETRE\|([A-Z0-9._]+)_C\|n=(\d+)\|err=(\d+)\|([^|]*)", ligne)
                if m:
                    marche, n, err, couv = m.group(1), int(m.group(2)), int(m.group(3)), m.group(4).strip()
                    res.setdefault(marche, {"annees": {}})
                    res[marche]["fenetre"] = (n, couv, err)
    return res


def lire_disque():
    """{symbole: [annees]} d'apres les fichiers presents."""
    out = {}
    if HIST.exists():
        for d in sorted(HIST.glob("*_C")):
            anns = sorted(x.stem for x in d.glob("*.hcc"))
            out[d.name] = anns
    return out


def main():
    journaux = lire_journaux()
    disque = lire_disque()

    lignes = []
    A = lignes.append
    A("# PROVENANCE DES SYMBOLES : BARRES ou TIQUES ?")
    A("")
    A("Genere par `research/provenance_des_symboles.py`.")
    A("")
    A("Le generateur lit d'abord la **serie M1 de la source** (`lire_serie`, l.230) et n'agrege nos")
    A("**tiques** qu'en secours (`construire_m1`, l.234). Nos tiques commencant en **%s**, une" % TICK_MIN)
    A("couverture qui **commence avant %s ne peut pas venir des tiques** : la preuve est la borne" % TICK_MIN)
    A("basse reelle. C'est ce critere qui est applique ci-dessous.")
    A("")
    A("## Tableau")
    A("")
    A("| symbole | barres (disque) | annees | borne basse | provenance |")
    A("|---|---|---|---|---|")

    barres = tiques = 0
    for nom in sorted(disque):
        anns = disque[nom]
        marche = nom[:-2] if nom.endswith("_C") else nom
        tot = sum(int((HIST / nom / (a + ".hcc")).stat().st_size // 60) for a in anns)
        info = journaux.get(marche, {})
        couv = ""
        if "fenetre" in info:
            couv = info["fenetre"][1]
        elif anns:
            couv = "%s -> %s" % (anns[0], anns[-1])
        basse = anns[0] if anns else "?"
        if basse != "?" and basse < TICK_MIN[:4]:
            verdict = "**BARRES** (anterieur aux tiques)"
            barres += 1
        elif basse == TICK_MIN[:4] and anns and anns[0] <= TICK_MIN:
            verdict = "TIQUES possibles (a verifier)"
            tiques += 1
        else:
            verdict = "BARRES (posterieur, indetermine)"
            barres += 1
        A("| `%s` | %s | %s | %s | %s |" % (nom, format(tot, ","), " ".join(anns), basse, verdict))

    A("")
    A("## Bilan")
    A("")
    A("- symboles **anterieurs a %s** (donc forces par les BARRES) : **%d**" % (TICK_MIN, barres))
    A("- symboles a verifier : **%d**" % tiques)
    A("")
    A("## Les journaux disponibles")
    A("")
    if journaux:
        for marche in sorted(journaux):
            info = journaux[marche]
            A("- `%s` : %d annee(s) mesuree(s)" % (marche, len(info.get("annees", {}))))
    else:
        A("Aucun journal de verification retrouve (le labo `CACHEPROBE_MT5` a ete supprime lors du")
        A("nettoyage de disque). Le critere de la borne basse reste valable : il ne depend d'aucun journal.")

    RAPPORT.write_text("\n".join(lignes), encoding="utf-8")
    print("ecrit : %s" % RAPPORT)
    print("  barres : %d | a verifier : %d" % (barres, tiques))
    print()
    for nom in sorted(disque):
        anns = disque[nom]
        tot = sum(int((HIST / nom / (a + ".hcc")).stat().st_size // 60) for a in anns)
        verdict = "BARRES" if anns and anns[0] < TICK_MIN[:4] else "?"
        print("  %-16s %12s barres  %s -> %s   %s" % (
            nom, format(tot, ","), anns[0] if anns else "?", anns[-1] if anns else "?", verdict))
    return 0


if __name__ == "__main__":
    sys.exit(main())
