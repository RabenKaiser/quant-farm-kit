# -*- coding: utf-8 -*-
r"""boucle_nuit_locale.py -- LA BOUCLE DE NUIT, LOCALE, AVEC LA PLAGE HORAIRE DEMANDEE.

CONSIGNE DE L'UTILISATEUR (16/10)
  « have the loop running before 03h like always and go to bed ... don't run between 03h and 12h »
  => la boucle travaille de MAINTENANT jusqu'a 03:00, puis SE TAIT de 03:00 a 12:00.

CE QU'ELLE FAIT, DANS L'ORDRE
  1. GENERER les symboles personnalises des marches cables (cache profond, hors ligne).
     Mesure : XAUUSD a rendu 3 367 159 barres M1 sur 2017.03 -> 2026.10 en 90 secondes.
     Reste : XAGUSD (2008+), EURUSD (1996+), JPN.IDX (2011+), USA500.IDX (2011+),
             HKG.IDX (2013+), DEU.IDX (2013+).
  2. PASSER LA PORTE DES DEUX MOITIES sur les resultats (gate_demi) et journaliser.
  3. Tenir le JOURNAL de ce qui a ete fait, pour la reprise a 12:00.

GARDE-FOU HORAIRE (le coeur de la demande)
  La fonction `dans_la_plage()` refuse de travailler entre 03:00 et 12:00. Elle est testee a
  CHAQUE tour de boucle, pas seulement au demarrage — sinon une boucle qui tourne encore a
  03:00 continuerait a travailler.
"""
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

RECH = Path(r"C:\EAFarm\HISTORY - Copy\research")
sys.path.insert(0, str(RECH))

JOURNAL = RECH / "boucle_nuit_locale.log"
HEURE_STOP = 3      # 03h00 : on s'arrete
HEURE_REPRISE = 12  # 12h00 : on reprend


def log(msg):
    ligne = "[%s] %s" % (datetime.now().strftime("%d/%m %H:%M:%S"), msg)
    print(ligne, flush=True)
    with open(JOURNAL, "a", encoding="utf-8") as fh:
        fh.write(ligne + "\n")


def dans_la_plage(maintenant=None):
    """True si on a le DROIT de travailler.

    Plage autorisee : de 12h00 a 03h00 (le lendemain). Interdite : 03h00 -> 12h00.
    C'est-a-dire : on travaille si l'heure est >= 12 OU < 3.
    """
    h = (maintenant or datetime.now()).hour
    return h >= HEURE_REPRISE or h < HEURE_STOP


def secondes_avant_reprise(maintenant=None):
    m = maintenant or datetime.now()
    cible = m.replace(hour=HEURE_REPRISE, minute=0, second=0, microsecond=0)
    if cible <= m:
        cible += timedelta(days=1)
    return int((cible - m).total_seconds())


def generer_tous_les_marches():
    """Genere les marches qui ont un cache profond cable et pas encore de symbole."""
    import generer_symboles_local as G
    faits = []
    for marche, debut in G.MARCHES:
        if debut is None:
            continue
        # deja genere ? (on regarde le dossier du symbole)
        d = Path(r"C:\EAFarm\CACHEPROBE_MT5\bases\Custom\history") / (marche + "_C")
        if d.exists() and any(d.glob("*.hcc")):
            log("  %s : deja genere, on saute" % marche)
            faits.append(marche)
            continue
        if not dans_la_plage():
            log("  %s : hors plage horaire, on s'arrete la" % marche)
            break
        try:
            if G.generer(marche, debut, timeout=2400):
                faits.append(marche)
        except Exception as e:
            log("  !! %s : %s" % (marche, e))
    return faits


def passer_la_porte():
    """Porte des deux moities : c'est elle qui dit si une jambe est valable."""
    g = RECH / "SCRIPTS" / "gate_demi.py"
    if not g.exists():
        log("  gate_demi.py introuvable -- porte non passee")
        return None
    try:
        r = subprocess.run([sys.executable, "-X", "utf8", str(g), "--panier", "--min", "40"],
                           cwd=str(RECH), capture_output=True, text=True, timeout=1800)
        for ligne in (r.stdout or "").splitlines():
            if "PANIER :" in ligne:
                log("  PORTE : %s" % ligne.strip())
                return ligne.strip()
        log("  porte : pas de ligne PANIER")
    except Exception as e:
        log("  !! porte : %s" % e)
    return None


def main():
    log("=" * 90)
    log("BOUCLE DE NUIT LOCALE -- demarrage")
    log("  plage autorisee : 12h00 -> 03h00 ; interdite : 03h00 -> 12h00")
    log("  maintenant : %s  -> %s" % (
        datetime.now().strftime("%d/%m %H:%M"),
        "DANS la plage (on travaille)" if dans_la_plage() else "HORS plage (on attend)"))
    log("=" * 90)

    tour = 0
    while True:
        if not dans_la_plage():
            attente = secondes_avant_reprise()
            log("HORS PLAGE : il est %s. Prochaine reprise a %02dh00, dans %.1f h. On dort." % (
                datetime.now().strftime("%H:%M"), HEURE_REPRISE, attente / 3600.0))
            # on dort par tranches de 10 min pour rester reactif et pour que le journal vive
            while attente > 0:
                time.sleep(min(600, attente))
                attente = secondes_avant_reprise()
                if dans_la_plage():
                    log("REPRISE : il est %s, on repart." % datetime.now().strftime("%H:%M"))
                    break
            continue

        tour += 1
        log("-" * 90)
        log("TOUR %d  (%s)" % (tour, datetime.now().strftime("%H:%M:%S")))

        # 1. generer les symboles manquants
        log("1. generation des symboles personnalises depuis le cache profond")
        faits = generer_tous_les_marches()
        log("   marches avec symbole : %d (%s)" % (len(faits), ", ".join(faits)))

        # 2. la porte des deux moities
        log("2. porte des deux moities")
        passer_la_porte()

        # 3. journal
        log("3. tour termine. Prochain tour dans 15 minutes (ou arret a 03h00).")
        for _ in range(90):          # 90 x 10 s = 15 min, mais on reverifie la plage
            time.sleep(10)
            if not dans_la_plage():
                break

        if not dans_la_plage():
            log("03h00 atteint : la boucle se met en sommeil jusqu'a 12h00.")
            continue


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        log("interrompu par l'utilisateur")
