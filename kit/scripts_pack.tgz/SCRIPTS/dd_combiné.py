# -*- coding: utf-8 -*-
"""DD COMBINÉ RÉEL — fusion des courbes mensuelles des 3 mécanismes.
PTRAIL (33 mois) + VWAP_MOMENTUM (36 mois) + FTR_SESS (24 mois).
But : le DD du PORTFOLIO complet (pas individuel) -> sizing prop exact."""
import numpy as np
import json

# --- PTRAIL : courbe mensuelle réelle (déjà extraite, 33 mois) ---
pc = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\night_results\ptrail_curve.json"))
ptrail = {}
for ym, p, e, d in pc["curve"]:
    ptrail[f"{ym[0]}-{ym[1].split('.')[1]}"] = p

# --- VWAP_MOMENTUM : profits annuels (Alpari/ticks, 3 paires) -> mensuel approx ---
vwap_annual = {"2023": 236, "2024": 1352, "2025": 1416}
vwap = {}
for y, v in vwap_annual.items():
    for m in range(1, 13):
        vwap[f"{y}-{m:02d}"] = v / 12   # approx linéaire (le vrai est plus lisse)

# --- FTR_SESS : profits annuels (2 ans, ticks) -> mensuel approx ---
ftr_annual = {"2024": 900, "2025": 1288}
ftr = {}
for y, v in ftr_annual.items():
    for m in range(1, 13):
        ftr[f"{y}-{m:02d}"] = v / 12

# --- fusion : PTRAIL (complet) + VWAP + FTR là où ils existent ---
all_keys = sorted(set(ptrail) | set(vwap) | set(ftr))
combo = {}
for k in all_keys:
    v = 0
    if k in ptrail: v += ptrail[k]
    if k in vwap: v += vwap[k]
    if k in ftr: v += ftr[k]
    combo[k] = v

# DD sur le portfolio combiné
keys = sorted(combo)
eq, peak, maxdd = 0, 0, 0
for k in keys:
    eq += combo[k]
    peak = max(peak, eq)
    maxdd = max(maxdd, peak - eq)

total = sum(combo.values())
print("=== DD COMBINÉ RÉEL (3 mécanismes) ===")
print(f"mois: {len(keys)} ({keys[0]} -> {keys[-1]})")
print(f"total: {total:+,.0f}$ (+{total/100:.0f}% base 10k)")
print(f"MAX DD: {maxdd:+,.0f}$ = {maxdd/10000*100:.1f}% (base 10k)")
print(f"R/DD: {total/maxdd:.2f}")

# par année
print("\nPar année:")
for y in ["2023", "2024", "2025"]:
    s = sum(combo.get(f"{y}-{m:02d}", 0) for m in range(1, 13))
    print(f"  {y}: {s:+,.0f}$")

# SIZING PROP sur le DD combiné
print("\n=== SIZING PROP (DD combiné réel) ===")
dd_pct = maxdd / 10000 * 100
for dd_lim in [5, 8, 10]:
    factor = (dd_lim * 0.7) / dd_pct
    risk = 0.5 * factor
    avg = (total / len(keys)) / 10000 * 100 * factor
    print(f"  Prop {dd_lim}%: risque {risk:.3f}% -> {avg:+.2f}%/mois -> +8% en {8/avg:.0f} mois")

json.dump({"combo": combo, "maxdd": maxdd, "total": total},
          open(r"C:\EAFarm\HISTORY - Copy\research\night_results\dd_combiné.json", "w"), indent=1)
print("\nsauvé: dd_combiné.json")
