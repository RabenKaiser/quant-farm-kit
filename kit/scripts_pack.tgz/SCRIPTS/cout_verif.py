import pandas as pd, numpy as np, sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
for p in ["EURUSD", "XAUUSD", "USDCAD", "EURJPY", "GBPJPY"]:
    try:
        d = pd.read_csv(r"C:\EAFarm\HISTORY - Copy\research\m1_pos\%s_M1.csv" % p,
                        usecols=["time", "high", "low", "close", "spread"])
    except Exception as e:
        print("%-8s absent (%s)" % (p, e)); continue
    d["t"] = pd.to_datetime(d["time"], unit="s", utc=True)
    b = d.set_index("t").resample("5min").agg(
        high=("high", "max"), low=("low", "min"),
        close=("close", "last"), sp=("spread", "median")).dropna()
    tr = pd.concat([b.high - b.low, (b.high - b.close.shift()).abs(),
                    (b.low - b.close.shift()).abs()], axis=1).max(axis=1)
    b["atr"] = tr.rolling(14).mean()
    b = b.dropna()
    sp = float(np.median(b.sp)); atr = float(np.median(b.atr))
    print("%-8s spread %9.5f | ATR(M5) %9.5f | prix %9.2f | spread/ATR %7.2f %% | barres %d"
          % (p, sp, atr, float(np.median(b.close)), 100.0 * sp / atr, len(b)))
