import sys, datetime as _dt
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
import numpy as np
import polars as pl
from edge_correct import load_m1, to_tf, backtest_m1_ptrail, COMMISSION_RT, TICK_VALUE_PER_PT
import deep_signals as DS

def E(d):
    return int(_dt.datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=_dt.timezone.utc).timestamp())

OOS = (E("2023-01-01"), E("2024-01-01"))
CFG = {"slippage_pts": 0.5, "htf_sec": 14400, "lookback": 40, "sl_atr": 1.5, "rr": 99,
       "trail_atr_mult": 3.5, "trail_trigger_r": 1.0, "pyramid_max": 2, "pyramid_trigger_r": 1.5}


def audit(sym, tf_sec):
    m1 = load_m1(sym)
    tf = to_tf(m1, tf_sec)
    c = dict(CFG, commission_rt=COMMISSION_RT[sym], tick_value_per_pt=TICK_VALUE_PER_PT[sym])
    m1o = m1.filter((pl.col("time") >= OOS[0]) & (pl.col("time") < OOS[1]))
    tfo = tf.filter((pl.col("time") >= OOS[0]) & (pl.col("time") < OOS[1]))
    f = DS.REGISTRY["htf_nest"](tfo, c)
    tr = backtest_m1_ptrail(m1o, tfo, f, sym, c)
    res = pl.DataFrame(tr).with_columns((pl.col("r") - pl.col("cost_r")).alias("net"))
    net = res["net"].to_numpy(); n = len(res)
    top5 = np.sort(net)[-5:]
    no5 = (net.sum() - top5.sum()) / (n - 5) if n > 5 else 0.0
    cum = np.cumsum(net); maxdd = float((cum - np.maximum.accumulate(cum)).min())
    res = res.with_columns((pl.col("entry_ts") // 86400 * 86400 * 1000).cast(pl.Datetime("ms")).dt.strftime("%Y-%m").alias("ym"))
    g = res.group_by("ym").agg(pl.col("net").sum().alias("R")).sort("ym")
    months = [(r["ym"], round(float(r["R"]), 1)) for r in g.to_dicts()]
    # Dec = mois du crash BoJ
    dec = next((r for _, r in months if _.startswith("2023-12")), 0.0)
    base = sum(r for _, r in months) - dec
    pos = sum(1 for _, r in months if r > 0)
    print(f"[{sym} M{tf_sec//60:2d}] n={n:3d} netR/tr={net.mean():+.3f} top5-out={no5:+.3f} "
          f"maxDD={maxdd:.1f}R pos={pos}/{len(months)} | Dec={dec:.1f}R | hors-Dec={base/10:.1f}/mois")
    print(f"      {months}")


print("=== htf_nest_ptrail M30 leader (lb40 sl1.5 trail3.5 pyr2 trig1.5) — OOS 2023 ===")
for tf in [3600, 1800, 900]:
    audit("USDJPY", tf)
