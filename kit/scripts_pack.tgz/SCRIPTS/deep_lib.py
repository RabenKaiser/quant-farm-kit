# -*- coding: utf-8 -*-
"""deep_lib.py — MOTEUR DE SORTIE ETENDU (trailing SL, breakeven, partiels).

Vectorise le trailing via np.maximum.accumulate sur la fenetre M1 du trade :
  - niveau de stop connu AU DEBUT de la barre k  (donc construit sur les barres < k)
  - => 100% causal, aucun look-ahead intra-barre
  - tie-break SL/TP DANS LA MEME BARRE = PESSIMISTE (le SL gagne), contrairement
    au tie-break optimiste de giga_lib.run_trades (a verifier separement).

Variantes d'exit :
  be_r      : deplace le SL a l'entree des que +be_r*R est touche (barre suivante)
  trail_atr : SL = extreme courant -/+ trail_atr * ATR15 (trailing ATR classique)
  tp_r      : TP fixe (mettre tres grand pour un pur trailing)
"""
import numpy as np
import giga_lib as G


def run_ex(sym, sig_dir, sl_mult, tp_r, max_hold_bars,
           be_r=None, trail_atr=None, t0=None, t1=None, use_m1=True,
           sp_mult=1.0, slip_mult=0.1, collect=False):
    F = G.get_frames(sym)
    m5 = F["m5"]; n5 = len(m5); idx5 = m5.index
    ps = F["ps"]
    SP = F["sp_units"] * ps * sp_mult
    SLIP = ps * slip_mult            # R320 : en points REELS (ps/10 = 1 point)
    o5 = F["o5"]; c5 = F["c5"]; h5 = F["h5"]; l5 = F["l5"]; a15i = F["a15i"]
    m1h = F["m1h"]; m1l = F["m1l"]; m1c = F["m1c"]; n1 = len(m1c)
    m1_start = F["m1_start"]; m1_end = F["m1_end"]
    ep1 = F["ep1"]; ep5 = F["ep5"]

    sig = np.asarray(sig_dir)
    cand = np.nonzero(sig)[0]
    if len(cand) == 0:
        return G.stats([], [])
    if t0 is not None:
        cand = cand[idx5[np.minimum(cand + 1, n5 - 1)] >= t0]
    if t1 is not None:
        cand = cand[idx5[np.minimum(cand + 1, n5 - 1)] <= t1]

    rets = []; tse = []
    last_exit = -1
    for i in cand:
        if i + 1 >= n5 - 1:
            break
        b0 = m1_start[i + 1] if use_m1 else (i + 1)
        if b0 <= last_exit:
            continue
        a5 = a15i[i]
        if not np.isfinite(a5) or a5 <= 0:
            continue
        d = 1 if sig[i] > 0 else -1
        # R322 : pas de decalage d entree (il doublait le spread, cf giga_lib)
        entry = o5[i + 1]
        sl0 = entry - d * sl_mult * a5
        risk = abs(entry - sl0)
        if risk < 0.15 * a5 or risk > 12 * a5:
            continue
        tp = entry + d * tp_r * risk
        kend = min(i + 1 + max_hold_bars, n5 - 1)
        if use_m1:
            b1 = int(m1_end[kend]); H = m1h[b0:b1]; L = m1l[b0:b1]
        else:
            b1 = kend + 1; H = h5[b0:b1]; L = l5[b0:b1]
        if b1 <= b0:
            continue
        m = len(H)
        stop = np.full(m, sl0, dtype=np.float64)

        # --- TRAILING : niveau connu au debut de la barre k = extreme des barres < k
        if trail_atr is not None:
            if d == 1:
                run = np.maximum.accumulate(H)
            else:
                run = np.minimum.accumulate(L)
            sh = np.empty(m, dtype=np.float64)
            sh[0] = run[0]
            if m > 1:
                sh[1:] = run[:-1]
            if d == 1:
                stop = np.maximum(stop, sh - trail_atr * a5)
            else:
                stop = np.minimum(stop, sh + trail_atr * a5)
            # garde-fou : le trail ne peut pas depasser l'entree dans le mauvais sens
            if d == 1:
                stop = np.minimum(stop, tp)
            else:
                stop = np.maximum(stop, tp)

        # --- BREAKEVEN : actif a partir de la barre SUIVANT le trigger
        if be_r is not None:
            trg = entry + d * be_r * risk
            raw = (H >= trg) if d == 1 else (L <= trg)
            act = np.zeros(m, dtype=bool)
            if m > 1:
                act[1:] = raw[:-1]
            np.maximum.accumulate(act, out=act)
            if d == 1:
                stop = np.where(act, np.maximum(stop, entry), stop)
            else:
                stop = np.where(act, np.minimum(stop, entry), stop)

        if d == 1:
            hsl = L <= stop; htp = H >= tp
        else:
            hsl = H >= stop; htp = L <= tp
        any_sl = bool(hsl.any()); any_tp = bool(htp.any())
        k_sl = int(hsl.argmax()) if any_sl else 10 ** 9
        k_tp = int(htp.argmax()) if any_tp else 10 ** 9
        # PESSIMISTE : a egalite de barre, le SL est PRIORITAIRE
        if k_sl <= k_tp and k_sl < 10 ** 9:
            j = b0 + k_sl; px = float(stop[k_sl])
        elif k_tp < 10 ** 9:
            j = b0 + k_tp; px = tp
        else:
            j = b1 - 1
            px = float(m1c[min(j, n1 - 1)] if use_m1 else c5[min(j, n5 - 1)])
        cost = SP + 2 * SLIP
        rets.append(((px - entry) * d - cost) / risk)
        tse.append(int(ep1[min(j, n1 - 1)] if use_m1 else ep5[min(j, n5 - 1)]))
        last_exit = j
    st = G.stats(rets, tse)
    if collect:
        st["rets"] = rets
        st["tse"] = tse
    return st


def rex(sym, sig, ex, t0=None, t1=None, use_m1=False, sp_mult=1.0):
    """Raccourci : ex = dict(sl_mult, tp_r, max_hold, be_r, trail_atr)."""
    return run_ex(sym, sig, ex.get("sl_mult", 1.0), ex.get("tp_r", 2.0),
                  ex.get("max_hold", 48), be_r=ex.get("be_r"),
                  trail_atr=ex.get("trail_atr"), t0=t0, t1=t1,
                  use_m1=use_m1, sp_mult=sp_mult)
