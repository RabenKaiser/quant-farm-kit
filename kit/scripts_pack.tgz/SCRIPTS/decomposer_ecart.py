# -*- coding: utf-8 -*-
"""decomposer_ecart.py — D'OU VIENNENT LES -0.09 R D'EXECUTION ?

POURQUOI C'EST LE CHIFFRE QUI DECIDE DE TOUT (18/09, 11 h 15)
-----------------------------------------------------------
Mesures de la nuit :
  - le laboratoire, cotes symetrises, hors derive, vaut -0.0554 R ;
  - une entree ALEATOIRE avec la meme geometrie vaut -0.0069 R ;
  - et surtout : les VRAIS ORDRES valent -0.09 R de MOINS que le laboratoire,
    de facon uniforme (77 % des combinaisons comparees, ecart median -0.090).

Ce -0.09 R est 8 FOIS le spread theorique (sur EURUSD, le spread vaut 6.3 % de
l'ATR, or 1 R = 12 ATR, donc environ 0.011 R aller-retour). Une telle ampleur est
suspecte : soit c'est du glissement reel massif, soit une partie vient de la
facon dont les ordres reels ont ete passes (heure d'entree, sortie, swap).

TROIS HYPOTHESES, ET COMMENT LES DEPARTAGER
  H1 GLISSEMENT SUR LES STOPS. Si c'est la cause, l'ecart doit etre proportionnel
     au NOMBRE DE STOPS touches : les combinaisons qui se font stopper souvent
     doivent avoir un ecart plus grand.
  H2 COUT FIXE PAR TRANSACTION (spread elargi, swap, commission). Si c'est la
     cause, l'ecart doit etre le MEME pour toutes les combinaisons, quel que
     soit leur taux de stops.
  H3 ARTEFACT DE COMPARAISON (le labo et le reel ne mesurent pas la meme chose).
     Si c'est la cause, l'ecart doit dependre de la facon dont le R est
     normalise, donc du nombre de transactions et non du taux de stops.

CE QUE CE SCRIPT MESURE : l'ecart reel-labo par combinaison, sa correlation avec
le taux de stops (H1) et avec le nombre de transactions (H3), et sa dispersion
(H2).

USAGE : python decomposer_ecart.py [tag]
"""
import collections
import json
import statistics
import sys
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
FEN = {"2020", "2021", "2020.01", "2020.07", "2021.01", "2021.07",
       "2024Q1", "2024Q2", "2024Q3", "2024Q4", "2025Q1"}


def lignes(nom):
    p = BASE / nom
    if not p.exists():
        return
    for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
        if line.strip().startswith("{"):
            try:
                yield json.loads(line)
            except ValueError:
                continue


def main():
    tag = sys.argv[1] if len(sys.argv) > 1 else "top8"
    setf = (Path.home() / "AppData/Roaming/MetaQuotes/Terminal/Common/Files"
            / ("%s_set.txt" % tag))
    ids = {l.strip() for l in setf.read_text().splitlines() if "|" in l}

    # --- R du labo par combinaison, sur les fenetres reelles ------------
    lab = collections.defaultdict(lambda: [0.0, 0, 0.0, 0])
    for r in lignes("lab_results.jsonl"):
        if r["id"] not in ids or str(r.get("period", "")) not in FEN:
            continue
        if r["n"] < 3 or r.get("r_x54") is None:
            continue
        e = lab[r["id"]]
        e[0] += r["r_x54"] * r["n"]
        e[1] += r["n"]
        if r.get("stop_sl12") is not None:
            e[2] += r["stop_sl12"] * r["n"]
            e[3] += r["n"]
    labo = {k: (v[0] / v[1], v[2] / v[3] if v[3] else None, v[1])
            for k, v in lab.items() if v[1]}

    # --- R du reel par combinaison (les DEUX profils) -------------------
    pnl = collections.defaultdict(list)
    for prof in ("mt5", "farm"):
        for d in lignes("par_%s_%s_deals.jsonl" % (prof, tag)):
            if d.get("id") in ids:
                pnl[d["id"]].append(d["pnl"])
    reel = {}
    for cid, lst in pnl.items():
        pertes = [v for v in lst if v < 0]
        if len(pertes) < 5:
            continue
        r1 = -statistics.median(pertes)
        if r1 <= 0:
            continue
        reel[cid] = (sum(lst) / len(lst) / r1, len(lst))

    print("=" * 100)
    print("DECOMPOSITION DE L'ECART LABO/REEL — set %s" % tag)
    print("=" * 100)
    print("   %-34s %9s %9s %9s %8s %8s"
          % ("combinaison", "R labo", "R reel", "ecart", "stops %", "trades"))
    print("   " + "-" * 86)
    obs = []
    for cid in sorted(reel, key=lambda c: reel[c][0]):
        if cid not in labo:
            continue
        rl, st, nl = labo[cid]
        rr, nr = reel[cid]
        obs.append((cid, rl, rr, rr - rl, st, nr))
        print("   %-34s %+9.4f %+9.4f %+9.4f %8s %8d"
              % (cid[:34], rl, rr, rr - rl,
                 ("%.1f" % st) if st is not None else "-", nr))
    if len(obs) < 10:
        print("   trop peu de combinaisons comparables")
        return
    ecarts = [x[3] for x in obs]
    stops = [x[4] for x in obs if x[4] is not None]
    tks = [x[5] for x in obs]
    ec_s = [x[3] for x in obs if x[4] is not None]
    print()
    print("   %d combinaisons comparees" % len(obs))
    print("   ecart median : %+.4f   moyen : %+.4f   ecart-type : %.4f"
          % (statistics.median(ecarts), statistics.mean(ecarts),
             statistics.pstdev(ecarts)))
    print("   ecart relatif a sa moyenne : %.0f %%"
          % (100 * statistics.pstdev(ecarts) / abs(statistics.mean(ecarts))))

    def corr(a, b):
        if len(a) < 5:
            return 0.0
        ma, mb = statistics.mean(a), statistics.mean(b)
        num = sum((x - ma) * (y - mb) for x, y in zip(a, b))
        da = sum((x - ma) ** 2 for x in a) ** 0.5
        db = sum((y - mb) ** 2 for y in b) ** 0.5
        return num / (da * db) if da and db else 0.0

    c1 = corr(ec_s, stops)
    c3 = corr(ecarts, tks)
    print()
    print("   H1 GLISSEMENT SUR LES STOPS : correlation(ecart, taux de stops)")
    print("      = %+.3f" % c1)
    print("   H3 ARTEFACT DE NORMALISATION : correlation(ecart, nb transactions)")
    print("      = %+.3f" % c3)
    print()
    rel = statistics.pstdev(ecarts) / abs(statistics.mean(ecarts))
    if abs(c1) > 0.4 and abs(c1) > abs(c3):
        print("   >>> H1 : L'ECART SUIT LE TAUX DE STOPS. C'est du GLISSEMENT")
        print("       sur les stops. Il est donc en partie EVITABLE : des stops")
        print("       moins souvent touches (stop plus large, sortie plus proche)")
        print("       reduisent l'ecart.")
    elif abs(c3) > 0.4:
        print("   >>> H3 : l'ecart suit le NOMBRE DE TRANSACTIONS : c'est un")
        print("       cout par transaction, pas un probleme de signal.")
    elif rel < 0.5:
        print("   >>> H2 : L'ECART EST LE MEME POUR TOUTES LES COMBINAISONS")
        print("       (dispersion faible). C'est un COUT FIXE par transaction :")
        print("       spread elargi, swap, commission. Consequence : aucune")
        print("       selection de combinaisons ne peut le reduire -- seul le")
        print("       choix de l'instrument et de la duree de detention le peut.")
    else:
        print("   >>> AUCUNE HYPOTHESE NE DOMINE nettement (dispersion %.0f %%,"
              % (100 * rel))
        print("       correlations faibles). L'ecart est heterogene : a creuser")
        print("       combinaison par combinaison avant de conclure.")


if __name__ == "__main__":
    main()
