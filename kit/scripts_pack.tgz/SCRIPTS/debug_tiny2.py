# -*- coding: utf-8 -*-
"""debug_tiny2.py — print inside loop."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import c13v2_py_v3 as F
import pandas as pd

m1 = F.load_m1("EURUSD")
start = pd.Timestamp("2024-01-01", tz="UTC")
wu = start - pd.Timedelta(days=260)
m15 = F.resample(m1.loc[wu:start], "15min")
cfg = {"imp_atr": 0.9, "imp_vol": 1.0, "imp_look": 6}
bull, bear = F.detect_ob(m15, cfg, lookahead=False)
items = sorted(bull.items())
print("items[0]:", items[0] if items else None)
cur = None
bi = 0
for i15 in range(0, 40):
    entered = False
    while bi < len(items) and items[bi][0] <= i15:
        jj, (d, z, h2) = items[bi]
        if d <= i15:
            cur = (z, h2, jj)
        bi += 1
        entered = True
    if i15 in (14, 15, 16, 20):
        print(f"i15={i15} bi={bi} entered={entered} cur={cur}")
print("final:", cur)
