import sys, datetime as _dt
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
import numpy as np
import polars as pl
from edge_correct import load_m1, to_tf, backtest_m1, COMMISSION_RT, TICK_VALUE_PER_PT
import deep_signals as DS

def E(d):
    return int(_dt.datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=_dt.timezone.utc).timestamp())

OOS = (E("2023-01-01"), E("2024-01-01"))
FULL = (E("2022-01-01"), E("2024-01-01"))
CFG = {"slippage_pts": 0.5, "lookback": 10, "sl_atr": 0.5, "rr": 1.5}


def run(sym, tf_sec, lo, hi, label):
    m1 = load_m1(sym)
    tf = to_tf(m1, tf_sec)
    c = dict(CFG, commission_rt=COMMISSION_RT[sym], tick_value_per_pt=TICK_VALUE_PER_PT[sym])
    m1s = m1.filter((pl.col("time") >= lo) & (pl.col("time") < hi))
    tfs = tf.filter((pl.col("time") >= lo) & (pl.col("time") < hi))
    f = DS.REGISTRY["scalp_range"](tfs, c)
    tr = backtest_m1(m1s, tfs, f, sym, c)
    res = pl.DataFrame(tr).with_columns((pl.col("r") - pl.col("cost_r")).alias("net"))
    net = res["net"].to_numpy(); n = len(res)
    top5 = np.sort(net)[-5:]
    no5 = (net.sum() - top5.sum()) / (n - 5) if n > 5 else 0.0
    cum = np.cumsum(net); maxdd = float((cum - np.maximum.accumulate(cum)).min())
    res = res.with_columns((pl.col("entry_ts") // 86400 * 86400 * 1000).cast(pl.Datetime("ms")).dt.strftime("%Y-%m").alias("ym"))
    g = res.group_by("ym").agg(pl.col("net").sum().alias("R")).sort("ym")
    Rs = g["R"].to_numpy()
    pos = int((Rs > 0).sum())
    print(f"[{label} {sym} M{tf_sec//60:2d}] n={n:4d} netR/tr={net.mean():+.4f} top5-out={no5:+.4f} "
          f"avg/mois={Rs.mean():+.2f} med/mois={np.median(Rs):+.2f} maxDD={maxdd:+.1f}R pos={pos}/{len(Rs)}")
    return net.mean(), no5


print("=== scalp_range EURUSD H1 (lb10 sl0.5 rr1.5) ===")
# TF reproduction (OOS)
for tf in [3600, 1800, 900, 300]:
    run("EURUSD", tf, OOS[0], OOS[1], "OOS")
# full 2 years on H1
run("EURUSD", 3600, FULL[0], FULL[1], "FULL2Y")
# USDJPY same config (edge there too?)
for tf in [3600, 1800]:
    run("USDJPY", tf, OOS[0], OOS[1], "OOS")
