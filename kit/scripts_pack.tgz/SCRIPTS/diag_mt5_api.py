# -*- coding: utf-8 -*-
"""diag_mt5_api.py — pourquoi copy_rates renvoie 0 barre pour EURUSD ?"""
import sys, time, datetime as dt
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import MetaTrader5 as mt5

if not mt5.initialize(r"C:\EAFarm\MT5\Farm\terminal64.exe"):
    print("init KO", mt5.last_error()); sys.exit(1)
ti = mt5.terminal_info()
print(f"terminal: connected={ti.connected} trade_allowed={ti.trade_allowed} "
      f"ping={ti.ping_last}us build={ti.build}")
print(f"data_path: {ti.data_path}")
for s in ("EURUSD", "XAUUSD", "GBPUSD", "EURAUD"):
    si = mt5.symbol_info(s)
    sel = mt5.symbol_select(s, True)
    si2 = mt5.symbol_info(s)
    print(f"\n--- {s} : select={sel}")
    if si2 is None:
        print("   symbol_info None"); continue
    print(f"   visible={si2.visible} select={si2.select} point={si2.point} "
          f"digits={si2.digits} spread={si2.spread} trade_mode={si2.trade_mode}")
    for lbl, fn in (("from_pos(20000)",
                     lambda: mt5.copy_rates_from_pos(s, mt5.TIMEFRAME_M1, 0, 20000)),
                    ("range 2024",
                     lambda: mt5.copy_rates_range(s, mt5.TIMEFRAME_M1,
                                                  dt.datetime(2024, 1, 1),
                                                  dt.datetime(2024, 12, 31))),
                    ("from 2024-06-01",
                     lambda: mt5.copy_rates_from(s, mt5.TIMEFRAME_M1,
                                                 dt.datetime(2024, 6, 1), 50000))):
        r = fn()
        n = 0 if r is None else len(r)
        print(f"   {lbl:18s} -> {n} barres | last_error={mt5.last_error()}")
        time.sleep(1)
mt5.shutdown()
