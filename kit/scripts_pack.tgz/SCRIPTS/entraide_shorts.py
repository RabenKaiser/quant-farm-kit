# -*- coding: utf-8 -*-
"""ENTRAIDE INVERSE : le short du cousin (US100_M5_SHORTS_OBV) sur MES paires FX.
Si son short Donchian + volume marche sur GBPUSD/EURUSD, on l'ajoute au portfolio FX
(ça couvre PTRAIL qui est long !)."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner as m

for sym in ["GBPUSD", "EURUSD", "USDJPY"]:
    r = m.run_backtest("US100_M5_SHORTS_OBV", sym, "M5", "2025.01.01", "2026.01.01", 10000, max_wait=300)
    if r:
        print(f"SHORTS_OBV {sym} 2025: profit=${r.get('profit')} n={r.get('trades')} wr={r.get('wr')}")
    else:
        print(f"{sym}: None ({r.get('error') if r else 'parse fail'})")
