"""combine_jambes : empiler deux portefeuilles de transactions datees, puis les simuler ensemble.

Round 311. Question posee : la reference (CREST-M sur EURCHF + EURGBP + GBPCHF, mu/sigma2 = 0,112)
peut-elle etre AMELIOREE en lui ajoutant la meilleure jambe decorrelee de la table corrigee
(XAUUSD BOS50 LONG, mu/sigma2 = 0,059) ? La theorie dit qu'une jambe ajoutee aide si elle ne
degrade pas trop le rapport global tout en augmentant le nombre de paris ; seule la simulation le
tranche, parce que c'est le drawdown qui decide.

Usage : python combine_jambes.py A.csv B.csv > C.csv, puis prop_jambes.py avec CSV=C.csv
"""
import csv
import os
import sys
from pathlib import Path


def main():
    if len(sys.argv) < 3:
        print("usage : combine_jambes.py fichier1.csv fichier2.csv [...]")
        return 2
    lignes = []
    for nom in sys.argv[1:]:
        f = Path(nom)
        if not f.exists():
            print("absent : %s" % f, file=sys.stderr)
            return 1
        with f.open(encoding="utf-8") as fh:
            for r in csv.DictReader(fh):
                lignes.append((r["date"], r["paire"], r["R"]))
    lignes.sort()
    # ECRITURE PAR PYTHON, PAS PAR REDIRECTION DE SHELL : `>` sous PowerShell ecrit en UTF-16 et
    # le fichier devient illisible pour tout lecteur UTF-8 (piege deja paye trois fois).
    dest = os.environ.get("SORTIE")
    if dest:
        with Path(dest).open("w", encoding="utf-8") as fh:
            fh.write("date,paire,R\n")
            for d, p, v in lignes:
                fh.write("%s,%s,%s\n" % (d, p, v))
        print("%d transactions -> %s" % (len(lignes), dest))
    else:
        sys.stdout.write("date,paire,R\n")
        for d, p, v in lignes:
            sys.stdout.write("%s,%s,%s\n" % (d, p, v))
    return 0


if __name__ == "__main__":
    sys.exit(main())
