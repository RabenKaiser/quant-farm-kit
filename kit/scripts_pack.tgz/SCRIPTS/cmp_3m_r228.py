# -*- coding: utf-8 -*-
"""cmp_3m_r228.py — comparer MT5 (37 trades 3 mois) au python sur la MEME
periode 2024.01-04. Le test court de fidelite."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import c13v2_py_v3 as F
import c13v2_engine as ENG
import sweep_py_r205 as SW
import pandas as pd

BASE = {"imp_atr": 0.9, "imp_vol": 1.0, "imp_look": 6, "ob_age": 16,
        "rej_wick": 0.8, "rej_vol": 1.0, "close_zone": 0.15, "tp_r": 2.0,
        "bias": "vwap", "excl_hours": [6, 7, 12, 15, 19, 23],
        "min_stop": 0.00025, "buf_atr": 0.25, "lookahead": False, "vwap_len": 96}

# charger M1 EURUSD, fenetre 3 mois + warmup 260j
m1 = F.load_m1("EURUSD")
start = pd.Timestamp("2024-01-01", tz="UTC")
end = pd.Timestamp("2024-04-01", tz="UTC")
wu = start - pd.Timedelta(days=260)
m5 = F.resample(m1.loc[wu:end], "5min").loc[start:end]
m15 = F.resample(m1.loc[wu:end], "15min")
h4 = F.resample(m1.loc[wu:end], "4h")
r = ENG.run_exit(m5, m15, h4, dict(BASE), exit_mode="tp", tp_r=2.0)
print(f"PYTHON 3 mois (2024.01-04): n={r['n']} pf={r['pf']:.2f} "
      f"wr={r['wr']:.1f}% R={r['R']:+.1f}")
print(f"MT5    3 mois (2024.01-04): n=37 pf=0.55 wr=21.6% ")
print()
print(f"ECART n: python {r['n']} vs MT5 37")
# detail: distribution des R python
tr = [t[0] for t in r["trades"]]
import numpy as np
arr = np.array(tr)
print(f"python: {int((arr>0).sum())} gagnants / {int((arr<0).sum())} perdants")
print(f"MT5   : 8 gagnants / 29 perdants")
print("=> si python n~20 et MT5 n=37, le MT5 genere ~2x plus de signaux")
