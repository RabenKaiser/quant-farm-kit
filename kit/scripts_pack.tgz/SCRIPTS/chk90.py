﻿import sys, numpy as np, gc
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT, deep_lib as D
G._cache.clear(); gc.collect()
F = G.get_frames("CADJPY"); m5,m1=F["m5"],F["m1"]
h1z,hh,ll,a1,gb,gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd,zlo,zhi = MT.project(m5.index,h1z,hh,ll,gb,gr,max_age_h=48)
M = NL.build(m5,F,zd,zlo,zhi); M.update(FE.more(m5,F,m1))
vw = np.asarray(M["xup_vwapD"]); bb = np.asarray(M["bb_low"])
print(f"xup_vwapD       : {vw.sum():>7,}")
print(f"bb_low          : {bb.sum():>7,}")
print(f"ET              : {(vw&bb).sum():>7,}")
s = NL.sig(M, "xup_vwapD", ["bb_low"])
print(f"NL.sig          : {int((s!=0).sum()):>7,}")
st = D.run_ex("CADJPY", s, 1.5, 99.0, 960, trail_atr=None,
              t0=m5.index[0], t1=m5.index[-1], use_m1=False)
print(f"trades python   : {st.get('n'):>7,}")
print()
print("MT5 : 495 entrees pour VWAPXUP")
print()
print("=> python 185 trades pour 208 signaux (89 %)")
print("   MT5 495 entrees. MT5 prend 2.7x PLUS que python SANS filtre spread.")
