﻿import os, re
LOGD=r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
seen={}
for f in os.listdir(LOGD):
    if '.log' not in f: continue
    p=os.path.join(LOGD,f)
    if os.path.getsize(p)<300: continue
    raw=open(p,'rb').read(4)
    enc='utf-16' if raw[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8'
    try: txt=open(p,encoding=enc,errors='replace').read()
    except Exception: continue
    for mm in re.finditer(r'([A-Z]{6}|XAUUSD|XAGUSD|USOIL|UKOIL),M1: history cache allocated for \d+ bars and contains (\d+) bars from ([\d.]+) to ([\d.]+)', txt):
        s=mm.group(1)
        seen[s]=(int(mm.group(2)), mm.group(3), mm.group(4))
print(f"{'sym':<8}{'bars':>10}  {'debut':>12}  {'fin':>12}")
for s in sorted(seen):
    b,d0,d1 = seen[s]
    print(f"{s:<8}{b:>10,}  {d0[:10]:>12}  {d1[:10]:>12}")
