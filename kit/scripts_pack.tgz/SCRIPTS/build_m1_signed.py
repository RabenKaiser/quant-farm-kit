﻿"""Build M1 bars with tick-direction volume (up/down classification).

For each tick: compare bid price to previous tick's bid price.
  - higher bid -> buyer-initiated (up): vol_up += tick_vol
  - lower bid  -> seller-initiated (down): vol_down += tick_vol
This is the faithful reproduction of the prior NAS100 OFI finding
(tick classification by direction, not raw bid/ask volume sums).
"""
import polars as pl
import sys, time
from pathlib import Path

CHUNKS = Path(r"C:\EAFarm\HISTORY\chunks")
RESEARCH = Path(r"C:\EAFarm\HISTORY - Copy\research\bars")
POINT = {"EURUSD": 0.00001, "USDJPY": 0.001, "EURCAD": 0.00001, "USATECHIDXUSD": 0.001}
PIP = {"EURUSD": 0.0001, "USDJPY": 0.01, "EURCAD": 0.0001, "USATECHIDXUSD": 1.0}

SPREAD_CAP = {s: 300 * p for s, p in POINT.items()}
SPREAD_CAP["USATECHIDXUSD"] = 5000 * POINT["USATECHIDXUSD"]

def build_signed(sym: str, ym: str) -> pl.DataFrame:
    src = CHUNKS / f"{sym}_{ym}.csv"
    pt = POINT[sym]
    lf = pl.scan_csv(
        src,
        schema_overrides={
            "Timestamp": pl.Utf8, "Bid price": pl.Float64, "Ask price": pl.Float64,
            "Bid volume": pl.Float64, "Ask volume": pl.Float64,
        },
        low_memory=True,
    )
    df = (
        lf.with_columns(
            pl.col("Timestamp").str.replace(r":(\d{3})$", r".$1").str.to_datetime("%Y%m%d %H:%M:%S%.f").alias("ts"),
        )
        .drop_nulls("ts")
        .filter(
            (pl.col("Bid price") > 0) & (pl.col("Ask price") > 0)
            & (pl.col("Ask price") >= pl.col("Bid price"))
            & ((pl.col("Ask price") - pl.col("Bid price")) <= SPREAD_CAP[sym])
        )
        .sort("ts")
        .with_columns(
            ((pl.col("Bid price") + pl.col("Ask price")) / 2).alias("mid"),
        )
        .with_columns(
            (pl.col("mid") - pl.col("mid").shift(1)).alias("d_mid"),
            (pl.col("Bid price") - pl.col("Bid price").shift(1)).alias("d_bid"),
        )
        .with_columns(
            # spread change (widening/narrowing)
            ((pl.col("Ask price") - pl.col("Bid price")) - (pl.col("Ask price") - pl.col("Bid price")).shift(1)).alias("d_spread"),
        )
        .with_columns(
            pl.when(pl.col("d_mid") > 0).then(pl.col("Bid volume") + pl.col("Ask volume")).otherwise(0).alias("vol_up"),
            pl.when(pl.col("d_mid") < 0).then(pl.col("Bid volume") + pl.col("Ask volume")).otherwise(0).alias("vol_down"),
            pl.when(pl.col("d_mid") > 0).then(1).otherwise(0).alias("n_up"),
            pl.when(pl.col("d_mid") < 0).then(1).otherwise(0).alias("n_down"),
            # bid-only classification for comparison
            pl.when(pl.col("d_bid") > 0).then(pl.col("Bid volume") + pl.col("Ask volume")).otherwise(0).alias("vol_up_b"),
            pl.when(pl.col("d_bid") < 0).then(pl.col("Bid volume") + pl.col("Ask volume")).otherwise(0).alias("vol_down_b"),
            pl.when((pl.col("d_spread").abs() < 1e-9)).then(pl.col("Bid volume") + pl.col("Ask volume")).otherwise(0).alias("vol_mid_stable"),
        )
        .with_columns(
            pl.col("ts").dt.truncate("1m").dt.epoch("s").alias("time"),
            (pl.col("Ask price") - pl.col("Bid price")).alias("spread_px"),
        )
        .group_by("time")
        .agg(
            pl.col("Bid price").first().alias("bid_o"),
            pl.col("Bid price").max().alias("bid_h"),
            pl.col("Bid price").min().alias("bid_l"),
            pl.col("Bid price").last().alias("bid_c"),
            pl.col("Ask price").first().alias("ask_o"),
            pl.col("Ask price").max().alias("ask_h"),
            pl.col("Ask price").min().alias("ask_l"),
            pl.col("Ask price").last().alias("ask_c"),
            pl.col("mid").first().alias("mid_o"),
            pl.col("mid").last().alias("mid_c"),
            pl.col("Bid volume").sum().alias("bid_vol"),
            pl.col("Ask volume").sum().alias("ask_vol"),
            pl.col("vol_up").sum().alias("vol_up"),
            pl.col("vol_down").sum().alias("vol_down"),
            pl.col("vol_up_b").sum().alias("vol_up_b"),
            pl.col("vol_down_b").sum().alias("vol_down_b"),
            pl.col("vol_mid_stable").sum().alias("vol_mid_stable"),
            pl.col("n_up").sum().alias("n_up"),
            pl.col("n_down").sum().alias("n_down"),
            pl.len().alias("n_ticks"),
            pl.col("spread_px").median().alias("spread_med"),
            pl.col("spread_px").max().alias("spread_max"),
        )
        .sort("time")
        .collect()
    )
    return df

if __name__ == "__main__":
    symbols = sys.argv[1:] or ["EURUSD", "USDJPY", "EURCAD", "USATECHIDXUSD"]
    for sym in symbols:
        months = sorted(p.stem.removeprefix(f"{sym}_") for p in CHUNKS.glob(f"{sym}_*.csv"))
        parts = []
        for ym in months:
            t0 = time.time()
            r = build_signed(sym, ym)
            parts.append(r)
            print(f"{sym} {ym}: {len(r)} bars in {time.time()-t0:.1f}s", flush=True)
        if parts:
            full = pl.concat(parts).sort("time")
            out = RESEARCH / f"{sym}_M1_signed.parquet"
            full.write_parquet(out)
            # quick sanity
            tot_up = full["vol_up"].sum()
            tot_dn = full["vol_down"].sum()
            print(f"{sym}: {len(full)} M1 bars -> {out}  up={tot_up:,.0f} down={tot_dn:,.0f} ratio={tot_up/max(tot_dn,1):.4f}", flush=True)
