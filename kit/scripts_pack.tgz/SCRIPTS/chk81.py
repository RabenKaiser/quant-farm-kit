﻿import re
src = open(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\MQL5\Experts\eepeek\ORION_ROBOT.mq5", encoding="utf-8").read()
handled = sorted(set(re.findall(r't\s*==\s*"([A-Z0-9]+)"', src)))
print(f"{len(handled)} declencheurs geres :")
for h in handled: print("   ", h)
