"""compare_atr_barres : les barres M30 du TESTEUR sont-elles celles de mon CORPUS ?

Round 360. Le round 359 a etabli que mon moteur est juste (les entrees aleatoires sur le corpus
rendent 30,2-31,3 %, soit la theorie (1-s)/3 a un demi-point pres) et que le signal y a un vrai edge
(37-43,5 %), alors que les ordres reels font 26,1 % -- SOUS le hasard. Tout le reste ayant ete ecarte
(instants, densite, mecanique de sortie, spread, ATR median), il ne reste qu'une explication : le
chemin de prix n'est pas le meme.

Ce script la met a l'epreuve sans lancer aucun test : les lignes `SIG` du journal portent l'ATR que
l'EA lit a chaque entree (`atr=`), c'est-a-dire un **ATR de Wilder(14) calcule sur les barres M30 du
TESTEUR**. On recalcule le meme ATR de Wilder sur les barres M30 de mon CORPUS au meme instant et on
compare, entree par entree.

  - rapport ~1,00 avec faible dispersion  -> les barres coincident, l'ecart est ailleurs ;
  - rapport qui s'ecarte nettement de 1, avec une dispersion forte -> les deux series different :
    c'est le corpus qu'il faut reconstruire depuis les barres du testeur avant toute nouvelle mesure.

Un ecart constant de quelques pour cent est attendu (Wilder contre moyenne simple n'entre pas en jeu
ici puisque les deux cotes sont en Wilder) : ce qui compte est la DISPERSION, pas la moyenne.
"""
import os
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
PROFILS = {"mt5": "E23367DD11DBEB0EF97D08185EAB7295",
           "farm": "CF0B997454318B475CF01419AFE2BBF3"}
TESTER = (Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Tester")
          / PROFILS.get(os.environ.get("PROFIL", "farm"), ""))
PAIRE = sys.argv[1] if len(sys.argv) > 1 else "EURCHF"


def lignes_sig():
    out = []
    for lg in TESTER.glob("Agent-*/logs/*.log"):
        for enc in ("utf-16", "utf-8"):
            try:
                txt = lg.read_text(encoding=enc, errors="replace")
            except OSError:
                continue
            for m in re.finditer(r"(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s+SIG %s \S+ "
                                 r"spread_pts=(\d+) atr=([\d.]+)" % re.escape(PAIRE), txt):
                out.append((pd.Timestamp(m.group(1).replace(".", "-", 2).replace(".", " ")),
                            float(m.group(3))))
    return out


def atr_wilder(D):
    h, l, c = D["h"], D["l"], D["c"]
    tr = pd.concat([pd.Series(h) - pd.Series(l),
                    (pd.Series(h) - pd.Series(c).shift()).abs(),
                    (pd.Series(l) - pd.Series(c).shift()).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1.0 / 14.0, adjust=False).mean().values


def main():
    sig = lignes_sig()
    if not sig:
        print("aucune ligne SIG pour %s dans %s" % (PAIRE, TESTER))
        return 1
    D = NM.charge(PAIRE, "m1_pos")
    if D is None:
        print("corpus absent")
        return 1
    aw = atr_wilder(D)
    idx = D["idx"]
    rapports, lignes = [], []
    for t, atr_ea in sig:
        # l'EA agit au premier tick de la barre suivante : la barre de signal est la precedente
        i = idx.searchsorted(t) - 1
        if i < 30 or i >= len(idx):
            continue
        a_corpus = aw[i]
        if not np.isfinite(a_corpus) or a_corpus <= 0:
            continue
        rapports.append(atr_ea / a_corpus)
        lignes.append((t, atr_ea, a_corpus, atr_ea / a_corpus))
    if len(rapports) < 20:
        print("trop peu d'entrees appariees (%d)" % len(rapports))
        return 1
    r = np.array(rapports)
    print("=== %s : ATR de Wilder du TESTEUR contre celui du CORPUS, %d entrees appariees ==="
          % (PAIRE, len(r)))
    print("  %-20s %10s %12s %8s" % ("instant (exemples)", "ATR testeur", "ATR corpus", "rapport"))
    for t, a, b, q in lignes[:6]:
        print("  %-20s %10.6f %12.6f %8.3f" % (str(t)[:16], a, b, q))
    print("\n  rapport testeur/corpus : median %.4f | moyenne %.4f | ecart-type %.4f"
          % (float(np.median(r)), float(np.mean(r)), float(np.std(r))))
    print("  percentiles : p05 %.3f | p25 %.3f | p75 %.3f | p95 %.3f"
          % tuple(float(np.percentile(r, q)) for q in (5, 25, 75, 95)))
    print("\n  lecture : une dispersion faible (ecart-type < 0,05) signifie que les barres coincident")
    print("  et que l'ecart modele/reel vient d'ailleurs. Une dispersion forte signifie que les deux")
    print("  series de prix different -- et c'est alors mon corpus qu'il faut reconstruire.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
