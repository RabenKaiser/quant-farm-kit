﻿# -*- coding: utf-8 -*-
"""bilan_boll.py â€” PERSISTANCE TRIMESTRE PAR TRIMESTRE, ET PORTEE.

La configuration qui a survecu au crible ET a la verification independante :
    entree : cloture sous MA20 - 2 ecarts-types  -> achat
             cloture au-dessus de MA20 + 2 sigma -> vente
    sortie : stop 2.0 x ATR, objectif 1.5 x ATR, 48 barres (4 heures)
    resultat verifie sur EURUSD : +0.0229 R par transaction, 58.3 % de
    reussite, 14 655 transactions sur deux ans. Les deux implementations
    (boucle elementaire et vectorisee) donnent le meme chiffre a 1e-6.

CE QUE CE SCRIPT ETABLIT, ET QUI MANQUE ENCORE
  1. la PERSISTANCE : le R de chaque trimestre, pour voir si c'est regulier ou
     concentre sur une ou deux periodes ;
  2. la PORTEE : la meme mecanique sur 12 paires, avec le meme filtre de
     persistance (au moins 7 trimestres sur 8 positifs) ;
  3. le R PAR AN realisable, en additionnant des paires DISTINCTES (et non des
     configurations qui se recouvrent sur la meme paire : additionner 21 regles
     EURUSD qui se chevauchent ne fait pas un portefeuille, ca fait une seule
     position 21 fois plus grosse).

USAGE : python bilan_boll.py
"""
import collections
import statistics
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
M1 = BASE / "m1_pos"
PAIRES = ["EURUSD", "USDJPY", "EURJPY", "AUDJPY", "GBPJPY", "USDCAD",
          "CADJPY", "NZDUSD", "EURGBP", "AUDUSD", "NZDJPY", "EURAUD"]
PERIODES = [("2024Q1", "2024-01-01", "2024-04-01"),
            ("2024Q2", "2024-04-01", "2024-07-01"),
            ("2024Q3", "2024-07-01", "2024-10-01"),
            ("2024Q4", "2024-10-01", "2025-01-01"),
            ("2025Q1", "2025-01-01", "2025-04-01"),
            ("2025Q2", "2025-04-01", "2025-07-01"),
            ("2025Q3", "2025-07-01", "2025-10-01"),
            ("2025Q4", "2025-10-01", "2026-01-01")]
SL_ATR, TP_ATR, HOLD = 2.0, 1.5, 48
PAS = 3
# SENSIBILITE AU PHASAGE (18/09, 20 h). Le crible annoncait EURUSD positif sur
# 8 trimestres sur 8 ; ce script, avec exactement la meme mecanique, n'en trouve
# que 6. La seule difference est le point de depart de l'echantillonnage des
# entrees (barre 290 pour le crible, barre 30 ici), donc le PHASAGE des entrÃ©es
# testees. Si le resultat bascule selon ce phasage, c'est qu'il n'est pas
# robuste : un vrai avantage ne doit pas dependre de quelle barre sur trois on
# echantillonne. DEBUT permet de le mesurer.
import os
DEBUT = int(os.environ.get("DEBUT", "30"))


def point_de(close):
    ex = close.dropna().astype(str)
    ex = ex[~ex.str.contains("e", case=False, na=False)].head(2000)
    dec = 0
    for x in ex:
        if "." in x:
            dec = max(dec, len(x.split(".")[1]))
    return 10.0 ** (-dec)


def charge(sym):
    p = M1 / ("%s_M1.csv" % sym)
    if not p.exists():
        return None
    d = pd.read_csv(p, usecols=["time", "high", "low", "close", "spread"])
    d["time"] = pd.to_datetime(d["time"], unit="s", utc=True)
    d = d.set_index("time").sort_index()
    pt = point_de(d["close"])
    m5 = d.resample("5min").agg({"high": "max", "low": "min",
                                 "close": "last", "spread": "mean"}).dropna()
    m5["spr"] = m5["spread"] * pt
    pc = m5["close"].shift(1)
    tr = pd.concat([(m5["high"] - m5["low"]).abs(),
                    (m5["high"] - pc).abs(),
                    (m5["low"] - pc).abs()], axis=1).max(axis=1)
    m5["atr"] = tr.rolling(14).mean()
    m5["ma"] = m5["close"].rolling(20).mean()
    m5["sd"] = m5["close"].rolling(20).std()
    return m5.dropna()


def simule(m5, sl_atr=SL_ATR, tp_atr=TP_ATR, hold=HOLD, aleatoire=False):
    H = m5["high"].to_numpy()
    L = m5["low"].to_numpy()
    C = m5["close"].to_numpy()
    A = m5["atr"].to_numpy()
    S = m5["spr"].to_numpy()
    MA = m5["ma"].to_numpy()
    SD = m5["sd"].to_numpy()
    n = len(C)
    idx, side = [], []
    for i in range(DEBUT, n - HOLD - 1, PAS):
        if not (A[i] > 0):
            continue
        if aleatoire:
            idx.append(i)
            side.append(1.0 if (i // PAS) % 2 == 0 else -1.0)
            continue
        if SD[i] <= 0:
            continue
        if C[i] < MA[i] - 2 * SD[i]:
            idx.append(i)
            side.append(1.0)
        elif C[i] > MA[i] + 2 * SD[i]:
            idx.append(i)
            side.append(-1.0)
    if len(idx) < 50:
        return []
    idx = np.array(idx)
    side = np.array(side)
    W = hold
    fen = idx[:, None] + np.arange(1, W + 1)[None, :]
    Hw, Lw = H[fen], L[fen]
    spr = np.where(S[idx] > 0, S[idx], 0.0)
    ent = C[idx] + side * spr / 2.0
    long_ = (side[:, None] > 0)
    fav = np.where(long_, Hw - ent[:, None], ent[:, None] - Lw)
    adv = np.where(long_, ent[:, None] - Lw, Hw - ent[:, None])
    atr = A[idx]
    hs = adv >= (sl_atr * atr)[:, None]
    ht = fav >= (tp_atr * atr)[:, None]
    prem_s = np.where(hs.any(axis=1), hs.argmax(axis=1), W + 1)
    prem_t = np.where(ht.any(axis=1), ht.argmax(axis=1), W + 1)
    franchi = np.minimum(prem_s, prem_t) < W
    gagne = prem_t < prem_s
    R = np.where(franchi, np.where(gagne, tp_atr / sl_atr, -1.0), np.nan)
    j = np.minimum(idx + hold, n - 1)
    sortie = C[j] - side * spr / 2.0
    Rm = (sortie - ent) * side / (sl_atr * atr)
    R = np.where(np.isnan(R), Rm, R)
    return list(zip(idx, R))


def main():
    print("=" * 100)
    print("LA CONFIGURATION VERIFIEE : PERSISTANCE ET PORTEE")
    print("=" * 100)
    print("   entree : Bollinger 20 / 2 ecarts-types, a contre-sens")
    print("   sortie : stop %.1f ATR / objectif %.1f ATR / %d barres"
          % (SL_ATR, TP_ATR, HOLD))
    print()
    resultats = {}
    for sym in PAIRES:
        m5 = charge(sym)
        if m5 is None or len(m5) < 10000:
            continue
        res = simule(m5)
        if not res:
            continue
        idx = np.array([x[0] for x in res])
        R = np.array([x[1] for x in res])
        tem = simule(m5, aleatoire=True)
        Rtem = np.array([x[1] for x in tem]) if tem else np.array([0.0])
        t = m5.index
        par_per = {}
        for lab, a, b in PERIODES:
            x = t.searchsorted(pd.Timestamp(a, tz="UTC"))
            y = t.searchsorted(pd.Timestamp(b, tz="UTC"))
            masque = (idx >= x) & (idx < y)
            if masque.sum() >= 40:
                par_per[lab] = (float(R[masque].mean()), int(masque.sum()))
        if len(par_per) < len(PERIODES):
            continue
        resultats[sym] = (par_per, float(R.mean()), float(Rtem.mean()),
                          len(R))
    print("   %-8s %s %8s %8s %10s %10s"
          % ("paire", " ".join("%7s" % p[0][-2:] for p in PERIODES),
             "moyen", "temoin", "tx/an", "/8"))
    print("   " + "-" * 96)
    retenues = []
    for sym, (par_per, moy, tm, n) in sorted(resultats.items()):
        vals = [par_per[lab][0] for lab, _, _ in PERIODES]
        npos = sum(1 for v in vals if v > 0)
        txan = n / 2.0
        if npos >= 7:
            retenues.append(sym)
        print("   %-8s %s %+8.4f %+8.4f %10.0f %6d"
              % (sym, " ".join("%+7.3f" % v for v in vals), moy, tm, txan, npos))
    print()
    print("   Paires avec au moins 7 trimestres sur 8 positifs : %d" % len(retenues))
    print("      %s" % ", ".join(retenues))
    print()
    # --- R par an d'un portefeuille de paires DISTINCTES -----------------
    if retenues:
        tx = sum(resultats[s][3] / 2.0 for s in retenues)
        Rm = statistics.mean(resultats[s][1] for s in retenues)
        print("   PORTEFEUILLE DE PAIRES DISTINCTES (pas de chevauchement)")
        print("      paires           : %d" % len(retenues))
        print("      transactions/an  : %.0f" % tx)
        print("      R moyen/tx       : %+.4f" % Rm)
        print("      R par an         : %+.0f" % (Rm * tx))
        print("      objectif         : +500 R/an")
        if Rm * tx >= 500:
            print("      -> OBJECTIF ATTEINT, sur des paires distinctes et une")
            print("         seule regle. C'est la premiere fois que c'est vrai")
            print("         avec un chiffre verifie par deux implementations.")
        else:
            print("      -> il manque %.0f R/an." % (500 - Rm * tx))
    else:
        print("   AUCUNE paire n'atteint 7 trimestres sur 8 : la configuration")
        print("   verifiee sur EURUSD ne se generalise pas.")
    print()
    print("   RAPPEL DE PRUDENCE : ceci est une SIMULATION sur donnees M1, avec")
    print("   le spread paye deux fois, mais SANS glissement, SANS swap et SANS")
    print("   commission. L'ecart labo/reel mesure plus tot valait -0.09 R par")
    print("   transaction sur le mecanisme precedent. Il faut donc tester en")
    print("   ordres reels avant de conclure.")


if __name__ == "__main__":
    main()
