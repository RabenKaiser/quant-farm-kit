"""diag_debut : pourquoi le compte est-il COUPE DANS LE PREMIER MOIS sur les DEUX feeds ?

Constat du round 257 : la simulation du portefeuille SR COURT finit coupee a -5 % en
2026-01 sur Upcomers ET en 2020-01 sur Dukascopy, a TOUS les risques et tous les
plafonds. Deux mois consecutifs, en tete de chaque fichier, ca ressemble plus a un
artefact de debut de donnees qu'a un vrai drawdown. Ce script regarde les R par jour
sur les premiers jours de chaque feed et les compare au reste de l'historique.

Usage : SOURCE=m1_pos PAIRES=EURGBP,EURJPY,... ND=20 python SCRIPTS\\diag_debut.py
"""
import os
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compte_final as C

B = Path(r"C:\EAFarm\HISTORY - Copy\research")


def stats(v):
    if not v:
        return "vide"
    v = sorted(v)
    return "n=%d moy %+.3f | pire %+.3f | median %+.3f | meilleur %+.3f" % (
        len(v), sum(v) / len(v), v[0], v[len(v) // 2], v[-1])


def main():
    src = os.environ.get("SOURCE", "m1_pos")
    C.os.environ["SOURCE"] = src
    paires = [p for p in os.environ.get(
        "PAIRES", "EURGBP,EURJPY,USDCHF,AUDJPY,NZDJPY").split(",") if p]
    nd = int(os.environ.get("ND", "15"))
    print("feed %s | %d paires | %d premiers jours detailles" % (src, len(paires), nd), flush=True)

    for p in paires:
        tr = C.trades_pair(p)
        if not tr:
            print("%-8s AUCUN trade" % p, flush=True)
            continue
        par_jour = defaultdict(list)
        for t, r in tr:
            par_jour[t.date()].append(r)
        jours = sorted(par_jour)
        tot = sum(r for _, r in tr)
        # 1. les ND premiers jours
        tete = jours[:nd]
        r_tete = sum(sum(par_jour[j]) for j in tete)
        n_tete = sum(len(par_jour[j]) for j in tete)
        reste = jours[nd:]
        r_reste = sum(sum(par_jour[j]) for j in reste)
        n_reste = sum(len(par_jour[j]) for j in reste)
        print("\n=== %s : %d jours de %s a %s | R total %+.1f sur %d trades"
              % (p, len(jours), jours[0], jours[-1], tot, len(tr)), flush=True)
        for j in tete:
            v = par_jour[j]
            print("    %s  n=%3d  somme R %+7.2f  (%s)" % (j, len(v), sum(v),
                                                             stats(v)), flush=True)
        print("    -- tete (%d j) : %d trades %+.1f R (%.3f R/tx) | reste : %d trades %+.1f R (%.3f R/tx)"
              % (len(tete), n_tete, r_tete, r_tete / n_tete if n_tete else 0,
                 n_reste, r_reste, r_reste / n_reste if n_reste else 0), flush=True)
        print("    -- R/jour : tete %s" % stats([sum(par_jour[j]) for j in tete]), flush=True)
        print("    -- R/jour : reste %s" % stats([sum(par_jour[j]) for j in reste]), flush=True)
        pires = sorted(jours, key=lambda j: sum(par_jour[j]))[:5]
        print("    -- 5 pires jours : " + ", ".join(
            "%s %+.1f R (%d tx)" % (j, sum(par_jour[j]), len(par_jour[j])) for j in pires), flush=True)
        meil = sorted(jours, key=lambda j: -sum(par_jour[j]))[:3]
        print("    -- 3 meilleurs jours : " + ", ".join(
            "%s %+.1f R" % (j, sum(par_jour[j])) for j in meil), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
