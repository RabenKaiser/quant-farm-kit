﻿"""Rigorous audit of G13: USDJPY M30 range_break (Donchian 40, SL 2.5 ATR, RR 2.5).

Checks:
  1. Correct reproduction on M5/M15/H1 (the loop's repro key mapping was buggy)
  2. OOS-only stats (2023) with t-stat
  3. Monthly equity path + max DD for prop viability
  4. Per-year decomposition (2022 vs 2023)
"""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import datetime as _dt
from pathlib import Path
import numpy as np
import polars as pl

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
from edge_correct import (load_m1, to_tf, seg_of, backtest_m1, summarize,
                          POINT, COMMISSION_RT, TICK_VALUE_PER_PT)
from edge_correct import make_signals as ms_base
from alpha_loop_gen import add_costs, apply_filters

def E(d):
    return int(_dt.datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=_dt.timezone.utc).timestamp())

SYM = "USDJPY"
cfg = {"slippage_pts": 0.5, "lookback": 40, "sl_atr": 2.5, "rr": 2.5}

# 1) reproduction across timeframes (full 2022)
print("=== Reproduction (2022-01-01 -> 2023-01-01) ===")
for tf_sec in [300, 900, 1800, 3600]:
    m1 = load_m1(SYM)
    tf = to_tf(m1, tf_sec)
    seg = tf.filter((pl.col("time") >= E("2022-01-01")) & (pl.col("time") < E("2023-01-01")))
    m1seg = m1.filter((pl.col("time") >= E("2022-01-01")) & (pl.col("time") < E("2023-01-01")))
    f = ms_base(seg, "range_break", cfg)
    tr = backtest_m1(m1seg, seg, f, SYM, add_costs(SYM, cfg))
    s = summarize(tr)
    print(f"  M{tf_sec//60}: n={s['n']} gross={s['gross']:.4f} net={s['net']:.4f} wr={s['wr']}% t={s['t']}")

# 2) full-period with per-year split + OOS t
print("\n=== Per-year ===")
for label, (t0, t1) in [("2022", (E("2022-01-01"), E("2023-01-01"))),
                         ("2023", (E("2023-01-01"), E("2024-01-01")))]:
    m1 = load_m1(SYM)
    tf = to_tf(m1, 1800)
    seg = tf.filter((pl.col("time") >= t0) & (pl.col("time") < t1))
    m1seg = m1.filter((pl.col("time") >= t0) & (pl.col("time") < t1))
    f = ms_base(seg, "range_break", cfg)
    tr = backtest_m1(m1seg, seg, f, SYM, add_costs(SYM, cfg))
    s = summarize(tr)
    print(f"  {label}: n={s['n']} gross={s['gross']:.4f} net={s['net']:.4f} wr={s['wr']}% t={s['t']}")

# 3) monthly equity path with DD
print("\n=== Monthly path (M30, full 2y) ===")
m1 = load_m1(SYM)
tf = to_tf(m1, 1800)
f = ms_base(tf, "range_break", cfg)
tr = backtest_m1(m1, tf, f, SYM, add_costs(SYM, cfg))
res = pl.DataFrame(tr).with_columns((pl.col("r") - pl.col("cost_r")).alias("net"))
res = res.with_columns((pl.col("ts") // 86400 * 86400 * 1000).cast(pl.Datetime("ms")).dt.strftime("%Y-%m").alias("ym"))
g = res.group_by("ym").agg(pl.col("net").sum().alias("R"), pl.len().alias("n")).sort("ym")
cum = 0
peak = 0
maxdd = 0
for r in g.iter_rows(named=True):
    cum += r["R"]
    peak = max(peak, cum)
    dd = cum - peak
    maxdd = min(maxdd, dd)
    print(f"  {r['ym']}: R={r['R']:+.2f} (n={int(r['n'])}) cum={cum:+.2f}")
print(f"\n  Total R (2y): {cum:.2f}  max DD in R: {maxdd:.2f}")
print(f"  trades: {len(res)}  avg R/trade: {cum/len(res):.4f}")
# equity in % at 0.5% risk/trade
eq = 1.0; peak = 1.0; maxddpct = 0.0
for r in res.iter_rows(named=True):
    eq *= (1 + 0.005 * r["net"])
    peak = max(peak, eq)
    maxddpct = min(maxddpct, eq/peak - 1)
print(f"  Equity at 0.5%/trade: final={eq:.3f} ({(eq-1)*100:+.1f}%) maxDD={maxddpct*100:.1f}%")
# what about 0.25% risk? 
eq = 1.0; peak = 1.0; maxddpct = 0.0
for r in res.iter_rows(named=True):
    eq *= (1 + 0.0025 * r["net"])
    peak = max(peak, eq)
    maxddpct = min(maxddpct, eq/peak - 1)
print(f"  Equity at 0.25%/trade: final={eq:.3f} ({(eq-1)*100:+.1f}%) maxDD={maxddpct*100:.1f}%")
