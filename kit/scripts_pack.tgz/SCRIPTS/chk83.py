﻿import sys, numpy as np, gc
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT
G._cache.clear(); gc.collect()
for sym in ("NZDUSD","CADJPY"):
    F = G.get_frames(sym); m5,m1=F["m5"],F["m1"]
    h1z,hh,ll,a1,gb,gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
    zd,zlo,zhi = MT.project(m5.index,h1z,hh,ll,gb,gr,max_age_h=48)
    M = NL.build(m5,F,zd,zlo,zhi); M.update(FE.more(m5,F,m1))
    for k in ("stoch_xdn","stoch_xup","macd_xup","macd_xdn","div_bull","div_bear","sweep_hi","sweep_lo","rsi_xup","rsi_xdn"):
        if k in M:
            v=np.asarray(M[k])
            if v.dtype==bool: print(f"  {sym:<8} {k:<12} {100*v.mean():6.2f} %")
    print()
