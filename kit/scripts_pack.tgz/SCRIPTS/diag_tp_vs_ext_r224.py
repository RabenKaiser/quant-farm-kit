# -*- coding: utf-8 -*-
"""diag_tp_vs_ext_r224.py — ISOLER: MT5 TP FIXE (ext=0) vs extend (ext=2).
Si TP fixe ~pf1.4 (comme python tp2.0) => entree OK, exit extend bugge."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\diag_tp_vs_ext_r224.jsonl"
def cfg(mg, ext):
    return dict(InpMagic=mg, InpLots=0.10, InpTpR=2.0, InpAtrPeriod=14,
                InpImpAtrMult=0.9, InpImpVolMult=1.0, InpVolLookback=50,
                InpImpLook=6, InpObMaxAge=16, InpRejWickRatio=0.8,
                InpCloseInZone=0.15, InpBufferAtrFrac=0.25, InpMinStopPips=3.0,
                InpBiasMode=1, InpVwapLen=96, InpHtfEmaPeriod=200,
                InpUseHourFilter=True, InpExcludedHours="6,7,12,15,19,23",
                InpUseDailyStop=True, InpDailyStopPct=2.0, InpMaxTradesDay=0,
                InpUtcOffset=2, InpVerbose=False, InpExtAtr=ext)
mg = 830000
RUNS = [("EUR24-TPFIXE", "EURUSD", "2024.01.01", "2025.01.01", 0.0),
        ("EUR24-EXTEND2", "EURUSD", "2024.01.01", "2025.01.01", 2.0),
        ("NZD24-TPFIXE", "NZDUSD", "2024.01.01", "2025.01.01", 0.0),
        ("NZD24-EXTEND2", "NZDUSD", "2024.01.01", "2025.01.01", 2.0)]
with open(OUT, "a", encoding="utf-8") as fo:
    for tag, sym, frm, to, ext in RUNS:
        mg += 1
        c = cfg(mg, ext)
        print(f"[r224 {tag}] ext={ext} ...", flush=True)
        r = RF.run_backtest("C13V2_MT5_EA", symbol=sym, tf="M5",
                            from_d=frm, to_d=to, deposit=10000,
                            max_wait=2400, inputs=c)
        fo.write(json.dumps({"tag": tag, "r": r}, default=str) + "\n")
        print(f"[{tag}] " + ("null" if r is None else
              f"p={r.get('profit')} n={r.get('trades')} "
              f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
        time.sleep(2)
print("FIN", flush=True)
