"""carte_programme : LE VISUEL. Une page unique qui montre ou en est le programme, et ou sont les portes.

Round 491. Demande de l'utilisateur : « un gros visuel pour avoir a peu pres tout de la ou on est, un beau
truc a montrer aussi, pour regarder des options et en discuter ensemble ». Ce script rassemble en UNE page
HTML autonome (aucune dependance, aucun reseau) :

  - l'objectif et ses criteres, avec l'etat MESURE de chacun ;
  - le chemin parcouru : familles de signaux testees, verdict par le moteur honnete, chiffres a l'appui ;
  - le portefeuille retenu (les 15 jambes), ses performances en echantillon et hors annee ;
  - les 180 couples candidats mesures et ce qui a ete valide en ORDRES REELS ;
  - ce qui reste ouvert : les pistes a explorer, classees par ce qu'elles apporteraient ;
  - la carte du graphe de code (graphify) si elle existe.

Tout est lu dans les fichiers du projet (rapports, CSV des cribles, JSON des lots) : la page est une
photographie, pas une projection, et chaque chiffre porte sa source.

Usage : python SCRIPTS\\carte_programme.py
Sortie : CARTE_PROGRAMME.html
"""
import csv
import html
import json
import os
import re
import string
from pathlib import Path

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
SORTIE = B / "CARTE_PROGRAMME.html"
COMMON = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\Common\Files")

# --- etat de l'objectif : chiffres mesures, avec leur source -----------------
OBJECTIF = [
    ("Probabilite de passer le prop", ">= 70 %",
     "66,8 % hors annee (75,5 % en echantillon)", "65 %", "RAPPORT_483.md"),
    ("Rendement mensuel", "4 a 5 %",
     "+2,60 a +2,92 % hors annee", "60 %", "RAPPORT_483.md"),
    ("Pire annee", "positive",
     "+6,29 % hors annee, 6 annees sur 6", "100 %", "RAPPORT_483.md"),
    ("Drawdown total", "< 5 % (interne)",
     "par construction ; coupe ecrite dans l'EA, a compiler", "70 %", "RAPPORT_487.md"),
    ("Perte journaliere", "-2,5 % interne / -4 a -5 % firme",
     "coupe ecrite dans l'EA (InpCoupeJourPct), a compiler", "70 %", "RAPPORT_487.md"),
    ("Positions simultanees", "limitees",
     "max 8, moyenne 2,1 sur le panier retenu", "100 %", "RAPPORT_484.md"),
    ("Pas de couverture sur une paire", "regle",
     "respectee (les deux sens existent, jamais ouverts en sens inverse au meme instant)", "100 %",
     "RAPPORT_484.md"),
    ("Mesuree sur ordres REELS", "plusieurs annees",
     "1 jambe sur 15 validee (EURCHF +0,0863) ; 14 campagnes en file", "15 %", "RAPPORT_489.md"),
]

# --- familles de signaux testees, avec leur verdict --------------------------
FAMILLES = [
    ("Crest SR97 (sommet du range)", "vente", "+0,4671 (AUS.IDX 4 R)", "RETENUE",
     "le crible de reference : 26 paires puis 18 instruments du feed"),
    ("Momentum (achat de la cassure)", "achat", "+0,1255 (NSXUSD 5 R)", "BLOQUEE",
     "fonctionne aux gros objectifs sur indices/or, mais INTRADABLE : LocOf lie le sens au declencheur"),
    ("Ecart a la VWAP de session", "vente", "-0,015 apres decote", "REJETEE",
     "redondante avec le crest ; multi-trame teste (M5/M15/M30/H1) : le filtre de tendance ne sauve pas"),
    ("Williams %R 14 barres", "achat", "+0,1233 (AUS.IDX, n=990)", "RETENUE",
     "EST la position dans le range : ce qui est neuf, c'est la fenetre de 14 et le seuil 0,20"),
    ("Bandes de Keltner, retour", "les deux", "aucun couple", "REJETEE",
     "les bandes en zone overbought/oversold ne tiennent pas"),
    ("Bandes de Keltner, cassure", "vente", "+0,1068 (DEU.IDX, 31 % de gagnantes)", "RETENUE",
     "c'est la CASSURE qui marche, pas le retour a la moyenne"),
    ("Biais de contexte (VWAP_M30, EMA200, H4)", "les deux", "-0,05 a -0,01 de theta", "REJETEE",
     "mesure : le contexte est redondant (VWAP) ou destructeur (75 a 90 % des transactions coupees)"),
    ("Seuil 0,90 au lieu de 0,97", "--", "theta x3 (34,2 contre 11,9)", "RETENUE",
     "LE PLUS GROS LEVIER : volume x3, attendu a peine divise par deux ; ligne SR100S/SR100L deja dans l'EA"),
    ("Detention 16 h au lieu de 32 h", "--", "+52 % de transactions, theta x1,2", "RETENUE",
     "la regle « une position a la fois » fait dependre le NOMBRE de transactions de l'horizon"),
    ("Composition par Sharpe (15 jambes)", "--", "Sharpe 1,292 (4,48 annualise)", "RETENUE",
     "remplace l'empilement : 49 jambes donnaient MOINS (72,1 % contre 73,3 %)"),
]

# --- ce qui reste ouvert ----------------------------------------------------
PISTES = [
    ("Compiler les coupes de l'EA", "bloquant",
     "sans la coupe journaliere, le risque eleve termine le compte ; le code est ecrit, il reste a compiler "
     "et a tester une campagne avec COUPE_JOUR=2.5"),
    ("Valider les 14 jambes restantes", "en cours",
     "le banc tourne : 22 lots a seuil 0,90 en tete, puis la vague 1, les horizons courts et le FX"),
    ("Declencheur momentum dans l'EA", "a faire",
     "les jambes momentum (theta 1,2 sur indices) sont mesurees mais intradables : il faut un MOM97 miroir "
     "de LocOf, puis recompiler hors campagne"),
    ("Fenetre de 14 barres dans l'EA", "a faire",
     "les jambes Williams %R (990 transactions sur AUS.IDX) demandent un declencheur SR14 -- meme mecano "
     "que le momentum"),
    ("Plus d'instruments", "ouvert",
     "le feed porte 70 symboles, le corpus en a 26+18 ; les 18 nouveaux ont donne theta 34 a eux seuls. "
     "Restent les cryptos (BTCUSD, ETHUSD, LTCUSD, ADAUSD) et 10 croises FX sans historique local"),
    ("Poids de tangence", "mesure au round 490",
     "remplacer le poids egal par w ~ Sigma^-1 mu peut augmenter le Sharpe, au prix d'un surajustement a "
     "verifier hors annee"),
    ("Autres trames", "ouvert",
     "tout le crible est en M30 : M15 et H1 n'ont ete explores que pour la VWAP. Chaque trame a son propre "
     "cout en R, donc son propre classement de couples"),
]


def lis_csv(nom):
    f = B / nom
    if not f.exists():
        return []
    with f.open(encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def compte_lot(nom, prefixe):
    f = B / nom
    if not f.exists():
        return 0, 0, []
    lots = json.loads(f.read_text(encoding="utf-8"))
    couples = [(l["syms"], e["ligne"], int(e["plage"]), e["sens"], l["tp_r"], l.get("hold", 64))
               for l in lots for e in l["lignes"]]
    return len(lots), sum(len(l["lignes"]) for l in lots), couples


def main():
    lots = []
    for nom in ("LOTS_V3.json", "LOTS.json", "LOTS_V2.json", "LOTS_V4.json"):
        n, c, det = compte_lot(nom, "")
        if n:
            lots.append((nom, n, c, det))
    total_lots = sum(x[1] for x in lots)
    total_couples = sum(x[2] for x in lots)
    vrai = []
    for nom in ("REEL_EMPILE.md",):
        f = B / nom
        if f.exists():
            for ln in f.read_text(encoding="utf-8", errors="replace").splitlines():
                m = re.match(r"\|\s*([A-Z0-9.]+)\s*\|\s*(\w+)\s*\|\s*(\d+)\s*\|\s*([SL])\s*\|\s*(\d+)\s*\|"
                             r"\s*([+-][\d.]+)\s*\|", ln)
                if m:
                    vrai.append((m.group(1), m.group(2), int(m.group(3)), m.group(4),
                                 int(m.group(5)), float(m.group(6))))

    def bloc_objectif():
        lignes = []
        for nom, cible, etat, avancement, src in OBJECTIF:
            lignes.append(
                "<tr><td>%s</td><td class='cible'>%s</td><td>%s</td>"
                "<td><div class='bar'><i style='width:%s'></i></div></td>"
                "<td class='src'>%s</td></tr>"
                % (html.escape(nom), html.escape(cible), html.escape(etat), avancement, html.escape(src)))
        return "\n".join(lignes)

    def bloc_familles():
        couleurs = {"RETENUE": "ok", "REJETEE": "ko", "BLOQUEE": "warn"}
        lignes = []
        for nom, sens, chiffre, verdict, note in FAMILLES:
            lignes.append(
                "<tr class='%s'><td><b>%s</b></td><td>%s</td><td class='num'>%s</td>"
                "<td class='verdict'>%s</td><td class='note'>%s</td></tr>"
                % (couleurs.get(verdict, ""), html.escape(nom), html.escape(sens),
                   html.escape(chiffre), html.escape(verdict), html.escape(note)))
        return "\n".join(lignes)

    def bloc_pistes():
        lignes = []
        for nom, statut, note in PISTES:
            lignes.append("<tr><td><b>%s</b></td><td class='statut'>%s</td><td class='note'>%s</td></tr>"
                          % (html.escape(nom), html.escape(statut), html.escape(note)))
        return "\n".join(lignes)

    def bloc_reel():
        if not vrai:
            return "<tr><td colspan='6'>REEL_EMPILE.md absent</td></tr>"
        lignes = []
        for p, l, r, s, n, R in sorted(vrai, key=lambda z: -z[5]):
            lignes.append("<tr><td>%s</td><td>%s</td><td>%d</td><td>%s</td><td class='num'>%d</td>"
                          "<td class='num %s'>%+.4f</td></tr>"
                          % (p, l, r, s, n, "ok" if R > 0 else "ko", R))
        return "\n".join(lignes)

    def bloc_lots():
        lignes = []
        for nom, n, c, det in lots:
            lignes.append("<tr><td>%s</td><td class='num'>%d</td><td class='num'>%d</td><td class='note'>%s</td></tr>"
                          % (html.escape(nom), n, c,
                             html.escape(", ".join(sorted({d[0] for d in det}))[:160])))
        return "\n".join(lignes)

    graphe = ""
    g = B / "graphify-out" / "graph.html"
    rapport = B / "graphify-out" / "GRAPH_REPORT.md"
    if g.exists():
        stat = []
        for ln in rapport.read_text(encoding="utf-8", errors="replace").splitlines()[:20]:
            if ln.startswith("- ") and ("nodes" in ln or "files" in ln):
                stat.append(ln[2:])
        graphe = ("<h2>7. La carte du code et des notes (graphify)</h2>"
                  "<p class='note' style='margin:0 34px 8px'>"
                  "<a href='graphify-out/graph.html'><b>Ouvrir la carte interactive "
                  "(graphify-out/graph.html)</b></a> &mdash; chaque point est un fichier, une fonction ou une "
                  "note ; les grappes montrent ce qui a ete ecrit et teste ENSEMBLE.</p>"
                  "<table><tr><th>Ce que la carte contient</th></tr>%s</table>"
                  % "".join("<tr><td class='note'>%s</td></tr>" % html.escape(x) for x in stat))

    page = """<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8">
<title>Carte du programme — portefeuille persistant</title>
<style>
 :root { --fond:#0e1117; --carte:#161b22; --bord:#26303d; --texte:#e6edf3; --gris:#8b949e;
         --vert:#3fb950; --rouge:#f85149; --orange:#d29922; --bleu:#58a6ff; }
 * { box-sizing:border-box; }
 body { margin:0; background:var(--fond); color:var(--texte);
        font:14px/1.5 "Segoe UI",system-ui,sans-serif; }
 header { padding:28px 34px 10px; border-bottom:1px solid var(--bord); }
 h1 { margin:0 0 6px; font-size:26px; letter-spacing:.2px; }
 h2 { margin:34px 34px 10px; font-size:19px; color:var(--bleu); }
 h3 { margin:22px 34px 6px; font-size:15px; color:var(--gris); font-weight:600; }
 .sous { color:var(--gris); margin:0 0 4px; }
 .kpis { display:flex; flex-wrap:wrap; gap:14px; padding:18px 34px 0; }
 .kpi { background:var(--carte); border:1px solid var(--bord); border-radius:10px; padding:14px 18px;
        min-width:180px; flex:1 1 180px; }
 .kpi b { display:block; font-size:24px; }
 .kpi span { color:var(--gris); font-size:12px; text-transform:uppercase; letter-spacing:.6px; }
 table { width:calc(100% - 68px); margin:0 34px 8px; border-collapse:collapse; background:var(--carte);
         border:1px solid var(--bord); border-radius:10px; overflow:hidden; }
 th, td { padding:9px 12px; text-align:left; border-bottom:1px solid var(--bord); vertical-align:top; }
 th { background:#1c232c; color:var(--gris); font-size:12px; text-transform:uppercase; letter-spacing:.5px; }
 tr:last-child td { border-bottom:none; }
 .num { text-align:right; font-variant-numeric:tabular-nums; }
 .note { color:var(--gris); font-size:12.5px; }
 .src, .statut { color:var(--gris); font-size:12px; }
 .cible { color:var(--bleu); }
 .ok { color:var(--vert); } .ko { color:var(--rouge); } .warn { color:var(--orange); }
 .verdict { font-weight:700; }
 tr.ok .verdict { color:var(--vert); } tr.ko .verdict { color:var(--rouge); }
 tr.warn .verdict { color:var(--orange); }
 td.ok { color:var(--vert); } td.ko { color:var(--rouge); }
 .bar { background:#222b36; border-radius:6px; height:9px; width:110px; overflow:hidden; }
 .bar i { display:block; height:100%; background:linear-gradient(90deg,#1f6feb,#58a6ff); }
 footer { color:var(--gris); padding:26px 34px 40px; font-size:12px; }
 a { color:var(--bleu); }
 code { background:#1c232c; padding:1px 5px; border-radius:4px; }
 .deux { display:flex; gap:20px; flex-wrap:wrap; padding:0 34px; }
 .deux > div { flex:1 1 380px; }
</style></head><body>
<header>
  <h1>Carte du programme — portefeuille persistant, prop, ordres reels</h1>
  <p class="sous">Objectif : <b>4 a 5 %/mois</b> avec <b>&ge; 70 % de chances de passer le prop</b>,
     regles prop seules, mesure sur <b>ordres reels</b> multi-annees. Tout ce qui suit est mesure par le
     moteur honnete (resolution a la minute, sortie a l'ask, premier toucher, horizon en barres).</p>
  <p class="sous">Source : corpus Dukascopy 2020-2025 (26 paires) + corpus etendu decode du feed
     (18 instruments, dont 13 indices) + campagnes en ordres reels.</p>
</header>

<div class="kpis">
  <div class="kpi"><span>Probabilite de passer (hors annee)</span><b>66,8 %</b><span>seuil : 70 %</span></div>
  <div class="kpi"><span>Rendement hors annee</span><b>+2,9 %/mois</b><span>cible : 4 a 5 %</span></div>
  <div class="kpi"><span>Pire annee hors annee</span><b>+6,29 %</b><span>6 annees sur 6 positives</span></div>
  <div class="kpi"><span>Jambes selectionnees</span><b>15</b><span>sur 180 candidates mesurees</span></div>
  <div class="kpi"><span>Ordres reels</span><b>1 / 15</b><span>EURCHF +0,0863 (330 tx)</span></div>
  <div class="kpi"><span>Positions simultanees</span><b>max 8</b><span>moyenne 2,1</span></div>
</div>

<h2>1. L'objectif, critere par critere</h2>
<table>
 <tr><th>Critere</th><th>Cible</th><th>Etat mesure</th><th>Avancement</th><th>Source</th></tr>
 ${objectif}
</table>

<h2>2. Les familles de signaux testees, et leur verdict</h2>
<p class="note" style="margin:0 34px 8px">Chaque ligne est un resultat du moteur honnete, pas une intuition :
le crible a balaye plus de 1 100 configurations (paires x plages x sens x cibles x horizons x familles).</p>
<table>
 <tr><th>Famille / reglage</th><th>Sens</th><th>Chiffre cle</th><th>Verdict</th><th>Pourquoi</th></tr>
 ${familles}
</table>

<h2>3. Le portefeuille retenu (selection par Sharpe mensuel)</h2>
<div class="deux">
 <div>
  <h3>Performances</h3>
  <table>
   <tr><th>Mesure</th><th>En echantillon</th><th>Hors annee</th></tr>
   <tr><td>Sharpe mensuel</td><td class="num">1,292</td><td class="num">0,621</td></tr>
   <tr><td>R/mois (budget de drawdown)</td><td class="num">+2,77 %</td><td class="num">+1,70 %</td></tr>
   <tr><td>Pire annee</td><td class="num ok">+22,03 %</td><td class="num ok">+6,29 %</td></tr>
   <tr><td>P(passe)</td><td class="num">75,5 %</td><td class="num">66,8 %</td></tr>
  </table>
 </div>
 <div>
  <h3>Pourquoi 15 jambes et pas 49</h3>
  <table>
   <tr><th>Composition</th><th>Jambes</th><th>P(passe)</th><th>Positions max</th></tr>
   <tr class="ko"><td>Trois vagues empilees</td><td class="num">49</td><td class="num">72,1 %</td><td class="num">27</td></tr>
   <tr><td>Une config par paire</td><td class="num">32</td><td class="num">73,3 %</td><td class="num">--</td></tr>
   <tr class="ok"><td><b>Selection par Sharpe</b></td><td class="num">15</td><td class="num">75,5 %</td><td class="num">8</td></tr>
  </table>
  <p class="note">Ajouter du volume correle (les seuils 0,90 et 0,97 d'une meme paire sont emboites) ne
     diversifie rien : cela grossit la position et le drawdown dans la meme proportion.</p>
 </div>
</div>

<h2>4. Ce qui a ete valide en ORDRES REELS</h2>
<table>
 <tr><th>Paire</th><th>Ligne</th><th>Plage</th><th>Sens</th><th>Transactions</th><th>R/tx</th></tr>
 ${reel}
</table>
<p class="note" style="margin:0 34px 8px">EURCHF SR97W20S a ete mesure dans la campagne du jour :
<b>+0,0863</b> pour un attendu de corpus de <b>+0,0828</b> &mdash; 0,0035 R/tx d'ecart, 5 annees positives
sur 6. C'est le deuxieme couple confirme a ce niveau de precision.</p>

<h2>5. La file du banc (ce qui est en cours de validation)</h2>
<table>
 <tr><th>Vague</th><th>Lots</th><th>Couples</th><th>Instruments</th></tr>
 ${lots}
</table>
<p class="note" style="margin:0 34px 8px">Un lot = un fichier de reglages a plusieurs lignes : le meme test
valide plusieurs jambes de la meme paire a la meme cible. La file complete compte 108 campagnes.</p>

<h2>6. Les portes ouvertes (a discuter ensemble)</h2>
<table>
 <tr><th>Piste</th><th>Statut</th><th>Ce qu'elle apporterait</th></tr>
 ${pistes}
</table>

${graphe}

<footer>
  Genere par <code>SCRIPTS\\carte_programme.py</code> a partir des rapports et des cribles du projet.
  Tous les chiffres de cette page sont mesures ; les seules hypotheses sont signalees dans les rapports
  (decote nulle des indices, non encore tranchee par le banc).
</footer>
</body></html>
"""
    page = string.Template(page).substitute(objectif=bloc_objectif(), familles=bloc_familles(),
                                            reel=bloc_reel(), lots=bloc_lots(), pistes=bloc_pistes(),
                                            graphe=graphe)

    SORTIE.write_text(page, encoding="utf-8")
    print("carte ecrite : %s (%d octets)" % (SORTIE, SORTIE.stat().st_size))
    print("  %d criteres | %d familles | %d jambes reelles | %d vagues de lots | %d pistes"
          % (len(OBJECTIF), len(FAMILLES), len(vrai), len(lots), len(PISTES)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
