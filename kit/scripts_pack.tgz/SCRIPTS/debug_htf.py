"""Debug : pourquoi htf_nest moteur donne 0 trades sur USDJPY 2024 ?
Vérifie les signaux bruts et les params."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
import polars as pl
import numpy as np
import datetime as dt
import edge_correct as ec
import deep_signals as DS

E = lambda s: int(dt.datetime.strptime(s, "%Y-%m-%d").timestamp())
m1 = ec.load_m1("USDJPY")
tf = ec.to_tf(m1, 1800)
print(f"USDJPY M30: {len(tf)} barres")

# signal htf_nest sur toute la période
for htf in [14400, 28800]:
    for lb in [20, 40]:
        cfg = dict(htf_sec=htf, lookback=lb, sl_atr=1.5, rr=99, pyramid_max=2,
                   pyramid_trigger_r=1.5, trail_atr_mult=3.5, trail_trigger_r=1.0)
        f = DS.htf_nest(tf, cfg)
        n_sig = int((f["sig"] != 0).sum())
        n_long = int((f["sig"] == 1).sum()); n_short = int((f["sig"] == -1).sum())
        print(f"htf={htf} lb={lb}: {n_sig} signaux (long={n_long} short={n_short})")
