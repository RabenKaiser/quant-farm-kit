﻿# -*- coding: utf-8 -*-
"""bande_stable.py -- Y A-T-IL UNE STRATEGIE STABLE DANS LA BANDE 1:1 a 1:6 ?

Lecture DIRECTE de lab_results.jsonl (donc mesures fraiches comprises), pas du
registre qui date du dernier cycle.

Critere de stabilite : TOUTES les fenetres mesurees positives, au moins 4
fenetres, au moins 25 transactions. Classement par la PIRE fenetre, jamais par
la moyenne.
"""
import collections
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
LIVE = r"C:\EAFarm\HISTORY - Copy\research\lab_results.jsonl"
# ROUND 130 (19/09, 18 h 50) -- LA PAIRE N'EST PLUS FIGEE.
# L'outil etait code sur EURUSD : le pivot multi-paires (USDCAD d'abord,
# puis EURJPY) ne pouvait pas s'en servir. On la choisit par l'environnement :
#     set LAB_SYM=USDCAD ; python SCRIPTS\bande_stable.py
SYM = os.environ.get("LAB_SYM", "EURUSD").strip().upper()
SL = [2, 3, 4, 6, 8, 12]
TP = [1, 2, 3, 4, 6, 8, 12, 24]

g = collections.defaultdict(dict)
n = 0
with open(LIVE, encoding="utf-8", errors="replace") as fh:
    for line in fh:
        if '"r_x7"' not in line:
            continue
        n += 1
        try:
            r = json.loads(line)
        except ValueError:
            continue
        if r.get("sym") != SYM or "|NONE|" in r.get("id", ""):
            continue
        if int(r.get("n", 0)) < 3:
            continue
        for i, sl in enumerate(SL):
            for j, tp in enumerate(TP):
                if not (1.0 * sl <= tp <= 6.0 * sl):
                    continue
                v = r.get("r_x%d" % (7 + i * len(TP) + j))
                if v is not None:
                    g[(r["id"], sl, tp)][str(r["period"])] = (float(v),
                                                              int(r["n"]))
print("lignes lues : %d | couples en bande : %d" % (n, len(g)))

ok = []
for (cid, sl, tp), d in g.items():
    if len(d) < 4:
        continue
    tx = sum(v[1] for v in d.values())
    if tx < 25:
        continue
    vals = [v[0] for v in d.values()]
    if min(vals) <= 0:
        continue
    ok.append((min(vals), sum(vals) / len(vals), len(d), tx, cid, sl, tp,
               sorted(d)))
ok.sort(key=lambda z: (-z[0], -z[3]))
print("couples STABLES en bande (toutes fenetres positives) : %d" % len(ok))
print()
print("   %-42s %-8s %-6s %5s %8s %8s %6s"
      % ("combinaison", "sortie", "ratio", "fen", "pire", "moyen", "tx"))
for mini, moy, nf, tx, cid, sl, tp, per in ok[:16]:
    print("   %-42s s%-2d/t%-2d %4.1f:1 %5d %+8.4f %+8.4f %6d"
          % (cid[:42], sl, tp, tp / float(sl), nf, mini, moy, tx))
print()
trois = [x for x in ok if abs(x[6] / float(x[5]) - 3.0) < 0.01]
print("   DONT RAPPORT EXACT 1:3 (%d couples) :" % len(trois))
for mini, moy, nf, tx, cid, sl, tp, per in trois[:10]:
    print("   %-42s s%-2d/t%-2d %5d fen %+8.4f (pire)  %d tx"
          % (cid[:42], sl, tp, nf, mini, tx))

