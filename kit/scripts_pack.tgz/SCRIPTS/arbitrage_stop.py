# -*- coding: utf-8 -*-
"""arbitrage_stop.py — TRANCHER : STOP SERRE OU STOP LARGE ?

LE PROBLEME (mesure round 63)
-----------------------------
  MFE median  ~5 ATR      MAE median ~5-8 ATR
  MFE p75    ~10 ATR      MAE p75   ~10-13 ATR

Le prix monte AUTANT qu'il descend : le rapport median est proche de 1.
Un stop serre (2 ATR) est touche presque toujours.
Un stop large (8 ATR) survit, mais 1 R = 8 ATR, donc un MFE de 5 ATR ne vaut
que 0,6 R. On ne gagne rien.

CE N'EST PAS UN PROBLEME DE STOP, C'EST UN PROBLEME DE TEMPS.
-------------------------------------------------------------
Le MFE croit avec le TEMPS de detention. A 48 barres on capture le MFE
precoce ; a 192 barres on capture la queue (mfeP75, voire plus).

DONC : la bonne question n'est pas "quel stop" mais
       "combien de temps faut-il tenir pour que le MFE depasse le MAE ?"

CE SCRIPT
---------
Rejoue les donnees M5 reelles et trace, pour chaque horizon de detention
(24, 48, 96, 192, 384, 576 barres), la distribution du MFE et du MAE.
On cherche l'horizon ou le rapport MFE/MAE franchit 1.5-2.0.

C'est LA mesure qui dit s'il faut tenir plus longtemps, ou abandonner.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")

HORIZONS = [24, 48, 96, 192, 384, 576, 768]
SYMS = ["CADJPY", "EURUSD", "GBPJPY", "AUDUSD", "USDCHF"]

# les declencheurs, en python (memes definitions que la sonde MQL5)
def masks(d):
    h = d["high"].to_numpy(float); l = d["low"].to_numpy(float)
    o = d["open"].to_numpy(float); c = d["close"].to_numpy(float)
    v = d["volume"].to_numpy(float)
    pc = np.roll(c, 1); pc[0] = c[0]
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    atr = pd.Series(tr).ewm(alpha=1/14, adjust=False).mean().to_numpy()
    M = {"atr": atr}
    M["FVGDN10"] = np.where(np.arange(len(c)) > 5,
                            h < (np.roll(l, 2) - 1.0 * atr), False)
    M["FVGDN20"] = np.where(np.arange(len(c)) > 5,
                            h < (np.roll(l, 2) - 2.0 * atr), False)
    # PINBULL : meche basse > 2 x corps et > 55 % du range
    body = np.abs(c - o); rng = h - l
    dnw = np.minimum(o, c) - l
    M["PINBULL"] = (rng > 0) & (dnw > 2.0 * body) & (dnw > 0.55 * rng)
    # REJBULL : cloture haussiere avec meche basse >= 50 % du corps
    M["REJBULL"] = (c > o) & (body > 0) & (dnw >= 0.5 * body)
    # CHOCHBEAR : cassure du plus bas des 10 barres, apres une barre haussiere
    lo10 = pd.Series(l).rolling(10).min().shift(1).to_numpy()
    hi10 = pd.Series(h).rolling(10).max().shift(1).to_numpy()
    M["CHOCHBEAR"] = (c < lo10) & (np.roll(c, 1) > np.roll(o, 1))
    M["CHOCHBULL"] = (c > hi10) & (np.roll(c, 1) < np.roll(o, 1))
    # SWEEPLO50 : balayage du plus bas des 50 barres puis cloture haussiere
    lo50 = pd.Series(l).rolling(50).min().shift(1).to_numpy()
    M["SWEEPLO50"] = (l < lo50) & (c > o)
    return M


def load_m5(sym):
    p = BASE / "m1_pos" / f"{sym}_M1.csv"
    if not p.exists():
        return None
    df = pd.read_csv(p, usecols=["time", "open", "high", "low", "close",
                                 "tick_volume"])
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time").sort_index()
    return pd.DataFrame({
        "open": df["open"].resample("5min").first(),
        "high": df["high"].resample("5min").max(),
        "low": df["low"].resample("5min").min(),
        "close": df["close"].resample("5min").last(),
        "volume": df["tick_volume"].resample("5min").sum()}).dropna()


def excursions(d, sig, horizon, atr):
    """MFE et MAE en multiples d'ATR, par trade, sur un horizon donne."""
    h = d["high"].to_numpy(float); l = d["low"].to_numpy(float)
    o = d["open"].to_numpy(float)
    N = len(o)
    mfe = []; mae = []
    for i in np.where(sig)[0]:
        e = i + 1
        if e + 2 >= N:
            continue
        a = atr[i]
        if not np.isfinite(a) or a <= 0:
            continue
        entry = o[e]
        kend = min(e + horizon, N)
        hi = h[e:kend].max() if kend > e else entry
        lo = l[e:kend].min() if kend > e else entry
        mfe.append((hi - entry) / a)
        mae.append((entry - lo) / a)
    return np.array(mfe), np.array(mae)


print("=" * 104)
print("ARBITRAGE : COMBIEN DE TEMPS FAUT-IL TENIR ? (MFE/MAE par horizon)")
print("=" * 104)
print()
print("Lecture : pour chaque horizon de detention, le MFE et le MAE MEDIANS.")
print("On cherche l'horizon ou MFE_median / MAE_median depasse 1.5.")
print()

TRIGS = ["FVGDN10", "PINBULL", "REJBULL", "SWEEP_LO50", "CHOCHBEAR"]

for trig in TRIGS:
    key = "SWEEPLO50" if trig == "SWEEP_LO50" else trig
    print(f"### {trig} ###")
    print(f"{'horizon':>8}{'heures':>8}{'n':>7}{'MFE_p50':>9}{'MAE_p50':>9}"
          f"{'MFE_p75':>9}{'MAE_p75':>9}{'ratio_p50':>10}{'ratio_p75':>10}")
    print("-" * 104)
    for hz in HORIZONS:
        M_all = []; A_all = []
        for sym in SYMS:
            d = load_m5(sym)
            if d is None or len(d) < 20000:
                continue
            M = masks(d)
            if key not in M:
                continue
            sig = M[key]
            if sig.sum() < 30:
                continue
            m, a = excursions(d, sig, hz, M["atr"])
            if len(m):
                M_all.append(m); A_all.append(a)
        if not M_all:
            continue
        M_all = np.concatenate(M_all); A_all = np.concatenate(A_all)
        mp50 = np.median(M_all); ap50 = np.median(A_all)
        mp75 = np.percentile(M_all, 75); ap75 = np.percentile(A_all, 75)
        r50 = mp50 / ap50 if ap50 > 0 else 0
        r75 = mp75 / ap75 if ap75 > 0 else 0
        print(f"{hz:>8}{hz*5/60:>7.0f}h{len(M_all):>7}{mp50:>9.2f}{ap50:>9.2f}"
              f"{mp75:>9.2f}{ap75:>9.2f}{r50:>10.2f}{r75:>10.2f}")
    print()

print("=" * 104)
print("CONCLUSION")
print("=" * 104)
print("  Si le ratio MONTE avec l'horizon -> il faut tenir plus longtemps.")
print("  S'il reste plat autour de 1    -> le declencheur n'a pas d'edge,")
print("                                    quelle que soit la duree.")
