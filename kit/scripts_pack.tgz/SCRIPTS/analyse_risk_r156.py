# -*- coding: utf-8 -*-
"""analyse_risk_r156.py — verdict validation sizing:
FIXED-0.5 +120 n94 | FIXED-3.6 invalide (marge) | RISK1pct -183 n105 |
RISK2pct -834 n103. Compare risque/trade reel en extrayant pires SL des logs."""
import json, sys, glob, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"

# trouver les runs: RISK1pct (V3INT_EA_RISK, bal~9817), RISK2pct (bal~9166)
for ea, bal0, tag in [("V3INT_EA_RISK", 9817.29, "RISK1pct"),
                      ("V3INT_EA_RISK", 9165.83, "RISK2pct")]:
    best = None
    for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-40:]:
        try:
            runs = F.parse_stream(lp, ea)
        except Exception:
            continue
        for key, data in runs.items():
            if "GBPJPY" not in key:
                continue
            closed = [t for t in data["trades"].values() if t["close"] is not None]
            if len(closed) < 90:
                continue
            b = data.get("balance") or 0.0
            if best is None or abs(b - bal0) < abs(best.get("d", 1e9)):
                best = {"d": abs(b - bal0), "trades": closed, "bal": b, "lp": lp}
    if best is None:
        print(tag, "pas trouve")
        continue
    losses = sorted([F.pnl_usd(t) for t in best["trades"] if F.pnl_usd(t) < 0])
    wins = [F.pnl_usd(t) for t in best["trades"] if F.pnl_usd(t) > 0]
    vols = sorted({round(t.get("vol", 0), 3) for t in best["trades"]})
    print(f"{tag}: bal={best['bal']:.0f} n={len(best['trades'])} "
          f"pireSL={losses[0]:+.0f} (sur depot 10000 = {losses[0]/10000*100:.1f}%) "
          f"| vols utilises: min={vols[0]} max={vols[-1]}")
    print(f"   SL top5: {[round(x) for x in losses[:5]]} | wins {len(wins)}")
print("FIN", flush=True)
