# -*- coding: utf-8 -*-
"""debug_extremes.py — affiche les trades extrêmes d'un log V45G."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

log = sys.argv[1]
runs = F.parse_stream(log, "V45G")
for key, trades in list(runs.items())[:1]:
    print("===", key)
    for tid, t in sorted(trades.items()):
        if t["close"] is None:
            continue
        if t["side"] == "buy":
            px = (t["close"] - t["entry"]) / 0.0001
        else:
            px = (t["entry"] - t["close"]) / 0.0001
        if abs(px) > 3000:
            print(f"#{tid} {t['side']} entry={t['entry']} close={t['close']} "
                  f"({t['ctype']}) px={px:.0f} modifs={len(t['modifs'])}")
