import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import polars as pl
from pathlib import Path

src = Path(r"C:\EAFarm\HISTORY\chunks\EURUSD_202203.csv")
lf = pl.scan_csv(
    src,
    schema_overrides={
        "Timestamp": pl.Utf8, "Bid price": pl.Float64, "Ask price": pl.Float64,
        "Bid volume": pl.Float64, "Ask volume": pl.Float64,
    },
    low_memory=True,
)
df = (
    lf.with_columns(
        pl.col("Timestamp").str.replace(r":(\d{3})$", r".$1").str.to_datetime("%Y%m%d %H:%M:%S%.f").alias("ts"),
        (pl.col("Ask price") - pl.col("Bid price")).alias("spread"),
    )
    .drop_nulls("ts")
    .filter((pl.col("spread") >= 0) & (pl.col("spread") <= 0.003))
    .with_columns(
        pl.col("ts").dt.weekday().alias("wd"),
        pl.col("ts").dt.hour().alias("hr"),
    )
    .collect()
)
print("total kept:", len(df))
print("spread==0 pct:", round((df["spread"] == 0).mean() * 100, 2))
q = df["spread"].quantile([0.01, 0.25, 0.5, 0.75, 0.9, 0.99])
print("spread quantiles (price):", [round(x, 6) for x in q])
print("spread quantiles (pts 1e-5):", [round(x / 1e-5, 1) for x in q])
print("\nweekday counts (1=Mon):", df.group_by("wd").agg(pl.len().alias("n")).sort("wd").to_dict(as_series=False))
# spread by hour on Wednesday only
wed = df.filter(pl.col("wd") == 3)
prof = wed.group_by("hr").agg(
    pl.col("spread").median().alias("med"),
    pl.col("spread").quantile(0.9).alias("p90"),
).sort("hr")
print("\nWednesday median spread pts by hour:")
print([(int(r["hr"]), round(r["med"] / 1e-5, 2), round(r["p90"] / 1e-5, 2)) for r in prof.iter_rows(named=True)])
