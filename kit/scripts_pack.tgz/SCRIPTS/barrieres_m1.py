"""barrieres_m1 : resolution HONNETE des barrieres, a la minute, avec le spread DE CHAQUE MINUTE.

Round 384. Le modele historique resout les barrieres sur les barres M30 avec UN SEUL spread par
paire (la mediane du corpus, `cout`) et compare le TP au PLUS BAS COURS DU BID. Deux erreurs
structurelles, et elles se paient exactement la ou le marche bouge :

  1. pour un SHORT la sortie se fait a l'ASK ; un plus-bas du bid qui touche le TP ne prouve RIEN si
     le spread du moment est large. Mesure du 25/04/2025 00:04 sur NZDUSD : bid 0,59717, spread
     340 points (34 pips), donc ask 0,60057 -- l'ordre reel est bien sorti a 0,60057, le TP du
     modele etait a 0,59788. Le bid a touche le TP, l'ASK JAMAIS ;
  2. le spread n'est pas une constante : sa mediane vaut 0,7 pip sur NZDUSD mais il monte a 34 pips
     au roulement quotidien (00:00 serveur), c'est-a-dire precisement pendant les heures ou cette
     strategie detient ses positions. Un spread constant median ne peut pas voir ce risque.

Ce module donne donc l'issue a la resolution de la MINUTE, avec le spread de la minute :

  sortie (short) a l'ASK = high/low de la minute + spread de la minute * point
  TP touche  si ask_bas  <= entree - 2 * ATR
  SL touche  si ask_haut >= entree + 1 * ATR
  premiere touche dans l'ordre des minutes, egalite dans la meme minute = stop (conservateur)
  a l'echeance, sortie a l'ask = close + spread

Le corpus M1 porte la colonne `spread` (en points) : c'est la meme donnee que celle du testeur,
verifiee au point sur le cas du 25/04/2025 (340 points dans le fichier, 34 pips dans l'ordre reel).
"""
from pathlib import Path

import numpy as np
import pandas as pd

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
COLS = ["time", "open", "high", "low", "close", "spread"]


def charge_m1(paire, source="m1_pos"):
    """Barres M1 + spread en PRIX (points x point de cotation) + le point."""
    f = B / source / ("%s_M1.csv" % paire)
    if not f.exists():
        return None
    d = pd.read_csv(f, usecols=COLS)
    dcl = d["close"].diff().abs()
    nzc = dcl[dcl > 0]
    if not len(nzc):
        return None
    pt = float(nzc.min())
    return dict(paire=paire, source=source, pt=pt,
                t=d["time"].values.astype("int64"),
                o=d["open"].values.astype(float), h=d["high"].values.astype(float),
                l=d["low"].values.astype(float), c=d["close"].values.astype(float),
                spr=d["spread"].values.astype(float) * pt)


def issue(D, t_entree, e, st, tpr=2.0, slr=1.0, hold_min=1920, sens="S", r_en_risque=True,
          par_barres=False, flat_hour=None, tz_off=2):
    """Issue d'une position ouverte a `t_entree` (secondes) au prix `e`, ATR `st`.

    RENVOIE R EN MULTIPLES DU RISQUE (et non en ATR) : cible = tpr/slr, stop = -1, echeance =
    deplacement / (slr * st). Au stop de 1 ATR les deux definitions coincident -- ce qui a masque
    l'erreur jusqu'au round 385 ; au stop de 3 ATR / cible 6 ATR elles diffèrent d'un facteur 3, et
    la table annoncait alors des R/tx trois fois trop gros. Les regles de mesure du projet disent
    « tout cout > 0,2 R est une erreur d'unite » : le R d'un portefeuille est le multiple du
    RISQUE, c'est donc cette definition qui fait foi pour tous les appelants.

    OPTION INTRADAY (directive utilisateur 07/10, 21 h 30 : « SEULEMENT intraday, ordre ferme a
    22 h ») : `flat_hour` force la fermeture de TOUTE position encore ouverte a la barre ou l'heure
    serveur atteint `flat_hour` (serveur = UTC + `tz_off` heures, defaut +2, l'heure MT5 typique).
    Renvoie alors kind = 3 (fermeture de session) avec le R d'echeance calcule au prix de cloture
    de la barre flat — exactement la convention de l'echeance (ask pour une sortie acheteuse).

    Renvoie (kind, R, prix_de_sortie, seconde_de_sortie) avec kind : 0 = cible, 1 = stop,
    2 = echeance, 3 = fermeture de session ; ou None si l'instant d'entree n'existe pas dans le
    corpus.
    """
    t = D["t"]
    i0 = int(np.searchsorted(t, t_entree))
    if i0 >= len(t) or t[i0] - t_entree > 60:
        return None
    # ROUND 388 : L'HORIZON DOIT SE COMPTER EN BARRES, PAS EN HEURES MURALES. L'EA detient
    # `InpHoldBars` barres de la trame (64 barres M30), et il les compte dans la DONNEE : un week-end
    # intercale ne consomme aucune barre, donc 64 barres peuvent couvrir 50 h de temps mural. Le
    # moteur, lui, s'arretait a 1920 minutes MURALES, donc plus tot des qu'un week-end tombait dans la
    # fenetre. Mesure du round 388 sur les deux couples disponibles : la poche « echeance » (le moteur
    # conclut a l'echeance, le reel a fini en stop ou en cible) contient exactement ces transactions --
    # 14/71 chez AUDCAD et 17/83 chez EURCHF, de duree reelle MEDIANE 50 h, dont 64-71 % au-dela de
    # 30 h. `par_barres=True` compte 1920 barres M1 de donnee (= 64 barres M30), comme l'EA.
    if par_barres:
        i1 = min(len(t), i0 + int(hold_min))
    else:
        i1 = int(np.searchsorted(t, t_entree + hold_min * 60, side="right"))
    if i1 <= i0:
        return None
    if sens == "S":
        # entree vendeuse au bid ; la sortie est un achat a l'ask
        ask_h = D["h"][i0:i1] + D["spr"][i0:i1]
        ask_b = D["l"][i0:i1] + D["spr"][i0:i1]
        lvl_tp = e - tpr * st
        lvl_sl = e + slr * st
        it = np.flatnonzero(ask_b <= lvl_tp)
        isl = np.flatnonzero(ask_h >= lvl_sl)
    else:
        # ROUND 384 : une ENTREE ACHETEUSE paie le spread des l'ouverture -- elle se fait a l'ask.
        # Sans cette ligne, toute jambe LONGUE serait mesuree avec une transaction gratuite, alors
        # que la jambe VENDEUSE, elle, encaisse le spread a la sortie.
        e = e + float(D["spr"][i0])
        # entree acheteuse a l'ask ; la sortie est une vente au bid
        bid_h = D["h"][i0:i1]
        bid_b = D["l"][i0:i1]
        lvl_tp = e + tpr * st
        lvl_sl = e - slr * st
        it = np.flatnonzero(bid_h >= lvl_tp)
        isl = np.flatnonzero(bid_b <= lvl_sl)
    kt = int(it[0]) if len(it) else 10 ** 9
    ks = int(isl[0]) if len(isl) else 10 ** 9
    # OPTION ANTI-ROLLOVER (precision utilisateur 07/10, 21 h 50 : « rather 22:30, avoid the
    # rollover, and it could reopen them like at 01:00 ») : la premiere barre de la fenetre dont
    # l'heure serveur atteint `flat_hour` (float, 22.5 = 22 h 30) force la fermeture (kind 3),
    # AVANT le rollover/swap. Le blocage des entrees pendant la pause (22:30 -> 01:00) se fait au
    # niveau du crible (fenetre d'entree [open_hour, flat_hour)), pas ici.
    kf = 10 ** 9
    if flat_hour is not None:
        mn_serveur = ((t[i0:i1].astype(np.int64) + int(tz_off) * 3600) % 86400) // 60
        jflat = np.flatnonzero(mn_serveur >= int(round(float(flat_hour) * 60)))
        if len(jflat):
            kf = int(jflat[0])
    # `r_en_risque=False` : R exprime en ATR et non en multiples du risque -- utile seulement quand
    # il n'y a PAS de barriere (cible et stop a 999 ATR, cas de derive_horizon.py), ou diviser par
    # slr n'aurait aucun sens.
    div = slr if r_en_risque else 1.0
    if kf < kt and kf < ks:
        j = i0 + kf
        if sens == "S":
            prix = float(D["c"][j] + D["spr"][j])
            return 3, ((e - prix) / st) / div, prix, int(t[j])
        prix = float(D["c"][j])
        return 3, ((prix - e) / st) / div, prix, int(t[j])
    if kt < ks:
        return 0, tpr / div, float(lvl_tp), int(t[ i0 + kt])
    if ks < 10 ** 9:
        return 1, -slr / div, float(lvl_sl), int(t[i0 + ks])
    j = i1 - 1
    if sens == "S":
        prix = float(D["c"][j] + D["spr"][j])
        return 2, ((e - prix) / st) / div, prix, int(t[j])
    prix = float(D["c"][j])
    return 2, ((prix - e) / st) / div, prix, int(t[j])


def charge_tf(paire, source="m1_pos", minutes=30, n=14):
    """Comme `charge_m30`, mais pour N'IMPORTE QUELLE TRAME (5, 15, 30, 60 minutes).

    ROUND 468. La trame etait jusqu'ici figee a 30 minutes : tout le laboratoire honnete -- ATR, cout en R,
    geometrie -- etait donc mesure sur M30, et une famille jugee sur M30 l'etait sans recours. Or un signal
    peut porter un edge en M15 et pas en M30 (ou l'inverse) : le cout en R vaut spread / (stop x ATR de la
    TRAME), et l'ATR change d'un facteur 2 entre M15 et M30. Cette fonction ouvre la mesure aux autres
    trames sans toucher a `charge_m30`, dont dependent tous les scripts existants.
    """
    D = charge_m1(paire, source)
    if D is None:
        return None
    d = pd.DataFrame({"t": pd.to_datetime(D["t"], unit="s"), "open": D["o"], "high": D["h"],
                      "low": D["l"], "close": D["c"], "spread": D["spr"]})
    d = d.set_index("t")
    b = d.resample("%dmin" % minutes).agg(o=("open", "first"), h=("high", "max"), l=("low", "min"),
                                          c=("close", "last"), sp_med=("spread", "median"),
                                          sp_max=("spread", "max")).dropna()
    if len(b) < 500:
        return None
    tr = pd.concat([b.h - b.l, (b.h - b.c.shift()).abs(), (b.l - b.c.shift()).abs()],
                   axis=1).max(axis=1)
    return dict(paire=paire, pt=D["pt"], idx=b.index, o=b.o.values, h=b.h.values,
                l=b.l.values, c=b.c.values, a=tr.rolling(n).mean().values,
                spr=b.sp_med.values, spx=b.sp_max.values, m1=D, minutes=minutes)


def charge_m30(paire, source="m1_pos", n=14):
    """Barres M30 (o,h,l,c) + ATR M30 + spread M30 (MEDIAN et MAX) en prix.

    Sert a garder le meme ATR et la meme geometrie que le modele historique, tout en donnant le
    spread reel de chaque barre pour les scripts qui ne descendent pas a la minute.
    """
    D = charge_m1(paire, source)
    if D is None:
        return None
    d = pd.DataFrame({"t": pd.to_datetime(D["t"], unit="s"), "open": D["o"], "high": D["h"],
                      "low": D["l"], "close": D["c"], "spread": D["spr"]})
    d = d.set_index("t")
    b = d.resample("30min").agg(o=("open", "first"), h=("high", "max"), l=("low", "min"),
                               c=("close", "last"), sp_med=("spread", "median"),
                               sp_max=("spread", "max")).dropna()
    if len(b) < 3000:
        return None
    tr = pd.concat([b.h - b.l, (b.h - b.c.shift()).abs(), (b.l - b.c.shift()).abs()],
                   axis=1).max(axis=1)
    return dict(paire=paire, pt=D["pt"], idx=b.index, o=b.o.values, h=b.h.values,
                l=b.l.values, c=b.c.values, a=tr.rolling(n).mean().values,
                spr=b.sp_med.values, spx=b.sp_max.values, m1=D)
