# -*- coding: utf-8 -*-
"""cost_check.py — VALIDATION du modele de cout corrige (R320).
Compare cost/risque calcule vs les valeurs MESUREES independamment :
  XAUUSD Dukascopy 5.9 % | XAUUSD Upcomers 2.5 % | GBPJPY 5.4 %
  NACUSD.c 3.8 % | SPCUSD.c 7.1 % | DJCUSD.c 4.0 % | XAGUSD 14.3 %
  AUDCAD 23.8 %
"""
import sys
import numpy as np
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G

REF = {"XAUUSD": 5.9, "U_XAUUSD": 2.5, "U_GBPJPY": 5.4, "U_NACUSD": 3.8,
       "U_SPCUSD": 7.1, "U_DJCUSD": 4.0, "U_XAGUSD": 14.3, "AUDCAD": 23.8}

SYMS = ["XAUUSD", "AUDUSD", "NZDUSD", "USDCAD", "AUDCAD",
        "U_XAUUSD", "U_XAGUSD", "U_GBPJPY", "U_NACUSD", "U_SPCUSD",
        "U_DJCUSD", "U_EURUSD", "U_USDJPY", "U_SWI20", "U_EURAUD"]

print("=" * 100)
print("VALIDATION DU MODELE DE COUT (corrige R320)")
print("=" * 100)
print(f"{'marche':12s} {'point':>8s} {'spread$':>10s} {'ATR15':>9s} "
      f"{'SP/ATR':>8s} {'(SP+2s)/ATR':>12s} {'MESURE':>8s} {'ecart':>8s}")
ok = 0; tot = 0
for s in SYMS:
    if s not in G.MK:
        continue
    try:
        F = G.get_frames(s)
    except Exception as e:
        print(f"{s:12s} ERREUR {e}")
        continue
    ps = F["ps"]
    SP = F["sp_units"] * ps
    a = float(np.nanmedian(F["a15i"]))
    if not np.isfinite(a) or a <= 0:
        a = float(np.nanmedian(F["m5"]["high"] - F["m5"]["low"]))
    sp_atr = SP / a * 100
    c_atr = (SP + 2 * ps) / a * 100
    ref = REF.get(s)
    if ref is not None:
        tot += 1
        d = sp_atr - ref
        good = abs(d) < max(1.5, 0.28 * ref)
        ok += good
        print(f"{s:12s} {ps:>8.5f} {SP:>10.5f} {a:>9.4f} "
              f"{sp_atr:>7.2f}% {c_atr:>11.2f}% {ref:>7.1f}% "
              f"{d:>+7.2f} {'OK' if good else '*** ECART ***'}")
    else:
        print(f"{s:12s} {ps:>8.5f} {SP:>10.5f} {a:>9.4f} "
              f"{sp_atr:>7.2f}% {c_atr:>11.2f}% {'-':>8s} {'-':>8s}")
print("=" * 100)
print(f"CONCORDANCE : {ok}/{tot} marches dans la tolerance")
print("\nRappel de la LOI DU PROJET : c est le rapport ATR/spread qui gouverne tout.")
print("Tout marche au-dessus de ~20 % de cout/risque est structurellement mort.")
print("\nFIN")
