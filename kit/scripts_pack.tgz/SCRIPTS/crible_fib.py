﻿# -*- coding: utf-8 -*-
"""crible_fib : la famille RETRACEMENT DE FIBONACCI -- le retour dans l'impulsion.

Round 541. La Market Map (MARKET_MAP_15.md) a montre OU le marche deplace : NY 13-15 pour les
indices, Londres 09-11 pour EURJPY, 15-17 pour l'or -- et OU il marche mort (03-06, 22:30-24).
La famille fib mesure le comportement STRUCTUREL classique : apres une impulsion (un swing ZigZag
de ZIG_ATR x ATR), le prix REVIENT sur 38.2 / 50 / 61.8 % du swing avant de poursuivre. L'entree
est le retest-causal : le niveau est connu des la confirmation du pivot (aucune anticipation),
le signal = la touche du niveau (TOCHE) ou la touche + cloture de retour dans le sens de l'impulsion
(RETOUR, la plus propre).

Causalite : le swing (p0 -> p1) n'est connu qu'a la CONFIRMATION du pivot p1 (ZigZag standard,
retard ZIG_ATR x ATR). Les niveaux fib sont figes a ce moment-la ; on ne redessine jamais.

Quatre niveaux x deux sens, meme evaluateur partage que les autres cribles (mesure_dir, offsets
par classe, n_pos/n_an par annee) : 38.2 / 50.0 / 61.8 en RETOUR, 38.2 en TOCHE.

Env : CORPUS=m1_ext TF_MIN=30 ZIG_ATR=3.0 ATR_N=14 TPRS=6,12 HOLD=64 PAIRES=... SORTIE=CRIBLE_FIB.csv
Sortie : CRIBLE_FIB.csv
"""
import csv
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
sys.path.insert(0, str(B / "SCRIPTS"))
import barrieres_m1 as BM  # noqa: E402
import crible_payoff as CP  # noqa: E402
import spread_barrieres as SB  # noqa: E402

CORPUS = os.environ.get("CORPUS", "m1_ext")
SORTIE = B / os.environ.get("SORTIE", "CRIBLE_FIB.csv")
TF_MIN = int(os.environ.get("TF_MIN", "30"))
ZIG_ATR = float(os.environ.get("ZIG_ATR", "3.0"))
ATR_N = int(os.environ.get("ATR_N", "14"))
TPRS = [float(x) for x in os.environ.get("TPRS", "6,12").split(",")]
HOLD = int(os.environ.get("HOLD", "64"))
PAIRES = [x for x in os.environ.get("PAIRES", "").split(",") if x]
HOUR_SCOPE = os.environ.get("HOUR_SCOPE", "")  # ex "13-15,15-17" : le signal n'est retenu que dans ces fenetres d'heure serveur
CLASSE = CP.CLASSE
OFFSETS = CP.OFFSETS

NIVEAUX = {"FIB38": 0.382, "FIB50": 0.5, "FIB618": 0.618}


def heures_barres(M):
    """Heure serveur de chaque barre (depuis l'epoch int64 du m30 ou l'index du charge_tf)."""
    if M.get("idx") is not None:
        return np.asarray(M["idx"].hour)
    t = M["t"]
    return pd.to_datetime(pd.Series(t), unit="s").dt.hour.values


def heures_autorisees(h: np.ndarray):
    """Masque des fenetres HOUR_SCOPE ; None = pas de filtre."""
    if not HOUR_SCOPE:
        return None
    mask = np.zeros(len(h), dtype=bool)
    for bloc in HOUR_SCOPE.split(","):
        a, _, b = bloc.partition("-")
        mask |= (h >= int(a)) & (h < int(b))
    return mask


def grille(paire):
    return BM.charge_m30(paire, CORPUS) if TF_MIN == 30 else BM.charge_tf(paire, CORPUS, minutes=TF_MIN)


def atr_serie(M):
    h, l, c = M["h"], M["l"], M["c"]
    tr = np.maximum(h - l, np.maximum(np.abs(h - np.roll(c, 1)), np.abs(l - np.roll(c, 1))))
    return pd.Series(tr).rolling(ATR_N, min_periods=ATR_N).mean().values


def zigzag(M, atr):
    """Pivots ZigZag causal (identique a crible_avwap) : (i_extreme, type, i_confirmation)."""
    c = M["c"]
    piv = []
    if len(c) < 50:
        return piv
    sens, extreme, i_ext = 1, c[0], 0
    for i in range(1, len(c)):
        a = atr[i]
        if not np.isfinite(a) or a <= 0:
            continue
        if sens == 1:
            if c[i] > extreme:
                extreme, i_ext = c[i], i
            elif extreme - c[i] > ZIG_ATR * a:
                piv.append((i_ext, 1, i))
                sens, extreme, i_ext = -1, c[i], i
        else:
            if c[i] < extreme:
                extreme, i_ext = c[i], i
            elif c[i] - extreme > ZIG_ATR * a:
                piv.append((i_ext, -1, i))
                sens, extreme, i_ext = 1, c[i], i
    return piv


def signaux_fib(M, atr, niveau, mode, sens):
    """Fib retracement causal : apres un swing confirme, le retour sur le niveau.

    Swing pour un achat : dernier pivot BAS confirme (p_lo) puis pivot HAUT confirme (p_hi) —
    l'impulsion montante est alors connue. Niveau = p_hi - ratio*(p_hi-p_lo). Signal L :
    TOCHE = low <= niveau ; RETOUR = low <= niveau et close >= niveau (retest tenu).
    Sens S : le miroir sur le swing descendant. Le niveau est fige a la confirmation du pivot.
    """
    c, h, l = M["c"], M["h"], M["l"]
    piv = zigzag(M, atr)
    if len(piv) < 2:
        return np.array([], dtype=int)
    sig = np.zeros(len(c), dtype=bool)
    # parcours des pivots consecutifs de types alternes : chaque paire (origine, extremite) = un swing
    seq = piv
    for k in range(1, len(seq)):
        (i0, t0, c0) = seq[k - 1]
        (i1, t1, c1) = seq[k]
        if sens == "L":
            # swing haussier : t0 == -1 (bas), t1 == +1 (haut)
            if t0 != -1 or t1 != 1:
                continue
            p_lo, p_hi = M["c"][i0], M["c"][i1]
            span = p_hi - p_lo
            if span <= 0:
                continue
            niveau_p = p_hi - niveau * span
            zone = slice(c1, min(len(c), c1 + HOLD * 3))
            if mode == "RETOUR":
                touch = (l[zone] <= niveau_p) & (c[zone] >= niveau_p)
            else:
                touch = l[zone] <= niveau_p
            loc = np.flatnonzero(touch) + c1
        else:
            if t0 != 1 or t1 != -1:
                continue
            p_hi, p_lo = M["c"][i0], M["c"][i1]
            span = p_hi - p_lo
            if span <= 0:
                continue
            niveau_p = p_lo + niveau * span
            zone = slice(c1, min(len(c), c1 + HOLD * 3))
            if mode == "RETOUR":
                touch = (h[zone] >= niveau_p) & (c[zone] <= niveau_p)
            else:
                touch = h[zone] >= niveau_p
            loc = np.flatnonzero(touch) + c1
        for i in loc:
            sig[i] = True
    idx = np.flatnonzero(sig)
    idx = idx[(idx >= ATR_N + 5) & (idx < len(c) - HOLD - 2)]
    if len(idx):
        hh = heures_barres(M)
        msk = heures_autorisees(hh)
        if msk is not None:
            idx = idx[msk[idx]]
    garde, dernier_i = [], -10 ** 9
    for i in idx:
        if i - dernier_i >= HOLD:
            garde.append(i)
            dernier_i = i
    return np.array(garde, dtype=int)


def main():
    pairs = PAIRES or sorted(p.name[:-7] for p in (B / CORPUS).glob("*_M1.csv"))
    print("%s : %d paires | trame %d min | ZigZag %.1f ATR | detention %d barres"
          % (CORPUS, len(pairs), TF_MIN, ZIG_ATR, HOLD))
    lignes = []
    for p in pairs:
        M = grille(p)
        if M is None:
            continue
        atr = atr_serie(M)
        cls = "INDICE" if p.endswith(".IDX") else CLASSE.get(p, "FX")
        for nom_niv, ratio in NIVEAUX.items():
            for mode in ("RETOUR", "TOCHE"):
                if nom_niv != "FIB38" and mode == "TOCHE":
                    continue  # TOCHE seulement sur 38.2 (les autres sont deja des retests profonds)
                for sens in ("L", "S"):
                    sig = signaux_fib(M, atr, ratio, mode, sens)
                    if len(sig) < 12:
                        continue
                    for tpr in TPRS:
                        SB.HOLD = HOLD
                        m = CP.mesure_dir(M, sig, sens, tpr)
                        if m is None or m["sd"] <= 0:
                            continue
                        off = OFFSETS[cls][0 if sens == "S" else 1]
                        att = m["R"] - off
                        theta = max(att, 0.0) ** 2 * m["n"] / m["sd"] ** 2 / 6.0
                        ok = att > 0 and m["n_pos"] >= (2.0 / 3.0) * m["n_an"]
                        fam = "%s_%s" % (nom_niv, mode)
                        lignes.append(dict(paire=p, famille=fam, sens=sens, tpr=tpr, n=m["n"], R=m["R"],
                                           sigma=m["sd"], gagn=m["gagn"], attendu=att, theta=theta,
                                           npos=m["n_pos"], nan=m["n_an"], retenu=ok,
                                           annees=" ".join("%d %+.2f" % (y, v) for y, v in m["ans"].items())))
                        if ok:
                            print("    %-14s %-15s %s n=%4.0fR att %+.4f gagn %4.1f%% npos %d nan %d"
                                  % (p, fam, sens, m["n"], att, m["gagn"], m["n_pos"], m["n_an"]), flush=True)
        del M
    if not lignes:
        print("  aucune mesure")
        return 1
    with SORTIE.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(lignes[0].keys()))
        w.writeheader()
        w.writerows(lignes)
    ret = [x for x in lignes if x["retenu"]]
    print("\n=== %d mesures | %d retenues ===" % (len(lignes), len(ret)))
    fams = sorted({x["famille"] for x in ret})
    for fam in fams:
        g = [x for x in ret if x["famille"] == fam]
        print("  %-14s %3d retenues | R/tx moy %+.4f | meilleur %+.4f (%s)"
              % (fam, len(g), sum(x["attendu"] for x in g) / len(g),
                 max(g, key=lambda x: x["attendu"])["attendu"],
                 max(g, key=lambda x: x["attendu"])["paire"]))
    print("-> %s" % SORTIE.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
