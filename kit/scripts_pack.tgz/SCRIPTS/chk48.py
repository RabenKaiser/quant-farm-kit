﻿import sys, numpy as np, gc
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT, deep_lib as D
G._cache.clear(); gc.collect()
F = G.get_frames("EURAUD"); m5,m1=F["m5"],F["m1"]
h1z,hh,ll,a1,gb,gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd,zlo,zhi = MT.project(m5.index,h1z,hh,ll,gb,gr,max_age_h=48)
M = NL.build(m5,F,zd,zlo,zhi); M.update(FE.more(m5,F,m1))
s = NL.sig(M, "big_bear", ["vol_lo"])
cand = np.nonzero(s)[0]
print(f"signaux             : {len(cand)}")
st = D.run_ex("EURAUD", s, 1.5, 99.0, 192, trail_atr=3.5,
              t0=m5.index[0], t1=m5.index[-1], use_m1=False)
print(f"trades python       : {st.get('n')}")
print(f"signaux ignores     : {len(cand)-st.get('n')} (par 'b0 <= last_exit')")
print()
# duree moyenne de detention
print("Duree de detention : hold=192 barres M5 = 16 h max")
print("Ecart median entre signaux : 264 barres M5 = 22 h")
print()
print("=> 264 > 192 : en MEDIANE les signaux sont assez espaces, mais les")
print("   groupes de signaux rapproches (ecart min = 1 barre) sont ignores.")
print()
print("COTE MT5 : la regle 'une position par magic' joue le MEME role, mais")
print("MT5 ferme sur maxhold en temps REEL (TimeCurrent - open_time), alors")
print("que python compte en BARRES. Un decalage d'1 barre suffit a changer")
print("le nombre de trades acceptes.")
