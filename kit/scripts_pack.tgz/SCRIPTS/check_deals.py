﻿"""Analyze ST5 deal history for range_fade: gross vs swap vs commission."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import csv, json
from pathlib import Path
import polars as pl

RESEARCH = Path(r"C:\EAFarm\HISTORY - Copy\research")
# ST5 writes deal history to trading_history_dir when NOT optimization mode.
# We ran in optimization mode; instead rerun quickly is heavy. Check logs dir.
import glob
files = glob.glob(str(RESEARCH / "st5_logs" / "*.log")) + glob.glob(str(RESEARCH / "st5_trades" / "**" / "*"), recursive=True)
for f in files[:20]:
    print(f, Path(f).stat().st_size)
