"""carry.py — ROUND 64 : LE CARRY EXPLIQUE-T-IL LA SEULE PERSISTANCE TROUVEE ?

POURQUOI CE TEST, ET RIEN D'AUTRE SUR FRED.

Nos mesures les plus persistantes sont le cote LONG des croisements JPY (EURJPY
+0,0199 -> +0,0425 ; GBPJPY +0,0167 -> +0,0198) et des indices. Acheter EURJPY,
c'est acheter de l'EUR et vendre du JPY : on encaisse le differentiel de taux.
Le carry est donc l'explication MECANIQUE candidate de cette persistance -- et
contrairement aux features de volatilite testees sans succes (Yang-Zhang,
Garman-Klass, Parkinson : 0,41 contre 0,58 pour l'ATR nu), elle est :
  - connaissable d'avance (un taux directeur ne se devine pas, il est publie),
  - NON REVISEE (un taux interbancaire est un prix, pas une statistique estimee).

CE DERNIER POINT EST DECISIF. C'est lui qui rend FRED utilisable ici sans biais
d'anticipation : on n'utilise AUCUNE serie revisee (pas de production
industrielle, pas de PIB, pas de chiffres d'emploi). Un taux 3 mois publie en
mars 2021 est le meme aujourd'hui qu'a l'epoque. Si un jour ce script se met a
lire des series estimees, il faudra passer par ALFRED (les millenismes) -- et
c'est exactement le genre d'erreur silencieuse qui a deja coute trois pannes au
projet.

PROTOCOLE, fixe avant resultat.
  1. Pour chaque paire, carry = taux(base) - taux(quote), mensuel.
  2. On classe les paires par carry MOYEN sur 2020-2023 (le passe connu).
  3. On mesure le R directionnel sur 2024-2026 dans le SENS DU CARRY POSITIF
     (acheter la devise qui paye), avec le moteur M30 deja valide : stop 2 ATR,
     objectif 6 ATR (1:3), 32 barres, cout deduit.
  4. Critere d'abandon, fixe d'avance : si le carry ne bat pas eff_range seule
     sur le meme decoupage, on jette le carry.

USAGE : python carry.py        (necessite le paquet fredapi et la cle dans
                                research\\.fred_key)
"""
import os, sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
B = Path(r"C:\EAFarm\HISTORY - Copy\research")
M1 = B / "m1_pos"
CLE = (B / ".fred_key").read_text().strip()

# Series OECD "3-month interbank rate", mensuelles. Un taux est un PRIX : non
# revise, donc utilisable sans ALFRED.
TAUX = {"USD": "IR3TIB01USM156N", "EUR": "IR3TIB01EZM156N",
        "JPY": "IR3TIB01JPM156N", "GBP": "IR3TIB01GBM156N",
        "AUD": "IR3TIB01AUM156N", "CAD": "IR3TIB01CAM156N",
        "CHF": "IR3TIB01CHM156N", "NZD": "IR3TIB01NZM156N"}
PAIRES = {"EURUSD": ("EUR", "USD"), "GBPUSD": ("GBP", "USD"),
          "AUDUSD": ("AUD", "USD"), "NZDUSD": ("NZD", "USD"),
          "USDCAD": ("USD", "CAD"), "USDCHF": ("USD", "CHF"),
          "EURGBP": ("EUR", "GBP"), "USDJPY": ("USD", "JPY"),
          "EURJPY": ("EUR", "JPY"), "GBPJPY": ("GBP", "JPY"),
          "AUDJPY": ("AUD", "JPY"), "CADJPY": ("CAD", "JPY"),
          "CHFJPY": ("CHF", "JPY")}
POINT = {"EURUSD": 1e-5, "GBPUSD": 1e-5, "AUDUSD": 1e-5, "NZDUSD": 1e-5,
         "USDCAD": 1e-5, "USDCHF": 1e-5, "EURGBP": 1e-5,
         "USDJPY": 1e-3, "EURJPY": 1e-3, "GBPJPY": 1e-3,
         "AUDJPY": 1e-3, "CADJPY": 1e-3, "CHFJPY": 1e-3}
HOLD, STOP_ATR, RR = 32, 2.0, 3.0
AN, RE = (2020, 2021, 2022, 2023), (2024, 2025, 2026)

try:
    from fredapi import Fred
except ImportError:
    print("fredapi n'est pas installe :  pip install fredapi")
    sys.exit(1)

fred = Fred(api_key=CLE)
print("=== LECTURE DES TAUX (series non revisees) ===")
taux = {}
for dev, code in TAUX.items():
    try:
        s = fred.get_series(code)
        s = pd.Series(s).dropna()
        s.index = pd.DatetimeIndex(s.index)
        taux[dev] = s
        print("   %-4s %-20s %4d points | %s -> %s"
              % (dev, code, len(s), s.index[0].date(), s.index[-1].date()))
    except Exception as e:
        print("   %-4s %-20s INDISPONIBLE (%s)" % (dev, code, str(e)[:60]))
if len(taux) < 4:
    print("\nTrop peu de series recuperees pour conclure.")
    sys.exit(1)


def charge(p):
    f = M1 / ("%s_M1.csv" % p)
    if not f.exists():
        return None
    d = pd.read_csv(f, usecols=["time", "high", "low", "close", "spread"])
    d["t"] = pd.to_datetime(d["time"], unit="s", utc=True)
    b = d.set_index("t").resample("30min").agg(
        high=("high", "max"), low=("low", "min"), close=("close", "last"),
        sp=("spread", "median")).dropna()
    tr = pd.concat([b.high - b.low, (b.high - b.close.shift()).abs(),
                    (b.low - b.close.shift()).abs()], axis=1).max(axis=1)
    b["atr"] = tr.rolling(14).mean()
    b = b.dropna()
    b.attrs["cout"] = float(d["spread"].median() or 0) * POINT[p] / float(b.atr.median())
    return b


def simule(b, sens):
    h, l, c, a = b.high.values, b.low.values, b.close.values, b.atr.values
    t = b.index
    n = len(b) - HOLD - 1
    idx = np.arange(20, n)
    at = a[idx]
    ok = at > 0
    idx, at = idx[ok], at[ok]
    off = np.arange(1, HOLD + 1)
    R, T = [], []
    for d0 in range(0, len(idx), 20000):
        ii = idx[d0:d0 + 20000]
        e = c[ii]
        stop = STOP_ATR * at[d0:d0 + 20000]
        H = h[ii[:, None] + off]
        L = l[ii[:, None] + off]
        if sens > 0:
            ht, hs = H >= (e + RR * stop)[:, None], L <= (e - stop)[:, None]
        else:
            ht, hs = L <= (e - RR * stop)[:, None], H >= (e + stop)[:, None]
        it = np.where(ht.any(1), ht.argmax(1), 10 ** 6)
        isl = np.where(hs.any(1), hs.argmax(1), 10 ** 6)
        cl = c[ii + HOLD]
        fin = (cl - e) / stop if sens > 0 else (e - cl) / stop
        R.append(np.where(it < isl, RR, np.where(isl < it, -1.0, fin)))
        T.append(t[ii])
    return np.concatenate(R), pd.DatetimeIndex(np.concatenate(T))


print("\n=== CARRY MOYEN 2020-2023 ET R DIRECTIONNEL 2024-2026 (sens du carry) ===")
print("%-7s | %8s | %8s | %9s | %9s | %s"
      % ("paire", "carry A", "carry B", "R/cout", "R net", "verdict"))
lignes = []
for p, (base, quote) in PAIRES.items():
    if base not in taux or quote not in taux:
        continue
    b = charge(p)
    if b is None:
        continue
    dif = (taux[base] - taux[quote]).dropna()
    ca = dif[(dif.index.year >= 2020) & (dif.index.year <= 2023)].mean()
    cb = dif[(dif.index.year >= 2024)].mean()
    sens = 1 if ca >= 0 else -1
    R, T = simule(b, sens)
    cout = b.attrs["cout"] / STOP_ATR
    rec = np.isin(T.year, RE)
    brut = R[rec].mean() - cout
    anc = R[np.isin(T.year, AN)].mean() - cout
    lignes.append((p, ca, cb, anc, brut, cout))
    print("%-7s | %+8.2f | %+8.2f | %+9.4f | %+9.4f | %s"
          % (p, ca, cb, anc, brut,
             "POSITIF" if brut > 0 else "negatif"))

print("\n=== LE CARRY SEPARE-T-IL ? ===")
if lignes:
    fort = [x for x in lignes if abs(x[1]) >= 1.0]
    faible = [x for x in lignes if abs(x[1]) < 1.0]
    for nom, g in (("carry fort (|carry| >= 1 %)", fort),
                   ("carry faible", faible)):
        if g:
            print("   %-28s %2d paires | R net moyen 2024-2026 %+.4f | positives %d/%d"
                  % (nom, len(g), np.mean([x[4] for x in g]),
                     sum(1 for x in g if x[4] > 0), len(g)))
    print("\n   CRITERE D'ABANDON (fixe d'avance) : si le carry ne bat pas eff_range")
    print("   seule sur ce meme decoupage 2020-2023 -> 2024-2026, on jette le carry.")
