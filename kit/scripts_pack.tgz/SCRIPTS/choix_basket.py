"""choix_basket : la bonne mesure -- le rendement A BUDGET DE DRAWDOWN FIXE.

Round 463. `prop_mixte.py` compare des compositions a RISQUE FIXE (0,25 % par transaction). C'est la
mauvaise comparaison : une composition qui ajoute 1 750 transactions de corpus fait mecaniquement
exploser le drawdown brut (17,8 % a 0,25 %) et parait donc hors regle prop -- alors qu'il suffit de
baisser le risque par transaction pour la ramener sous 5 %. Ce qui se compare, c'est le RENDEMENT
obtenu SOUS LA MEME CONTRAINTE : drawdown brut = 5 % (la coupe interne), pire annee positive.

Le raisonnement de composition reste mu/sigma2 (le rendement a drawdown impose croit comme mu^2/sigma2),
mais il faut le mesurer : on cherche le risque r tel que le drawdown brut vaille 5 %, puis on lit le
rendement mensuel et la pire annee A CE risque. Comme la courbe est composee, r est trouve par trois
iterations (le drawdown est quasi lineaire en r aux petits risques).

On ne melange PAS les sources : les jambes retenues sont celles MESUREES EN ORDRES REELS (reel_empile
.COMPOS, 12 couples). Les trois jambes de corpus du round 463 sont mesurees a part, comme candidates,
et leur suite perdante maximale (32, 28 et 62 R) dit deja ce qu'il faut en penser.

Usage : python SCRIPTS\\choix_basket.py [--toutes]
"""
import os
import pickle
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import barrieres_m1 as BM  # noqa: E402
import reel_empile as RE  # noqa: E402

SL_ATR = float(os.environ.get("SL_ATR", "3.0"))
HOLD = 64
GEOM = [6.0, 3.0, 1.0]
BUDGET = 0.05
CACHE = Path(r"C:\EAFarm\HISTORY - Copy\research\cache_jambes_%s.pkl" % SL_ATR)
JAMBES = list(RE.COMPOS)


def serie(paire, ligne, range_, sens, tpr, t0=None, t1=None):
    """R par transaction (en multiples du RISQUE) et instant de sortie, sur les instants REELS."""
    base = RE.mesure(paire, ligne, range_, sens)
    if base is None:
        return None
    M = BM.charge_m30(paire, "m1_pos")
    if M is None:
        return None
    idx, a, o, spr = M["idx"], M["a"], M["o"], M["spr"]
    ok = np.isfinite(a) & (a > 0)
    cout = (float(np.median(spr[ok]) / np.median(a[ok])) if ok.sum() >= 100 else 0.0) / SL_ATR
    ap = "L" if sens == "L" else "S"
    out = []
    for t in pd.to_datetime(base["times"]):
        if t0 is not None and not (t0 <= t <= t1):
            continue
        i = int(idx.searchsorted(t - pd.Timedelta(minutes=30)))
        if i >= len(idx) or abs((idx[i] - (t - pd.Timedelta(minutes=30))).total_seconds()) > 60:
            i -= 1
        if i < range_ + 1 or i + 1 + HOLD >= len(idx):
            continue
        st = float(a[i])
        if not np.isfinite(st) or st <= 0:
            continue
        r = BM.issue(M["m1"], int(idx[i + 1].timestamp()), float(o[i + 1]), st, tpr, SL_ATR,
                     HOLD * 30, sens, par_barres=True)
        if r is not None:
            out.append((t, r[1] - cout, int(r[3])))
    return out or None


def stats(ser):
    R = np.array([x[1] for x in ser])
    an = defaultdict(list)
    for t, x, _ in ser:
        an[t.year].append(x)
    sd = R.std(ddof=1)
    return dict(n=len(R), mu=R.mean(), sd=sd, mus2=R.mean() / sd ** 2 if sd > 0 else 0.0,
                npos=sum(1 for v in an.values() if np.mean(v) > 0), nan=len(an))


def charge():
    """Series par couple et par geometrie, avec cache."""
    if CACHE.exists():
        with CACHE.open("rb") as f:
            return pickle.load(f)
    cache = {}
    for paire, ligne, range_, sens in JAMBES:
        for g in GEOM:
            s = serie(paire, ligne, range_, sens, g)
            if s and len(s) >= 20:
                cache[(paire, ligne, range_, sens, g)] = s
    with CACHE.open("wb") as f:
        pickle.dump(cache, f)
    return cache


def courbe(ser, r):
    """Simulation prop : risque r (fraction), coupe -2,5 %/jour, courbe composee. Retourne (dd, mois, annee)."""
    cap, pic, dd, jour, jcap, mois, annee = 1.0, 1.0, 0.0, None, 0.0, defaultdict(float), defaultdict(float)
    for t, x, _ in sorted(ser, key=lambda z: z[0]):
        if jour != t.date():
            jour, jcap = t.date(), 0.0
        g = r * x
        if jcap + g < -0.025:
            g = -0.025 - jcap
        jcap += g
        cap *= (1 + g)
        pic = max(pic, cap)
        dd = max(dd, (pic - cap) / pic)
        mois[(t.year, t.month)] += g
        annee[t.year] += g
    return dd, (float(np.mean(list(mois.values()))) if mois else 0.0), (min(annee.values()) if annee else 0.0)


def a_budget(ser, budget=BUDGET):
    """Risque qui amene le drawdown brut au budget, puis (risque, R/mois, pire annee, dd, n concurrency)."""
    r = 0.0025
    for _ in range(4):
        dd, _, _ = courbe(ser, r)
        if dd <= 0:
            break
        r *= budget / dd
    dd, rm, pa = courbe(ser, r)
    return r, rm, pa, dd, bool(dd <= 1.05 * budget)


def simultane(ser):
    """Nombre maximal de positions ouvertes en meme temps (regle prop : positions simultanees limitees)."""
    ev = []
    for t, _, te in ser:
        ev.append((t, 1))
        ev.append((pd.Timestamp(te, unit="s"), -1))
    ev.sort()
    n = mx = 0
    for _, d in ev:
        n += d
        mx = max(mx, n)
    return mx


def main():
    cache = charge()
    garde = {}
    print("=== JAMBES (ordres reels) : geometrie choisie par mu/sigma2, >= 2/3 annees positives ===")
    print("%-20s %6s %8s %8s %8s %9s %6s" %
          ("jambe", "cible", "n", "R/tx", "R/mois", "pire an.", "simul."))
    for paire, ligne, range_, sens in JAMBES:
        cds = {g: cache[(paire, ligne, range_, sens, g)] for g in GEOM
               if (paire, ligne, range_, sens, g) in cache}
        if not cds:
            print("  %s r=%d %s : aucun ordre reel" % (paire, range_, sens))
            continue
        st = {g: stats(s) for g, s in cds.items()}
        ok = {g: v for g, v in st.items() if v["npos"] >= (2 * v["nan"]) / 3.0 and v["mu"] > 0}
        g = max(ok, key=lambda k: ok[k]["mus2"]) if ok else max(st, key=lambda k: st[k]["mus2"])
        nom = "%s r=%d %s" % (paire, range_, sens)
        r, rm, pa, dd, okk = a_budget(cds[g])
        garde[nom] = (g, cds[g])
        print("%-20s %6g %8d %+8.4f %+8.3f %+8.2f %6d  [risque %.3f %%]" %
              (nom, g, st[g]["n"], st[g]["mu"], 100 * rm, 100 * pa, simultane(cds[g]), 100 * r), flush=True)
    if not garde:
        print("  aucune jambe reelle")
        return 1

    def compo(noms):
        return [x for n in noms for x in garde[n][1]]

    print("\n=== A BUDGET DE DRAWDOWN 5 %% : composition ===")
    print("%-46s %5s %9s %9s %9s %6s" % ("composition", "tx", "risque/tx", "R/mois", "pire an.", "simul."))
    def ligne(nom, noms):
        s = compo(noms)
        if not s:
            return
        r, rm, pa, dd, okk = a_budget(s)
        print("%-46s %5d %8.3f %% %+8.2f %% %+8.2f %% %6d" %
              (nom, len(s), 100 * r, 100 * rm, 100 * pa, simultane(s)), flush=True)

    tous = list(garde)
    ligne("TOUTES les jambes reelles (%d)" % len(tous), tous)
    # glouton : on ajoute la jambe qui maximise le rendement mensuel a budget constant
    sel = []
    reste = list(tous)
    while reste:
        essais = []
        for n in reste:
            s = compo(sel + [n])
            r, rm, pa, dd, okk = a_budget(s)
            essais.append((rm, n, pa))
        rm, n, pa = max(essais)
        base = a_budget(compo(sel))[1] if sel else -9.9
        if rm <= base:
            break
        sel.append(n)
        reste.remove(n)
        ligne("  + %s" % n, sel)
    print("\n meilleure composition gloutonne : %s" % ", ".join(sel))
    r, rm, pa, dd, okk = a_budget(compo(sel))
    print("   %d tx | risque %.3f %% | R/mois %+.2f %% | drawdown %.2f %% | pire annee %+.2f %%"
          % (len(compo(sel)), 100 * r, 100 * rm, 100 * dd, 100 * pa))
    print("   regle prop (drawdown brut <= 5 %%, pire annee > 0) : %s"
          % ("SATISFAITE" if (dd <= 1.05 * BUDGET and pa > 0) else "non satisfaite"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
