﻿import MetaTrader5 as mt5
from datetime import datetime, timezone
mt5.initialize(path=r"C:\EAFarm\MT5\Farm\terminal64.exe")
syms = ["GBPUSD","EURUSD","AUDNZD","XAGUSD","EURJPY","EURAUD","GBPJPY",
        "USDCAD","XAUUSD","AUDUSD","NZDUSD","AUDCAD","USDCHF","EURGBP","NZDCAD"]
print(f"{'sym':<9}{'M1 dispo':>12}  {'debut':>12}  {'fin':>12}")
for s in syms:
    mt5.symbol_select(s, True)
    r = mt5.copy_rates_from_pos(s, mt5.TIMEFRAME_M1, 0, 5000000)
    n = 0 if r is None else len(r)
    if n:
        d0 = datetime.fromtimestamp(r[0][0], tz=timezone.utc).date()
        d1 = datetime.fromtimestamp(r[-1][0], tz=timezone.utc).date()
        print(f"{s:<9}{n:>12,}  {str(d0):>12}  {str(d1):>12}")
    else:
        print(f"{s:<9}{'0':>12}")
mt5.shutdown()
