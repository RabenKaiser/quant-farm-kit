# -*- coding: utf-8 -*-
"""audit_sl_r43.py — pire trade reel (SL) par leg aux lots presets deploy.
Equity rescalees au reel: pnl_0.1lot_reel = parse x k (k calcule du balance).
On retrouve le run reel par dates (comme rescale_all) et le pire SL parse x k
x lots/0.1 -> pire perte deploy $ et %."""
import sys, glob, os
import pandas as pd
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
TEAM = r"C:\EAFarm\HISTORY - Copy\research\prop_team\equities"
ACCT = 50000.0
LEGS = {"EURUSD": ("equity_UPC-V3INT-EURUSD.csv", 1.9, "V3INT", ["EURUSD"]),
        "GBPJPY": ("equity_UPC-V3INT-GBPJPY.csv", 2.4, "V3INT", ["GBPJPY"]),
        "NZDJPY": ("equity_UPC-V3INT-NZDJPY.csv", 1.1, "V3INT", ["NZDJPY"]),
        "AUDUSD": ("equity_UPC-V3INT-AUDUSD.csv", 2.3, "V3INT", ["AUDUSD"]),
        "NZDUSD": ("equity_UPC-V3INT-NZDUSD.csv", 2.4, "V3INT", ["NZDUSD"]),
        "CROSS-EURGBP": ("equity_UPC-CROSS-EURGBP.csv", 20.0, "V3INT", ["EURGBP"]),
        "GBPUSD-620": ("equity_UPC-GBPUSD-620.csv", 1.6, "V3INT", ["GBPUSD"]),
        "DOW": ("equity_UPC-DOW.csv", 0.5, "V3INT", ["DJCUSD"]),
        "SPX": ("equity_UPC-SPX.csv", 1.4, "V3INT", ["SPCUSD"]),
        "FRCEUR": ("equity_UPC-FRCEUR.csv", 1.7, "V3INT", ["FRCEUR"]),
        "VWAPF-XAU": ("equity_UPC-VWAPF-XAU.csv", 0.1, "VWAPFADE", ["XAUUSD"]),
        "VWAPT-XAU": ("equity_UPC-VWAPT-XAU.csv", 0.1, "VWAPTREND", ["XAUUSD"])}

# collect runs par (EA, sym)
runs = {}
for EA in ("V3INT", "VWAPFADE", "VWAPTREND"):
    for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-120:]:
        try:
            rs = F.parse_stream(lp, EA)
        except Exception:
            continue
        for key, data in rs.items():
            if "20260101" not in key.replace(".", ""):
                continue
            closed = [t for t in data["trades"].values() if t["close"] is not None]
            if len(closed) < 3:
                continue
            sym = (closed[0].get("sym") or "").split(".")[0].upper()
            days = sorted({str(t["ts_entry"])[:10].replace(".", "-")
                           for t in closed})
            runs.setdefault((EA, sym), []).append(
                {"days": days, "bal": data.get("balance") or 0.0,
                 "trades": closed, "n": len(closed)})

print(f"{'leg':13s} {'lots':>6s} {'pireSL$':>9s} {'pct':>6s} | SLmoy$ {'pct':>6s} "
      f"| nSL  win%")
for tag, (fn, lots, EA, syms) in LEGS.items():
    csvp = os.path.join(TEAM, fn)
    x = pd.read_csv(csvp, index_col=0, parse_dates=True).iloc[:, 0]
    csvdays = sorted({d.strftime("%Y-%m-%d") for d in x[x != 0].index})
    cset = set(csvdays)
    best = None
    for sym in syms:
        for c in runs.get((EA, sym), []):
            cs = set(c["days"])
            cov = len(cset & cs) / max(len(cset), 1)
            if best is None or cov > best["cov"]:
                best = {"cov": cov, **c}
    if best is None or best["cov"] < 0.85:
        print(f"{tag:13s} pas de run fiable (cov={best and best['cov']})")
        continue
    reel = best["bal"] - 10000.0
    # k par trade: parse -> reel uniforme
    parse_tot = sum(F.pnl_usd(t) for t in best["trades"])
    k = reel / parse_tot if parse_tot != 0 else 1.0
    losses = [F.pnl_usd(t) for t in best["trades"] if F.pnl_usd(t) < 0]
    wins = [F.pnl_usd(t) for t in best["trades"] if F.pnl_usd(t) > 0]
    mult = lots / 0.10
    psl = (min(losses) if losses else 0.0) * k * mult
    asl = (sum(losses) / len(losses) if losses else 0.0) * k * mult
    wr = len(wins) / len(best["trades"]) * 100
    print(f"{tag:13s} {lots:6.1f} {psl:+9.0f} {psl/ACCT*100:5.2f}% | "
          f"{asl:+7.0f} {asl/ACCT*100:5.2f}% | "
          f"{len(losses):3d}  {wr:.0f}%")
print("FIN", flush=True)
