# -*- coding: utf-8 -*-
"""check base volume EURGBP run."""
import sys, glob, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
found = 0
for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-60:]:
    try:
        runs = F.parse_stream(lp, "V3INT")
    except Exception:
        continue
    for key, data in runs.items():
        if "20260101" not in key.replace(".", "") or "EURGBP" not in key:
            continue
        closed = [t for t in data["trades"].values() if t["close"] is not None]
        if len(closed) != 15:
            continue
        vols = sorted({round(t.get("volume", 0), 2) for t in closed})
        print(f"{os.path.basename(lp)} | {key} | bal={data.get('balance'):.0f} | vols={vols}")
        for t in closed[:4]:
            print("   ", {k: t.get(k) for k in ("volume", "pnl", "price_entry", "price_close", "profit", "ts_entry", "ts_close")})
        found += 1
        if found >= 2:
            sys.exit(0)
print("fin, found", found)
