# -*- coding: utf-8 -*-
"""EVT sur le MAE des trades PTRAIL (GBPUSD) : extrait les trades réels du log,
calcule le MAE (excursion adverse) de chaque trade, et calibre le stop optimal
via la loi de Pareto généralisée (GPD). But : réduire le DD sans tuer l'edge."""
import re, json
import numpy as np
from scipy.stats import genpareto

LOG = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs\20260824.log"
with open(LOG, "rb") as fh:
    t = fh.read().decode("utf-16-le", errors="replace")

# run PTRAIL GBPUSD 2023 (qualité 100%)
pat = re.compile(r"GBPUSD,\w+[^\r\n]*?testing of Experts\\PTRAIL_LONG\.ex5 from 2023\.01\.01 00:00 to 2024\.01\.01 00:00")
hits = [m.start() for m in pat.finditer(t)]
idx = hits[-1]
nxt = t.find("testing of", idx + 100)
seg = t[idx:(nxt if nxt > idx else min(idx + 6_000_000, len(t)))]

# entrées: "deal #N buy VOL GBPUSD at P done"
entries = {}
for mm in re.finditer(r"(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s+deal #(\d+) (buy|sell) ([\d.]+) GBPUSD at ([\d.]+) done", seg):
    entries[int(mm.group(2))] = (mm.group(3), float(mm.group(4)), float(mm.group(5)))

# sorties: "stop loss triggered #N ... [#M sell VOL GBPUSD at P]"
trades = []
for mm in re.finditer(r"(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s+stop loss triggered #(\d+) [^\r\n]*?\[#\d+ (buy|sell) ([\d.]+) GBPUSD at ([\d.]+)\]", seg):
    tm, tk, cdir, cvol, cpx = mm.group(1), int(mm.group(2)), mm.group(3), float(mm.group(4)), float(mm.group(5))
    if tk in entries:
        edir, evol, eprice = entries[tk]
        # R = |stop - entry| (stop = prix de sortie SL)
        R = abs(cpx - eprice)
        # MAE approx = distance maximale adverse = R (le SL est touché) pour les perdants
        # pour les gagnants (trailing), le SL n'est pas touché -> on ne peut pas mesurer le MAE exact
        trades.append({"entry": eprice, "exit": cpx, "dir": edir, "vol": evol, "R": R, "is_sl": True})

print(f"trades SL parsés (GBPUSD 2023): {len(trades)}")
if not trades:
    raise SystemExit

# distribution des R (distances stop) en % du prix
Rs = np.array([t["R"] / t["entry"] for t in trades])
print(f"R/prix: mediane={np.median(Rs)*1e4:.1f} pips, p90={np.percentile(Rs,90)*1e4:.1f} pips")

# MAE théorique : pour les trades SL, le MAE = R (le prix a touché le stop)
# EVT : fit GPD sur la queue des R
mae = Rs * 1e4   # en pips
u = np.percentile(mae, 80)
exc = mae[mae > u] - u
if len(exc) >= 20:
    xi, loc, sigma = genpareto.fit(exc, floc=0)
    p_u = np.mean(mae > u)
    print(f"\nEVT sur MAE (pips): seuil u={u:.1f}, xi={xi:.3f}, sigma={sigma:.2f}, P(MAE>u)={p_u:.3f}")
    # P(stop hit) pour différents stops
    print("\nCalibrage du stop (P que le MAE dépasse le stop) :")
    for stop_pips in [10, 15, 20, 25, 30, 40]:
        if stop_pips <= u:
            p = np.mean(mae >= stop_pips)
        else:
            p = p_u * genpareto.sf(stop_pips - u, c=xi, loc=0, scale=sigma)
        print(f"  stop {stop_pips:>3} pips: P(hit) = {p:.3f}")
else:
    print("pas assez d'excédents pour EVT")

# le stop actuel de PTRAIL = 1.5 ATR. Calculons l'ATR H1 moyen GBPUSD 2023
# (approx : R median = 1.5*ATR -> ATR ~ R/1.5)
atr_est = np.median(Rs) * 1e4 / 1.5
print(f"\nATR H1 estimé (GBPUSD): {atr_est:.1f} pips (stop actuel 1.5*ATR = {atr_est*1.5:.1f} pips)")
