"""etude_sortie : d'ou vient reellement l'esperance - de l'objectif, du stop, ou de la sortie a l'echeance ?

Constat du round 258 qui motive ce script : en ORDRES REELS, MT5 (EURUSD 2024Q1 -191,80,
GBPJPY -923,38, AUDUSD -628,19, USDCHF -651,48) est negatif partout, alors que le MEME motif
est positif en Python sur le corpus long. La difference connue : le modele Python garde la
position 32 barres M30 et sort AU MARCHE a l'echeance, alors que le chemin ordres reels de
l'EA n'a aucune sortie a l'echeance (InpHoldBars n'existe que dans le chemin de mesure) et
ne sort que par SL ou TP.

Ce script decompose donc chaque jambe en trois issues (objectif touche / stop touche /
sortie au marche a l'echeance) et balaie la detention et la geometrie. Si l'esperance vit
dans la troisieme colonne, alors tout le reste (le motif, le stop, l'objectif) n'est qu'un
support, et c'est la SORTIE qu'il faut porter dans MT5.
"""
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM

B = Path(r"C:\EAFarm\HISTORY - Copy\research")


def evald(D, sig, side, H, sl_atr=1.0, tp_r=1.0):
    """R + type d'issue. 0 = objectif, 1 = stop, 2 = echeance (sortie au marche)."""
    c, h, l, a = D["c"], D["h"], D["l"], D["a"]
    sig = np.asarray(sig, dtype=int)
    sig = sig[sig < len(c) - H - 2]
    sig = sig[np.isfinite(a[sig]) & (a[sig] > 0)]
    if len(sig) < 60:
        return None
    e, st = c[sig], a[sig] * sl_atr
    tp, sl = (e - tp_r * st, e + st) if side < 0 else (e + tp_r * st, e - st)
    off = np.arange(1, H + 1)
    Hh = h[sig[:, None] + off]
    Ll = l[sig[:, None] + off]
    cl = c[sig + H]
    htp = (Ll <= tp[:, None]) if side < 0 else (Hh >= tp[:, None])
    hsl = (Hh >= sl[:, None]) if side < 0 else (Ll <= sl[:, None])
    it = np.where(htp.any(1), htp.argmax(1), 10 ** 6)
    isl = np.where(hsl.any(1), hsl.argmax(1), 10 ** 6)
    fin = ((e - cl) if side < 0 else (cl - e)) / st
    # BUG corrige (round 259) : quand NI l'objectif NI le stop n'est touche, les deux
    # sentinelles valent 10**6 et `isl <= it` etait VRAI -> la transaction etait notee
    # -1 R au lieu de sa sortie au marche. La branche "echeance" etait inatteignable.
    tp_hit, sl_hit = htp.any(1), hsl.any(1)
    kind = np.where(tp_hit & (~sl_hit | (it < isl)), 0, np.where(sl_hit, 1, 2))
    R = np.where(kind == 0, tp_r, np.where(kind == 1, -1.0, fin)) - D["cout"]
    ok = np.isfinite(R)
    return R[ok], kind[ok]


def ligne(D, sig, side, H, sla, tpr):
    r = evald(D, sig, side, H, sla, tpr)
    if r is None:
        return None
    R, k = r
    m = [R[k == i] for i in (0, 1, 2)]
    return dict(n=len(R), moy=float(np.mean(R)),
                ptp=100.0 * len(m[0]) / len(R), psl=100.0 * len(m[1]) / len(R),
                pfin=100.0 * len(m[2]) / len(R),
                rtp=float(np.mean(m[0])) if len(m[0]) else 0.0,
                rsl=float(np.mean(m[1])) if len(m[1]) else 0.0,
                rfin=float(np.mean(m[2])) if len(m[2]) else 0.0,
                contrib_fin=float(np.sum(m[2]) / len(R)))


def main():
    source = os.environ.get("SOURCE", "m1_pos")
    legs = [x for x in os.environ.get("LEGS", "").split(",") if x]
    if not legs:
        legs = ["EURCHF:SR100:C", "EURCHF:RSI14:C", "GBPCHF:SR50:C", "EURJPY:SR100:C",
                "EURGBP:SR50:C", "USDCHF:SR50:C"]
    print("SOURCE=%s | %d jambes" % (source, len(legs)), flush=True)
    lignes = ["# D'ou vient l'esperance : objectif, stop ou echeance ? - corpus %s" % source, "",
              "Chaque ligne : trades, R/tx moyen, part et R moyen de chaque issue. "
              "`contrib fin` = R/tx apporte par la SEULE sortie a l'echeance (part x R moyen) : "
              "si ce nombre porte l'esperance totale, c'est la sortie au marche qui fait le motif.", "",
              "| jambe | hold | stop | cible | trades | R/tx | % objectif | % stop | % echeance | R/objectif | R/stop | R/echeance | contrib echeance |",
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for leg in legs:
        paire, motif, sens = leg.split(":")
        D = NM.charge(paire, source)
        if D is None:
            print("  %-22s ECARTEE (donnees/cout)" % leg, flush=True)
            continue
        m = NM.motifs(D)
        if motif not in m:
            print("  %-22s motif inconnu" % leg, flush=True)
            continue
        sig = m[motif][0 if sens == "C" else 1]
        side = -1 if sens == "C" else 1
        print("\n=== %s (%s %s) | cout %.4f R" % (leg, paire, motif, D["cout"]), flush=True)
        for (sla, tpr, hold) in [(1.0, 1.0, 4), (1.0, 1.0, 8), (1.0, 1.0, 16), (1.0, 1.0, 32),
                                 (1.0, 1.0, 64), (1.0, 1.0, 128),
                                 (1.0, 2.0, 16), (1.0, 2.0, 32), (1.0, 2.0, 64),
                                 (1.5, 1.0, 32), (1.5, 1.0, 64),
                                 (10.0, 10.0, 16), (10.0, 10.0, 32), (10.0, 10.0, 64)]:
            x = ligne(D, sig, side, hold, sla, tpr)
            if x is None:
                continue
            print("    hold %3d stop %.1f cible %.1f | n=%5d R/tx %+.4f | obj %4.1f%% (%+.2f) | stop %4.1f%% (%+.2f) | ech %4.1f%% (%+.2f) | contrib fin %+.4f"
                  % (hold, sla, tpr, x["n"], x["moy"], x["ptp"], x["rtp"], x["psl"], x["rsl"],
                     x["pfin"], x["rfin"], x["contrib_fin"]), flush=True)
            lignes.append("| %s | %d | %.1f | %.1f | %d | %+.4f | %.1f %% | %.1f %% | %.1f %% | %+.2f | %+.2f | %+.2f | %+.4f |"
                          % (leg, hold, sla, tpr, x["n"], x["moy"], x["ptp"], x["psl"], x["pfin"],
                             x["rtp"], x["rsl"], x["rfin"], x["contrib_fin"]))
    out = B / ("ETUDE_SORTIE_%s.md" % source)
    out.write_text("\n".join(lignes), encoding="utf-8")
    print("\necrit %s" % out, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
