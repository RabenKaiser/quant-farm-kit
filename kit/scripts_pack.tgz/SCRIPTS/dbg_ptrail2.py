"""Diagnostic final : combien de barres H4 CopyRates retourne-t-il vraiment ?
Version debug avec Print du nombre de barres H4 obtenues."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner as m

SRC = r"C:\EAFarm\HISTORY - Copy\research\EAs\USDJPY_M30_PTRAIL.mq5"
DST = r"C:\EAFarm\MT5\Farm\MQL5\Experts\USDJPY_M30_PTRAIL_DBG2.mq5"

src = open(SRC, encoding="utf-8").read()
debug = """int _d1=0;
void OnTick(){
   _d1++;
   if(_d1<=3){
      MqlRates _r4[];
      ArraySetAsSeries(_r4, true);
      int _g = CopyRates(_Symbol, PERIOD_H4, 0, 300, _r4);
      Print("DBG H4 got=",_g," (besoin 202) ticks=",_d1);
      MqlRates _r30[];
      ArraySetAsSeries(_r30, true);
      int _g30 = CopyRates(_Symbol, PERIOD_M30, 0, 60, _r30);
      Print("DBG M30 got=",_g30);
   }
"""
src = src.replace("void OnTick(){", debug, 1)
open(DST, "w", encoding="utf-8").write(src)
print("debug2 écrit")

ok, ex5, tail = m.compile_ea(DST)
print("compile:", "OK" if ok else "ECHEC")
if ok:
    r = m.run_backtest("USDJPY_M30_PTRAIL_DBG2", "USDJPY", "M30",
                       "2023.01.01", "2023.02.01", 10000)
    print("profit:", r.get("profit"), "trades:", r.get("trades"))
