# -*- coding: utf-8 -*-
"""AXE QUANT AVANCÉ — banc de test sur données réelles (COPY, 2026-08-24).
Vérifie chaque brique du document de référence : est-ce "goo" (edge réel)
sur EURUSD Dukascopy M15/M1 ?
  1. DC/OS (Olsen)      : loi d'échelle <OS>≈delta ? + edge de retour d'overshoot
  2. Rough vol (Hurst)  : H≈0.1 sur log-vol ? (régime anti-persistant)
  3. Hawkes n           : ratio de branchement (régime critique n>0.85)
  4. FFD                : différenciation fractionnaire (stationnarité+ mémoire)
  5. EVT sur MAE        : fit GPD des excursions -> P(stop hit) calibrée
  6. VPIN               : toxicité flux d'ordres (vol_up/down) -> prédit retours ?
  7. WFC                : corrélation IS/OOS des résultats FORGE existants
Verdict GO / NO-GO par brique, basé sur le pouvoir prédictif MESURÉ.
"""
import sys, json, os
import numpy as np
import pandas as pd

BASE = r"C:\EAFarm\HISTORY - Copy\research"
os.makedirs(os.path.join(BASE, "night_results"), exist_ok=True)
OUT = os.path.join(BASE, "night_results", "axe_quant.jsonl")
def jl(d):
    with open(OUT, "a", encoding="utf-8") as f:
        f.write(json.dumps(d, ensure_ascii=False) + "\n")

def hr():
    print("=" * 78)

# ---------------------------------------------------------------------------
# 1. DC / OS (Olsen & Glattfelder)
# ---------------------------------------------------------------------------
def compute_dc_os(prices, delta):
    events = []
    mode = 0
    ext_price = prices[0]
    dc_price = prices[0]
    dc_idx = 0
    for i in range(1, len(prices)):
        p = prices[i]
        if mode == 0:
            if p >= ext_price * (1 + delta):
                mode = 1; ext_price = p; dc_price = p; dc_idx = i
                events.append(('DC_UP', i, p, 0.0))
            elif p <= ext_price * (1 - delta):
                mode = -1; ext_price = p; dc_price = p; dc_idx = i
                events.append(('DC_DOWN', i, p, 0.0))
        elif mode == 1:
            if p > ext_price:
                ext_price = p
            elif p <= ext_price * (1 - delta):
                os_val = (ext_price - dc_price) / dc_price
                events.append(('OS_UP', dc_idx, ext_price, os_val))
                mode = -1; ext_price = p; dc_price = p; dc_idx = i
                events.append(('DC_DOWN', i, p, 0.0))
        elif mode == -1:
            if p < ext_price:
                ext_price = p
            elif p >= ext_price * (1 + delta):
                os_val = (dc_price - ext_price) / dc_price
                events.append(('OS_DOWN', dc_idx, ext_price, os_val))
                mode = 1; ext_price = p; dc_price = p; dc_idx = i
                events.append(('DC_UP', i, p, 0.0))
    return events

def test_dc_os(df, delta=0.0005, label="EURUSD M15"):
    """Loi d'échelle <OS>/delta et edge de retour d'overshoot (fade)."""
    closes = df['c'].values
    ev = compute_dc_os(closes, delta)
    os_ev = [e for e in ev if e[0] in ('OS_UP', 'OS_DOWN')]
    if len(os_ev) < 50:
        print(f"  [{label}] trop peu d'événements OS ({len(os_ev)})"); return
    os_vals = np.array([e[3] for e in os_ev])
    ratio = os_vals.mean() / delta
    # edge : après un OS_UP (extrême haut), le prix baisse-t-il dans les K barres ?
    K = 30
    fwd = []
    for e in os_ev:
        i = e[1]
        if i + K < len(closes):
            fwd.append((closes[i + K] - closes[i]) / closes[i] * (1 if e[0] == 'OS_UP' else -1))
    fwd = np.array(fwd)
    net = fwd.mean()
    t = net / (fwd.std() / np.sqrt(len(fwd))) if len(fwd) > 1 else 0
    print(f"  [{label}] delta={delta}: n_OS={len(os_ev)} <OS>/delta={ratio:.3f} "
          f"(loi Glattfelder ≈1) | fade K={K}: net={net*1e4:+.2f}bp t={t:+.2f}")
    go = ratio > 0.8 and t > 1.5
    jl({"brique": "DC_OS", "label": label, "delta": delta, "n": len(os_ev),
        "os_delta_ratio": float(ratio), "fade_net_bp": float(net*1e4), "t": float(t),
        "verdict": "GO" if go else "NO-GO"})
    return go

# ---------------------------------------------------------------------------
# 2. Rough volatility (Hurst H≈0.1)
# ---------------------------------------------------------------------------
def hurst_roughness(log_vol, max_lag=20):
    lags = np.arange(1, max_lag + 1)
    vg = []
    for lag in lags:
        d = log_vol[lag:] - log_vol[:-lag]
        vg.append(np.mean(d ** 2))
    vg = np.array(vg)
    pente = np.polyfit(np.log(lags), np.log(np.maximum(vg, 1e-12)), 1)[0]
    return max(0.01, min(pente / 2.0, 0.49))

def test_rough_vol(df, label="EURUSD M15"):
    r = np.diff(np.log(df['c'].values))
    # log-vol glissant (fenêtre 30)
    win = 30
    log_vol = np.array([np.log(np.std(r[i:i+win]) + 1e-9)
                        for i in range(0, len(r) - win, win)])
    if len(log_vol) < 100:
        print(f"  [{label}] log-vol trop court"); return
    H = hurst_roughness(log_vol)
    print(f"  [{label}] Hurst log-vol (rough): H={H:.3f} (attendu ≈0.1)")
    go = H < 0.35   # rough confirmé
    jl({"brique": "ROUGH_VOL", "label": label, "hurst": float(H),
        "verdict": "GO" if go else "NO-GO"})
    return go

# ---------------------------------------------------------------------------
# 3. Hawkes branching ratio n
# ---------------------------------------------------------------------------
def hawkes_branching(timestamps):
    from scipy.optimize import minimize
    t = timestamps - timestamps[0]
    T_max = t[-1] if len(t) > 1 else 1.0
    n_events = len(t)

    def ll(params):
        mu, alpha, beta = params
        if mu <= 0 or alpha <= 0 or beta <= 0 or alpha >= beta:
            return 1e10
        A = 0.0
        s = 0.0
        for i in range(1, n_events):
            dt = t[i] - t[i-1]
            A = (1.0 + A) * np.exp(-beta * dt)
            lam = mu + alpha * A
            s += np.log(max(lam, 1e-9))
        integral = mu * T_max + (alpha / beta) * np.sum(1.0 - np.exp(-beta * (T_max - t)))
        return -(s - integral)

    try:
        res = minimize(ll, [0.05, 0.3, 0.6], bounds=[(1e-4, None)] * 3, method='L-BFGS-B', options={'maxiter': 200})
        _, alpha, beta = res.x
        return alpha / beta
    except Exception:
        return float('nan')

def test_hawkes(df, label="EURUSD M15"):
    # timestamps synthétiques : 1 event par barre (bornes sup de n)
    t = (pd.to_datetime(df['dt']) - pd.to_datetime(df['dt']).iloc[0]).dt.total_seconds().values
    t = t[::10]  # échantillon 1/10 pour la vitesse
    n = hawkes_branching(t[:2000])
    print(f"  [{label}] Hawkes branching ratio n={n:.3f} (critique si >0.85)")
    go = np.isfinite(n) and 0.2 < n < 0.95
    jl({"brique": "HAWKES", "label": label, "branching": float(n) if np.isfinite(n) else None,
        "verdict": "GO" if go else "NO-GO"})
    return go

# ---------------------------------------------------------------------------
# 4. FFD (différenciation fractionnaire)
# ---------------------------------------------------------------------------
def ffd(series, d, threshold=1e-4):
    w = [1.0]
    k = 1
    while True:
        wk = -w[-1] / k * (d - k + 1)
        if abs(wk) < threshold:
            break
        w.append(wk)
        k += 1
    w = np.array(w[::-1])
    width = len(w)
    out = np.full(len(series), np.nan)
    for i in range(width - 1, len(series)):
        out[i] = np.dot(w, series[i - width + 1:i + 1])
    return out

def test_ffd(df, label="EURUSD M15"):
    closes = df['c'].values
    for d in [0.3, 0.5]:
        fd = ffd(closes, d)
        fd = fd[~np.isnan(fd)]
        r = np.diff(np.log(closes[~np.isnan(fd)][:len(fd)])) if False else None
        # ADF approx : corrélation de lag-1 (0 = stationnaire)
        lag1 = np.corrcoef(fd[:-1], fd[1:])[0, 1]
        print(f"  [{label}] FFD d={d}: lag-1 corr={lag1:+.3f} (proche 0 = stationnaire+mémoire)")
    jl({"brique": "FFD", "label": label, "verdict": "INFO"})
    return None

# ---------------------------------------------------------------------------
# 5. EVT sur MAE (excursions adverses)
# ---------------------------------------------------------------------------
def test_evt_mae(df, label="EURUSD M15"):
    """MAE sur une grille simple : entrée à l'ouverture, MAE sur les 48 barres suivantes."""
    closes = df['c'].values
    highs = df['h'].values
    lows = df['l'].values
    mae = []
    step = 30
    for i in range(0, len(closes) - 50, step):
        o = closes[i]
        lo = lows[i+1:i+49].min()
        hi = highs[i+1:i+49].max()
        mae.append(max(o - lo, hi - o) / o)
    mae = np.array(mae)
    u = np.percentile(mae, 80)
    exc = mae[mae > u] - u
    if len(exc) < 30:
        print(f"  [{label}] pas assez d'excédents"); return
    from scipy.stats import genpareto
    xi, loc, sigma = genpareto.fit(exc, floc=0)
    p_u = np.mean(mae > u)
    # P(MAE > 2*u) via GPD vs empirique
    thr = 2 * u
    p_gpd = p_u * genpareto.sf(thr - u, c=xi, loc=0, scale=sigma)
    p_emp = np.mean(mae >= thr)
    print(f"  [{label}] EVT: xi={xi:.3f} sigma={sigma:.5f} | P(MAE>2u): "
          f"GPD={p_gpd:.4f} empirique={p_emp:.4f}")
    go = np.isfinite(xi) and p_emp > 0.005
    jl({"brique": "EVT_MAE", "label": label, "xi": float(xi), "sigma": float(sigma),
        "p_gpd": float(p_gpd), "p_emp": float(p_emp), "verdict": "GO" if go else "NO-GO"})
    return go

# ---------------------------------------------------------------------------
# 6. VPIN (toxicité)
# ---------------------------------------------------------------------------
def test_vpin(df, label="EURUSD M15"):
    """VPIN sur barres de volume : vol_up/vol_down disponibles en M1 signé."""
    if 'vol_up' not in df.columns:
        print(f"  [{label}] pas de vol_up/vol_down — skip")
        return None
    buy = df['vol_up'].values.astype(float)
    sell = df['vol_down'].values.astype(float)
    target = np.percentile(buy + sell, 50)
    n = 50
    imb = np.abs(buy - sell)
    vpin = np.convolve(imb, np.ones(n), 'valid') / (n * target)
    # pouvoir prédictif : VPIN haut -> retournement (mean reversion) dans les K barres
    r = np.diff(np.log(df['c'].values))
    K = 20
    fwd = np.array([r[i+1:i+1+K].sum() for i in range(len(r) - K)])
    n_vp = min(len(vpin), len(fwd))
    vp = vpin[:n_vp]
    fwd = fwd[:n_vp]
    if len(vp) == 0 or len(fwd) == 0:
        print(f"  [{label}] VPIN: pas de données après convolution"); return None
    hi = vp > np.percentile(vp, 80)
    lo = vp < np.percentile(vp, 20)
    net_hi = fwd[hi].mean(); net_lo = fwd[lo].mean()
    print(f"  [{label}] VPIN: high={net_hi*1e4:+.2f}bp low={net_lo*1e4:+.2f}bp "
          f"(diff={ (net_hi-net_lo)*1e4:+.2f}bp) | toxicité moyenne={vp.mean():.3f}")
    go = abs((net_hi - net_lo) * 1e4) > 3.0
    jl({"brique": "VPIN", "label": label, "net_hi_bp": float(net_hi*1e4),
        "net_lo_bp": float(net_lo*1e4), "diff_bp": float((net_hi-net_lo)*1e4),
        "verdict": "GO" if go else "NO-GO"})
    return go

# ---------------------------------------------------------------------------
# 7. WFC (résultats FORGE existants)
# ---------------------------------------------------------------------------
def test_wfc():
    f = os.path.join(BASE, "forge_endless_results.jsonl")
    if not os.path.exists(f):
        print("  [WFC] forge_endless_results.jsonl absent — skip")
        return None
    rows = []
    for line in open(f, encoding="utf-8"):
        try:
            d = json.loads(line)
            rows.append(d)
        except Exception:
            pass
    if len(rows) < 10:
        print(f"  [WFC] seulement {len(rows)} lignes — skip")
        return None
    # extraire net par segment si présent
    is_vals, oos_vals = [], []
    for d in rows:
        r = d.get("results") or d
        if isinstance(r, dict):
            segs = {k: v for k, v in r.items() if isinstance(v, (int, float))}
            isv = segs.get("IS-1") or segs.get("is1") or segs.get("T1")
            oosv = segs.get("OOS-3") or segs.get("oos3") or segs.get("OOS")
            if isv is not None and oosv is not None:
                is_vals.append(float(isv)); oos_vals.append(float(oosv))
    if len(is_vals) < 8:
        print(f"  [WFC] {len(is_vals)} paires IS/OOS — skip")
        return None
    from scipy.stats import spearmanr
    c, p = spearmanr(is_vals, oos_vals)
    print(f"  [WFC] n={len(is_vals)} spearman IS-OOS={c:+.3f} (p={p:.3f}, seuil >0.4)")
    go = c > 0.4
    jl({"brique": "WFC", "n": len(is_vals), "spearman": float(c), "p": float(p),
        "verdict": "GO" if go else "NO-GO"})
    return go

# ---------------------------------------------------------------------------
def main():
    print("AXE QUANT AVANCÉ — banc de test sur données réelles")
    print("heure:", pd.Timestamp.now())
    hr()
    # données M15 (Dukascopy, 2022-2026)
    m15 = pd.read_csv(os.path.join(BASE, "edge_6E", "donnees_m15.csv"), parse_dates=['dt'])
    print(f"EURUSD M15: {len(m15):,} barres {m15.dt.min()} -> {m15.dt.max()}")
    hr()
    print("1) DC/OS (Olsen)")
    test_dc_os(m15, 0.0005, "EURUSD M15 delta=0.05%")
    test_dc_os(m15, 0.001, "EURUSD M15 delta=0.10%")
    hr()
    print("2) Rough volatility (Hurst)")
    test_rough_vol(m15)
    hr()
    print("3) Hawkes branching ratio")
    test_hawkes(m15)
    hr()
    print("4) FFD (mémoire)")
    test_ffd(m15)
    hr()
    print("5) EVT sur MAE")
    test_evt_mae(m15)
    hr()
    print("6) VPIN (M1 signé)")
    m1 = pd.read_parquet(os.path.join(BASE, "bars", "EURUSD_M1_signed.parquet"))
    m1s = m1[['bid_c', 'vol_up', 'vol_down']].rename(columns={'bid_c': 'c'})
    test_vpin(m1s, "EURUSD M1 signed")
    hr()
    print("7) WFC sur résultats FORGE")
    test_wfc()
    hr()
    print("FIN — résultats dans night_results/axe_quant.jsonl")

if __name__ == "__main__":
    main()
