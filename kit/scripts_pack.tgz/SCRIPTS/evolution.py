# -*- coding: utf-8 -*-
"""evolution.py — LE MARCHE A-T-IL CHANGE ENTRE 2024 ET 2026 ?

QUESTION DE L'UTILISATEUR (18/09, 13 h 30) : "on devrait checker 2025 et 2026
pour les periodes favorables ou hostiles. J'ai une inquietude par rapport a
l'evolution du marche. Est-ce que les structures barrent ou l'evolution change ?"

C'EST UNE QUESTION DE FOND, ET ELLE EST MESURABLE
-------------------------------------------------
Le holdout vient d'echouer durement : le candidat gagne +1.30 USD par
transaction pendant l'apprentissage (2024Q1-2025Q1) et perd -11.04 USD par
transaction sur 2025Q2-2026Q1, dont -17.56 sur EURJPY.

Deux explications concurrentes :
  (a) LE MARCHE A CHANGE. Si la volatilite, le cout relatif ou la tendance se
      sont deplaces en 2025-2026, alors le mecanisme lui-meme (stop a 12 ATR,
      objectif a 24 ATR, duree 16 h) ne veut plus dire la meme chose.
  (b) LE CANDIDAT N'A JAMAIS ETE REEL. Son apparent avantage etait du bruit de
      selection, et le holdout n'a fait que le reveler.

CE QUI LES DEPARTAGE : si le marche a change, les CONDITIONS doivent avoir
bouge de facon mesurable sur TOUTES les paires, pas seulement sur les deux du
candidat. Si les conditions sont stables, l'explication (b) l'emporte.

CE QUE LE SCRIPT MESURE, par paire et par trimestre de 2024Q1 a 2026Q1 :
  - ATR M5 moyen (l'activite) ;
  - spread / ATR (le cout relatif) ;
  - derive de la paire sur le trimestre (%) ;
  - efficacite de la tendance = |derive| / (ATR x racine du nombre de barres),
    qui distingue un marche qui TEND d'un marche qui BRASSE.

USAGE : python evolution.py
"""
import collections
import statistics
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
M1 = BASE / "m1_pos"
PAIRES = ["EURUSD", "EURJPY", "GBPJPY", "AUDJPY", "USDJPY", "NZDUSD"]
PERIODES = [("2024Q1", "2024-01-01", "2024-04-01"),
            ("2024Q2", "2024-04-01", "2024-07-01"),
            ("2024Q3", "2024-07-01", "2024-10-01"),
            ("2024Q4", "2024-10-01", "2025-01-01"),
            ("2025Q1", "2025-01-01", "2025-04-01"),
            ("2025Q2", "2025-04-01", "2025-07-01"),
            ("2025Q3", "2025-07-01", "2025-10-01"),
            ("2025Q4", "2025-10-01", "2026-01-01"),
            ("2026Q1", "2026-01-01", "2026-04-01")]
HOLDOUT = ["2025Q2", "2025Q3", "2025Q4", "2026Q1"]


def charge(sym):
    import pandas as pd
    p = M1 / ("%s_M1.csv" % sym)
    if not p.exists():
        return None
    d = pd.read_csv(p, usecols=["time", "high", "low", "close", "spread"])
    d["time"] = pd.to_datetime(d["time"], unit="s", utc=True)
    d = d.set_index("time").sort_index()
    ex = d["close"].dropna().astype(str).head(2000)
    dec = 0
    for x in ex:
        if "." in x:
            dec = max(dec, len(x.split(".")[1]))
    pt = 10.0 ** (-dec)
    m5 = d.resample("5min").agg({"high": "max", "low": "min",
                                 "close": "last", "spread": "mean"}).dropna()
    pc = m5["close"].shift(1)
    m5["tr"] = pd.concat([(m5["high"] - m5["low"]).abs(),
                          (m5["high"] - pc).abs(),
                          (m5["low"] - pc).abs()], axis=1).max(axis=1)
    m5["spread_px"] = m5["spread"] * pt
    return m5


def main():
    print("=" * 104)
    print("LE MARCHE A-T-IL CHANGE ENTRE 2024 ET 2026 ?")
    print("=" * 104)
    res = {}
    for sym in PAIRES:
        m5 = charge(sym)
        if m5 is None:
            print("   %-8s pas de donnees M1" % sym)
            continue
        for lab, a, b in PERIODES:
            s = m5.loc[a:b]
            if len(s) < 500:
                continue
            atr = float(s["tr"].mean())
            cout = 100.0 * float(s["spread_px"].mean()) / atr if atr > 0 else None
            c0, c1 = float(s["close"].iloc[0]), float(s["close"].iloc[-1])
            derive = 100.0 * (c1 / c0 - 1.0)
            eff = abs(derive / 100.0) * c0 / (atr * (len(s) ** 0.5)) if atr else 0
            res[(sym, lab)] = dict(atr=atr, cout=cout, derive=derive,
                                   eff=eff, n=len(s))
    print()
    print("   ATR M5 MOYEN (l'activite, en pips)")
    print("   %-8s %s" % ("paire", " ".join("%8s" % p[0][-2:] for p in PERIODES)))
    for sym in PAIRES:
        vals = []
        for lab, _, _ in PERIODES:
            x = res.get((sym, lab))
            vals.append("%8.1f" % x["atr"] if x else "%8s" % "-")
        print("   %-8s %s" % (sym, " ".join(vals)))
    print()
    print("   SPREAD / ATR EN % (le cout relatif)")
    print("   %-8s %s" % ("paire", " ".join("%8s" % p[0][-2:] for p in PERIODES)))
    for sym in PAIRES:
        vals = []
        for lab, _, _ in PERIODES:
            x = res.get((sym, lab))
            vals.append("%8.1f" % x["cout"] if x and x["cout"] else "%8s" % "-")
        print("   %-8s %s" % (sym, " ".join(vals)))
    print()
    print("   DERIVE DE LA PAIRE SUR LE TRIMESTRE (%)")
    print("   %-8s %s" % ("paire", " ".join("%8s" % p[0][-2:] for p in PERIODES)))
    for sym in PAIRES:
        vals = []
        for lab, _, _ in PERIODES:
            x = res.get((sym, lab))
            vals.append("%+8.1f" % x["derive"] if x else "%8s" % "-")
        print("   %-8s %s" % (sym, " ".join(vals)))
    print()
    print("   EFFICACITE DE LA TENDANCE (grand = ca tend, petit = ca brasse)")
    print("   %-8s %s" % ("paire", " ".join("%8s" % p[0][-2:] for p in PERIODES)))
    for sym in PAIRES:
        vals = []
        for lab, _, _ in PERIODES:
            x = res.get((sym, lab))
            vals.append("%8.2f" % x["eff"] if x else "%8s" % "-")
        print("   %-8s %s" % (sym, " ".join(vals)))
    print()
    # --- agregation 2024 vs holdout -------------------------------------
    print("=" * 104)
    print("   COMPARAISON APPRENTISSAGE (5 trimestres 2024-2025Q1) "
          "CONTRE HOLDOUT (2025Q2-2026Q1)")
    print("=" * 104)
    print("   %-8s %10s %10s %10s %10s %10s %10s"
          % ("paire", "ATR 2024", "ATR 2025-26", "cout 2024", "cout 2025-26",
             "|der| 2024", "|der| 25-26"))
    for sym in PAIRES:
        a24 = [res[(sym, p[0])] for p in PERIODES[:5] if (sym, p[0]) in res]
        a25 = [res[(sym, p[0])] for p in PERIODES[5:] if (sym, p[0]) in res]
        if not a24 or not a25:
            continue
        print("   %-8s %10.1f %10.1f %10s %10s %10.1f %10.1f"
              % (sym, statistics.mean(x["atr"] for x in a24),
                 statistics.mean(x["atr"] for x in a25),
                 ("%.1f" % statistics.mean(x["cout"] for x in a24
                                           if x["cout"])) if any(x["cout"] for x in a24) else "-",
                 ("%.1f" % statistics.mean(x["cout"] for x in a25
                                           if x["cout"])) if any(x["cout"] for x in a25) else "-",
                 statistics.mean(abs(x["derive"]) for x in a24),
                 statistics.mean(abs(x["derive"]) for x in a25)))
    print()
    # --- verdict global --------------------------------------------------
    tous24 = [res[(s, p[0])] for s in PAIRES for p in PERIODES[:5]
              if (s, p[0]) in res]
    tous25 = [res[(s, p[0])] for s in PAIRES for p in PERIODES[5:]
              if (s, p[0]) in res]
    if tous24 and tous25:
        d_atr = 100.0 * (statistics.mean(x["atr"] for x in tous25)
                         / statistics.mean(x["atr"] for x in tous24) - 1)
        c24 = [x["cout"] for x in tous24 if x["cout"]]
        c25 = [x["cout"] for x in tous25 if x["cout"]]
        d_cout = 100.0 * (statistics.mean(c25) / statistics.mean(c24) - 1) \
            if c24 and c25 else 0
        d_eff = 100.0 * (statistics.mean(x["eff"] for x in tous25)
                         / max(1e-9, statistics.mean(x["eff"] for x in tous24)) - 1)
        print("   ATR        : %+.1f %% sur la periode 2025-2026" % d_atr)
        print("   cout/ATR   : %+.1f %%" % d_cout)
        print("   efficacite : %+.1f %% (positif = le marche tend davantage)" % d_eff)
        print()
        chang = max(abs(d_atr), abs(d_cout), abs(d_eff))
        if chang < 15:
            print("   >>> LE MARCHE N'A PAS CHANGE de facon mesurable (moins de")
            print("       15 %% sur toutes les conditions). L'echec du holdout")
            print("       ne s'explique donc PAS par une evolution du marche :")
            print("       le candidat n'a jamais eu d'avantage reel.")
        else:
            print("   >>> LE MARCHE A BOUGE sur au moins une condition. Une")
            print("       partie de l'echec peut venir de la, et non du")
            print("       candidat. A examiner condition par condition.")


if __name__ == "__main__":
    main()
