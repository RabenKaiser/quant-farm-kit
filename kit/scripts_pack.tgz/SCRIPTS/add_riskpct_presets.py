# -*- coding: utf-8 -*-
"""add_riskpct_presets.py — ajouter InpRiskPct=1.0 a chaque preset deploy
Upcomers (les EAs RISK l'acceptent; les anciens presets sans ce champ doivent
etre recharges sur les EAs _RISK)."""
import os, io, sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BASE = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\MQL5\Presets"
FILES = [
    "V3INT_EA\\EURUSD_H1.set", "V3INT_EA\\GBPJPY_H1.set",
    "V3INT_EA\\NZDJPY_H1.set", "V3INT_EA\\AUDUSD_H1.set",
    "V3INT_EA\\NZDUSD_H1.set", "V3INT_EA\\EURGBP_H1.set",
    "V3INT_EA\\GBPUSD_H1.set", "V3INT_EA\\DJCUSD_H1_INDICE_DOW.set",
    "V3INT_EA\\SPCUSD_H1_INDICE_SPX.set",
    "V3INT_EA\\FRCEUR_H1_INDICE_FR40.set",
    "VWAPFADE_EA\\XAUUSD_H1.set", "VWAPTREND_EA\\XAUUSD_H1.set",
]
for rel in FILES:
    p = os.path.join(BASE, rel)
    if not os.path.exists(p):
        print("ABSENT", rel)
        continue
    with io.open(p, "r", encoding="utf-8-sig", errors="replace") as f:
        c = f.read()
    if "InpRiskPct=" in c:
        # maj valeur si deja la
        c2 = c.replace("InpRiskPct=0.0", "InpRiskPct=1.0").replace(
            "InpRiskPct=1.0", "InpRiskPct=1.0")
        if c2 == c and "InpRiskPct=0.0" in c:
            c2 = c.replace("InpRiskPct=0.0", "InpRiskPct=1.0")
        c = c2
        print("MAJ", rel)
    else:
        # inserer apres la ligne InpLots
        lines = c.splitlines()
        out = []
        added = False
        for ln in lines:
            out.append(ln)
            if (not added) and ln.strip().startswith("InpLots="):
                out.append("InpRiskPct=1.0")
                added = True
        if not added:
            out.insert(1, "InpRiskPct=1.0")
        c = "\n".join(out)
        print("AJOUT", rel)
    with io.open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(c + "\n")
print("FIN")
