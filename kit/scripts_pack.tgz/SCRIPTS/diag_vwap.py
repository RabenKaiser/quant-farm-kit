"""Diagnostic : un run VWAP seul + lecture brute du log."""
import sys, json
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner as m

# run simple avec capture de l'archive
r = m.run_backtest("VWAP_TRAIL_FX", "GBPUSD", "H1", "2024.01.01", "2024.02.01", 10000)
print("résultat:", json.dumps(r, default=str))
print("archive:", r.get("_archive") if r else None)

# lire le log du data folder directement
from pathlib import Path
import re
CF = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3")
log = CF / "Tester" / "logs" / "20260824.log"
if log.exists():
    raw = log.read_text("utf-16", errors="replace")
    # chercher le dernier VWAP
    hits = [m_ for m_ in re.finditer(r"VWAP_TRAIL_FX", raw)]
    print(f"\noccurrences VWAP_TRAIL_FX dans le log: {len(hits)}")
    if hits:
        pos = hits[-1].start()
        seg = raw[max(0, pos - 200):pos + 3000]
        lines = seg.splitlines()
        # les lignes testing + final balance
        for l in lines:
            if "testing" in l or "final balance" in l or "VWAP" in l:
                print("  ", l[:150])
