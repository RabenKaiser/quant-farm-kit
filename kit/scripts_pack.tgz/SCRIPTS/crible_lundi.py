# -*- coding: utf-8 -*-
r"""crible_lundi.py -- STRATEGIE 3 de Tring.txt (Stacey Burke) au moteur honnete.

« 3-Day Liquidity Cycle » simplifie en version mesurable sans etats caches
fragiles : le range du LUNDI (H/L de la premiere journee de la semaine) sert
d'enveloppe ; on trade la SORTIE D'ECHEC du range les jours suivants :
  - MONDAYFADE S : apres un poussee au-dessus du range lundi (Day 1),
    la premiere cloture qui retombe DANS le range -> vente retour range.
  - MONDAYFADE L : symetrique sous le range.
La lecture 3 jours (Day3 = exhaustion) est testee en variante : ne trader
que si au moins UN range deja casse plus tot dans la semaine (2e poussee).
M30, hold 64 barres, SLR 1 et 3, TPR 2, barrieres decalees, une position
par paire, TEMOIN aleatoire integre (regle du 10/12).
"""
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM

HOLD = int(os.environ.get("HOLD", "64"))
TPR = 2.0
SLRS = [float(x) for x in os.environ.get("SLRS", "1,3").split(",")]
JAMBES = [x.strip() for x in os.environ.get(
    "PAIRES", "EURUSD,GBPUSD,USDCHF,AUDUSD,NZDUSD,EURJPY,GBPJPY,AUDJPY,"
    "CADJPY,NZDJPY,EURGBP,XAUUSD").split(",") if x.strip()]
SORTIE = Path(__file__).resolve().parent.parent / "CRIBLE_LUNDI_WF.csv"


def signaux(D):
    """Range du lundi (heure serveur, lundi = dayofweek 0) + signaux."""
    c, h, l, o = D["c"], D["h"], D["l"], D["o"]
    n = len(c)
    dow = D["idx"].dayofweek
    jour = D["idx"].date
    hi = np.full(n, np.nan)
    lo = np.full(n, np.nan)
    # vecteur : pour chaque barre, le range du dernier lundi TERMINE (au plus
    # tard le mardi 00h). construction par dates de lundi.
    dates = pd.Series(jour).drop_duplicates().values
    lundi_hi = {}
    lundi_lo = {}
    for d in dates:
        t = pd.Timestamp(d)
        if t.dayofweek == 0:
            lundi_hi[d] = None
            lundi_lo[d] = None
    cur = None
    for i in range(n):
        d = jour[i]
        if d in lundi_hi:
            cur = d
        if dow[i] == 0 and cur == d:
            # BUG DU 10/13 corrige : le range ne se met a jour QUE sur les
            # barres du lundi lui-meme ; apres, il est FIGE (avant, chaque
            # barle de la semaine rallongeait le range -> rien ne pouvait
            # jamais le depasser -> 0 signal).
            if lundi_hi[cur] is None or h[i] > lundi_hi[cur]:
                lundi_hi[cur] = h[i]
            if lundi_lo[cur] is None or l[i] < lundi_lo[cur]:
                lundi_lo[cur] = l[i]
        if cur is not None and dow[i] != 0:
            hi[i] = lundi_hi[cur]
            lo[i] = lundi_lo[cur]
        else:
            hi[i] = lundi_hi.get(jour[i], np.nan)
            lo[i] = lundi_lo.get(jour[i], np.nan)
    rng = np.where(hi - lo > 0, hi - lo, np.nan)
    sur = (h > hi)   # poussee au-dessus du range
    sous = (l < lo)
    # fade : etait dehors a la bougie precedente, rentre dedans a la cloture
    fade_s = (np.roll(sur, 1)) & (c < hi) & (c > lo)
    fade_l = (np.roll(sous, 1)) & (c < hi) & (c > lo)
    return (np.flatnonzero(np.nan_to_num(fade_s)),
            np.flatnonzero(np.nan_to_num(fade_l)), rng)


def resultat(D, sig, slr, sens):
    c, h, l, o, a = D["c"], D["h"], D["l"], D["o"], D["a"]
    sig = sig[(sig >= 60) & (sig < len(c) - HOLD - 3)]
    sig = sig[np.isfinite(a[sig]) & (a[sig] > 0) & (a[sig] > 0)]
    if len(sig) < 30:
        return None
    ent = sig + 1
    ent = ent[ent < len(c) - HOLD - 2]
    e, st = o[ent], a[sig[:len(ent)]]
    sp = D["cout"]
    if sens == "L":
        tp, sl = e + (TPR * slr + sp) * st, e - max(slr - sp, 0.1) * st
    else:
        tp, sl = e - (TPR * slr + sp) * st, e + max(slr - sp, 0.1) * st
    off = np.arange(1, HOLD + 1)
    Hh, Ll = h[ent[:, None] + off], l[ent[:, None] + off]
    if sens == "L":
        htp, hsl = Hh >= tp[:, None], Ll <= sl[:, None]
    else:
        htp, hsl = Ll <= tp[:, None], Hh >= sl[:, None]
    it = np.where(htp.any(1), htp.argmax(1), 10 ** 6)
    isl = np.where(hsl.any(1), hsl.argmax(1), 10 ** 6)
    tph, slh = htp.any(1), hsl.any(1)
    kind = np.where(tph & (~slh | (it < isl)), 0, np.where(slh, 1, 2))
    fin = ((c[ent + HOLD] - e) / st if sens == "L"
           else (e - c[ent + HOLD]) / st)
    R = np.where(kind == 0, TPR, np.where(kind == 1, -1.0,
                                          fin + (sp if sens == "L" else -sp)))
    garde, fin_bloc = [], None
    for k, i in enumerate(ent):
        t = D["idx"][i]
        if fin_bloc is not None and t < fin_bloc:
            continue
        garde.append(k)
        fin_bloc = t + pd.Timedelta(minutes=30 * HOLD)
    g = np.array(garde, dtype=int)
    ok = np.isfinite(R[g])
    if ok.sum() < 30:
        return None
    g = g[ok]
    R = R[g]
    annees = np.array([D["idx"][ent[k]].year for k in g])
    par_an = {int(y): float(np.mean(R[annees == y]))
              for y in np.unique(annees)}
    train = [v for y, v in par_an.items() if 2020 <= y <= 2023]
    valid = [v for y, v in par_an.items() if y >= 2024]
    return dict(n=len(R), mu=float(np.mean(R)),
                gagn=100.0 * float(np.mean(kind[g] == 0)),
                train_mu=float(np.mean(train)) if train else None,
                valid_mu=float(np.mean(valid)) if valid else None,
                annees=par_an)


def temoin(D, sig_s, sig_l, slr):
    """Le melange des deux listes de signaux re-cote en direction aleatoire."""
    rng = np.random.default_rng(7)
    sig = np.sort(np.concatenate([sig_s, sig_l]))
    if len(sig) < 30:
        return None
    sens = rng.integers(0, 2, size=len(sig))
    return resultat(D, sig, slr, "L"), resultat(D, sig, slr, "S"), sens


def main():
    print("LUNDI (Tring S3) : fade du range du lundi | M30 hold=%d | SLR %s"
          % (HOLD, SLRS))
    lignes = []
    acc_t = []
    for p in JAMBES:
        D = NM.charge(p, "m1_pos")
        if D is None:
            print("  %-8s : corpus absent" % p)
            continue
        sig_s, sig_l, rngv = signaux(D)
        # temoin : memes creneaux, direction aleatoire
        sig_mix = np.sort(np.concatenate([sig_s, sig_l]))
        if len(sig_mix) >= 30:
            mix = np.array(sig_mix, dtype=int)
            rng2 = np.random.default_rng(7)
            sens = np.where(rng2.integers(0, 2, size=len(mix)) == 0, "L", "S")
            R_l = resultat(D, mix, 1, "L")
            R_s = resultat(D, mix, 1, "S")
            if R_l and R_s:
                mu_t = (R_l["mu"] * R_l["n"] + R_s["mu"] * R_s["n"]) \
                    / (R_l["n"] + R_s["n"])
                acc_t.append((mu_t, R_l["n"] + R_s["n"]))
                print("  %-8s TEMOIN n=%4.0f mu=%+.3f" % (p, R_l["n"] + R_s["n"], mu_t))
        for slr in SLRS:
            for sens, sig, nom in (("S", sig_s, "MONDAYFADE_S"),
                                   ("L", sig_l, "MONDAYFADE_L")):
                r = resultat(D, sig, slr, sens)
                if r is None:
                    continue
                ans = " ".join("%d %+.2f" % (y, v)
                               for y, v in sorted(r["annees"].items()))
                wf_ok = (r["train_mu"] is not None and r["train_mu"] > 0
                         and r["valid_mu"] is not None and r["valid_mu"] > 0)
                print("  %-8s %-13s slr=%.0f n=%4.0f mu=%+.3f train=%+.3f "
                      "valid=%+.3f %s"
                      % (p, nom, slr, r["n"], r["mu"], r["train_mu"] or 0,
                         r["valid_mu"] or 0, "WF-OK" if wf_ok else "wf-fail"))
                lignes.append(dict(jambe=p, famille=nom, slr=slr,
                                   n=r["n"], mu=r["mu"],
                                   train=r["train_mu"], valid=r["valid_mu"],
                                   gagnants=r["gagn"], wf_ok=int(wf_ok),
                                   annees=ans))
    if acc_t:
        n = sum(x[1] for x in acc_t)
        print("TEMOIN AGREGAT : mu=%+.4f (n=%d) — le surplus des fades doit "
              "depasser ca pour etre un edge" % (sum(x[0] * x[1] for x in acc_t) / n, n))
    if lignes:
        import csv
        with open(SORTIE, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(lignes[0].keys()))
            w.writeheader()
            w.writerows(lignes)
        print("ecrit %s" % SORTIE.name)


if __name__ == "__main__":
    main()
