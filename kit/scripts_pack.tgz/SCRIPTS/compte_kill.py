"""compte_kill : simulation avec KILL-SWITCH INTRADAY et PLAFOND PAR DEVISE.

Deux corrections issues du round 214 (le compte etait coupe a -5 % dans TOUTES les
configurations, car 10 positions contre dollar sont en realite un seul pari) :
  1. plafond PAR DEVISE : aucune devise ne peut apparaitre dans deux positions
     ouvertes en meme temps (16 paires => beaucoup de USD et d'EUR partages) ;
  2. kill-switch INTRADAY : des que la perte du jour atteint le seuil, on arrete
     de prendre des trades ce jour-la (au lieu de plafonner apres coup).
Reutilise les trades valides de compte_final.py (directions imposees, premier toucher).
"""
import os
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compte_final as C

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
OUT = B / os.environ.get("OUTFILE", "compte_kill.md")
RISK = float(os.environ.get("RISK", "0.5"))       # % de l'equity par trade
MAXPOS = int(os.environ.get("MAXPOS", "6"))
STOP_JOUR = float(os.environ.get("STOP_JOUR", "1.5"))   # % de perte, kill intraday
CAP = int(os.environ.get("CAP_DEV_N", "1"))       # max de positions OUVERTES par devise
DD_COUPE = -5.0
DEV = ("EUR", "GBP", "AUD", "NZD", "USD", "CAD", "CHF", "JPY")


def devises(p):
    a, b = p[:3], p[3:]
    return {a, b}


def main():
    tous = []
    debut = int(os.environ.get("DEBUT", "0"))   # 230 : annee de depart (0 = tout)
    sel = os.environ.get("PAIRES6", "")
    liste = [x for x in sel.split(",") if x] if sel else list(C.COURT)
    print("jambes utilisees : %s" % ", ".join(liste), flush=True)
    for p in liste:
        for t, r in C.trades_pair(p):
            if debut and t.year < debut:
                continue
            tous.append((t, float(r), p))
    tous.sort(key=lambda x: x[0])
    occ = []                      # (fin, devises)
    par_jour = defaultdict(float)
    pris = rejet_dev = rejet_pos = rejet_kill = 0
    pris_r = []
    jour_courant = None
    perte_jour = 0.0
    for t, r, p in tous:
        j = t.date()
        if j != jour_courant:
            jour_courant = j
            perte_jour = 0.0
        if t.hour >= 21 or t.hour < 1:
            continue
        if perte_jour >= STOP_JOUR:          # kill-switch intraday
            rejet_kill += 1
            continue
        occ = [o for o in occ if o[0] > t]
        if len(occ) >= MAXPOS:
            rejet_pos += 1
            continue
        dv = devises(p)
        if os.environ.get("CAP_DEV", "1") == "1" and any(
                sum(1 for o in occ if c in o[1]) >= CAP for c in dv):   # plafond par devise
            rejet_dev += 1
            continue
        occ.append((t + __import__("pandas").Timedelta(hours=16), dv))
        par_jour[j] += r
        pris += 1
        pris_r.append(r)
        if r < 0 and par_jour[j] * RISK <= -STOP_JOUR:
            perte_jour = par_jour[j] * -1 * 0 + STOP_JOUR   # declenche le kill
    eq, pic, dd_max = 1.0, 1.0, 0.0
    mois = {}
    coupe = False
    for j in sorted(par_jour):
        if coupe:
            break
        pnl = par_jour[j] * RISK
        if pnl < -STOP_JOUR:
            pnl = -STOP_JOUR
        eq *= (1 + pnl / 100.0)
        pic = max(pic, eq)
        dd = (eq / pic - 1) * 100
        dd_max = min(dd_max, dd)
        mois["%04d-%02d" % (j.year, j.month)] = eq
        if dd <= DD_COUPE:
            coupe = True
    ret = []
    eq0 = 1.0
    for m in sorted(mois):
        ret.append((m, (mois[m] / eq0 - 1) * 100))
        eq0 = mois[m]
    gains = [x for _, x in ret]
    lignes = ["# Compte prop avec kill-switch intraday et plafond par devise", "",
              "risque %.2f %% / trade | max %d positions | kill intraday -%.1f %% | "
              "drawdown coupe a %.1f %% | 16 h de detention" % (RISK, MAXPOS, STOP_JOUR, DD_COUPE), "",
              "| indicateur | valeur |", "|---|---|",
              "| trades pris | %d |" % pris,
              "| R/tx moyen des trades pris | %+.4f |" % (sum(pris_r) / len(pris_r) if pris_r else 0),
              "| rejetes (devise deja ouverte) | %d |" % rejet_dev,
              "| rejetes (positions pleines) | %d |" % rejet_pos,
              "| rejetes (kill intraday) | %d |" % rejet_kill,
              "| rendement mensuel moyen | %+.2f %% |" % (sum(gains) / len(gains) if gains else 0),
              "| mois positifs | %d/%d |" % (sum(1 for x in gains if x > 0), len(gains)),
              "| meilleur / pire mois | %+.2f %% / %+.2f %% |" % (max(gains) if gains else 0, min(gains) if gains else 0),
              "| drawdown max | %.2f %% |" % dd_max,
              "| compte coupe | %s |" % ("OUI" if coupe else "non"), ""]
    for m, x in ret:
        lignes.append("- %s : %+.2f %%" % (m, x))
    # 256 : detail par ANNEE (validation longue) : somme des R du jour / an
    an = defaultdict(list)
    for j in sorted(par_jour):
        an[j.year].append(par_jour[j])
    lignes += ["", "## par annee (approx : somme des R du jour x risque, plafonnee au stop journalier)",
               "", "| annee | jours | somme R | R/jour | P&L approx |", "|---|---|---|---|---|"]
    for y in sorted(an):
        v = an[y]
        pl = sum(max(x * RISK, -STOP_JOUR) if x * RISK < STOP_JOUR else x * RISK for x in v)
        lignes.append("| %d | %d | %+.1f | %+.4f | %+.2f %% |" % (y, len(v), sum(v), sum(v) / len(v), pl))
    OUT.write_text("\n".join(lignes), encoding="utf-8")
    print("  RESUME risque %.2f | cap %d/dev | pris %d | R/tx %+.4f | mois %+.2f %% | pire %+.2f %% | DD %.2f %% | coupe %s"
          % (RISK, CAP, pris, (sum(pris_r) / len(pris_r) if pris_r else 0),
             (sum(gains) / len(gains) if gains else 0), (min(gains) if gains else 0),
             dd_max, "OUI" if coupe else "non"), flush=True)
    print("\n".join(lignes[:14]), flush=True)
    print("ecrit %s" % OUT, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())



