# -*- coding: utf-8 -*-
"""enveloppe.py -- LE PLAFOND. Ou le marche donne-t-il plus qu'il ne prend ?

POURQUOI CE SCRIPT (idee de l'utilisateur, 19/09 18 h)
"Le MFE/MAE est juste, c'est enorme -- peut-etre qu'on peut tourner en Python
avec ca seulement."

OUI, et voici la consequence exacte. La validation a montre :
    MFE / MAE ....... juste a moins de 5 % (10.90 vs 11.03, 12.41 vs 11.74)
    nombre de trades . FAUX d'un facteur 10 (88 vs 935)
Donc la MACHINE DE MESURE est fiable ; c'est la definition des declencheurs qui
differe de celle de l'EA. On peut donc mesurer en Python n'importe quelle regle
d'entree que NOUS definissons, sans dependre des identifiants de l'EA.

Premiere question, celle qui precede tous les declencheurs : sur quelle paire,
quelle trame et quel regime le prix va-t-il plus loin POUR nous que CONTRE
nous ? C'est le PLAFOND de toute strategie a barrieres. Si le MFE median est
inferieur au MAE median, aucune entree symetrique ne peut gagner, et il est
inutile d'y chercher.

Ici les entrees sont TOUTES les barres (pas de declencheur) : c'est la mesure
de l'instrument lui-meme.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
BASE = Path(r"C:\EAFarm\HISTORY - Copy\research\m1_pos")
HOLD = 192          # barres de la trame mesuree (16 h)


def charge(paire, regle):
    f = BASE / ("%s_M1.csv" % paire)
    if not f.exists():
        return None
    d = pd.read_csv(f, usecols=["time", "high", "low", "close"])
    d["t"] = pd.to_datetime(d["time"], unit="s", utc=True)
    b = d.set_index("t").resample(regle).agg(
        high=("high", "max"), low=("low", "min"),
        close=("close", "last")).dropna()
    tr = pd.concat([b.high - b.low,
                    (b.high - b.close.shift()).abs(),
                    (b.low - b.close.shift()).abs()], axis=1).max(axis=1)
    b["atr"] = tr.rolling(14).mean()
    return b.dropna()


def enveloppe(b, sens):
    """MFE et MAE en ATR, sur TOUTES les barres (entree a la cloture)."""
    h, l, c, a = b.high.values, b.low.values, b.close.values, b.atr.values
    n = len(b) - HOLD - 1
    if n < 500:
        return None
    idx = np.arange(20, n)
    e = c[idx]
    at = a[idx]
    ok = at > 0
    idx, e, at = idx[ok], e[ok], at[ok]
    # ROUND 125 : par PAQUETS. La version precedente construisait une matrice
    # (n, HOLD) d'un coup : sur 5 ans de M5 cela fait 1,5 million x 192 x 8
    # octets = 2,3 Go par tableau, et la machine tombait. On decoupe.
    PAS = 20000
    mfe_all, mae_all = [], []
    off = np.arange(1, HOLD + 1)
    for d0 in range(0, len(idx), PAS):
        d1 = min(d0 + PAS, len(idx))
        ii = idx[d0:d1]
        ee = e[d0:d1]
        aa = at[d0:d1]
        H = h[ii[:, None] + off]
        L = l[ii[:, None] + off]
        if sens > 0:
            mfe_all.append((H.max(axis=1) - ee) / aa)
            mae_all.append((ee - L.min(axis=1)) / aa)
        else:
            mfe_all.append((ee - L.min(axis=1)) / aa)
            mae_all.append((H.max(axis=1) - ee) / aa)
    mfe = np.concatenate(mfe_all)
    mae = np.concatenate(mae_all)
    return (len(mfe), float(np.median(mfe)), float(np.median(mae)),
            float(mfe.mean()), float(mae.mean()),
            float(np.percentile(mfe, 75)))


def main():
    paires = ["EURUSD", "USDJPY", "EURJPY", "GBPUSD", "USDCHF", "AUDUSD",
              "USDCAD", "NZDUSD", "CADJPY", "EURGBP", "GBPJPY", "AUDJPY",
              "CHFJPY", "XAUUSD"]
    trames = [("5min", "M5")]
    print("=" * 104)
    print("ENVELOPPE -- MFE contre MAE, TOUTES les entrees, en ATR")
    print("   MFE median > MAE median  =>  le prix va plus loin POUR nous :")
    print("   c'est la seule zone ou un systeme a barrieres peut gagner.")
    print("=" * 104)
    print("   %-8s %-5s %7s %8s %8s %8s %8s %-8s"
          % ("paire", "trame", "n", "MFE med", "MAE med", "MFE moy", "MAE moy",
             "plafond"))
    res = []
    for p in paires:
        for regle, nom in trames:
            b = charge(p, regle)
            if b is None:
                continue
            r = enveloppe(b, +1)
            if not r:
                continue
            n, mf, ma, mfm, mam, p75 = r
            ratio = mf / ma if ma else 0
            verdict = "FAVORABLE" if mf > ma else "defavorable"
            res.append((ratio, p, nom, n, mf, ma, mfm, mam, p75))
            print("   %-8s %-5s %7d %8.2f %8.2f %8.2f %8.2f %-8s (%.2f)"
                  % (p, nom, n, mf, ma, mfm, mam, verdict, ratio))
    print()
    res.sort(reverse=True)
    print("   CLASSEMENT PAR PLAFOND (MFE median / MAE median) :")
    for ratio, p, nom, n, mf, ma, mfm, mam, p75 in res[:10]:
        print("      %-8s %-4s  %.3f   (MFE %5.2f  MAE %5.2f, %d entrees)"
              % (p, nom, ratio, mf, ma, n))
    fav = [x for x in res if x[0] > 1.0]
    print()
    print("   zones FAVORABLES (MFE > MAE) : %d sur %d mesurees"
          % (len(fav), len(res)))
    print("   => ce sont les SEULES ou il vaut la peine d'ecrire un declencheur.")


if __name__ == "__main__":
    main()
