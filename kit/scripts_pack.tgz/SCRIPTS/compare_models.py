# -*- coding: utf-8 -*-
"""compare_models.py — Model=1 vs Model=4 sur une periode COURTE.

OBJECTIF
  Verifier que le mode de test change le resultat. On ne cherche PAS a mesurer
  la performance (3 mois c'est trop court) : on cherche a savoir si le mode
  "1 minute OHLC" fabrique de faux SL.

PROTOCOLE
  Meme symbole, meme periode (3 mois), MEMES parametres. Seul `Model` change :
    Model=1 : 1 minute OHLC (chemin de prix interpole)
    Model=4 : ticks reels du broker
  On compare :
    - le nombre d'entrees
    - le nombre de SL vs TP
    - le R moyen

PERIODE : 2026-06-01 -> 2026-09-01 (3 mois), la ou les donnees existent.

SORTIE : model_compare.json
"""
import os, sys, re, time, glob, subprocess, json
from pathlib import Path
from collections import Counter

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
SCR = BASE / "SCRIPTS"
sys.path.insert(0, str(SCR))
import mt5_pos_run as M

CFG = M.FARM / "Config" / "config_cmp.ini"
FROM, TO = "2026.06.01", "2026.09.01"
OUT = BASE / "model_compare.json"


def write_ini(sym, model):
    lines = [
        "[Tester]",
        r"Expert=eepeek\ORION_ROBOT.ex5",
        f"Symbol={sym}", "Period=M5", f"Model={model}", "Optimization=0",
        f"FromDate={FROM}", f"ToDate={TO}", "Deposit=100000", "Currency=USD",
        "Leverage=100", "ReplaceReport=1", "ShutdownTerminal=1",
        "[TesterInputs]", "InpLots=0.10", "InpMaxPos=1", "InpMaxPerSide=1",
        "InpMaxSpreadMult=2.5", "InpDayStopPct=3.0", "InpMaxDDStopPct=15.0",
        "InpVerbose=true", "InpTrace=false", "InpNoHedge=true",
    ]
    CFG.write_text("\n".join(lines) + "\n", encoding="ascii")


def read_log(p):
    raw = open(p, "rb").read()
    return (raw.decode("utf-16") if raw[:2] in (b"\xff\xfe", b"\xfe\xff")
            else raw.decode("utf-8", errors="replace"))


def run(sym, model, wait=1800):
    write_ini(sym, model)
    M.kill_farm(); time.sleep(3); M.rotate()
    t0 = time.time()
    p = subprocess.Popen([str(M.TM), "/config:" + str(CFG)], cwd=str(M.FARM),
                         creationflags=0x08000000,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    w = 0
    while w < wait:
        time.sleep(3); w += 3
        rr = subprocess.run(["tasklist", "/FI", "PID eq %d" % p.pid],
                            capture_output=True, text=True)
        if "terminal64" not in rr.stdout:
            break
    M.kill_farm(); time.sleep(3)
    dt = time.time() - t0
    # lire le log du run
    files = sorted(glob.glob(str(M.LOGD / "*log*")),
                   key=os.path.getmtime, reverse=True)
    for lf in files[:6]:
        try:
            txt = read_log(lf)
        except Exception:
            continue
        if f"ORION OPEN {sym} " not in txt:
            continue
        nopen = len(re.findall(rf"ORION OPEN {sym} ", txt))
        nsl = len(re.findall(r"stop loss triggered", txt))
        ntp = len(re.findall(r"take profit triggered", txt))
        return dict(model=model, sym=sym, secs=round(dt), log=os.path.basename(lf),
                    opens=nopen, sl=nsl, tp=ntp)
    return dict(model=model, sym=sym, secs=round(dt), log=None,
                opens=0, sl=0, tp=0)


if __name__ == "__main__":
    sym = sys.argv[1] if len(sys.argv) > 1 else "CADJPY"
    res = json.load(open(OUT, encoding="utf-8")) if OUT.exists() else {}
    key = sym
    res.setdefault(key, {})
    for model in (1, 4):
        if str(model) in res[key]:
            print(f"{sym} Model={model} deja fait")
            continue
        print(f"\n>>> {sym} Model={model} ({FROM} -> {TO}) ...", flush=True)
        r = run(sym, model)
        res[key][str(model)] = r
        print(f"    {r['secs']}s  opens={r['opens']}  SL={r['sl']}  TP={r['tp']}")
        json.dump(res, open(OUT, "w"), indent=1)
    # comparaison
    d = res[key]
    if "1" in d and "4" in d:
        a, b = d["1"], d["4"]
        print("\n" + "=" * 78)
        print(f"COMPARAISON {sym} : Model=1 (OHLC interpole) vs Model=4 (ticks reels)")
        print("=" * 78)
        print(f"{'':<14}{'Model=1':>10}{'Model=4':>10}{'ecart':>10}")
        for k in ("opens", "sl", "tp"):
            va, vb = a[k], b[k]
            print(f"{k:<14}{va:>10}{vb:>10}{vb-va:>+10}")
        print(f"{'duree (s)':<14}{a['secs']:>10}{b['secs']:>10}")
        if a["opens"]:
            print(f"\n  part de SL : M1 {100*a['sl']/max(a['opens'],1):.0f} %"
                  f"  |  M4 {100*b['sl']/max(b['opens'],1):.0f} %")
        print(f"\n  -> si le taux de SL change fortement, le mode 1 FABRIQUAIT")
        print(f"     des declenchements (chemin de prix interpole).")
