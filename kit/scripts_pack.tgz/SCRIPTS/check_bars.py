﻿import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import polars as pl
from pathlib import Path

BARS = Path(r"C:\EAFarm\HISTORY - Copy\research\bars")
POINT = {"EURUSD": 0.00001, "USDJPY": 0.001, "EURCAD": 0.00001, "USATECHIDXUSD": 0.001}

for sym in ["EURUSD", "USDJPY", "EURCAD", "USATECHIDXUSD"]:
    p = BARS / f"{sym}_M1.parquet"
    if not p.exists():
        print(sym, "MISSING")
        continue
    df = pl.read_parquet(p)
    pt = POINT[sym]
    print(f"\n=== {sym}: {len(df)} M1 bars  {df['time'].min()}..{df['time'].max()}")
    print("  spread_med pts quantiles:", [round(x, 1) for x in df["spread_med"].quantile([0.1, 0.5, 0.9, 0.99])])
    print("  n_ticks median:", int(df["n_ticks"].median()))
    print("  bid_vol>0 pct:", round((df["bid_vol"] > 0).mean() * 100, 1),
          " ask_vol>0 pct:", round((df["ask_vol"] > 0).mean() * 100, 1))
    # hourly volume profile
    hr = df.with_columns(((pl.col("time") % 86400) // 3600).alias("hr"))
    prof = hr.group_by("hr").agg(
        pl.col("n_ticks").sum().alias("ticks"),
        pl.col("bid_vol").sum().alias("bv"),
        pl.col("ask_vol").sum().alias("av"),
    ).sort("hr")
    top = prof.sort("ticks", descending=True).head(6)
    print("  top tick hours:", [(int(r["hr"]), int(r["ticks"])) for r in top.iter_rows(named=True)])
