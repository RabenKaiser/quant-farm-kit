﻿# -*- coding: utf-8 -*-
"""CHASSE A 15 JAMBES — L'ENTONNOIR (07/10, 21 h 00).

Nouvelle organisation (directive utilisateur) : les cribles PYTHON (gratuits, heures) chassent sur
TOUT le corpus multi-annees ; seuls les survivants partent a la ferme (ordres reels) ; seuls les
confirmes ferment partent au juge. Ce script lit TOUS les csv de crible de la chasse, applique le
filtre walk-forward (train 2020-2023 ET valid 2024-2026 positifs, au moins 2/3 d'annees positives),
et ecrit la liste de selection HUNT_15.md / HUNT_15.csv qui pilote la file de la ferme.

Filtre walk-forward (lecon de crible_periodes.py : les edges 2020-23 meurent souvent en 2024+) :
  train  = annees <= 2023, valid = annees >= 2024 — les DEUX moyennes de R/tx doivent etre > 0.
Sortie triee par score = min(R_train, R_valid) * sqrt(n) — recompense la solidite des deux cotes.
"""
import csv
import re
import sys
from collections import defaultdict
from pathlib import Path

B = Path(__file__).resolve().parent.parent
FICHIERS = ["CHASSE_INDIC.csv", "CHASSE_INDIC_UPC.csv", "CHASSE_PAYOFF.csv", "CHASSE_PAYOFF_IDX.csv",
            "CHASSE_KELT.csv", "CHASSE_KELT_FX.csv", "CHASSE_MR.csv", "CHASSE_AVWAP.csv",
            "CHASSE_AVWAP_FX.csv", "CHASSE_CC.csv", "CHASSE_VOL.csv", "CRIBLE_INDICATEURS.csv",
            "CHASSE_KELT.csv", "CHASSE_KELT_FX.csv", "CHASSE_MR.csv", "CHASSE_AVWAP.csv",
            "CHASSE_AVWAP_FX.csv", "CHASSE_CC.csv", "CHASSE_VOL.csv", "CRIBLE_INDICATEURS.csv",
            "CRIBLE_PAYOFF.csv", "CRIBLE_KELTNER.csv",
            # ROUND 546 : LES SCOPES HORAIRES (marche-map) entrent dans l'entonnoir —
            # Londres 07-09 d'abord (le meilleur fib du programme : USSC2000 +0.31 n=297).
            "CRIBLE_FIB_LDN.csv", "CRIBLE_STRUCTURE_LDN.csv"]
# la variante ANTI-ROLLOVER (flat 22:30 serveur, rouverture 01:00) reste UNE FAMILLE A PART :
# ses lignes prennent le suffixe « _ID » pour ne pas fusionner avec les memes signaux en
# mode classique (differentes regles de sortie = differentes mesures).
FICHIER_ID = "CHASSE_INDIC_ID.csv"
N_MIN = int(__import__("os").environ.get("N_MIN", "40"))


def lit_colonnes(row):
    """Trouve les noms de colonnes quel que soit le crible (paire/symbole, trame/tf, signal/regle)."""
    def c(*cands):
        for k in cands:
            if k in row:
                return k
        return None
    return c("paire", "symbole", "symbol"), c("trame", "tf", "minutes"), c("signal", "regle", "ligne", "famille")


def parse_annees(champ):
    """« 2020 +0.123 2021 -0.045 ... » -> {2020: 0.123, ...}."""
    if not champ:
        return {}
    out = {}
    toks = str(champ).replace(",", " ").split()
    for i, t in enumerate(toks):
        if re.fullmatch(r"\d{4}", t):
            try:
                out[int(t)] = float(toks[i + 1])
            except (IndexError, ValueError):
                pass
    return out


def verdict_wf(ans):
    train = [v for y, v in ans.items() if y <= 2023]
    valid = [v for y, v in ans.items() if y >= 2024]
    if not train or not valid:
        return "COURTE", None
    mt, mv = sum(train) / len(train), sum(valid) / len(valid)
    if mt > 0 and mv > 0:
        return "PASSE", (mt, mv)
    if mt > 0 and mv <= 0:
        return "DEGRADATION", (mt, mv)
    return "RECENT", (mt, mv)


def normalise_symbole(s):
    """Les noms du corpus Upcomers (DJCUSD.c, SPCUSD.c, BTCUSD.nx) vers les noms ferme."""
    base = s.replace(".c", "").replace(".nx", "").strip()
    equiv = {"DJCUSD": "USA30.IDX", "SPCUSD": "USA500.IDX", "BTCUSD": "BTCUSD",
             "NSXUSD": "NSXUSD", "SPXUSD": "SPXUSD", "UDXUSD": "UDXUSD"}
    return equiv.get(base, base)


def main():
    lignes = {}
    for nom in FICHIERS + [FICHIER_ID]:
        f = B / nom
        if not f.exists():
            continue
        # le corpus qui a servi : m1_upcomers = le feed du courtier prop (3e flux), sinon Dukascopy
        if "UPC" in nom or "upcomers" in nom.lower():
            feed = "upcomers"
        else:
            feed = "duka"
        anti_rollover = (nom == FICHIER_ID)
        with f.open(encoding="utf-8", errors="replace", newline="") as fh:
            for row in csv.DictReader(fh):
                if not row:
                    continue
                cp, ctr, cs = lit_colonnes(row)
                if not cp or not cs:
                    continue
                try:
                    n = int(float(row.get("n") or row.get("nb") or 0))
                    r = float(row.get("R") or row.get("r_moy") or 0)
                except ValueError:
                    continue
                if n < N_MIN or r <= 0:
                    continue
                ans = parse_annees(row.get("annees") or row.get("ans") or "")
                sym = normalise_symbole(row[cp])
                sig = row[cs] + ("_ID" if anti_rollover else "")
                # la variante anti-rollover doit tenir SANS les transactions de news aussi :
                # directive 08/10 (« careful with news »). Si la colonne R_sans_news existe et
                # tombe <= 0, la variante ne survit pas au filtre.
                rs_n = row.get("R_sans_news")
                if rs_n not in (None, ""):
                    try:
                        if float(rs_n) <= 0:
                            continue
                    except ValueError:
                        pass
                cle = (sym, sig, row.get("sens", ""), str(row.get(ctr, "")))
                if feed == "upcomers":
                    # le corpus du courtier prop est COURT (2026) : pas de walk-forward possible.
                    # Il sert de CONTROLE DE FLUX : on ne garde que les signaux deja passés au
                    # filtre WF sur Dukascopy, et on verifie qu'ils restent positifs chez le
                    # courtier (le meme moteur, les prix du courtier prop, ses spreads).
                    if r <= 0 or cle not in lignes:
                        continue
                    ent = lignes[cle]
                    ent["feeds"] = sorted(set(ent["feeds"] + ["upcomers"]))
                    ent["R_upc"] = r
                    continue
                if len(ans) < 3:
                    continue
                v, mv = verdict_wf(ans)
                if v != "PASSE":
                    continue
                mt, mvalid = mv
                np_ = sum(1 for x in ans.values() if x > 0)
                if np_ < 2 * len(ans) / 3.0:
                    continue
                ent = lignes.get(cle)
                if ent is None:
                    ent = lignes[cle] = dict(
                        symbole=sym, trame=row.get(ctr, ""), signal=sig, sens=row.get("sens", ""),
                        n=n, R=r, attendu=row.get("attendu", ""), cout=row.get("cout", ""),
                        train=round(mt, 4), valid=round(mvalid, 4), R_upc="",
                        annees_pos="%d/%d" % (np_, len(ans)), feeds=["duka"],
                        score=round(min(mt, mvalid) * (n ** 0.5), 3))
                else:
                    ent["feeds"] = sorted(set(ent["feeds"] + [feed]))
                # la plus vigoureuse des deux mesures du meme signal sur le meme flux
                if r > ent["R"]:
                    ent["R"] = r
                    ent["n"] = n
                    ent["attendu"] = row.get("attendu", "")
                    ent["cout"] = row.get("cout", "")
                ent["score"] = round(min(ent["train"], ent["valid"]) * (ent["n"] ** 0.5), 3)
    if not lignes:
        print("aucun survivant walk-forward (les cribles ont-ils tourne ?)")
        return 1
    lignes = list(lignes.values())
    lignes.sort(key=lambda x: -(x["score"] + 0.35 * (len(x["feeds"]) - 1) * abs(x["score"])))
    ent = ["symbole", "trame", "signal", "sens", "n", "R", "train", "valid", "annees_pos",
           "score", "feeds", "R_upc", "attendu", "cout"]
    with (B / "HUNT_15.csv").open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=ent)
        w.writeheader()
        w.writerows(lignes)
    md = ["# CHASSE 15 — LES SURVIVANTS WALK-FORWARD (07/10)", "",
          "Filtre : n >= %d, R ferme > 0, train 2020-23 > 0 ET valid 2024-26 > 0, >= 2/3 d'annees positives." % N_MIN,
          "Score = min(train, valid) x sqrt(n), majore de 35 %% par flux de donnees supplementaire",
          "(multi-flux = plus resilient : directive utilisateur 08/10).", "",
          "| # | symbole | trame | signal | sens | n | R | train | valid | annees+ | score | flux |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for i, x in enumerate(lignes[:80], 1):
        md.append("| %d | %s | %s | %s | %s | %d | %+.4f | %+.4f | %+.4f | %s | %.2f | %s |"
                  % (i, x["symbole"], x["trame"], x["signal"], x["sens"], x["n"], x["R"],
                     x["train"], x["valid"], x["annees_pos"], x["score"], "+".join(x["feeds"])))
    (B / "HUNT_15.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print("survivants walk-forward : %d -> HUNT_15.csv / HUNT_15.md" % len(lignes))
    syms = sorted({x["symbole"] for x in lignes})
    multi = sum(1 for x in lignes if len(x["feeds"]) > 1)
    print("symboles couverts : %d ; signaux confirmes sur 2 flux : %d" % (len(syms), multi))
    return 0


if __name__ == "__main__":
    sys.exit(main())
