import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import polars as pl
from pathlib import Path

src = Path(r"C:\EAFarm\HISTORY\chunks\EURUSD_202201.csv")
pt = 0.00001
lf = pl.scan_csv(
    src,
    schema_overrides={
        "Timestamp": pl.Utf8,
        "Bid price": pl.Float64,
        "Ask price": pl.Float64,
        "Bid volume": pl.Float64,
        "Ask volume": pl.Float64,
    },
    low_memory=True,
)
df = (
    lf.with_columns(
        pl.col("Timestamp").str.replace(r":(\d{3})$", r".$1").str.to_datetime("%Y%m%d %H:%M:%S%.f").alias("ts"),
    )
    .drop_nulls("ts")
    .filter(
        (pl.col("Bid price") > 0)
        & (pl.col("Ask price") > 0)
        & (pl.col("Ask price") >= pl.col("Bid price"))
        & ((pl.col("Ask price") - pl.col("Bid price")) <= 300 * pt)
        & (pl.col("Bid volume") >= 0)
        & (pl.col("Ask volume") >= 0)
    )
    .with_columns(
        pl.col("ts").dt.truncate("1m").dt.epoch("s").alias("time"),
        (pl.col("Ask price") - pl.col("Bid price")).alias("spread_px"),
    )
    .group_by("time")
    .agg(
        pl.col("Bid price").first().alias("bid_o"),
        pl.len().alias("n"),
    )
    .sort("time")
    .collect()
)
print("bars:", len(df))
print(df.head(3))
