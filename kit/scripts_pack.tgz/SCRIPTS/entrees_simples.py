# -*- coding: utf-8 -*-
"""entrees_simples.py — UNE REGLE D'ENTREE SIMPLE BAT-ELLE L'ALEATOIRE ?

POURQUOI CETTE EXPERIENCE (18/09, 02 h)
---------------------------------------
Mesure de la nuit : avec la geometrie SL 12 x ATR / TP 1 x ATR, une entree
ALEATOIRE vaut -0.0069 R (63 768 entrees), alors que nos 2 100 declencheurs
valent -0.0554 R. Autrement dit : le MECANISME est presque gratuit, et c'est le
CHOIX DES ENTREES qui detruit 0.048 R par transaction.

Toute la recherche du projet portait sur des declencheurs complexes (FVG,
sweeps, VWAP, structures imbriquees : 2 100 combinaisons). Aucun ne bat le
hasard. La question n'a donc jamais ete posee simplement :

    une regle d'entree TRIVIALE bat-elle l'aleatoire, sur la meme geometrie ?

C'est testable directement, sans l'EA : on simule sur nos CSV M1, avec le meme
moteur que le controle aleatoire (spread paye a l'entree et a la sortie, stop
12 ATR, objectif 1 ATR, duree max 192 barres M5).

REGLES TESTEES (petit nombre, ecrit avant de regarder — c'est volontaire :
tester 2 100 regles produirait un faux gagnant, c'est la lecon de la nuit)
   1. ALEATOIRE     : une barre sur dix, les deux sens (temoin)
   2. MOMENTUM      : achat si le prix depasse la cloture d'il y a 12 barres
                      de plus d'1 ATR ; vente si l'inverse
   3. RETOUR        : l'inverse exact du precedent (on fade le mouvement)
   4. BAS DE RANGE  : achat si le prix est dans les 20 % bas du range des
                      96 dernieres barres ; vente si dans les 20 % hauts
   5. HAUT DE RANGE : l'inverse
   6. VOLATILITE    : une barre sur dix, mais seulement si l'ATR depasse sa
                      mediane sur 96 barres, les deux sens
   7. CALME         : l'inverse
   8. SEANCE        : une barre sur dix, mais seulement entre 7 h et 16 h
                      (heure serveur = Londres + New York), les deux sens

CRITERE (ecrit avant de regarder) : une regle est retenue si elle bat
l'aleatoire de plus de 0.02 R dans les DEUX moities de la periode
(A = 2024Q1-Q3, B = 2024Q4 + 2025Q1).

USAGE : python entrees_simples.py
"""
import collections
import math
import statistics
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
M1 = BASE / "m1_pos"
PAIRES = ["EURUSD", "USDJPY", "EURJPY", "AUDJPY", "GBPJPY"]
QA = ["2024Q1", "2024Q2", "2024Q3"]
QB = ["2024Q4", "2025Q1"]
PERIODES = {"2024Q1": ("2024-01-01", "2024-04-01"),
            "2024Q2": ("2024-04-01", "2024-07-01"),
            "2024Q3": ("2024-07-01", "2024-10-01"),
            "2024Q4": ("2024-10-01", "2025-01-01"),
            "2025Q1": ("2025-01-01", "2025-04-01")}
HOLD, SL_ATR, TP_ATR = 192, 12.0, 1.0
FEN_MOM, FEN_RANGE, PAS = 12, 96, 10


def point_de(close):
    ex = close.dropna().astype(str)
    ex = ex[~ex.str.contains("e", case=False, na=False)].head(2000)
    dec = 0
    for x in ex:
        if "." in x:
            dec = max(dec, len(x.split(".")[1]))
    return 10.0 ** (-dec)


def barres(sym):
    import pandas as pd
    p = M1 / ("%s_M1.csv" % sym)
    if not p.exists():
        return None
    d = pd.read_csv(p, usecols=["time", "high", "low", "close", "spread"])
    d["time"] = pd.to_datetime(d["time"], unit="s", utc=True)
    d = d.set_index("time").sort_index()
    pt = point_de(d["close"])
    m5 = d.resample("5min").agg({"high": "max", "low": "min",
                                 "close": "last", "spread": "mean"}).dropna()
    m5["spread_px"] = m5["spread"] * pt
    pc = m5["close"].shift(1)
    tr = pd.concat([(m5["high"] - m5["low"]).abs(),
                    (m5["high"] - pc).abs(),
                    (m5["low"] - pc).abs()], axis=1).max(axis=1)
    m5["atr"] = tr.rolling(14).mean()
    m5["rng_hi"] = m5["high"].rolling(FEN_RANGE).max()
    m5["rng_lo"] = m5["low"].rolling(FEN_RANGE).min()
    m5["atr_med"] = m5["atr"].rolling(FEN_RANGE).median()
    return m5


def simule(m5, sens):
    """Rend la liste de (R, periode) pour une liste d'entrees (indice, sens)."""
    import numpy as np
    H, L, C = m5["high"].to_numpy(), m5["low"].to_numpy(), m5["close"].to_numpy()
    A, S = m5["atr"].to_numpy(), m5["spread_px"].to_numpy()
    idx = m5.index
    res = []
    bornes = {}
    for per, (a, b) in PERIODES.items():
        bornes[per] = (idx.searchsorted(__import__("pandas").Timestamp(a, tz="UTC")),
                       idx.searchsorted(__import__("pandas").Timestamp(b, tz="UTC")))
    for i, side in sens:
        atr = A[i]
        if not (atr > 0) or i + HOLD >= len(C):
            continue
        per = None
        for p, (x, y) in bornes.items():
            if x <= i < y:
                per = p
                break
        if per is None:
            continue
        sp = S[i] if S[i] > 0 else 0.0
        dist = SL_ATR * atr
        ent = C[i] + side * sp / 2.0
        sl = ent - side * dist
        tp = ent + side * TP_ATR * atr
        R = None
        for j in range(i + 1, i + 1 + HOLD):
            if side > 0:
                if L[j] <= sl:
                    R = -1.0
                    break
                if H[j] >= tp:
                    R = TP_ATR / SL_ATR
                    break
            else:
                if H[j] >= sl:
                    R = -1.0
                    break
                if L[j] <= tp:
                    R = TP_ATR / SL_ATR
                    break
        if R is None:
            sortie = C[min(i + HOLD, len(C) - 1)] - side * sp / 2.0
            R = (sortie - ent) * side / dist
        res.append((R, per))
    return res


def entrees(m5, regle):
    """Liste des (indice, sens) selon la regle."""
    C = m5["close"].to_numpy()
    A = m5["atr"].to_numpy()
    HI = m5["rng_hi"].to_numpy()
    LO = m5["rng_lo"].to_numpy()
    AM = m5["atr_med"].to_numpy()
    heures = [t.hour for t in m5.index]
    out = []
    n = len(C)
    for i in range(max(FEN_MOM, FEN_RANGE, 20), n - HOLD - 1):
        if not (A[i] > 0):
            continue
        if regle == "ALEATOIRE":
            if i % PAS == 0:
                out += [(i, 1.0), (i, -1.0)]
        elif regle == "SEANCE":
            if i % PAS == 0 and 7 <= heures[i] <= 16:
                out += [(i, 1.0), (i, -1.0)]
        elif regle == "VOLATILITE":
            if i % PAS == 0 and AM[i] == AM[i] and A[i] > AM[i]:
                out += [(i, 1.0), (i, -1.0)]
        elif regle == "CALME":
            if i % PAS == 0 and AM[i] == AM[i] and A[i] < AM[i]:
                out += [(i, 1.0), (i, -1.0)]
        elif regle == "MOMENTUM":
            d = C[i] - C[i - FEN_MOM]
            if d > A[i]:
                out.append((i, 1.0))
            elif d < -A[i]:
                out.append((i, -1.0))
        elif regle == "RETOUR":
            d = C[i] - C[i - FEN_MOM]
            if d > A[i]:
                out.append((i, -1.0))
            elif d < -A[i]:
                out.append((i, 1.0))
        elif regle == "BAS_DE_RANGE":
            if HI[i] > LO[i]:
                p = (C[i] - LO[i]) / (HI[i] - LO[i])
                if p < 0.2:
                    out.append((i, 1.0))
                elif p > 0.8:
                    out.append((i, -1.0))
        elif regle == "HAUT_DE_RANGE":
            if HI[i] > LO[i]:
                p = (C[i] - LO[i]) / (HI[i] - LO[i])
                if p < 0.2:
                    out.append((i, -1.0))
                elif p > 0.8:
                    out.append((i, 1.0))
    return out


def main():
    REGLES = ["ALEATOIRE", "MOMENTUM", "RETOUR", "BAS_DE_RANGE",
              "HAUT_DE_RANGE", "VOLATILITE", "CALME", "SEANCE"]
    print("=" * 96)
    print("UNE REGLE D'ENTREE SIMPLE BAT-ELLE L'ALEATOIRE ?")
    print("=" * 96)
    print("   geometrie : stop %g x ATR, objectif %g x ATR, %d barres, spread paye"
          % (SL_ATR, TP_ATR, HOLD))
    print("   paires : %s" % ", ".join(PAIRES))
    print()
    res = {}
    for sym in PAIRES:
        m5 = barres(sym)
        if m5 is None:
            continue
        for regle in REGLES:
            ent = entrees(m5, regle)
            sim = simule(m5, ent)
            if not sim:
                continue
            e = res.setdefault(regle, {"A": [], "B": [], "n": 0})
            for R, per in sim:
                if per in QA:
                    e["A"].append(R)
                else:
                    e["B"].append(R)
                e["n"] += 1
    base_a = statistics.mean(res["ALEATOIRE"]["A"])
    base_b = statistics.mean(res["ALEATOIRE"]["B"])
    base = (base_a + base_b) / 2
    print("   TEMOIN (aleatoire) : A %+.4f   B %+.4f" % (base_a, base_b))
    print()
    print("   %-16s %10s %10s %10s %10s %8s %s"
          % ("regle", "R(A)", "R(B)", "ecart A", "ecart B", "entrees", "verdict"))
    print("   " + "-" * 92)
    retenues = []
    for regle in REGLES:
        e = res.get(regle)
        if not e or not e["A"] or not e["B"]:
            continue
        ra, rb = statistics.mean(e["A"]), statistics.mean(e["B"])
        da, db = ra - base_a, rb - base_b
        ok = (da > 0.02 and db > 0.02 and regle != "ALEATOIRE")
        if ok:
            retenues.append(regle)
        print("   %-16s %+10.4f %+10.4f %+10.4f %+10.4f %8d %s"
              % (regle, ra, rb, da, db, e["n"], "RETENUE" if ok else ""))
    print()
    print("   Nombre de regles retenues (battent l'aleatoire dans les DEUX")
    print("   moities de plus de 0.02 R) : %d sur %d testees"
          % (len(retenues), len(REGLES) - 1))
    print()
    if retenues:
        print("   >>> REGLES A CREUSER : %s" % ", ".join(retenues))
        print("       C'est la premiere fois qu'une entree bat le temoin sur les")
        print("       deux moities. A verifier sur 2020-2021 et en ordres reels.")
    else:
        print("   >>> AUCUNE regle simple ne bat l'aleatoire. Meme le retour a")
        print("       la moyenne et le momentum, testes proprement, ne font pas")
        print("       mieux qu'une entree au hasard sur cette geometrie.")
        print("       Avec ce qui precede (0 declencheur sur 101 positif, 0 pool")
        print("       retenu sur 169, classement qui ne transfere pas), le")
        print("       verdict est coherent sur toute la ligne.")


if __name__ == "__main__":
    main()
