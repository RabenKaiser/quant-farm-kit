"""diag_mixte : d'ou vient le drawdown de la composition ? Par jambe.

Round 463. La composition a dix jambes affiche un drawdown brut de 17,8 % a 0,25 % de risque, alors que
la meme mesure valait 3,4 % avant l'ajout du bloc EUR-GBP-CHF. Avant d'accuser les trois nouvelles
jambes -- ou de conclure que la regle prop est hors d'atteinte -- on mesure JAMBE PAR JAMBE : nombre de
transactions, R moyen, PIRE transaction (avec sa date), plus grande suite perdante cumulee en R, et
moyenne par annee. Une pire transaction a -10 R n'est pas un edge, c'est un trou de donnees.

Usage : python SCRIPTS\\diag_mixte.py
"""
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import prop_mixte as PM  # noqa: E402


def pire_suite(ser):
    """Plus grande baisse cumulee (en R) de la courbe des R, jamais repassee au-dessus du pic."""
    pic, cum, dd = 0.0, 0.0, 0.0
    for t, x in ser:
        cum += x
        pic = max(pic, cum)
        dd = max(dd, pic - cum)
    return dd


def main():
    print("%-20s %-7s %5s %8s %20s %8s %8s %9s" %
          ("jambe", "source", "n", "R/tx", "pire tx (R @ date)", "suite R", "cible", "an. pos"))
    total = []
    for paire, ligne, range_, sens in PM.JAMBES:
        ent, src = PM.entrees(paire, ligne, range_, sens)
        if ent is None:
            print("  %s r=%d %s : aucune entree" % (paire, range_, sens))
            continue
        cands = {}
        for g in PM.GEOM:
            s = PM.serie(paire, range_, sens, g, ent)
            if s and len(s) >= 20:
                cands[g] = (s, PM.stats(s))
        if not cands:
            continue
        ok = {g: v for g, v in cands.items() if v[1]["npos"] >= (2 * v[1]["nan"]) / 3.0 and v[1]["mu"] > 0}
        g = max(ok, key=lambda k: ok[k][1]["mus2"]) if ok else max(cands, key=lambda k: cands[k][1]["mus2"])
        ser, st = cands[g]
        an = defaultdict(list)
        for t, x in ser:
            an[t.year].append(x)
        tmin, xmin = min(ser, key=lambda z: z[1])
        print("%-20s %-7s %5d %+8.4f %20s %8.1f %8g %9s" %
              ("%s r=%d %s" % (paire, range_, sens), src, st["n"], st["mu"],
               "%+.2f @ %s" % (xmin, tmin.date()), pire_suite(ser), g,
               "%d/%d" % (st["npos"], st["nan"])), flush=True)
        print("      annee : " + "  ".join("%d %+.3f" % (y, float(np.mean(v))) for y, v in sorted(an.items())))
        total += ser
    print("\nMELANGE : %d tx | R/tx %+.4f | suite perdante max %.1f R"
          % (len(total), float(np.mean([x for _, x in total])), pire_suite(sorted(total))))
    return 0


if __name__ == "__main__":
    sys.exit(main())
