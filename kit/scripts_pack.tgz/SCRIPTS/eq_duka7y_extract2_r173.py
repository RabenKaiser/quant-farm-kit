# -*- coding: utf-8 -*-
"""eq_duka7y_extract2_r173.py — chercher GBPJPY n105 + NZDJPY n54 dans TOUS
les logs recents Farm (y compris plus vieux)."""
import sys, os, glob
import pandas as pd
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
TEAM = r"C:\EAFarm\HISTORY - Copy\research\prop_team\equities"
WANT = {"GBPJPY": 105, "NZDJPY": 54}
found = {}
# scan logs par ordre chronologique inverse, tous (pas de limite taille pour
# etre sur — mais skip les >500MB)
logs = sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime, reverse=True)
for lp in logs:
    if os.path.getsize(lp) > 500 * 1024 * 1024:
        continue
    try:
        runs = F.parse_stream(lp, "V3INT")
    except Exception:
        continue
    for key, data in runs.items():
        for sym, n in WANT.items():
            if sym in found or sym not in key or "H1" not in key:
                continue
            closed = [t for t in data["trades"].values() if t["close"] is not None]
            if len(closed) != n:
                continue
            b = data.get("balance") or 0
            rows = []
            for t in closed:
                try:
                    rows.append((str(t["ts_entry"])[:10], F.pnl_usd(t)))
                except Exception:
                    pass
            s = pd.Series([r[1] for r in rows],
                          index=pd.DatetimeIndex([r[0] for r in rows]))
            ds = s.groupby(s.index).sum()
            k = (b - 10000) / ds.sum() if ds.sum() != 0 else 1.0
            ds2 = ds * k
            fn = TEAM + rf"\equity_V3INT-{sym}-H1-duka7y.csv"
            ds2.to_csv(fn, header=["pnl_day"])
            print(f"{sym}: n={len(closed)} bal={b:.0f} k={k:.3f} "
                  f"sum={ds2.sum():+.0f} [{os.path.basename(lp)}]")
            found[sym] = ds2
print("manquants:", [s for s in WANT if s not in found])
print("FIN", flush=True)
