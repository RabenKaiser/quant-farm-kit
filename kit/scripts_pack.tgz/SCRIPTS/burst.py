"""burst : d'ou viennent les paquets de signaux, et que faire du fait qu'ils tombent ensemble.

Deux questions, deux mesures :
  1. POURQUOI 33 signaux le meme jour : la condition SR50S (cloture dans le top 10 % du range
     de 50 barres) reste VRAIE barre apres barre quand le prix pousse contre le haut du range.
     On affiche donc les heures, les prix d'entree et le R de chaque signal d'une journee
     donnee : si les entrees sont a quelques ATR les unes des autres, ce n'est pas 33
     evenements, c'est UN mouvement compte 33 fois.
  2. EST-CE QUE BLOQUER LES SURENTREES REPARE : on rejoue les memes signaux en refusant toute
     nouvelle position sur la meme paire tant qu'une precedente est ouverte (comportement de
     l'EA en ordres reels, maxpos 1). Si le R/tx monte, la surexposition etait bien le
     probleme ; s'il ne bouge pas, le paquet n'est pas la cause.
"""
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM
import selectivite as S
import portefeuille_tp2 as P2      # masque_selectif (pos >= 0,97 + volatilite normale)

B = Path(r"C:\EAFarm\HISTORY - Copy\research")


def main():
    source = os.environ.get("SOURCE", "m1_upcomers")
    legs = [x for x in os.environ.get("LEGS", "AUDUSD:SR50:C").split(",") if x]
    tpr = float(os.environ.get("TP_R", "2.0"))
    H = int(os.environ.get("HOLD", "32"))
    print("SOURCE=%s | cible %.1f R | hold %d" % (source, tpr, H), flush=True)
    for leg in legs:
        paire, motif, sens = leg.split(":")
        D = NM.charge(paire, source)
        if D is None:
            print("%s : donnees indisponibles" % leg, flush=True)
            continue
        m = NM.motifs(D)
        sig, R = S.premier_toucher(D, m[motif][0 if sens == "C" else 1], -1 if sens == "C" else 1, tpr)
        tt = D["idx"][sig]
        print("\n=== %s | %d signaux | R/tx %+.4f" % (leg, len(R), np.mean(R)), flush=True)

        # --- 1. la journee la plus chargee et la pire journee ---
        par_jour = defaultdict(list)
        for k, t in enumerate(tt):
            par_jour[t.date()].append(k)
        charge = max(par_jour, key=lambda j: len(par_jour[j]))
        pire = min(par_jour, key=lambda j: sum(R[i] for i in par_jour[j]))
        for titre, jour in (("JOURNEE LA PLUS CHARGEE", charge), ("PIRE JOURNEE", pire)):
            idxs = par_jour[jour]
            ent = [D["c"][sig[i]] for i in idxs]
            rr = [R[i] for i in idxs]
            print("\n  %s : %s - %d signaux, somme %+.1f R" % (titre, jour, len(idxs), sum(rr)), flush=True)
            print("    entrees : de %.5f a %.5f (amplitude %.5f = %.2f ATR median)"
                  % (min(ent), max(ent), max(ent) - min(ent),
                     (max(ent) - min(ent)) / np.nanmedian(D["a"])), flush=True)
            print("    R : median %+.3f | stops %d/%d | objectifs %d/%d"
                  % (np.median(rr), sum(1 for x in rr if x < -0.9), len(rr),
                     sum(1 for x in rr if x > 0.9), len(rr)), flush=True)
            print("    heures : " + ", ".join(str(t)[11:16] for t in tt[idxs][:12])
                  + (" ..." if len(idxs) > 12 else ""), flush=True)

        # --- 2. blocage des surexpositions (une seule position par paire) ---
        garde = []
        fin_occupee = None
        for k, t in enumerate(tt):
            if fin_occupee is not None and t < fin_occupee:
                continue
            garde.append(k)
            fin_occupee = t + pd.Timedelta(hours=H / 2.0)
        garde = np.array(garde)
        print("\n  BLOCAGE (une position par paire a la fois) : %d signaux gardes sur %d (%.0f %%) | R/tx %+.4f (contre %+.4f)"
              % (len(garde), len(R), 100.0 * len(garde) / len(R), np.mean(R[garde]), np.mean(R)), flush=True)
        # et avec la selectivite en plus
        msq = P2.masque_selectif(D, sig)
        pos_ok = np.isin(sig, msq)
        Rsel = R[pos_ok]
        tsel = tt[pos_ok]
        garde2 = []
        fin2 = None
        for k, t in enumerate(tsel):
            if fin2 is not None and t < fin2:
                continue
            garde2.append(k)
            fin2 = t + pd.Timedelta(hours=H / 2.0)
        garde2 = np.array(garde2)
        print("  BLOCAGE + SELECTIVITE : %d signaux sur %d | R/tx %+.4f"
              % (len(garde2), len(Rsel), np.mean(Rsel[garde2]) if len(garde2) else 0), flush=True)
        # distribution des R/jour apres blocage
        pj = defaultdict(float)
        for k in garde:
            pj[tt[k].date()] += R[k]
        v = sorted(pj.values())
        print("  R/jour apres blocage : %d jours, moyenne %+.3f, pire %+.1f, 1er centile %+.1f, 5e %+.1f"
              % (len(v), np.mean(v), v[0], v[max(0, len(v) // 100)], v[max(0, len(v) // 20)]), flush=True)
        pj2 = defaultdict(float)
        for k in garde2:
            pj2[tsel[k].date()] += Rsel[k]
        v2 = sorted(pj2.values())
        if v2:
            print("  R/jour apres blocage + selectivite : %d jours, moyenne %+.3f, pire %+.1f, 5e centile %+.1f"
                  % (len(v2), np.mean(v2), v2[0], v2[max(0, len(v2) // 20)]), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
