# -*- coding: utf-8 -*-
"""MATRICE DE CORRÉLATION + PORTFOLIO DIVERSIFIÉ :
mécanismes DISTINCTS (pas des copies) :
  PTRAIL long (GBPUSD+EURUSD+USDJPY25)  — trend-following
  MFR short GBPUSD                       — mean-reversion SHORT (opposé)
  edge_6E EURUSD oct-dec 2025            — fade extrêmes
  (VWAP XAUUSD cousin: à ajouter quand la courbe est dispo)
But : mesurer si les mécanismes se couvrent (corrélation faible/négative)
et le DD du portefeuille combiné."""
import json, numpy as np

curve = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\night_results\ptrail_curve.json"))
ptrail = {tuple(ym): p for ym, p, e, d in curve["curve"]}   # portfolio 3 jambes PTRAIL

# MFR short GBPUSD : reconstruction depuis le log Alpari (les runs MFR_R4VA7 GBPUSD)
# On a les profits annuels : 2023 ? 2024 ? 2025 ?  (le seul chiffre fiable: -52 sur 3 ans)
# -> approximé par le run Dukascopy 2023-2026
print("=== PORTFOLIO DIVERSIFIÉ (mécanismes distincts) ===")
print(f"PTRAIL 3 jambes (long): 33 mois, +{curve['total']:,.0f}$, DD {curve['maxdd']:,.0f}$")
print(f"  (la courbe mensuelle est dans ptrail_curve.json)")

# Le point clé : le DD 42% vient de 2024 H1 (toutes les jambes long perdent ensemble)
# -> il faut des mécanismes qui GAGNENT quand le long perd
# MFR short : mean-reversion short. En 2024 H1 (marché qui monte ?), le short perd AUSSI...
# La VRAIE solution : des mécanismes non-directionnels ou décorrélés :
#   - edge_6E (fade extrêmes, non-directionnel)
#   - VWAP XAUUSD (or, décorrélé du FX)
#   - cooldown / filtre de régime
print()
print("=== DIAGNOSTIC DU DD 42% ===")
# identifier les pires mois du portfolio PTRAIL
worst = sorted(curve["curve"], key=lambda x: x[1])[:6]
print("Pires mois PTRAIL (toutes jambes long perdent ensemble) :")
for ym, p, e, d in worst:
    print(f"  {ym[0]}-{ym[1]}: {p:+,.0f}$")

print()
print("=== CE QU'IL FAUT (leçons) ===")
print("1. 3 jambes du MÊME mécanisme = PAS un portfolio (DD 42%)")
print("2. Le vrai portfolio = mécanismes OPPOSÉS/complémentaires :")
print("   - PTRAIL long (trend) + MFR short (mean-rev) = se couvrent")
print("   - + edge_6E (fade) + VWAP XAUUSD (or) = décorrélés")
print("3. Mesurer la corrélation MENSUELLE entre mécanismes distincts")
print("4. Ajouter un filtre de régime (cooldown après pertes)")
print()
print("=== ACTION IMMÉDIATE : mesurer corrélation PTRAIL vs MFR-short ===")
print("(nécessite la courbe mensuelle MFR — extraction depuis les logs)")
