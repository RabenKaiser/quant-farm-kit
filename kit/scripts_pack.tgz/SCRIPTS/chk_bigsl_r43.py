# -*- coding: utf-8 -*-
"""chk_bigsl_r43.py — plus gros trades perdants par leg: gap vs SL normal.
Compare distance close-entry (pips) vs SL theorique (2xATR env) et pnl parse."""
import sys, glob, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
TARGETS = [("VWAPTREND", "XAUUSD", 128, 19738),
           ("V3INT", "EURGBP", 15, 10024),
           ("V3INT", "FRCEUR", 9, 10203),
           ("V3INT", "GBPUSD", 24, 10179)]

for EA, sym, nt, bt in TARGETS:
    best = None
    for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-120:]:
        try:
            runs = F.parse_stream(lp, EA)
        except Exception:
            continue
        for key, data in runs.items():
            if sym not in key or "20260101" not in key.replace(".", ""):
                continue
            closed = [t for t in data["trades"].values() if t["close"] is not None]
            if len(closed) != nt:
                continue
            b = data.get("balance") or 0.0
            if abs(b - bt) > 5:
                continue
            best = {"trades": closed, "bal": b, "key": key}
            break
        if best:
            break
    if not best:
        print(f"{EA}-{sym}: introuvable"); continue
    print(f"===== {EA} {sym} n={nt} bal={best['bal']:.0f} =====")
    los = sorted([t for t in best["trades"] if F.pnl_usd(t) < 0],
                 key=lambda t: F.pnl_usd(t))[:4]
    for t in los:
        e, c = t.get("entry"), t.get("close")
        tick = 0.0001 if e and e > 1 else (0.01 if e and e > 100 else 1.0)
        dist = abs(c - e) / tick if e and c else float("nan")
        print(f"  {str(t['ts_entry'])[:10]} {str(t.get('side')):4s} "
              f"entry={e} close={c} dist={dist:7.1f} tick | "
              f"ctype={t.get('ctype')} pnl_parse={F.pnl_usd(t):+.0f}")
print("FIN")
