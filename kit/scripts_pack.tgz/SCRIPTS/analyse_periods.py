"""Quantifier l'écart CSVs vs Alpari : périodes couvertes et gaps.
Détermine si les CSVs GBPUSD sont tronqués (période incomplète) ou d'un
fournisseur différent."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
import polars as pl
import datetime as dt
import edge_correct as ec

for sym in ["GBPUSD", "AUDCAD"]:
    m1 = ec.load_m1(sym)
    tf = ec.to_tf(m1, 1800)
    t = tf["time"].cast(pl.Int64).to_numpy()
    c = tf["bid_c"].to_numpy()
    t0 = dt.datetime.utcfromtimestamp(t.min()); t1 = dt.datetime.utcfromtimestamp(t.max())
    print(f"=== {sym} M30 moteur ===")
    print(f"  période: {t0} -> {t1}")
    # par année : combien de barres et plage de closes
    for y in range(2022, 2027):
        mask = (t >= int(dt.datetime(y,1,1).timestamp())) & (t < int(dt.datetime(y+1,1,1).timestamp()))
        if mask.sum() == 0:
            continue
        cy = c[mask]
        print(f"  {y}: {mask.sum():6d} barres | closes {cy.min():.5f} -> {cy.max():.5f}")

# Alpari : le log montre GBPUSD jusqu'à 1.3757 -> vérifier si le CSV couvre
# la hausse de mi-2023 (GBPUSD ~1.31 en mai, ~1.27 en sep...)
print("\nNOTE : GBPUSD réel 2023 : ~1.20 jan -> ~1.27 juil -> ~1.21 oct -> ~1.27 déc")
print("Alpari max 1.3757 = probablement 2025 (GBPUSD a monté fort en 2025)")
print("=> les CSVs moteur s arrêtent probablement avant 2025 OU ont un autre provider")
