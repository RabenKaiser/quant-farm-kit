﻿src = open(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\MQL5\Experts\eepeek\ORION_ROBOT.mq5", encoding="utf-8").read()
i = src.find("bool KeltnerLow")
print(src[i:i+420])
