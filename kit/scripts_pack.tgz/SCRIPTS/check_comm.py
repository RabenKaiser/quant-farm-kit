import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import MetaTrader5 as mt5

TERM = r"C:\EAFarm\MT5\Farm\terminal64.exe"
if not mt5.initialize(path=TERM):
    raise RuntimeError(f"init failed: {mt5.last_error()}")
for sym in ["EURUSD", "USDJPY", "EURCAD"]:
    s = mt5.symbol_info(sym)
    print(sym, "contract=", s.trade_contract_size, "tickval=", s.trade_tick_value,
          "ticksize=", s.trade_tick_size, "calc=", s.trade_calc_mode)
# commission via order calc
for sym in ["EURUSD", "USDJPY"]:
    tick = mt5.symbol_info_tick(sym)
    for vol in [0.01, 0.10]:
        try:
            res = mt5.order_calc_profit(sym, mt5.ORDER_TYPE_BUY, vol, tick.bid, tick.ask + 10*s.point)
            print(sym, vol, "10pt profit:", res)
        except Exception as e:
            print(sym, vol, "ERR", e)
mt5.shutdown()
