# -*- coding: utf-8 -*-
"""courbes.py — LA FORME DES COURBES (round 89), ET LE RECLASSEMENT CORRIGE.

DEUX DEMANDES DE L'UTILISATEUR (16/09, 17 h)
--------------------------------------------
  1. "Aucun trigger teste ne fait le truc avec la nouvelle moyenne, nouveau
     calcul ?"  -> on reclasse TOUS les declencheurs avec le ratio des MOYENNES
     (pondere par les trades) et non plus la moyenne des ratios, qui est biaisee.
  2. "Peut-etre qu'avec la forme des courbes on pourrait tirer quelque chose."
     -> on analyse la FORME de la courbe d'excursion dans le temps.

POURQUOI LA FORME COMPTE
------------------------
Le round 89 enregistre l'excursion courante du trade aux jalons
    6, 12, 24, 36, 48, 72, 96, 144, 192 barres (0.5 h a 16 h).
La VALEUR de la courbe dit combien on gagne ; sa FORME dit QUAND.
Trois formes ont des sens completement differents :

  * reaction IMMEDIATE : la courbe monte des les premieres barres et se
    maintient. C'est un vrai signal directionnel -> on peut sortir tot.
  * montagne russe : elle monte puis rend tout. Le signal n'est pas
    directionnel, il est volatil -> aucune sortie ne sauve ca.
  * derive lente : elle monte regulierement sur 16 h. C'est du portage ou une
    tendance de fond -> il faut tenir longtemps et un stop large.

On mesure donc, pour chaque declencheur :
    f(0.5 h), f(1 h), f(2 h)   -> la reaction immediate
    le sommet et sa position   -> quand la position vaut le maximum
    f(16 h)                    -> ce qui reste a la fin
    la pente des 2 premieres heures

USAGE : python courbes.py [chemin_journal]
"""
import collections
import glob
import os
import re
import statistics
import sys
from pathlib import Path

CP = [6, 12, 24, 36, 48, 72, 96, 144, 192]
H = [c * 5 / 60.0 for c in CP]
LABT = re.compile(r"LABT (\S+) (\S+?) n=(\d+) f=([\d.,-]+) a=([\d.,-]+)")

RACINES = [
    Path(os.environ.get("APPDATA", "")) / "MetaQuotes" / "Tester",
    Path(os.environ.get("APPDATA", "")) / "MetaQuotes" / "Terminal",
]


def journaux():
    fs = []
    for r in RACINES:
        if not r.exists():
            continue
        fs += glob.glob(str(r / "**" / "*.log"), recursive=True)
    return sorted(set(fs), key=os.path.getmtime, reverse=True)[:12]


def charge():
    """id -> liste de courbes f (une par mesure)."""
    g = collections.defaultdict(list)
    for f in journaux():
        try:
            raw = Path(f).read_bytes()
        except OSError:
            continue
        for enc in ("utf-16", "utf-8"):
            try:
                t = raw.decode(enc, errors="strict")
                break
            except UnicodeDecodeError:
                t = raw.decode("utf-16", errors="replace")
        for m in LABT.finditer(t):
            try:
                v = [float(x) for x in m.group(4).split(",")]
            except ValueError:
                continue
            if len(v) == len(CP):
                g[m.group(2)].append(v)
    return g


def main():
    g = charge()
    if not g:
        print("aucune courbe LABT trouvee dans les journaux.")
        return
    print("=" * 96)
    print("LA FORME DES COURBES — %d combinaisons mesurees, %d courbes"
          % (len(g), sum(len(v) for v in g.values())))
    print("=" * 96)

    # --- 1. la courbe moyenne de tout le labo ---------------------------
    toutes = [c for v in g.values() for c in v]
    moy = [statistics.mean([c[k] for c in toutes]) for k in range(len(CP))]
    print("\n1. LA COURBE MOYENNE DU LABO (excursion favorable, en ATR)")
    for k in range(len(CP)):
        print("   %-12s %+7.2f  %s" % ("%.1f h" % H[k], moy[k],
                                       "#" * int(abs(moy[k]) * 3)))

    # --- 2. reclassement des DECLENCHEURS, calcul corrige ---------------
    # ratio des moyennes pondere par le nombre de trades, sur la courbe.
    par_t = collections.defaultdict(list)
    for cid, v in g.items():
        par_t[cid.split("|")[0]].append(cid)
    lignes = []
    for t, ids in par_t.items():
        cs = [c for i in ids for c in g[i]]
        if len(cs) < 20:
            continue
        f = [statistics.mean([c[k] for c in cs]) for k in range(len(CP))]
        f_net = f[len(CP) - 1]
        # "aire" = valeur moyenne sur toute la duree du hold
        aire = statistics.mean(f)
        # pente des 2 premieres heures
        pente = f[2] - f[0]
        sommet = max(f)
        ks = f.index(sommet)
        lignes.append(dict(t=t, n=len(cs), f=f, aire=aire, fin=f_net,
                           pente=pente, sommet=sommet, ks=ks))
    print("\n2. TOUS LES DECLENCHEURS, RECLASSES PAR L'AIR DE LA COURBE")
    print("   (aire > 0 = la position est en gain moyen sur la duree du hold)")
    print("   %-16s %5s %7s %7s %7s %7s %6s" % ("declencheur", "n", "f(0.5h)",
                                                "f(1h)", "f(2h)", "aire", "sommet"))
    print("   " + "-" * 74)
    for x in sorted(lignes, key=lambda y: -y["aire"])[:30]:
        print("   %-16s %5d %+7.2f %+7.2f %+7.2f %+7.2f %6.2f (%.1f h)"
              % (x["t"], x["n"], x["f"][0], x["f"][1], x["f"][2], x["aire"],
                 x["f"][x["ks"]], H[x["ks"]]))
    pos = [x for x in lignes if x["aire"] > 0]
    print("\n   declencheurs a aire POSITIVE : %d sur %d" % (len(pos), len(lignes)))

    # --- 3. les formes : qui monte tout de suite ? ----------------------
    print("\n3. REACTION IMMEDIATE (f(1 h) > 0) : y en a-t-il ?")
    imm = [x for x in lignes if x["f"][1] > 0]
    print("   declencheurs dont la position est en GAIN a 1 h : %d sur %d"
          % (len(imm), len(lignes)))
    for x in sorted(imm, key=lambda y: -y["f"][1])[:12]:
        print("      %-16s f(1h) %+6.2f | f(2h) %+6.2f | f(16h) %+6.2f | sommet %+6.2f a %.1f h"
              % (x["t"], x["f"][1], x["f"][2], x["fin"], x["f"][x["ks"]], H[x["ks"]]))

    # --- 4. quelle forme est exploitable ? ------------------------------
    print("\n4. QUELLE FORME EST EXPLOITABLE ?")
    print("   %-16s %7s %7s %7s %8s" % ("declencheur", "f(1h)", "sommet",
                                        "f(16h)", "rendu %"))
    for x in sorted(lignes, key=lambda y: -y["f"][1])[:10]:
        rendu = 100 * (1 - x["fin"] / x["f"][x["ks"]]) if x["f"][x["ks"]] else 0
        print("   %-16s %+7.2f %+7.2f %+7.2f %7.0f%%"
              % (x["t"], x["f"][1], x["f"][x["ks"]], x["fin"], rendu))
    print("\n   Rappel : une sortie au temps k rapporte f(k) / SL en R.")
    print("   Le meilleur cas est donc celui qui maximise f(k) - et si le")
    print("   sommet est a 1-2 h, il faut sortir a 1-2 h, pas a 16 h.")


if __name__ == "__main__":
    main()
