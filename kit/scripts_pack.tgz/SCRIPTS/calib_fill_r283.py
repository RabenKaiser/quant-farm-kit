# -*- coding: utf-8 -*-
"""calib_fill_r283.py — CALIBRATION DU MODELE DE REMPLISSAGE.

QUESTION: `ext_fill="close"` est-il le bon modele, trop optimiste, ou trop
pessimiste ? On a une mesure DIRECTE du MT5 pour trancher.

MESURES MT5 (subagent, SUBAGENT_MT5_XAU.md section 5) — sorties extension:
  run              buf MT5   n_ext   % perdantes   R moyen ext
  A2   (champ.)    2.941      449      10%          +1.010
  NB   (sans biais)2.941      660      13%          +0.969
  C    (non trad.) 6.000      499      16%          +0.583
  B16  (buf16)     7.843      810      20%          +0.514
  AUD brief        3.061     1020      15%          +0.523
  AUD B16          8.163      770      22%          +0.385
  NB 21-25         2.941      903      12%          +0.955
=> Le MT5 a **10 a 22% de sorties extension PERDANTES** et un R moyen de
   +0.39 a +1.01.
Le python en mode "thresh"/"extreme" en a **0%** (structurellement).
Le python en mode "close" en a combien ? Si c est ~15%, le modele est bon.

Ce script mesure, pour chaque modele, la distribution R des sorties extension
et les compare a ces cibles MT5.
"""
import sys, json
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import c13v2_py_v3 as F
import c13v2_engine as ENG
import pandas as pd, numpy as np

print("Chargement XAUUSD...", flush=True)
M1 = F.load_m1("XAUUSD")

BASE = {"imp_atr": 0.7, "imp_vol": 1.0, "imp_look": 6, "ob_age": 32,
        "rej_wick": 0.4, "rej_vol": 1.0, "close_zone": 0.15,
        "bias": "vwap", "excl_hours": [6, 7, 12, 15, 19, 23],
        "lookahead": False, "vwap_len": 96, "tp_r": 99, "min_stop": 0.00025,
        "buf_atr": 6.0}

def fr(y0, y1):
    s = pd.Timestamp(f"{y0}-01-01", tz="UTC"); e = pd.Timestamp(f"{y1+1}-01-01", tz="UTC")
    w = M1.loc[s - pd.Timedelta(days=260):e]
    m5 = F.resample(w, "5min").loc[s:e]
    m15 = F.resample(w, "15min"); h4 = F.resample(w, "4h")
    a15 = ENG.SW.F.atr_s(m15, 14)
    a15i = a15.reindex(a15.index.union(m5.index)).ffill().reindex(m5.index)
    return m5, m15, h4, a15i.to_numpy()

# On a besoin de savoir, pour chaque trade, si c est une sortie SL ou extension
# et son R. On instrumente run_exit en rejouant avec un marqueur.
def run_tagged(y0, y1, buf, ext, fill, bs="m5_asof"):
    """Rejoue run_exit et etiquettes les trades SL vs extension.
    Astuce: on lance 2 fois -- une avec un SL enorme (jamais touche) pour
    n avoir QUE des sorties extension, et on compare les n."""
    m5, m15, h4, a15 = fr(y0, y1)
    cf = dict(BASE); cf["buf_atr"] = buf; cf["bias_src"] = bs
    # run normal
    r = ENG.run_exit(m5, m15, h4, cf, exit_mode="extend", ext_atr=ext, tp_r=99,
                     spread_pips=20.0, point_size=0.01, atr_ref=a15,
                     ext_fill=fill, slip_points=1.0)
    # run "SL infranchissable": buf enorme -> le SL ne sera jamais touche, donc
    # toutes les sorties sont des sorties extension (ou positions ouvertes a la fin)
    cf2 = dict(cf); cf2["buf_atr"] = 10000.0
    r2 = ENG.run_exit(m5, m15, h4, cf2, exit_mode="extend", ext_atr=ext, tp_r=99,
                      spread_pips=20.0, point_size=0.01, atr_ref=a15,
                      ext_fill=fill, slip_points=1.0)
    return r, r2

print("=" * 108)
print("R283 — CALIBRATION: le modele 'close' reproduit-il les 10-22% de sorties PERDANTES ?")
print("=" * 108)

CIBLES = [
    ("A2 championne 21-23 (buf 2.941)", 2.941 / 2.04, 8.0, "m5_asof", 2021, 2023, 10, 1.010),
    ("NB sans biais 21-23 (buf 2.941)", 2.941 / 2.04, 8.0, "none", 2021, 2023, 13, 0.969),
    ("C non traduit 21-23 (buf 6.0)", 6.0, 8.0, "m5_asof", 2021, 2023, 16, 0.583),
    ("B16 buf16 21-25 (buf 7.843)", 7.843 / 2.04, 8.0, "m5_asof", 2021, 2025, 20, 0.514),
]

print(f"\n{'config':34s} {'modele':9s} | {'n':>5s} {'R tot':>7s} {'pf':>5s} | "
      f"{'cible MT5 %perd':>15s} {'R moy ext MT5':>13s}")
for lab, buf, ext, bs, y0, y1, pct_mt5, r_mt5 in CIBLES:
    print(f"\n--- {lab} | buf_python={buf:.2f} ext={ext} bias={bs} ---")
    for fill in ("extreme", "thresh", "close"):
        r, r2 = run_tagged(y0, y1, buf, ext, fill, bs)
        # r2 = uniquement sorties extension (SL infranchissable)
        arr2 = np.array([t[0] for t in r2["trades"]]) if r2["trades"] else np.array([])
        if len(arr2):
            pct_loss = (arr2 < 0).mean() * 100
            rmean = arr2.mean()
        else:
            pct_loss = rmean = float("nan")
        print(f"  {fill:9s} | {r['n']:5d} {r['R']:+7.1f} {r['pf']:5.2f} | "
              f"{pct_mt5:6d}%           {r_mt5:+8.3f}   || "
              f"python ext: n={len(arr2)} %perd={pct_loss:5.1f}% Rmoy={rmean:+.3f}")

print("\n" + "=" * 108)
print("VERDICT DE CALIBRATION")
print("=" * 108)
print("Le bon modele est celui dont le %PERDANT et le R MOYEN des sorties")
print("extension collent aux mesures MT5 (colonne 'cible' / 'R moy ext MT5').")
print("Rappel: 'extreme' et 'thresh' ont 0% de perdantes par construction.")
print("\nFIN", flush=True)
