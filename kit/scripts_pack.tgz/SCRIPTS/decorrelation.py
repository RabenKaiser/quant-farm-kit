# -*- coding: utf-8 -*-
r"""decorrelation.py -- MATRICE DE CORRELATION DES JAMBES (mix, pas collection).

POURQUOI. La simulation prop (SIMU_PROP_15.md) donne P(-5 %) = 12 a 28 % selon
le profil. Une part de ce risque n'est PAS de l'alpha manquant : c'est de la
REDONDANCE. Beaucoup de jambes gagnantes sont la MEME famille KELT sur des
indices correles (DEU/JPN/GBR/USA30/USA500), donc elles perdent ensemble le
meme jour. Un portefeuille de 15 jambes correlees n'est pas un portefeuille de
15 paris, c'est un pari repete 15 fois avec 15 fois les frais.

CE QUE FAIT CET OUTIL. Il lit les transactions REELLES (par_farm_*_deals.jsonl,
donc des ordres reels du terminal, pas du corpus), construit une matrice de PnL
QUOTIDIEN par jambe, et :
  1) publie la matrice de correlation des rendements quotidiens ;
  2) classe les jambes par apport marginal (correlation moyenne aux autres) ;
  3) propose un SOUS-ENSEMBLE DECORRELE de 15 jambes qui maximise le mu
     quotidien tout en plafonnant la correlation moyenne ;
  4) signale les grappes (clusters) ou une seule famille porte le risque.

USAGE :
  python decorrelation.py                  -> matrice + classement + mix propose
  python decorrelation.py --top 15         -> taille du mix
  python decorrelation.py --maxcorr 0.35   -> plafond de correlation moyenne
"""
import json
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent.parent


def charge_jambes(min_tx=100):
    """Charge chaque campagne reelle : PnL quotidien + mu + n.

    GARDE-FOUS (10/14, apres un premier passage qui proposait un mix contenant
    une jambe « holdout1 » et des jambes au mu de +20 R/tx) :
      - les jambes de HOLDOUT sont EXCLUES : le holdout sert au controle final,
        il ne peut jamais entrer dans un portefeuille ni dans un classement ;
      - n >= min_tx : une jambe de 31 transactions n'est pas une jambe ;
      - ATTENTION a l'unite : le champ 'pnl' des deals est en DEVISE du compte,
        pas en R. La correlation est insensible a l'echelle (donc valide), mais
        la colonne mu est du PnL moyen par transaction en devise, PAS un R/tx.
    """
    jambes = {}
    exclus = []
    # FAMILLES CONDAMNEES (mesurees en ordres reels puis fermees le 12/10) :
    # sr6, kvw, crt6/crt, bb3fx. Un outil de mix qui les reproposerait
    # ressusciterait des familles deja mortes sur ordres reels -- meme classe
    # d'erreur que la jambe « holdout1 » du premier passage.
    CONDAMNEES = ("sr6", "kvw", "crt6", "crt_", "bb3fx")
    for f in sorted(BASE.glob("par_farm_*_deals.jsonl")):
        tag = f.name[len("par_farm_"):-len("_deals.jsonl")]
        if tag.endswith("_deals") or "MESURE" in tag:
            continue
        if "holdout" in tag.lower():
            exclus.append(tag)
            continue
        if any(c in tag.lower() for c in CONDAMNEES):
            exclus.append(tag)
            continue
        jours = defaultdict(float)
        n = 0
        try:
            for ligne in f.read_text(encoding="utf-8").splitlines():
                ligne = ligne.strip()
                if not ligne or not ligne.startswith("{"):
                    continue
                try:
                    o = json.loads(ligne)
                except ValueError:
                    continue
                if "day" not in o or "pnl" not in o:
                    continue
                jours[o["day"]] += float(o["pnl"])
                n += 1
        except OSError:
            continue
        if n < min_tx or len(jours) < 20:
            continue
        jambes[tag] = dict(jours=dict(jours), n=n,
                           total=float(sum(jours.values())),
                           mu=float(sum(jours.values())) / n)
    if exclus:
        print("jambes de HOLDOUT exclues du classement : %s" % ", ".join(sorted(set(exclus))))
    return jambes


def matrice(jambes, cle="jours"):
    tags = sorted(jambes)
    dates = sorted({d for t in tags for d in jambes[t][cle]})
    di = {d: i for i, d in enumerate(dates)}
    M = np.zeros((len(tags), len(dates)))
    for k, t in enumerate(tags):
        for d, v in jambes[t][cle].items():
            M[k, di[d]] = v
    return tags, dates, M


def correlations(M):
    n = M.shape[0]
    C = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            a, b = M[i], M[j]
            if a.std() < 1e-12 or b.std() < 1e-12:
                C[i, j] = 0.0
            else:
                C[i, j] = float(np.corrcoef(a, b)[0, 1])
    return C


SYMBOLES = ["eurusd", "gbpusd", "usdcad", "usdchf", "usdjpy", "audusd", "nzdusd",
            "eurjpy", "gbpjpy", "audjpy", "nzdjpy", "cadjpy", "chfjpy",
            "eurgbp", "eurchf", "euraud", "eurcad", "eurnzd", "gbpcad", "gbpchf",
            "gbpaud", "audcad", "audnzd", "nzdcad", "xauusd", "xagusd", "xpt",
            "spxusd", "nsxusd", "udxusd", "btcusd", "ethusd",
            "usa30", "usa500", "ussc2000", "hkg", "deu", "jpn", "gbr", "aus",
            "che", "chi", "esp", "eus", "nld", "fra", "dollar", "vol"]


ABREV = {
    "ej": "eurjpy", "gj": "gbpjpy", "nj": "nzdjpy", "uj": "usdjpy",
    "aj": "audjpy", "cj": "cadjpy", "chj": "chfjpy", "eg": "eurgbp",
    "ec": "eurcad", "ea": "euraud", "an": "audnzd", "ac": "audcad",
    "nc": "nzdcad", "ga": "gbpaud", "gc": "gbpcad", "gf": "gbpchf",
    "us30": "usa30", "us500": "usa500", "spx": "spxusd", "nsx": "nsxusd",
    "xau": "xauusd", "xag": "xagusd", "ussc": "ussc2000",
}


def symbole(tag):
    """Symbole (marche) d'une jambe, devine depuis son nom. Sert a appliquer la
    regle prop « UNE direction par paire a la fois » : on n'accepte jamais deux
    jambes du meme marche dans le mix. Les abbreviations du labo (ej=EURJPY,
    gj=GBPJPY, xau=XAUUSD...) sont resolues AVANT la recherche longue, sinon
    « g3_scr_kelthigh_ej » et « g3_keltwalk_eurjpy » passaient pour deux marches
    differents alors que c'est le MEME (constate au 1er essai du mix)."""
    t = tag.lower()
    for a, complet in ABREV.items():
        if ("_" + a) in t or t.endswith(a):
            return complet
    trouve = []
    for s in SYMBOLES:
        if s in t:
            trouve.append((t.index(s), s))
    if not trouve:
        return t[:12]
    trouve.sort()
    return trouve[0][1]


def main():
    top = 15
    maxcorr = 0.40
    if "--top" in sys.argv:
        top = int(sys.argv[sys.argv.index("--top") + 1])
    if "--maxcorr" in sys.argv:
        maxcorr = float(sys.argv[sys.argv.index("--maxcorr") + 1])

    jambes = charge_jambes()
    if not jambes:
        print("aucune jambe reelle chargeable (par_farm_*_deals.jsonl)")
        return
    tags, dates, M = matrice(jambes)
    C = correlations(M)
    print("=== CORRELATION DES JAMBES REELLES ===")
    print("%d jambes, %d jours de transactions reelles (%s -> %s)"
          % (len(tags), len(dates), dates[0], dates[-1]))
    print()
    # correlation moyenne de chaque jambe aux autres
    moy = []
    for i, t in enumerate(tags):
        autres = [C[i, j] for j in range(len(tags)) if j != i]
        moy.append((float(np.mean(autres)), t, jambes[t]["mu"], jambes[t]["n"]))
    moy.sort()
    print("%-34s %8s %8s %6s" % ("jambe (la + decorrelee d'abord)", "corr_moy", "mu", "n"))
    for c, t, mu, n in moy[:18]:
        print("%-34s %+8.3f %+8.4f %6d" % (t[:34], c, mu, n))
    print()
    # grappes : jambes dont la correlation mutuelle depasse 0.5
    seuil = 0.5
    vus = set()
    print("=== GRAPPES (corr > %.2f) ===" % seuil)
    for i, t in enumerate(tags):
        if t in vus:
            continue
        grp = [tags[j] for j in range(len(tags)) if j != i and C[i, j] > seuil]
        if grp:
            grp = [t] + grp
            vus.update(grp)
            print("  %d jambes : %s" % (len(grp), ", ".join(x[:26] for x in grp)))
    print()
    # selection gloutonne : on prend la jambe au meilleur mu marginal en
    # respectant le plafond de correlation moyenne avec celles deja prises
    choisis = []
    restants = set(range(len(tags)))
    syms_pris = set()
    LAMBDA = 2.0        # penalite : 2 unites de mu par point de correlation moyenne
    while restants and len(choisis) < top:
        meilleur = None
        for i in restants:
            s = symbole(tags[i])
            if s in syms_pris:
                continue        # REGLE PROP : une seule jambe par marche
            cm = float(np.mean([C[i, j] for j in choisis])) if choisis else 0.0
            if cm > maxcorr:
                continue
            score = jambes[tags[i]]["mu"] - LAMBDA * max(cm, 0.0)
            if meilleur is None or score > meilleur[0]:
                meilleur = (score, i, cm)
        if meilleur is None:
            break
        choisis.append(meilleur[1])
        syms_pris.add(symbole(tags[meilleur[1]]))
        restants.discard(meilleur[1])
    print("=== MIX PROPOSE (%d jambes, UNE PAR MARCHE, corr plafonnee a %.2f) ===" % (top, maxcorr))
    print("%-34s %-9s %8s %6s %10s" % ("jambe", "marche", "mu(devise)", "n", "corr_mix"))
    tot_mu = []
    for i in choisis:
        cm = 0.0 if len(choisis) < 2 else float(np.mean([C[i, j] for j in choisis if j != i]))
        print("%-34s %-9s %+8.4f %6d %+10.3f" % (tags[i][:34], symbole(tags[i]),
                                                 jambes[tags[i]]["mu"],
                                                 jambes[tags[i]]["n"], cm))
        tot_mu.append(jambes[tags[i]]["mu"])
    if tot_mu:
        print()
        print("mu moyen des jambes retenues : %+.4f | corr moyenne du mix : %+.3f"
              % (float(np.mean(tot_mu)),
                 float(np.mean([C[i, j] for i in choisis for j in choisis if i != j])) if len(choisis) > 1 else 0.0))
    # comparaison : le mix decorrele contre les 15 meilleures jambes brutes
    brut = sorted(range(len(tags)), key=lambda i: -jambes[tags[i]]["mu"])[:top]
    if len(brut) > 1:
        cmb = float(np.mean([C[i, j] for i in brut for j in brut if i != j]))
        print("les %d meilleures jambes BRUTES : mu moyen %+.4f | corr moyenne %+.3f"
              % (top, float(np.mean([jambes[tags[i]]["mu"] for i in brut])), cmb))


if __name__ == "__main__":
    main()