# -*- coding: utf-8 -*-
"""c13v2t_map2_r198.py — fin de cartographie: EURJPY 2024-2025 + XAUUSD
2023-2025 (les 5 cellules manquantes)."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\c13v2t_map_r197.jsonl"


def cfg(mg):
    return dict(InpMagic=mg, InpLots=0.10, InpRiskPct=0.0, InpTpR=2.5,
                InpMagLookbackH4=60, InpTrailAtrMult=1.5, InpTrailAfterR=1.0,
                InpImpulseAtrMult=0.9, InpImpulseLook=6, InpAtrPeriod=14,
                InpHtfEmaPeriod=200, InpPinWickRatio=1.5, InpCloseInZoneMin=0.15,
                InpMinStopPips=2.5, InpBufferAtrFrac=0.25, InpMaxSpreadPts=80,
                InpUseHourFilter=True, InpExcludedHoursCSV="6,7,12,15,19,23",
                InpUseDailyStop=True, InpDailyStopR=3.0, InpMaxTradesDay=0,
                InpUtcOffset=2, InpVerbose=False)


def main():
    mg = 770000
    RUNS = [("EURJPY-2024", "EURJPY", "2024.01.01", "2025.01.01"),
            ("EURJPY-2025", "EURJPY", "2025.01.01", "2026.01.01"),
            ("XAUUSD-2023", "XAUUSD", "2023.01.01", "2024.01.01"),
            ("XAUUSD-2024", "XAUUSD", "2024.01.01", "2025.01.01"),
            ("XAUUSD-2025", "XAUUSD", "2025.01.01", "2026.01.01")]
    with open(OUT, "a", encoding="utf-8") as fo:
        for tag, sym, frm, to in RUNS:
            mg += 1
            c = cfg(mg)
            print(f"[r198 {tag}] ...", flush=True)
            r = RF.run_backtest("C13V2T_EA", symbol=sym, tf="M5",
                                from_d=frm, to_d=to, deposit=10000,
                                max_wait=3600, inputs=c)
            fo.write(json.dumps({"tag": tag, "sym": sym, "r": r},
                                default=str) + "\n")
            fo.flush()
            print(f"[{tag}] " + ("null" if r is None else
                  f"p={r.get('profit')} n={r.get('trades')} "
                  f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
            time.sleep(2)
    print("FIN r198", flush=True)


if __name__ == "__main__":
    main()
