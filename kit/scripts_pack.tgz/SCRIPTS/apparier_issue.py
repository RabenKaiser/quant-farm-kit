"""apparier_issue : sur LES MEMES transactions, que dit le modele et que dit le reel ?

Round 384. `apparier_modele_ea.py` a montre que le modele, evalue sur les instants REELS de l'EA,
annonce 41-46 % de gagnantes -- alors que les ordres reels donnent 33,7 %. Les instants, la densite,
la trame, la mecanique de sortie, le spread effectif, l'ATR de l'EA et la resolution M30/M1 ont tous
ete mesures et conformes. Il reste donc une seule question, et ce script la tranche :

    sur la MEME transaction (meme paire, meme instant d'entree), le modele dit "cible touchee"
    et le reel dit "stop touche" -- ou bien les deux sont d'accord ?

L'issue REELLE est dans les lignes `JRN` du journal du testeur, en DEUX enregistrements par position :

    JRN NZDUSD 2025.04.02 05:30 SR97S|... 0 2 0.57211  0.00 0.00 0.00 0.10   <- 0 = entree
    JRN NZDUSD 2025.04.02 09:11 SR97S|... 1 2 0.57274 -6.30 0.00 0.00 0.10   <- 1 = sortie

Le champ apres l'identifiant de ligne est le TYPE d'evenement, le suivant est l'id de position. On
recolle entree et sortie par l'id, et on exprime le deplacement de prix REEL en R avec **le meme ATR
que le modele** (celui du corpus, a la barre de signal). C'est volontaire : les deux R sont alors dans
la meme unite, et l'ecart mesure uniquement la question posee -- QUI a touche sa barriere le premier.
L'ATR de l'EA n'entre pas dans la comparaison, il ne peut donc pas l'expliquer.

Sortie : par paire, taux de gagnantes REEL et MODELE sur les memes transactions, taux d'accord,
table de contingence (modele x reel), controle d'alignement du prix d'entree, et les pires desaccords
en detail pour inspecter le chemin intra-barre.

Env : PROFIL=farm|mt5 (defaut farm), LIGNE=SR97S, TF=M30,
      PAIRES=NZDUSD,EURCHF,AUDUSD,CADJPY.
"""
import os
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM  # noqa: E402

PROFILS = {"mt5": "E23367DD11DBEB0EF97D08185EAB7295",
           "farm": "CF0B997454318B475CF01419AFE2BBF3"}
TESTER = (Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Tester")
          / PROFILS.get(os.environ.get("PROFIL", "farm"), ""))
LIGNE = os.environ.get("LIGNE", "SR97S")
TF = os.environ.get("TF", "M30")
# ROUND 393 : filtres de fenetre, indispensables pour ne pas melanger deux geometries ecrites dans le
# meme journal du jour (voir lit_journal).
JOUR = os.environ.get("JOUR", pd.Timestamp.now().strftime("%Y%m%d"))
EXEC_MIN = os.environ.get("EXEC_MIN", "")
EXEC_MAX = os.environ.get("EXEC_MAX", "")
HOLD, TPR, SL, RANGE = 64, 2.0, 1.0, 50
PAIRES = os.environ.get("PAIRES", "NZDUSD,EURCHF,AUDUSD,CADJPY").split(",")


def lit_journal():
    """Positions reelles recollees (entree+sortie) depuis les journaux du testeur.

    Le filtre `TRIGGER_LAB (SYM,TF)` est indispensable : un meme symbole a ete teste en M5 et en M30,
    et les lignes JRN ne portent pas l'unite de temps.

    ROUND 393 : deux filtres de plus, appris a la dure. `JOUR` restreint au journal du jour, parce
    qu'un filtre sur l'heure seule laisse passer la campagne de la VEILLE ("23:32" >= "01:27" est vrai
    en comparaison de chaines). `EXEC_MAX` borne la fenetre d'execution, parce que plusieurs campagnes
    du meme symbole avec des GEOMETRIES differentes (stop 1 ATR contre stop 3 ATR) sont ecrites dans le
    meme journal du jour : sans borne, elles se melangent en silence.
    """
    re_jrn = re.compile(
        r"(\d{2}:\d{2}:\d{2})\.\d+\s+TRIGGER_LAB \((\w+),%s\).*?JRN \w+ "
        r"(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}) (%s\|[^\s]*) "
        r"([01]) (\d+) ([\d.eE+-]+) ([-\d.]+) ([-\d.]+) ([-\d.]+) ([\d.]+)"
        % (TF, re.escape(LIGNE)))
    pos, orphelins = {}, 0
    for lg in TESTER.glob("Agent-*/logs/%s.log" % JOUR):
        try:
            txt = lg.read_text(encoding="utf-16", errors="replace")
        except OSError:
            continue
        if "JRN " not in txt:
            txt = lg.read_text(encoding="utf-8", errors="replace")
        for m in re_jrn.finditer(txt):
            ex, sym, t, _lid, typ, pid, prix, prof, swap, comm, lot = m.groups()
            if EXEC_MIN and ex < EXEC_MIN:
                continue
            if EXEC_MAX and ex > EXEC_MAX:
                continue
            p = pos.setdefault((sym, fin_cle(t), int(pid)), {})
            t = pd.Timestamp(t.replace(".", "-", 2).replace(".", " "))
            if typ == "0":
                p.setdefault("t_in", t)
                p.setdefault("p_in", float(prix))
                p["lot"] = float(lot)
            elif "t_in" in p:
                p["t_out"] = t
                p["p_out"] = float(prix)
                p["prof"] = float(prof) + float(swap) + float(comm)
            else:
                orphelins += 1
    return pos, orphelins


def fin_cle(t):
    """Cle de fenetre : le jour de l'entree. Les ids de position recommencent a chaque test, donc il
    faut une cle qui distingue les tests -- le jour suffit, et il resiste au fait que l'horodatage
    d'impression du journal n'est pas toujours disponible."""
    return str(t)[:10]


def modele(D, i):
    """Issue du modele pour le signal a la barre i : (kind, R, prix de sortie, prix d'entree)."""
    o, h, l, c, a = D["o"], D["h"], D["l"], D["c"], D["a"]
    if i < RANGE or i + 1 + HOLD >= len(c):
        return None
    st = a[i]
    if not np.isfinite(st) or st <= 0:
        return None
    sp = D["cout"]
    e = o[i + 1]
    tp, sl = e - (TPR + sp) * st, e + max(SL - sp, 0.1) * st
    Hh, Ll = h[i + 1:i + 1 + HOLD], l[i + 1:i + 1 + HOLD]
    htp, hsl = Ll <= tp, Hh >= sl
    it = int(np.argmax(htp)) if htp.any() else 10 ** 6
    isl = int(np.argmax(hsl)) if hsl.any() else 10 ** 6
    if htp.any() and (not hsl.any() or it < isl):
        return 0, TPR, tp, e
    if hsl.any():
        return 1, -1.0, sl, e
    return 2, ((e - c[i + 1 + HOLD]) / st) - sp, c[i + 1 + HOLD], e


def classe(R):
    return np.where(R > 1.0, 0, np.where(R < -0.5, 1, 2))


def main():
    prof = os.environ.get("PROFIL", "farm")
    pos, orphelins = lit_journal()
    n_pos = sum(1 for p in pos.values() if "p_out" in p)
    print("journal PROFIL=%s : %d positions recollees (entree+sortie), %d sorties orphelines"
          % (prof, n_pos, orphelins))
    lignes = []
    for paire in PAIRES:
        D = NM.charge(paire, "m1_pos")
        if D is None:
            print("  %s : corpus absent" % paire)
            continue
        idx = D["idx"]
        d = np.abs(np.diff(D["c"]))
        d = d[d > 0]
        pt = float(d.min()) if len(d) else 0.0
        reels, modeles, ecarts, detail = [], [], [], []
        fens, durs = [], []
        for (sym, fin, pid), p in sorted(pos.items(), key=lambda kv: kv[1].get("t_in", pd.Timestamp(0))):
            if sym != paire or "p_out" not in p or "t_in" not in p:
                continue
            sig_t = p["t_in"] - pd.Timedelta(minutes=30)
            i = int(idx.searchsorted(sig_t))
            if i >= len(idx) or (idx[i] - sig_t).total_seconds() > 60:
                i -= 1
            if i < 0 or abs((idx[i] - sig_t).total_seconds()) > 60:
                continue
            mm = modele(D, i)
            if mm is None:
                continue
            kind, Rm, pm, em = mm
            Rr = (p["p_in"] - p["p_out"]) / float(D["a"][i])
            reels.append(Rr)
            modeles.append(Rm)
            ecarts.append(p["p_in"] - em)
            fens.append(fin)
            durs.append((p["t_out"] - p["t_in"]).total_seconds() / 3600.0)
            detail.append((p["t_in"], kind, pm, p["p_out"], Rr, Rm, p["p_in"]))
        if len(reels) < 10:
            print("  %s : %d transactions appariees -- trop peu" % (paire, len(reels)))
            continue
        reels, modeles = np.array(reels), np.array(modeles)
        kr, km = classe(reels), classe(modeles)
        n = len(reels)
        pr, pm_ = 100.0 * np.mean(kr == 0), 100.0 * np.mean(km == 0)
        acc = 100.0 * np.mean(kr == km)
        print("\n=== %s : %d transactions identiques (modele ET reel) ===" % (paire, n))
        print("  gagnantes REELLES : %.1f %%   |  gagnantes MODELE : %.1f %%   |  accord : %.1f %%"
              % (pr, pm_, acc))
        print("  R/tx reel %+.4f  |  R/tx modele %+.4f" % (np.mean(reels), np.mean(modeles)))
        print("  ecart de prix d'entree : median %+.6f  |ecart| median %.6f (point=%.6f)"
              % (np.median(ecarts), np.median(np.abs(ecarts)), pt))
        print("  contingence (lignes=modele, colonnes=reel) cible/stop/echeance :")
        for a_, lab in ((0, "modele cible  "), (1, "modele stop   "), (2, "modele echeance")):
            print("    %s : %s" % (lab, [int(np.sum((km == a_) & (kr == b))) for b in (0, 1, 2)]))
        print("  pires desaccords (modele mieux que le reel) :")
        for j in np.argsort(-(modeles - reels))[:5]:
            t, kind, pmv, po, Rr, Rm, pin = detail[j]
            print("    %s modele=%-8s sortie modele %.5f vs reelle %.5f | R %+.2f vs %+.2f"
                  % (t, ("cible", "stop", "echeance")[kind], pmv, po, Rm, Rr))
        # --- integrite de la protection : une position doit sortir dans [-1, +2] R et en <= 32 h ---
        durs = np.array(durs)
        hors = np.abs(reels) > 1.6
        print("  INTEGRITE : duree mediane %.1f h  max %.1f h  |  duree > 34 h : %d/%d"
              % (np.median(durs), durs.max(), int(np.sum(durs > 34)), n))
        print("    |R| > 1,6 : %d/%d transactions (%.1f %%) portant %+.1f R au total"
              % (int(hors.sum()), n, 100.0 * hors.mean(), float(reels[hors].sum())))
        print("    R/tx reel SANS ces transactions : %+.4f" % float(np.mean(reels[~hors])))
        for j in np.argsort(reels)[:4]:
            t, kind, pmv, po, Rr, Rm, pin = detail[j]
            print("    pire : %s entree %.5f sortie %.5f | R %+.2f | duree %.1f h | modele=%s"
                  % (t, pin, po, Rr, durs[j], ("cible", "stop", "echeance")[kind]))
        print("  par fenetre (fin de test) : n, gagnantes reelles, gagnantes modele, R/tx reel")
        for f_ in sorted(set(fens)):
            sel = np.array([x == f_ for x in fens])
            if sel.sum() < 3:
                continue
            print("    %s : n=%2d  reel %5.1f %%  modele %5.1f %%  R/tx reel %+7.3f"
                  % (f_.date(), sel.sum(), 100.0 * np.mean(kr[sel] == 0),
                     100.0 * np.mean(km[sel] == 0), float(np.mean(reels[sel]))))
        lignes.append((paire, n, pr, pm_, acc, float(np.mean(reels)), float(np.mean(modeles))))
    if lignes:
        print("\n=== SYNTHESE ===")
        print("  paire      n  reel%  modele%  accord%   R/tx reel  R/tx modele")
        for p_, n, pr, pm_, acc, rr, rm in lignes:
            print("  %-7s %4d  %5.1f  %6.1f  %6.1f   %+9.4f  %+9.4f" % (p_, n, pr, pm_, acc, rr, rm))
        tr = sum(x[1] for x in lignes)
        print("  TOTAL   %4d  reel %+.4f R/tx   modele %+.4f R/tx"
              % (tr, sum(x[1] * x[5] for x in lignes) / tr, sum(x[1] * x[6] for x in lignes) / tr))
    return 0


if __name__ == "__main__":
    sys.exit(main())
