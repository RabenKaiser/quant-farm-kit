import collections, json, os, sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
B = r"C:\EAFarm\HISTORY - Copy\research"
ATR = 2.77
PAIRE = "EURUSD"
TESTS = [("prop_clean_s2_t12", 2), ("brkasia_s4_t12", 4)]

# 1. plafond net par annee, trame M5, pour la paire des deux candidats
plafond = collections.defaultdict(list)
for line in open(os.path.join(B, "ENVELOPPE.jsonl"), encoding="utf-8",
                 errors="replace"):
    if not line.strip().startswith("{"):
        continue
    d = json.loads(line)
    if d.get("paire") == PAIRE and d.get("trame") == "M5" and d.get("net") is not None:
        plafond[str(d["regime"])].append(float(d["net"]))
plafond = {k: sum(v) / len(v) for k, v in plafond.items()}
actifs = {k for k, v in plafond.items() if v >= 1.0}
print("Plafond net %s M5 par annee : %s"
      % (PAIRE, {k: round(v, 4) for k, v in sorted(plafond.items())}))
print("Annees ACTIVES (net >= 1) : %s" % sorted(actifs))


def mensuel(tag, sl):
    f = os.path.join(B, "par_farm_%s_deals.jsonl" % tag)
    un_r = sl * ATR
    m = collections.defaultdict(float)
    if os.path.exists(f):
        for line in open(f, encoding="utf-8", errors="replace"):
            if not line.strip().startswith("{"):
                continue
            d = json.loads(line)
            j = str(d.get("day") or "")
            p = d.get("pnl")
            if len(j) >= 7 and isinstance(p, (int, float)):
                m[j[:7]] += float(p) / un_r
    return dict(m)


def rdd(s):
    cum = dd = sommet = 0.0
    pos = 0
    for k in sorted(s):
        cum += s[k]
        sommet = max(sommet, cum)
        dd = min(dd, cum - sommet)
        if s[k] > 0:
            pos += 1
    return cum, dd, (cum / abs(dd) if dd else 99.0), pos


series = {t: mensuel(t, sl) for t, sl in TESTS}
print()
print("   %-22s %-10s %9s %9s %7s %8s" %
      ("test", "regime", "R cumule", "DD", "R/DD", "mois +"))
for tag, sl in TESTS:
    s = series[tag]
    if not s:
        continue
    for nom, sous in (("TOUT", s),
                      ("ACTIF SEUL", {k: v for k, v in s.items()
                                      if k[:4] in actifs})):
        if len(sous) < 3:
            continue
        c, d, r, p = rdd(sous)
        print("   %-22s %-10s %+9.1f %9.1f %7.2f %5d/%d"
              % (tag, nom, c, d, r, p, len(sous)))
# combinaison sur les mois actifs
a, b = series[TESTS[0][0]], series[TESTS[1][0]]
communs = [k for k in sorted(set(a) & set(b)) if k[:4] in actifs]
if len(communs) >= 3:
    comb = {k: a[k] + b[k] for k in communs}
    c, d, r, p = rdd(comb)
    print("   %-22s %-10s %+9.1f %9.1f %7.2f %5d/%d"
          % ("COMBINAISON", "ACTIF SEUL", c, d, r, p, len(communs)))
    print()
    print("   mois retenus : %s" % ", ".join(communs))
