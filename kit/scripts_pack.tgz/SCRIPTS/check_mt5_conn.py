# -*- coding: utf-8 -*-
"""check_mt5_conn.py — test connexion MetaTrader5 à C:\MT5 + data paires."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import MetaTrader5 as mt5

if not mt5.initialize(r"C:\MT5\terminal64.exe"):
    print("INIT FAIL:", mt5.last_error())
    sys.exit(1)
print("Connecte a C:\\MT5")
info = mt5.account_info()
if info:
    print(f"Compte: {info.login} | Devise: {info.currency} | Balance: {info.balance:.2f} | Equite: {info.equity:.2f}")
else:
    print("pas de compte info (terminal demo sans login actif?)")

for s in ["USDJPY", "GBPUSD", "NZDUSD", "AUDCAD", "EURCAD"]:
    sym = mt5.symbol_info(s)
    if sym:
        print(f"{s}: bid={sym.bid} ask={sym.ask} spread={sym.spread}")
    else:
        print(f"{s}: absent/desactive")

# data H1 recente pour USDJPY (ma paire principale)
rates = mt5.copy_rates_from_pos("USDJPY", mt5.TIMEFRAME_H1, 0, 5)
if rates is not None and len(rates):
    for r in rates[-3:]:
        import datetime as _dt
        t = _dt.datetime.fromtimestamp(int(r[0]), tz=_dt.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        print(f"USDJPY H1 {t}: O={r[1]} H={r[2]} L={r[3]} C={r[4]}")
mt5.shutdown()
