"""Comparaison moteur vs MT5 ptrail AVEC warm-up (2022-2023 en amont).
Le leader ptrail a besoin de 200 barres H4 (SMA200) -> si on ne charge que
2024, le moteur n'a pas le warm-up et donne 0 trades. Corrigeons ça."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
import polars as pl
import numpy as np
import datetime as dt
import edge_correct as ec
import deep_signals as DS

E = lambda s: int(dt.datetime.strptime(s, "%Y-%m-%d").timestamp())

# charger TOUTE la période (2022-2025) pour le warm-up, backtester 2024
m1 = ec.load_m1("USDJPY")
tf = ec.to_tf(m1, 1800)

# config ptrail "équilibré" : lookback 40, sl 1.5 ATR, pyr 1.5R max 2, trail 3.5/1.0
cfg = dict(htf_sec=14400, lookback=40, sl_atr=1.5, rr=99, pyramid_max=2,
           pyramid_trigger_r=1.5, trail_atr_mult=3.5, trail_trigger_r=1.0,
           commission_rt=4.0, tick_value_per_pt=0.67)

# signal sur TOUTE la période (warm-up naturel), backtest seulement 2024
f = DS.htf_nest(tf, cfg)
a, b = E("2024-01-01"), E("2025-01-01")
tfseg = tf.filter((pl.col("time") >= a) & (pl.col("time") < b))
m1seg = m1.filter((pl.col("time") >= a) & (pl.col("time") < b))
tr = ec.backtest_m1_ptrail(m1seg, tfseg, f, "USDJPY", cfg)
nets = np.array([t["r"] - t["cost_r"] for t in tr]) if tr else np.array([])
print(f"MOTEUR ptrail USDJPY 2024 (warm-up 2022-23): n={len(nets)}")
if len(nets):
    print(f"  net/trade={nets.mean():+.3f} | total R={nets.sum():+.1f}")
print(f"  MT5 EA: n=262, profit +$8797")
print(f"  écart count: {262/max(1,len(nets)):.1f}x")
