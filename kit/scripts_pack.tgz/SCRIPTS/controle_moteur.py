"""controle_moteur : mon moteur de premier toucher est-il coherent sur son PROPRE corpus ?

Round 359. Tout ce qui se mesure de mon cote a ete ecarte : trame (binaire recompile avec `_Period`),
densite (9 a 15 positions par paire et par trimestre, conforme), instants (10 entrees reelles sur 10 =
signal Python), mecanique de sortie (mouvement a la sortie exactement -1,00 ATR, gagnantes +2,00 ATR),
pertes non honorees et roulement (2 % des positions), spread reel (comparable ou meilleur que le
corpus), ATR de l'EA (0,00068 contre 0,000636 au corpus, soit 1,07). Pourtant le modele annonce 41,4 %
de gagnantes et les ordres reels 26,1 %.

Le controle qui reste est interne : **sur le corpus, une entree ALEATOIRE, avec les memes barrieres et
le meme moteur, doit donner le taux d'equilibre de la theorie**. Pour une marche sans derive et des
barrieres decalees par le spread s (cible 2 ATR + s, stop 1 ATR - s), ce taux vaut (1 - s) / 3.

  - si le controle colle a la THEORIE, mon moteur est juste et l'edge affiche est bien dans les
    donnees du corpus : c'est alors le FLUX du courtier qui differe du corpus ;
  - si le controle colle au SIGNAL, mon moteur surestime systematiquement : tout le modele est a
    refaire.

Entrees aleatoires tirees dans la MEME plage horaire que les signaux (hors 7-16 h), en meme nombre,
avec le meme blocage « une position par paire » (32 h).
"""
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM

HOLD, TPR, SL, RANGE, MOM, SEUIL = 64, 2.0, 1.0, 50, 2.0, 0.97
PAIRES = [p.strip() for p in os.environ.get("PAIRES", "EURCHF,NZDUSD,AUDUSD,CADJPY").split(",")]
TIRAGES = int(os.environ.get("TIRAGES", "40"))


def resultat(D, sig):
    """Premier toucher, barrieres decalees par le spread, une position par paire."""
    c, h, l, o, a = D["c"], D["h"], D["l"], D["o"], D["a"]
    sig = np.asarray(sig, dtype=int)
    sig = sig[(sig >= RANGE) & (sig < len(c) - HOLD - 3)]
    sig = sig[np.isfinite(a[sig]) & (a[sig] > 0)]
    if len(sig) < 30:
        return None
    ent = sig + 1
    ent = ent[ent < len(c) - HOLD - 2]
    e, st = o[ent], a[sig[:len(ent)]]
    sp = D["cout"]
    tp, sl = e - (TPR + sp) * st, e + max(SL - sp, 0.1) * st
    off = np.arange(1, HOLD + 1)
    Hh, Ll = h[ent[:, None] + off], l[ent[:, None] + off]
    htp, hsl = Ll <= tp[:, None], Hh >= sl[:, None]
    it = np.where(htp.any(1), htp.argmax(1), 10 ** 6)
    isl = np.where(hsl.any(1), hsl.argmax(1), 10 ** 6)
    tph, slh = htp.any(1), hsl.any(1)
    kind = np.where(tph & (~slh | (it < isl)), 0, np.where(slh, 1, 2))
    garde, finb = [], None
    for k, i in enumerate(ent):
        t = D["idx"][i]
        if finb is not None and t < finb:
            continue
        garde.append(k)
        finb = t + pd.Timedelta(minutes=30 * HOLD)
    g = np.array(garde, dtype=int)
    return 100.0 * float(np.mean(kind[g] == 0)), len(g)


def main():
    print("=== CONTROLE : entrees ALEATOIRES contre signal SR97, meme moteur, meme corpus ===")
    print("  %-8s %10s %12s %12s %12s" % ("paire", "spread", "signal", "aleatoire", "theorie"))
    for p in PAIRES:
        D = NM.charge(p, "m1_pos")
        if D is None:
            continue
        c, a, idx = D["c"], D["a"], D["idx"]
        plage = np.flatnonzero(~((idx.hour >= 7) & (idx.hour <= 16)))
        plage = plage[np.isfinite(a[plage]) & (a[plage] > 0)]
        df = pd.DataFrame({"h": D["h"], "l": D["l"]})
        hi = df.h.rolling(RANGE).max().values
        lo = df.l.rolling(RANGE).min().values
        pos = (c - lo) / np.where(hi - lo > 0, hi - lo, np.nan)
        momok = np.abs(c - np.roll(c, 8)) <= MOM * a
        sig = np.flatnonzero(np.nan_to_num(pos, nan=-9.0) >= SEUIL)
        heures = idx.hour.values
        sig = sig[momok[sig] & ((heures[sig] < 7) | (heures[sig] > 16))]
        r_sig = resultat(D, sig)
        n = len(sig) if r_sig else 200
        rng = np.random.default_rng(20260922)
        taux = []
        for _ in range(TIRAGES):
            ech = np.sort(rng.choice(plage, size=min(n, len(plage)), replace=False))
            r = resultat(D, ech)
            if r:
                taux.append(r[0])
        theo = 100.0 * (1.0 - D["cout"]) / 3.0
        print("  %-8s %10.3f %11s %11.1f %% %11.1f %%"
              % (p, D["cout"], ("%5.1f %%" % r_sig[0]) if r_sig else "  --  ",
                 float(np.mean(taux)) if taux else float("nan"), theo), flush=True)
    print("\n  lecture : si ALEATOIRE colle a THEORIE, mon moteur est juste et l'ecart avec les ordres")
    print("  reels vient du FLUX (corpus contre donnees du courtier). Si ALEATOIRE colle au SIGNAL,")
    print("  c'est mon moteur qui surestime -- et tout le modele est a refaire.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
