# -*- coding: utf-8 -*-
"""AXE QUANT — test clé : edge_6E échantillonné en TEMPS INTRINSÈQUE DC.
Le concept central du doc Olsen : les barres M30 chronologiques -> événements DC
(barres intrinsèques). On applique la même logique edge_6E (fade des extrêmes
de range) sur l'échantillonnage DC. Si GO -> le temps intrinsèque est "goo".
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\edge_6E")
from strategie import signal, executer, preparer
from protocole import decoupage, porte2_concordance, porte5_chevauchement

IS1, IS2 = pd.Timestamp('2024-06-22'), pd.Timestamp('2024-12-11')
OOS_D, OOS_F = pd.Timestamp('2025-04-30 23:00'), pd.Timestamp('2025-12-01')
seg = lambda ts: decoupage(ts, IS1, IS2, OOS_D, OOS_F)

# charge M15 réel
m15 = pd.read_csv(r"C:\EAFarm\HISTORY - Copy\research\edge_6E\donnees_m15.csv",
                  parse_dates=['dt']).set_index('dt').sort_index()

# --- échantillonnage DC (barres intrinsèques) ---
def dc_bars(df, delta):
    """Construit des barres intrinsèques : chaque nouvelle barre commence à un
    événement DC (retournement de delta). OHLC = mouvement continu entre DC."""
    closes = df['c'].values
    o = df['o'].values; h = df['h'].values; l = df['l'].values
    ts = df.index.values
    rows = []
    mode = 0
    ext = closes[0]
    dc_i = 0
    bar_o = closes[0]; bar_h = closes[0]; bar_l = closes[0]
    for i in range(1, len(closes)):
        p = closes[i]
        bar_h = max(bar_h, h[i]); bar_l = min(bar_l, l[i])
        flip = False
        if mode == 1:
            if p > ext:
                ext = p                      # extrême suivi (comme le doc)
            elif p <= ext * (1 - delta):
                flip = True
        elif mode == -1:
            if p < ext:
                ext = p
            elif p >= ext * (1 + delta):
                flip = True
        else:
            if p >= ext * (1 + delta):
                flip = True
            elif p <= ext * (1 - delta):
                flip = True
        if flip:
            rows.append((ts[dc_i], bar_o, bar_h, bar_l, closes[i-1]))
            mode = 1 if p > ext else -1
            ext = p
            dc_i = i
            bar_o = closes[i-1]; bar_h = h[i]; bar_l = l[i]
    if len(rows) > 5:
        rows.append((ts[dc_i], bar_o, bar_h, bar_l, closes[-1]))
    return pd.DataFrame(rows, columns=['dt', 'o', 'h', 'l', 'c']).set_index('dt').sort_index()

for delta in [0.0005, 0.001, 0.002]:
    dc = dc_bars(m15, delta)
    if len(dc) < 3000:
        print(f"delta={delta}: trop peu de barres DC ({len(dc)}) — skip")
        continue
    m30 = preparer(dc, '30min')   # M30 sur les timestamps DC (agrégation par horloge)
    sig = signal(m30)
    tr = executer(m30, dc, sig, segment=seg)
    tr = tr[tr.seg != 'x']
    c = porte2_concordance(tr)
    if c:
        p = c['par_periode']
        net = tr.net.mean()
        t = net / (tr.net.std() / np.sqrt(len(tr))) if len(tr) > 1 else 0
        ch = porte5_chevauchement(tr, pd.Series(np.full(len(tr), 96.0)), 30)
        print(f"DC delta={delta}: n_dc={len(dc)} trades={len(tr)} net={net:+.4f}R t={t:+.2f} "
              f"concord={c['concordante']}")
        print(f"   IS1={p['IS1']:+.3f} IS2={p['IS2']:+.3f} OOS={p['OOS']:+.3f} "
              f"t_corr={ch['t_corrige']:.2f}")
    else:
        print(f"DC delta={delta}: pas assez de trades par période")
