﻿p = "C:/EAFarm/HISTORY - Copy/research/SCRIPTS/mt5_up_run.py"
s = open(p, encoding="utf-8").read()
# tester avec un cap large pour isoler l'effet
s2 = s.replace("InpMaxPos=4\\nInpMaxPerSide=4", "InpMaxPos=99\\nInpMaxPerSide=99")
assert s2 != s, "remplacement echoue"
open(p+".cap99", "w", encoding="utf-8").write(s2)
print("variante ecrite : mt5_up_run.py.cap99")
