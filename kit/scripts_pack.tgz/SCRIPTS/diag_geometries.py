"""diag_geometries : que vaut CHAQUE geometrie de CHAQUE jambe, par annee, et laquelle les plis retiennent.

Round 463. Les deux tests hors echantillon (glouton et sans selection) s'effondrent a mu ~ 0 alors que le
choix de geometrie fait sur TOUT l'echantillon donne +0,076 R/tx. Une seule explication possible : les
plis retiennent des geometries dont le R/tx hors annee est mauvais. On le verifie jambes par jambes --
et on regarde si le R/tx d'une geometrie tient d'une annee a l'autre, ce qui est la vraie question.

Usage : python SCRIPTS\\diag_geometries.py
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import choix_basket as CB  # noqa: E402
import basket_loyo as LY  # noqa: E402


def main():
    cache = CB.charge()
    jambes = [(p, l, r, s) for p, l, r, s in CB.JAMBES
              if any((p, l, r, s, g) in cache for g in CB.GEOM)]
    annees = LY.annees(cache)
    print("=== R/tx PAR GEOMETRIE ET PAR ANNEE (ordres reels) ===")
    for paire, ligne, range_, sens in jambes:
        print("\n%s r=%d %s" % (paire, range_, sens))
        print("   %6s %5s %8s %8s   %s" % ("cible", "n", "R/tx total", "mu/s2", "R/tx par annee"))
        for g in CB.GEOM:
            s = cache.get((paire, ligne, range_, sens, g))
            if not s:
                continue
            st = CB.stats(s)
            par = {}
            for t, x, _ in s:
                par.setdefault(t.year, []).append(x)
            print("   %6g %5d %+8.4f %8.4f   %s" %
                  (g, st["n"], st["mu"], st["mus2"],
                   " ".join("%d %+.3f" % (y, float(np.mean(v))) for y, v in sorted(par.items()))))
        # geometrie retenue par chaque pli
        ret = []
        for y in annees:
            c = LY.candidats(cache, [ (paire, ligne, range_, sens) ], y)
            cle = (paire, ligne, range_, sens)
            ret.append("%d:%s" % (y, ("%g" % c[cle][0]) if cle in c else "-"))
        print("   geometrie retenue hors annee -> " + "  ".join(ret))
    return 0


if __name__ == "__main__":
    sys.exit(main())
