import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import MetaTrader5 as mt5
from pathlib import Path

TERM = r"C:\EAFarm\MT5\Farm\terminal64.exe"
if not mt5.initialize(path=TERM):
    raise RuntimeError(f"init failed: {mt5.last_error()}")
for sym in ["EURUSD", "USDJPY"]:
    s = mt5.symbol_info(sym)
    print(sym, "filling_mode=", s.filling_mode, "order_mode=", s.order_mode,
          "trade_exemode=", s.trade_exemode, "trade_mode=", s.trade_mode)
    tick = mt5.symbol_info_tick(sym)
    print("  tick:", None if tick is None else (tick.bid, tick.ask))
mt5.shutdown()
