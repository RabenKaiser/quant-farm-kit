﻿src = open(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\MQL5\Experts\eepeek\ORION_ROBOT.mq5", encoding="utf-8").read()
i = src.find("has=pos_selection")
print(src[i:i+1200] if i>0 else "(pas de code has=pos_selection)")
