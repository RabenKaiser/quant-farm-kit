# -*- coding: utf-8 -*-
"""corr_sel.py — ETAPE 3 : GARDER LES PAIRES PEU CORRELEES.

CONSIGNE
--------
"Tu essaies de trouver des paires qui ne sont pas trop correlees entre elles.
 Tu fais un portefeuille avec ca."

CE SCRIPT
---------
1. Calcule la CORRELATION des rendements M5 entre les 18 paires du portefeuille
   (sur les donnees Dukascopy reelles, qui couvrent 2019-2026).
2. Construit un portefeuille en GLOUTON : on ajoute les paires une par une en
   gardant celle qui apporte le plus tout en restant sous un seuil de
   correlation moyenne avec celles deja retenues.
3. Sort la liste des paires a garder + la matrice de correlation.

Le but : un portefeuille qui monte sans que toutes les paires tombent
ensemble. Deux paires correlees a 0.9 = une seule paire en double.
"""
import json, itertools
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
OUT = BASE / "corr_sel.json"

PORT = json.load(open(BASE / "port_wfvg.json", encoding="utf-8"))


def load_ret(sym):
    """Rendements M5 en % (log-returns) sur les donnees Dukascopy."""
    p = BASE / "m1_pos" / f"{sym}_M1.csv"
    if not p.exists():
        return None
    df = pd.read_csv(p, usecols=["time", "close"])
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    s = df.set_index("time")["close"].resample("5min").last().dropna()
    return np.log(s / s.shift(1)).dropna()


print("=" * 96)
print("CORRELATIONS DES PAIRES DU PORTEFEUILLE (rendements M5, Dukascopy)")
print("=" * 96)

rets = {}
for s in sorted(PORT):
    r = load_ret(s)
    if r is not None and len(r) > 50000:
        rets[s] = r
        print(f"  {s:<9}{len(r):>9} rendements  "
              f"du {r.index[0].date()} au {r.index[-1].date()}")

if len(rets) < 3:
    raise SystemExit("pas assez de paires")

df = pd.DataFrame(rets).dropna()
C = df.corr()
syms = list(C.columns)

print()
print("=" * 96)
print("MATRICE DE CORRELATION")
print("=" * 96)
print("        " + "".join(f"{s[:6]:>8}" for s in syms))
for s in syms:
    print(f"{s:<8}" + "".join(f"{C.loc[s, t]:>8.2f}" for t in syms))

print()
print("=" * 96)
print("PAIRES LES PLUS CORRELEES (a eviter ensemble)")
print("=" * 96)
pairs = []
for a, b in itertools.combinations(syms, 2):
    pairs.append((C.loc[a, b], a, b))
pairs.sort(reverse=True)
for c, a, b in pairs[:12]:
    print(f"  {a:<9}{b:<9}{c:>7.2f}")
print()
print("  paires les MOINS correlees :")
for c, a, b in pairs[-8:]:
    print(f"  {a:<9}{b:<9}{c:>7.2f}")

# ---- selection gloutonne ----
print()
print("=" * 96)
print("SELECTION GLOUTONNE (seuil de correlation moyenne)")
print("=" * 96)


def select(threshold, maxn=10):
    """Ajoute les paires une a une, en preferant celles qui apportent le plus
    de diversification (correlation moyenne la plus basse)."""
    chosen = []
    remaining = set(syms)
    # on demarre par la paire la moins correlee en moyenne avec les autres
    avg = {s: C.loc[s, [t for t in syms if t != s]].mean() for s in syms}
    first = min(avg, key=avg.get)
    chosen.append(first); remaining.discard(first)
    while remaining and len(chosen) < maxn:
        best, bestscore = None, 1e9
        for s in remaining:
            mc = C.loc[s, chosen].max()
            if mc > threshold:
                continue
            sc = C.loc[s, chosen].mean()
            if sc < bestscore:
                best, bestscore = s, sc
        if best is None:
            break
        chosen.append(best); remaining.discard(best)
    return chosen


for th in (0.5, 0.6, 0.7, 0.8):
    sel = select(th)
    if not sel:
        continue
    sub = C.loc[sel, sel]
    off = sub.to_numpy()[np.triu_indices(len(sel), 1)]
    print(f"\n  seuil {th} : {len(sel)} paires "
          f"| correlation moyenne {off.mean():.2f} "
          f"| max {off.max():.2f}")
    print(f"    {', '.join(sel)}")

print()
print("=" * 96)
print("PORTEFEUILLE RETENU (seuil 0.7)")
print("=" * 96)
final = select(0.7)
print(f"  {len(final)} paires : {', '.join(final)}")
sub = C.loc[final, final]
off = sub.to_numpy()[np.triu_indices(len(final), 1)]
print(f"  correlation moyenne : {off.mean():.2f}")
print(f"  correlation max     : {off.max():.2f}")
print()
print("  Pour comparaison, TOUT le portefeuille :")
allc = C.to_numpy()[np.triu_indices(len(syms), 1)]
print(f"  correlation moyenne : {allc.mean():.2f}  max {allc.max():.2f}")
print()
print("  Le filtre reduit la correlation moyenne de "
      f"{allc.mean():.2f} a {off.mean():.2f}.")

json.dump(dict(selected=final,
               corr_mean=float(off.mean()), corr_max=float(off.max()),
               matrix=C.round(3).to_dict()),
          open(OUT, "w"), indent=1)
print(f"\n-> {OUT}")
