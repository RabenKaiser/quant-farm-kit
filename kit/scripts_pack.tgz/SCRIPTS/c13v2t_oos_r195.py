# -*- coding: utf-8 -*-
"""c13v2t_oos_r195.py — validation OOS de la config gagnante T25-A10-TR15-W15
(TP2.5 trail1.5 after1.0 wick1.5): EURUSD 2025, GBPUSD 2024, GBPUSD 2025."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\c13v2t_oos_r195.jsonl"


def cfg(mg):
    return dict(InpMagic=mg, InpLots=0.10, InpRiskPct=0.0, InpTpR=2.5,
                InpMagLookbackH4=60, InpTrailAtrMult=1.5, InpTrailAfterR=1.0,
                InpImpulseAtrMult=0.9, InpImpulseLook=6, InpAtrPeriod=14,
                InpHtfEmaPeriod=200, InpPinWickRatio=1.5, InpCloseInZoneMin=0.15,
                InpMinStopPips=2.5, InpBufferAtrFrac=0.25, InpMaxSpreadPts=80,
                InpUseHourFilter=True, InpExcludedHoursCSV="6,7,12,15,19,23",
                InpUseDailyStop=True, InpDailyStopR=3.0, InpMaxTradesDay=0,
                InpUtcOffset=2, InpVerbose=False)


def main():
    mg = 757000
    RUNS = [("EURUSD-2024-IS", "EURUSD", "2024.01.01", "2025.01.01"),
            ("EURUSD-2025-OOS", "EURUSD", "2025.01.01", "2026.01.01"),
            ("GBPUSD-2024", "GBPUSD", "2024.01.01", "2025.01.01"),
            ("GBPUSD-2025", "GBPUSD", "2025.01.01", "2026.01.01"),
            ("EURUSD-2023", "EURUSD", "2023.01.01", "2024.01.01")]
    with open(OUT, "a", encoding="utf-8") as fo:
        for tag, sym, frm, to in RUNS:
            mg += 1
            c = cfg(mg)
            print(f"[r195 {tag}] {sym} {frm}->{to} ...", flush=True)
            r = RF.run_backtest("C13V2T_EA", symbol=sym, tf="M5",
                                from_d=frm, to_d=to, deposit=10000,
                                max_wait=3600, inputs=c)
            fo.write(json.dumps({"tag": tag, "r": r}, default=str) + "\n")
            fo.flush()
            print(f"[{tag}] " + ("null" if r is None else
                  f"p={r.get('profit')} n={r.get('trades')} "
                  f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
            time.sleep(2)
    print("FIN r195", flush=True)


if __name__ == "__main__":
    main()
