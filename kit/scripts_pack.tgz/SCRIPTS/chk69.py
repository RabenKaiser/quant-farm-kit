﻿import json, os
p = r"C:\EAFarm\HISTORY - Copy\research\pos_baseline_perleg.json"
if os.path.exists(p):
    d = json.load(open(p, encoding="utf-8"))
    print(f"{len(d)} jambes")
    for L in d[:5]:
        print(f"  {L['sym']:<8} {L['trig']:<12} n6={L['n6']:<6} n6_sans={L['n6_sans_filtre']}")
else:
    print("ABSENT")
