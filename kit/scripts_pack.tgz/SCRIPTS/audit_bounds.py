# -*- coding: utf-8 -*-
"""audit_bounds.py — cherche TOUTES les erreurs de borne dans l'EA.

POURQUOI
  Le bug n55 (SpreadMedian : garde `< 50` mais boucle `i < 200`) a fait
  planter l'EA sur Upcomers des la 1re barre -> 0 trade sur 10 marches.
  C'est la MEME famille que le bug n7 (BRKASIA : garde 60, lecture jusqu'a 95)
  qui avait deja produit un crash 502.

  Ce type de bug est INVISIBLE sur un broker qui fournit beaucoup de barres et
  MORTEL sur un broker qui en fournit peu. Il faut donc les trouver TOUS.

METHODE
  On analyse statiquement le source : pour chaque appel CopyRates/CopyBuffer/
  CopyTickVolume, on releve la taille demandee N, la garde (comparaison a un
  seuil), et l'indice maximal lu dans les boucles qui suivent.
  On signale tout cas ou l'indice maximal >= N ou >= garde.
"""
import re

EA = (r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal"
      r"\CF0B997454318B475CF01419AFE2BBF3\MQL5\Experts\eepeek\ORION_ROBOT.mq5")
src = open(EA, encoding="utf-8", errors="replace").read()
lines = src.splitlines()
print(f"source : {len(lines)} lignes\n")

# --- releve des appels Copy* avec leur taille ---
pat_copy = re.compile(
    r".*\b(CopyRates|CopyBuffer|CopyTickVolume)\s*\(([^;]*?)\)\s*(<|<=)\s*(\d+)")
print("=" * 96)
print("APPELS Copy* ET LEUR GARDE")
print("=" * 96)
appels = []
for i, ln in enumerate(lines, 1):
    m = pat_copy.search(ln)
    if not m:
        continue
    fn, args, op, garde = m.group(1), m.group(2), m.group(3), int(m.group(4))
    # taille demandee = dernier argument numerique
    nums = re.findall(r"\b(\d+)\b", args)
    taille = int(nums[-1]) if nums else 0
    appels.append((i, fn, taille, op, garde, ln.strip()[:90]))
    flag = ""
    if taille and garde < taille:
        flag = f"   <<< GARDE {garde} < TAILLE {taille}"
    print(f"  L{i:<5}{fn:<16}demande={taille:<6}garde {op} {garde}{flag}")

print()
print("=" * 96)
print("BOUCLES SUR DES TABLEAUX Copy* — indice maximal")
print("=" * 96)
# --- pour chaque appel, on cherche les boucles qui suivent dans les 40 lignes ---
susp = []
for (i, fn, taille, op, garde, txt) in appels:
    if not taille:
        continue
    # nom du tableau = 1er identifiant dans les args entre virgules
    arr = None
    for cand in re.findall(r"\b([A-Za-z_]\w*)\b", txt):
        if cand not in ("CopyRates", "CopyBuffer", "CopyTickVolume",
                        "PERIOD_M5", "PERIOD_M15", "PERIOD_H1",
                        "sym", "r", "b", "v", "sp", "0", "1"):
            arr = cand
    if arr is None:
        continue
    mx = 0
    for j in range(i, min(i + 60, len(lines))):
        for m in re.finditer(rf"{arr}\[\s*([A-Za-z_0-9+\-* ]+?)\s*\]", lines[j]):
            e = m.group(1).strip()
            if e.isdigit():
                mx = max(mx, int(e))
    if mx >= garde or mx >= taille:
        susp.append((i, fn, arr, taille, garde, mx))
        print(f"  L{i:<5}{fn:<16}{arr:<8}demande={taille:<5}garde={garde:<5}"
              f"indice_max={mx}   <<< RISQUE DE DEPASSEMENT")

if not susp:
    print("  aucun depassement evident detecte statiquement")
    print("  (attention : l'analyse statique ne couvre pas les boucles calculees)")

print()
print("=" * 96)
print("AUTRES BOUCLES A RISQUE : `for(... < CONST)` sur tableau Copy*")
print("=" * 96)
n = 0
for i, ln in enumerate(lines, 1):
    m = re.search(r"for\s*\([^;]*;\s*\w+\s*<\s*(\d+)\s*;", ln)
    if not m:
        continue
    cst = int(m.group(1))
    # cherche un tableau local Copie dans les 25 lignes precedentes
    ctx = "\n".join(lines[max(0, i - 25):i])
    if "CopyRates" in ctx or "CopyTickVolume" in ctx or "CopyBuffer" in ctx:
        g = re.search(r"Copy(?:Rates|TickVolume|Buffer)\([^;]*\)\s*(<|<=)\s*(\d+)", ctx)
        garde = int(g.group(2)) if g else None
        flag = "   <<< CONSTANTE EN DUR : OK seulement si le broker fournit assez" if garde and cst > garde else ""
        if garde and cst > garde:
            n += 1
            print(f"  L{i:<5}for < {cst:<6}garde={garde}{flag}")
            print(f"        {ln.strip()[:88]}")
if not n:
    print("  aucune boucle a constante en dur superieure a sa garde")
