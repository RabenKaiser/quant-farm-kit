﻿import subprocess, time, glob, os, re
from pathlib import Path
FARM = Path(r"C:\EAFarm\MT5\Farm"); TM = FARM/"terminal64.exe"
COMMON = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")/"Common"/"Files"
LOGD = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")/"CF0B997454318B475CF01419AFE2BBF3"/"Tester"/"logs"
CFG = FARM/"Config"/"config_exp_align.ini"
sym="GBPUSD"
# Le cache contient 2020. On demande un test en 2021 (pour charger 2020),
# et on demande a l'EA d'exporter 2021 (la ou le testeur travaille vraiment).
cfg = (f"[Tester]\nExpert=eepeek\\EXPORT_M1.ex5\nSymbol={sym}\nPeriod=M1\n"
       f"Model=0\nOptimization=0\nFromDate=2021.01.01\nToDate=2021.12.31\n"
       f"Deposit=10000\nCurrency=USD\nLeverage=100\nReplaceReport=1\nShutdownTerminal=1\n"
       f"[TesterInputs]\nInpSymbol={sym}\nInpFrom=2021.01.01\nInpTo=2021.12.31\n")
CFG.write_text(cfg)
src = COMMON/f"{sym}_M1.csv"
if src.exists(): src.unlink()
p=subprocess.Popen([str(TM),"/config:"+str(CFG)],cwd=str(FARM),
                   creationflags=0x08000000,
                   stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
w=0
while w<300:
    time.sleep(4); w+=4
    if "terminal64" not in subprocess.run(["tasklist","/FI",f"PID eq {p.pid}"],
        capture_output=True,text=True).stdout: break
subprocess.run(["taskkill","/F","/IM","terminal64.exe"],capture_output=True)
time.sleep(2)
print(f"duree {w}s | fichier: {(src.stat().st_size/1e6) if src.exists() else 0:.1f} Mo")
