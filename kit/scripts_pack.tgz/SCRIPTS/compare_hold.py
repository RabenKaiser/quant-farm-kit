"""compare_hold : une detention plus courte cree-t-elle du VOLUME ?

Round 478. La regle « une seule position a la fois » (spread_barrieres.bloque) fait dependre le nombre de
transactions de la DUREE de detention : une position tenue 64 barres M30 (32 h) interdit toute nouvelle
entree pendant 32 h, une position tenue 32 barres (16 h) en autorise deux fois plus. Si l'edge est
attache au SIGNAL et non a la duree de detention, raccourcir l'horizon double le volume a qualite egale --
c'est-a-dire double theta sans rien inventer.

Trois cribles identiques a cela pres (HOLD = 32, 64, 128 barres), sur le corpus etendu, cibles 2 et 4 R.
Le script met les trois cotes a cote, couple par couple.

Usage : python SCRIPTS\\compare_hold.py
"""
import csv
from pathlib import Path

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
FICHIERS = {"64 barres (32 h)": "CRIBLE_PAYOFF_EXT.csv",
            "32 barres (16 h)": "CRIBLE_HOLD32.csv",
            "128 barres (64 h)": "CRIBLE_HOLD128.csv"}


def charge(nom):
    f = B / nom
    if not f.exists():
        return {}
    out = {}
    with f.open(encoding="utf-8") as fh:
        for x in csv.DictReader(fh):
            if not x.get("famille", "").startswith("MR"):
                continue
            try:
                n, R, sig = int(x["n"]), float(x["R"]), float(x["sigma"])
                att = float(x["attendu"])
                npos, nan = int(x["npos"]), int(x["nan"])
            except (KeyError, ValueError):
                continue
            if sig <= 0 or n < 20:
                continue
            cle = (x["paire"], x["famille"], x["sens"], float(x["tpr"]))
            theta = max(att, 0.0) ** 2 * n / sig ** 2 / 6.0
            ok = att > 0 and npos >= (2.0 / 3.0) * nan
            out[cle] = dict(n=n, R=R, att=att, sigma=sig, theta=theta, ok=ok, npos=npos, nan=nan)
    return out


def main():
    tableaux = {k: charge(v) for k, v in FICHIERS.items()}
    print("%-34s %8s %9s %8s" % ("detention", "couples", "theta cum.", "tx cum."))
    for nom, t in tableaux.items():
        gardes = [x for x in t.values() if x["ok"]]
        print("%-34s %8d %9.1f %8d" % (nom, len(gardes), sum(x["theta"] for x in gardes),
                                       sum(x["n"] for x in gardes)))
    print("\ncomparaison couple par couple (theta, et n entre parentheses) :")
    cles = sorted({c for t in tableaux.values() for c in t
                   if any(t.get(c, {}).get("ok") for t in tableaux.values())})
    entetes = list(FICHIERS)
    print("%-10s %-6s %-3s %4s | %s" % ("paire", "famille", "s", "R",
                                        " | ".join("%-18s" % e[:18] for e in entetes)))
    for c in cles:
        cellule = []
        for e in entetes:
            x = tableaux[e].get(c)
            cellule.append("%5.2f (%4d)    " % (x["theta"], x["n"]) if x and x["ok"] else
                           ("  --          " if not x else "%5.2f (%4d) x  " % (x["theta"], x["n"])))
        print("%-10s %-6s %-3s %4.1f | %s" % (c[0], c[1], c[2], c[3], " | ".join(cellule)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
