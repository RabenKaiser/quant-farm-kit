# -*- coding: utf-8 -*-
"""CALENDRIER DES NEWS A FORT IMPACT — pour l'option « sans news » (directive 07/10, 21 h 30).

L'utilisateur veut pouvoir choisir des portefeuilles SANS exposition aux news. Le testeur MT5 n'a
pas de calendrier economique, donc le filtre vit ici, au niveau Python : une liste d'instants UTC
des evenements a fort impact (NFP, CPI americain, FOMC, ECB), et un test `dans_fenetre(t, w)` qui
dit si un instant est dans la fenetre a risque (± w minutes) d'un evenement.

PRECISION ASSUMEE (documentee) : le calendrier est RECONSTRUIT PAR REGLES, pas lu dans un flux :
  - NFP       : premier vendredi de chaque mois, 8 h 30 heure de New York (12 h 30 UTC l'ete,
                13 h 30 UTC l'hiver) ;
  - CPI US    : le 12 du mois (13 le week-end), 8 h 30 New York ;
  - FOMC      : dates officielles 2020-2026, communique a 14 h New York (19 h UTC l'hiver,
                18 h UTC l'ete) ;
  - ECB       : Conseils monetaires (dates officielles connues), annonce 14 h 15 CET.
Les dates approximatives ne servent qu'a CLASSIFIER des transactions ; les etages d'ordres reels
restent les arbitres. Un event sans semaine precise (CPI deplace) reste a ± 1 jour pres.
"""
import datetime as dt
from bisect import bisect_right

# FOMC — les huit dates de decision de chaque annee (jeu du communiqu�, 14 h New York).
FOMC = {
    2020: [(1, 29), (3, 15), (4, 29), (6, 10), (7, 29), (9, 16), (11, 5), (12, 16)],
    2021: [(1, 27), (3, 17), (4, 28), (6, 16), (7, 28), (9, 22), (11, 3), (12, 15)],
    2022: [(1, 26), (3, 16), (5, 4), (6, 15), (7, 27), (9, 21), (11, 2), (12, 14)],
    2023: [(2, 1), (3, 22), (5, 3), (6, 14), (7, 26), (9, 20), (11, 1), (12, 13)],
    2024: [(1, 31), (3, 20), (5, 1), (6, 12), (7, 31), (9, 18), (11, 7), (12, 18)],
    2025: [(1, 29), (3, 19), (5, 7), (6, 18), (7, 30), (9, 17), (10, 29), (12, 10)],
    2026: [(1, 28), (3, 18), (4, 29), (6, 17), (7, 29), (9, 16), (10, 28), (12, 9)],
}
# ECB — Conseils de politique monetaire (annonce 14 h 15 CET le jeudi).
ECB = {
    2020: [(1, 23), (3, 12), (4, 30), (6, 11), (7, 16), (9, 10), (10, 29), (12, 10)],
    2021: [(1, 21), (3, 11), (4, 22), (6, 10), (7, 22), (9, 9), (10, 28), (12, 16)],
    2022: [(2, 3), (3, 10), (4, 14), (6, 9), (7, 21), (9, 8), (10, 27), (12, 15)],
    2023: [(2, 2), (3, 16), (5, 4), (6, 15), (7, 27), (9, 14), (10, 26), (12, 14)],
    2024: [(1, 25), (3, 7), (4, 11), (6, 6), (7, 18), (9, 12), (10, 17), (12, 12)],
    2025: [(1, 30), (3, 6), (4, 17), (6, 5), (7, 24), (9, 11), (10, 30), (12, 18)],
    2026: [(2, 5), (3, 19), (4, 30), (6, 11), (7, 23), (9, 10), (10, 29), (12, 17)],
}


def _dst_ete(a, mois, jour):
    """Vrai si la date est a l'heure d'ete americaine (2e dimanche de mars -> 1er dimanche de nov.)."""
    d = dt.date(a, mois, jour)
    mars = d.replace(month=3, day=1)
    d2d = mars + dt.timedelta(days=(6 - mars.weekday()) % 7 + 7)   # 2e dimanche
    nov = d.replace(month=11, day=1)
    d1n = nov + dt.timedelta(days=(6 - nov.weekday()) % 7)          # 1er dimanche
    return d2d <= d < d1n


def _ny_utc(a, mois, jour, heure_ny, minute=0):
    """Epoch UTC d'un instant 8 h 30 New York (13 h 30 UTC l'hiver, 12 h 30 UTC l'ete)."""
    dec = 4 if _dst_ete(a, mois, jour) else 5
    return int(dt.datetime(a, mois, jour, heure_ny, minute, tzinfo=dt.timezone.utc).timestamp()) + dec * 3600


def _premier_vendredi(a, mois):
    d = dt.date(a, mois, 1)
    return d + dt.timedelta(days=(4 - d.weekday()) % 7)


def _premier_jour_ouvrable(a, mois, jour):
    d = dt.date(a, mois, jour)
    while d.weekday() >= 5:
        d += dt.timedelta(days=1)
    return d


def construire(debut=2020, fin=2026):
    ev = []
    for a in range(debut, fin + 1):
        for m in range(1, 13):
            vf = _premier_vendredi(a, m)
            ev.append((_ny_utc(a, vf.month, vf.day, 8, 30), "NFP"))
            cj = _premier_jour_ouvrable(a, m, 12)
            ev.append((_ny_utc(a, cj.month, cj.day, 8, 30), "CPI"))
        for (m, j) in FOMC.get(a, []):
            ev.append((_ny_utc(a, m, j, 14, 0), "FOMC"))
        for (m, j) in ECB.get(a, []):
            ev.append((_ny_utc(a, m, j, 14, 15), "ECB"))
    ev.sort()
    return ev


_EPOCHS = None
_NOMS = None


def charge():
    global _EPOCHS, _NOMS
    if _EPOCHS is None:
        _EPOCHS = [e for e, _ in construire()]
        _NOMS = [n for _, n in construire()]
    return _EPOCHS, _NOMS


def dans_fenetre(ts, minutes=45):
    """Vrai si l'instant `ts` (epoch s) est dans ± minutes d'un evenement a fort impact."""
    eps, _ = charge()
    w = minutes * 60
    i = bisect_right(eps, ts)
    for j in (i - 1, i):
        if 0 <= j < len(eps) and abs(eps[j] - ts) <= w:
            return True
    return False


def traverse(ts_entree, ts_sortie):
    """Vrai si une position ouverte entre ces deux instants CHEVAUCHE une fenetre d'evenement."""
    eps, _ = charge()
    i = bisect_right(eps, ts_entree)
    return i < len(eps) and eps[i] <= ts_sortie


if __name__ == "__main__":
    eps, noms = charge()
    print("evenements 2020-2026 : %d" % len(eps))
    import collections
    c = collections.Counter(noms)
    print("  ", dict(c))
    # exemple : le NFP du 03/01/2025 (13 h 30 UTC)
    for e, n in construire():
        if dt.datetime.fromtimestamp(e, dt.timezone.utc).year >= 2025:
            print("  premier 2026 :", dt.datetime.fromtimestamp(e, dt.timezone.utc), n)
            break