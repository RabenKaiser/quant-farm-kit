# -*- coding: utf-8 -*-
"""combined_expo.py — portefeuille POS + DUKA : exposition combinee.

OBJECTIF
--------
Le portefeuille POS (11 jambes, 10 marches) a 84 % d'exposition EUR.
Les 5 marches Dukascopy (AUDCAD, AUDUSD, NZDUSD, USDCAD, XAUUSD) n'ont
PAS d'EUR (sauf via USD). On mesure l'exposition combinee et on verifie que
la diversification est REELLE et pas nominale.

ATTENTION : les deux sources ont des historiques differents. On ne peut pas
additionner les series telles quelles : on mesure donc l'exposition en
poids, separement puis combinee, sans pretendre a une courbe d'equity unique.
"""
import os, glob, json, pickle
import numpy as np, pandas as pd

BASE = r"C:\EAFarm\HISTORY - Copy\research"

def dev_weights(legs, tag):
    tot = sum(abs(l["R3"]) for l in legs if l.get("R3") is not None)
    if tot == 0:
        print(f"  {tag}: R3 total nul"); return {}
    dev = {}
    for l in legs:
        s = l["sym"]
        w = abs(l.get("R3") or 0.0) / tot
        for d in (s[:3], s[3:]):
            dev[d] = dev.get(d, 0.0) + w
    return dev

def show(dev, tag):
    print(f"\n  --- {tag} ---")
    for d, w in sorted(dev.items(), key=lambda t: -t[1]):
        if w > 0.02:
            print(f"    {d}  {w:6.1%}  {'#'*int(round(w*50))}")

# ---- POS ----
H = json.load(open(os.path.join(BASE, "honest_test.json")))
pos_legs = H["A"]["legs"]
pos_dev = dev_weights(pos_legs, "POS")
show(pos_dev, f"POS ({len(pos_legs)} jambes)")

# ---- DUKA ----
dk = json.load(open(os.path.join(BASE, "duka_smooth.json")))
dlegs = dk["legs"]
print(f"\n  DUKA: {len(dlegs)} jambes / {dk['markets']}")
k0 = dlegs[0]
print(f"  champs d'une jambe : {sorted(k0.keys())}")

def norm(dl):
    """normalise une jambe duka vers le format commun."""
    sym = dl.get("sym") or dl.get("symbol")
    R3 = dl.get("R3", dl.get("r3", dl.get("R")))
    return dict(sym=sym, R3=R3)

dk_n = [norm(d) for d in dlegs]
miss = [d for d in dk_n if d["sym"] is None or d["R3"] is None]
if miss:
    print(f"  ⚠️ {len(miss)} jambes sans sym/R3 — champs:", sorted(dlegs[0].keys()))
    print("  exemple:", dlegs[0])
else:
    dk_dev = dev_weights(dk_n, "DUKA")
    show(dk_dev, f"DUKA ({len(dk_n)} jambes)")

    # ---- COMBINE ----
    alllegs = pos_legs + [dict(sym=d["sym"], R3=d["R3"]) for d in dk_n]
    comb = dev_weights(alllegs, "COMBINE")
    show(comb, f"COMBINE ({len(alllegs)} jambes)")

    print("\n" + "=" * 60)
    print("EFFET DE L'AJOUT")
    print("=" * 60)
    for d in sorted(set(list(pos_dev) + list(comb)), key=lambda k: -comb.get(k, 0)):
        a, b = pos_dev.get(d, 0), comb.get(d, 0)
        if max(a, b) > 0.03:
            arrow = "BAS " if b < a - 0.01 else ("HAUT" if b > a + 0.01 else "=")
            print(f"  {d}  POS {a:5.1%}  ->  COMBINE {b:5.1%}   {arrow}")

    # nombre de marches sans EUR
    noeur = [l for l in alllegs if "EUR" not in l["sym"]]
    print(f"\n  jambes SANS EUR : {len(noeur)}/{len(alllegs)} "
          f"({len(noeur)/len(alllegs):.0%})")
    print(f"  marches SANS EUR : "
          f"{sorted(set(l['sym'] for l in noeur))}")
