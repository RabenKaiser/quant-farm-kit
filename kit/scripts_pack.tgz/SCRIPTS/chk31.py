﻿import json
d = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\pos_selection.json", encoding="utf-8"))
print(f"jambes={d['n_legs']}  marches={d['markets']}")
L = d["legs"][0]
print(f"champs d'une jambe : {list(L.keys())}")
print(f"exemple : {L['k'][:70]}")
