# -*- coding: utf-8 -*-
"""d1complo_test.py — teste D1COMPLO_EA (regle closeLO+comp+narrow GBPUSD)
en model=0, 2020-2026, + sous-fenetre OOS. 2 runs.
"""
import sys, json
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_duka as R

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\d1complo.jsonl"

def main():
    inputs = dict(InpLots=0.10, InpMagic=705001)
    jobs = [
        ("D1-full", "2020.01.01", "2026.01.01"),
        ("D1-oos", "2023.01.01", "2026.01.01"),
    ]
    with open(OUT, "a", encoding="utf-8") as fo:
        for tag, frm, to in jobs:
            print(f"[{tag}] D1COMPLO GBPUSD D1 {frm}->{to} ...", flush=True)
            r = R.run_backtest("D1COMPLO_EA", symbol="GBPUSD", tf="D1",
                               from_d=frm, to_d=to, deposit=10000,
                               max_wait=1800, inputs=inputs)
            rec = {"tag": tag, "from": frm, "to": to, "r": r}
            fo.write(json.dumps(rec, default=str) + "\n")
            fo.flush()
            print(f"[{tag}] -> {json.dumps(r, default=str)}", flush=True)
    print("FIN", flush=True)

if __name__ == "__main__":
    main()
