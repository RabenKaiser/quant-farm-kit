# -*- coding: utf-8 -*-
"""align_py_r209.py — ajouter 'used-once' (1er retest par OB) au backtesteur
python sweep pour l aligner avec le MT5 C13V2_MT5_EA. Compare n avant/apres."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import sweep_py_r205 as SW
import numpy as np

# Le MT5 a 'used' -> apres le 1er trade sur un OB, plus de trade sur cet OB.
# Le python sweep re-entre a chaque retest du meme OB -> n x2.
# On patche bt() dans sweep_py_r205 en ajoutant un set de OB utilises.
import types


def bt_used_once(m5, m15, h4, cfg):
    """Copie de SW.bt + used-once: chaque OB (par son index m15) ne peut
    generer qu'UN trade."""
    if cfg.get("bias", "ema") == "vwap":
        tv = (h4["high"] + h4["low"] + h4["close"]) / 3
        vwap = (tv * h4["volume"]).rolling(cfg.get("vwap_len", 96)).sum() / \
               h4["volume"].rolling(cfg.get("vwap_len", 96)).sum()
    else:
        vwap = h4["close"].ewm(span=cfg.get("ema", 200), adjust=False).mean()
    bull, bear = SW.F.detect_ob(m15, cfg, False)
    n15 = len(m15)
    max_age = cfg.get("ob_age", 100000)
    bull_items = sorted(bull.items())
    bear_items = sorted(bear.items())
    lastB = {}; lastS = {}
    bi = si = 0
    curB = curS = None
    for i15 in range(n15):
        while bi < len(bull_items) and bull_items[bi][0] <= i15:
            jj, (dispo, zl, zh) = bull_items[bi]
            if dispo <= i15:
                curB = (zl, zh, jj); bi += 1
            else:
                break
        while si < len(bear_items) and bear_items[si][0] <= i15:
            jj, (dispo, zl, zh) = bear_items[si]
            if dispo <= i15:
                curS = (zl, zh, jj); si += 1
            else:
                break
        lastB[i15] = curB
        lastS[i15] = curS
    m15_t = m15.index.values.astype("datetime64[ns]")
    m5_t = m5.index.values.astype("datetime64[ns]")
    idx15 = np.clip(np.searchsorted(m15_t, m5_t, side="right") - 1, 0, n15 - 1)
    o5 = m5["open"].to_numpy(); h5 = m5["high"].to_numpy()
    l5 = m5["low"].to_numpy(); c5 = m5["close"].to_numpy()
    pip = 0.0001
    body5 = np.abs(c5 - o5)
    rej_wick = cfg.get("rej_wick", 1.0)
    close_in = cfg.get("close_zone", 0.15)
    used_ob = set()
    signals = {}  # i -> (dirn, zl, zh, ob_idx)
    for i in range(len(m5)):
        i15 = idx15[i]
        b = lastB.get(i15)
        if b is not None and i15 - b[2] <= max_age and b[2] not in used_ob:
            zl, zh = min(b[0], b[1]), max(b[0], b[1])
            zoneH = max(zh - zl, pip * 0.5)
            lowerW = min(o5[i], c5[i]) - l5[i]
            if (body5[i] >= pip * 0.5 and l5[i] <= zh and
                c5[i] >= zl + zoneH * close_in and c5[i] <= zh and
                c5[i] > o5[i] and body5[i] > 0 and
                (lowerW / body5[i]) >= rej_wick):
                signals[i] = (1, zl, zh, b[2])
        s_ = lastS.get(i15)
        if s_ is not None and i15 - s_[2] <= max_age and s_[2] not in used_ob:
            zl, zh = min(s_[0], s_[1]), max(s_[0], s_[1])
            zoneH = max(zh - zl, pip * 0.5)
            upperW = h5[i] - max(o5[i], c5[i])
            if (body5[i] >= pip * 0.5 and h5[i] >= zl and
                c5[i] <= zh - zoneH * close_in and c5[i] >= zl and
                c5[i] < o5[i] and body5[i] > 0 and
                (upperW / body5[i]) >= rej_wick):
                signals[i] = (-1, zl, zh, s_[2])
    hour = m5.index.hour.to_numpy()
    excl = set(cfg.get("excl_hours", []))
    min_stop = cfg.get("min_stop", 0.00025)
    tp_r = cfg.get("tp_r", 2.5)
    buf = cfg.get("buf_atr", 0.25)
    a15v = SW.F.atr_s(m15, 14).to_numpy()
    pos = None
    trades = []
    for i in range(1, len(m5)):
        if pos is not None:
            dirn = pos["dir"]
            sl = pos["sl"]; tp0 = pos["tp"]; entry = pos["entry"]
            hit_sl = (l5[i] <= sl) if dirn == 1 else (h5[i] >= sl)
            hit_tp = (h5[i] >= tp0) if dirn == 1 else (l5[i] <= tp0)
            if hit_sl or hit_tp:
                exit_px = tp0 if (hit_tp and not hit_sl) else sl
                r = (exit_px - entry) / pos["risk"] if dirn == 1 \
                    else (entry - exit_px) / pos["risk"]
                trades.append(r)
                pos = None
        if pos is None and i in signals and hour[i] not in excl:
            bv = vwap.asof(m5.index[i - 1]) if len(vwap.dropna()) else np.nan
            if np.isnan(bv):
                continue
            bias = 1 if c5[i - 1] > bv else -1
            dirn = signals[i][0]
            if (dirn == 1 and bias != 1) or (dirn == -1 and bias != -1):
                continue
            entry = c5[i]
            zl, zh = signals[i][1], signals[i][2]
            atrv = a15v[idx15[i]]
            if dirn == 1:
                sl = zl - (buf * atrv if np.isfinite(atrv) else pip * 5)
                if (entry - sl) < min_stop:
                    sl = entry - min_stop
                risk = entry - sl
                tp = entry + risk * tp_r
            else:
                sl = zh + (buf * atrv if np.isfinite(atrv) else pip * 5)
                if (sl - entry) < min_stop:
                    sl = entry + min_stop
                risk = sl - entry
                tp = entry - risk * tp_r
            if risk > 0:
                pos = {"dir": dirn, "entry": float(entry), "sl": float(sl),
                       "tp": float(tp), "risk": float(risk)}
                used_ob.add(signals[i][3])  # 1 seul trade par OB
    if not trades:
        return {"n": 0, "R": 0.0, "wr": 0, "pf": 0, "dd": 0}
    arr = np.array(trades)
    wins = arr[arr > 0]; losses = arr[arr < 0]
    gw = wins.sum(); gl = -losses.sum()
    eq = np.cumsum(arr)
    dd = float((np.maximum.accumulate(eq) - eq).max())
    return {"n": len(arr), "R": float(arr.sum()),
            "wr": float(len(wins) / len(arr) * 100),
            "pf": float(gw / gl) if gl > 0 else 99.0, "dd": dd}


if __name__ == "__main__":
    for sym, cfgm in [("EURUSD", dict(imp_atr=0.9, rej_wick=0.8, tp_r=2.0, ob_age=16)),
                      ("EURUSD", dict(imp_atr=0.9, rej_wick=1.0, tp_r=2.0, ob_age=16)),
                      ("GBPUSD", dict(imp_atr=0.9, rej_wick=2.0, tp_r=3.0, ob_age=16))]:
        for year in [2023, 2024, 2025]:
            m5, m15, h4 = SW.prep_frames(sym, year)
            BASE = {"imp_atr": 0.9, "imp_vol": 1.0, "imp_look": 6, "ob_age": 100000,
                    "rej_wick": 1.0, "rej_vol": 1.0, "close_zone": 0.15, "tp_r": 2.5,
                    "bias": "vwap", "excl_hours": [6, 7, 12, 15, 19, 23],
                    "min_stop": 0.00025, "buf_atr": 0.25, "lookahead": False}
            cfg = dict(BASE); cfg.update(cfgm)
            r1 = SW.bt(m5, m15, h4, cfg)   # sans used-once
            r2 = bt_used_once(m5, m15, h4, cfg)  # avec used-once
            print(f"{sym} {year} {cfgm}: no-use n={r1['n']} pf={r1['pf']:.2f} "
                  f"| used n={r2['n']} pf={r2['pf']:.2f}")
