"""Analyse des trades ptrail MT5 — répartition des gains (tail vs stable).
Lit le log du dernier run (2025) + vérifie le trailing dans le code."""
import re, sys
from pathlib import Path

CF = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3")
log_path = CF / "Tester" / "logs" / "20260823.log"
raw = log_path.read_text("utf-16", errors="replace")
lines = raw.splitlines()

# --- dernier run (2025) : extraire la séquence deals SL/TP ---
print(f"=== log: {len(lines)} lignes, dernier run ===")
# trouver le début du dernier "testing of"
starts = [i for i, l in enumerate(lines) if "testing of Experts" in l]
if starts:
    s = starts[-1]
    run = lines[s:s+3000]
    # deals: "market buy/sell", "stop loss triggered", "take profit triggered", "position closed"
    entries = [l for l in run if "market " in l and "sl:" in l]
    sl = [l for l in run if "stop loss triggered" in l]
    tp = [l for l in run if "take profit triggered" in l]
    ts = [l for l in run if "position closed due end of test" in l]
    print(f"  entrées: {len(entries)} | SL: {len(sl)} | TP: {len(tp)} | fin de test: {len(ts)}")
    # combien de positions restaient ouvertes en fin de test (trail jamais fermé)
    print(f"  -> {len(ts)} positions fermées par fin de test (jamais sorties par SL/TP/trail)")
    # PnL estimé par deal : lire les "deal ... done" avec prix
    deals = re.findall(r"deal #(\d+) (buy|sell) ([\d.]+) EURUSD|USDJPY at ([\d.]+)", raw)
    print(f"  deals totaux dans le log: {len(deals)}")

# --- Vérification du code trailing (SetSLAll / g_trailStop) ---
print("\n=== vérif trailing dans l'EA ===")
ea = open(r"C:\EAFarm\HISTORY - Copy\research\EAs\USDJPY_M30_PTRAIL.mq5", encoding="utf-8").read()
# le trail est activé après TrailTrig*SL et suit le pic - TrailMult*SL
for pat in ["g_trailActive", "TrailTrig*g_slDist", "TrailMult*g_slDist", "SetSLAll"]:
    n = ea.count(pat)
    print(f"  '{pat}': {n} occurrence(s)")
