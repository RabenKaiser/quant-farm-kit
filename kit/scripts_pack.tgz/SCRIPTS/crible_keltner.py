"""crible_keltner : les bandes de Keltner, et Williams %R remis a sa place.

Round 480. Deux familles proposees, et il faut d'abord dire ce qu'elles sont VRAIMENT -- la lecon du
biais VWAP (redondant avec le declencheur CREST) vaut ici aussi :

* **Williams %R** : %R = -100 x (plus_haut(n) - cloture) / (plus_haut(n) - plus_bas(n)). Or la position
  dans le range du projet s'ecrit pos = (cloture - plus_bas) / (plus_haut - plus_bas) = 1 + %R/100.
  **Williams %R EST la position dans le range**, avec une autre fenetre et un autre seuil : -80 % = pos
  <= 0,20, soit le declencheur de fond du projet a 0,20 au lieu de 0,03. Ce qui est neuf n'est donc pas la
  famille, c'est le SEUIL (et la fenetre) -- et cela se mesure en changeant SEUIL dans le crible, ce que
  fait `crible_payoff.py SEUIL=0.80`. Ce module mesure en plus la FENETRE courte (14 barres, la fenetre
  classique de Williams), qui n'a jamais ete essayee.

* **Bandes de Keltner** : moyenne mobile exponentielle +/- k x ATR. C'est une construction DIFFERENTE de
  tout ce qui a ete mesure : la distance d'entree a la moyenne est proportionnelle a la VOLATILITE, alors
  que la position dans le range est une distance RELATIVE a l'amplitude des n dernieres barres. Deux
  utilisations sont mesurees :
      - retour a la moyenne : vendre a la bande haute, acheter a la bande basse (la zone « overbought /
        oversold » dont parle l'utilisateur) ;
      - cassure : acheter AU-DESSUS de la bande haute, vendre SOUS la bande basse (l'inverse).

Tout est mesure par le moteur honnete, sur le corpus etendu, aux cibles 2 et 4 R, avec la decote de
classe appliquee et la contrainte des 2/3 d'annees positives.

Env : TF_BASE=30 FENETRE_WPR=14 KELT_EMA=20 KELT_ATR=14 KELT_K=2.0 TPRS=6,12 CORPUS=m1_ext
Sortie : CRIBLE_KELTNER.csv
"""
import csv
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
sys.path.insert(0, str(B / "SCRIPTS"))
import barrieres_m1 as BM  # noqa: E402
import crible_payoff as CP  # noqa: E402
import spread_barrieres as SB  # noqa: E402

CORPUS = os.environ.get("CORPUS", "m1_ext")
SORTIE = B / os.environ.get("SORTIE", "CRIBLE_KELTNER.csv")
TF_BASE = int(os.environ.get("TF_BASE", "30"))
FENETRE_WPR = int(os.environ.get("FENETRE_WPR", "14"))
KELT_EMA = int(os.environ.get("KELT_EMA", "20"))
KELT_ATR = int(os.environ.get("KELT_ATR", "14"))
KELT_K = float(os.environ.get("KELT_K", "2.0"))
TPRS = [float(x) for x in os.environ.get("TPRS", "6,12").split(",")]
HOLD = int(os.environ.get("HOLD", "64"))
PAIRES = [x for x in os.environ.get("PAIRES", "").split(",") if x]
CLASSE = CP.CLASSE
OFFSETS = CP.OFFSETS


def _grille(paire):
    if TF_BASE == 30:
        return BM.charge_m30(paire, CORPUS)
    return BM.charge_tf(paire, CORPUS, minutes=TF_BASE)


def sig_wpr(M, sens, fenetre=FENETRE_WPR, seuil=0.80):
    """Williams %R : seuil sur la position dans le range sur `fenetre` barres (pas de filtre d'heure)."""
    c, h, l, a = M["c"], M["h"], M["l"], M["a"]
    df = pd.DataFrame({"h": h, "l": l, "c": c})
    hi = df.h.rolling(fenetre).max().values
    lo = df.l.rolling(fenetre).min().values
    pos = (c - lo) / np.where(hi - lo > 0, hi - lo, np.nan)
    zz = np.nan_to_num(pos, nan=-9.0 if sens == "S" else 9.0)
    sig = np.flatnonzero(zz >= seuil) if sens == "S" else np.flatnonzero(zz <= 1.0 - seuil)
    sig = sig[(sig >= fenetre + 1) & (sig < len(c) - HOLD - 2)]
    return sig[np.isfinite(a[sig]) & (a[sig] > 0)]


def sig_keltner(M, sens, mode="retour"):
    """Bandes de Keltner : EMA(n) +/- k x ATR(m). mode=retour (bande basse a l'achat) ou cassure."""
    c, h, l, a = M["c"], M["h"], M["l"], M["a"]
    ema = pd.Series(c).ewm(span=KELT_EMA, min_periods=KELT_EMA).mean().values
    tr = pd.concat([pd.Series(h - l), pd.Series(np.abs(h - np.roll(c, 1))),
                    pd.Series(np.abs(l - np.roll(c, 1)))], axis=1).max(axis=1).values
    atr = pd.Series(tr).rolling(KELT_ATR, min_periods=KELT_ATR).mean().values
    haut, bas = ema + KELT_K * atr, ema - KELT_K * atr
    fini = np.isfinite(haut) & np.isfinite(bas)
    if mode == "retour":
        sig = np.flatnonzero(fini & (l <= bas)) if sens == "L" else np.flatnonzero(fini & (h >= haut))
    else:
        sig = np.flatnonzero(fini & (c >= haut)) if sens == "L" else np.flatnonzero(fini & (c <= bas))
    sig = sig[(sig >= KELT_EMA + KELT_ATR) & (sig < len(c) - HOLD - 2)]
    return sig[np.isfinite(a[sig]) & (a[sig] > 0)]


def main():
    pairs = PAIRES or sorted(p.name[:-7] for p in (B / CORPUS).glob("*_M1.csv"))
    print("%s : %d paires | trame %d min | WPR fenetre %d | Keltner EMA %d +/- %.1f x ATR %d"
          % (CORPUS, len(pairs), TF_BASE, FENETRE_WPR, KELT_EMA, KELT_K, KELT_ATR))
    print("%-10s %-12s %-4s %5s %8s %8s %8s %8s %5s  %s" %
          ("paire", "famille", "sens", "n", "attendu", "sigma", "theta", "gagn%", "annees", "verdict"))
    lignes = []
    for p in pairs:
        M = _grille(p)
        if M is None:
            continue
        cls = CLASSE.get(p, "INDICE" if p.endswith(".IDX") else "FX")
        essais = [("WPR%d" % FENETRE_WPR, lambda s: sig_wpr(M, s)),
                  ("KELT-retour", lambda s: sig_keltner(M, s, "retour")),
                  ("KELT-cassure", lambda s: sig_keltner(M, s, "cassure"))]
        for nom_f, fabrique in essais:
            for sens in ("S", "L"):
                sig = fabrique(sens)
                if sig is None or len(sig) < 12:
                    continue
                for tpr in TPRS:
                    SB.HOLD = HOLD
                    m = CP.mesure_dir(M, sig, sens, tpr)
                    if m is None or m["sd"] <= 0:
                        continue
                    off = OFFSETS[cls][0 if sens == "S" else 1]
                    att = m["R"] - off
                    theta = max(att, 0.0) ** 2 * m["n"] / m["sd"] ** 2 / 6.0
                    ok = att > 0 and m["n_pos"] >= (2.0 / 3.0) * m["n_an"]
                    lignes.append(dict(paire=p, famille=nom_f, sens=sens, tpr=tpr, n=m["n"], R=m["R"],
                                       sigma=m["sd"], gagn=m["gagn"], attendu=att, theta=theta,
                                       npos=m["n_pos"], nan=m["n_an"], retenu=ok))
                    if ok:
                        print("%-10s %-12s %-4s %5d %+8.4f %8.2f %8.3f %7.1f %3d/%-2d RETENU"
                              % (p, nom_f, sens, m["n"], att, m["sd"], theta, m["gagn"],
                                 m["n_pos"], m["n_an"]), flush=True)
        del M
    if not lignes:
        print("  aucune mesure")
        return 1
    with SORTIE.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(lignes[0].keys()))
        w.writeheader()
        w.writerows(lignes)
    ret = [x for x in lignes if x["retenu"]]
    print("\n=== %d mesures | %d retenues ===" % (len(lignes), len(ret)))
    for nom_f in ("WPR%d" % FENETRE_WPR, "KELT-retour", "KELT-cassure"):
        g = [x for x in ret if x["famille"] == nom_f]
        print("  %-12s : %2d couples retenus | theta cumule %6.2f | meilleur %s"
              % (nom_f, len(g), sum(x["theta"] for x in g),
                 max((x["paire"] + " " + x["sens"] + " %dR" % x["tpr"] for x in g), key=lambda _: 0)
                 if g else "--"))
    print("\n  -> %s" % SORTIE.name)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
