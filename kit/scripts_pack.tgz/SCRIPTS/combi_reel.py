"""combi_reel : quelle COMBINAISON de jambes validees a le meilleur mu/sigma2 ?

Round 412. `corr_reel.py` a montre que la decorrelation paie (mu/sigma2 du portefeuille a 3 jambes =
0,660 contre 0,368 pour la meilleure jambe seule) mais aussi qu'AUDCAD et AUDUSD sont correlees a
+0,495 -- deux croisees de l'AUD. Faut-il garder les deux ? Le critere de composition du projet est
mu/sigma2 ; ce script mesure donc TOUTES les combinaisons possibles des jambes validees, sur les
rendements mensuels des ordres reels, et les classe.

Usage : python SCRIPTS\\combi_reel.py
"""
import itertools
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import reel_empile as RE  # noqa: E402

COUPLES = [("AUDCAD", "SR97S", 50, "S"),
           ("AUDUSD", "SR97W20S", 20, "S"),
           ("NZDUSD", "SR97W20S", 20, "S"),
           # ROUND 419 : la jambe LONGUE, mesuree sur son echantillon complet au round 419
           # (+0,1065 R/tx sur 112 transactions, quatre annees mesurees toutes positives) et sans
           # composante commune avec AUD et NZD.
           ("XAUUSD", "SR97W20L", 20, "L")]


def main():
    mois = {}
    for paire, ligne, range_, sens in COUPLES:
        m = RE.mesure(paire, ligne, range_, sens)
        if m is None:
            continue
        d = defaultdict(list)
        for tt, rr in zip(m["times"], m["r"]):
            d[(tt.year, tt.month)].append(rr)
        mois[paire] = {k: float(np.mean(v)) for k, v in d.items()}
    noms = list(mois)
    # ROUND 420 : FENETRE FIGEE. Comparer des combinaisons sur leurs propres intersections compare des
    # fenetres differentes -- et une fenetre plus courte, surtout si elle tombe sur un bon regime,
    # flatte mecaniquement mu/sigma2. Mesure du round 419 : avec 4 jambes l'intersection tombait a
    # 16 mois (domines par 2025) contre 31 mois a 3 jambes, et le classement s'inversait entre les deux.
    # On impose donc la meme periode a toutes les combinaisons, declaree par FENETRE="AAAA-MM,AAAA-MM".
    fen = os.environ.get("FENETRE", "")
    if fen:
        d1, d2 = [int(x) for x in fen.split(",")[0].split("-")], \
                 [int(x) for x in fen.split(",")[1].split("-")]
        garde = lambda k: (d1[0], d1[1]) <= k <= (d2[0], d2[1])
        mois = {n: {k: v for k, v in d.items() if garde(k)} for n, d in mois.items()}
        vides = [n for n, d in mois.items() if not d]
        if vides:
            print("  ATTENTION : %s n'a AUCUNE transaction dans la fenetre %s -- combinaison non"
                  " comparable, la jambe doit etre ecartee" % (", ".join(vides), fen))
    commun = sorted(set.intersection(*[set(v) for v in mois.values()]))
    if len(commun) < 12:
        print("  trop peu de mois communs (%d)" % len(commun))
        return 1
    M = np.array([[mois[n][k] for k in commun] for n in noms])
    print("  %d mois ou les %d jambes coexistent\n" % (len(commun), len(noms)))
    lignes = []
    for k in range(1, len(noms) + 1):
        for comb in itertools.combinations(range(len(noms)), k):
            P = M[list(comb)].mean(axis=0)
            mu, sd = float(P.mean()), float(P.std(ddof=1))
            lignes.append((mu / sd ** 2, [noms[i] for i in comb], mu, sd, float(P.min())))
    print("  mu/sigma2 | mu mensuel | sigma | pire mois | jambes")
    for ms, nc, mu, sd, pm in sorted(lignes, reverse=True):
        print("  %8.3f | %+9.4f | %.4f | %+8.4f | %s" % (ms, mu, sd, pm, " + ".join(nc)))
    best = max(lignes)
    print("\n  MEILLEURE COMBINAISON : %s (mu/sigma2 %.3f)" % (" + ".join(best[1]), best[0]))
    print("  lecture : si la paire correlee (AUDCAD+AUDUSD) est ecartee au profit de la seule")
    print("  meilleure des deux plus une jambe independante, la composition gagne -- c'est la")
    print("  modification de methode que le round 411 imposait.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
