# -*- coding: utf-8 -*-
"""AUDIT MFR v2 — Causalité VAH, vectorisé (polars + numpy optimisé).

V1 : VAH incluant la barre k (moteur) — suspectée d'auto-référence.
V2 : VAH excluant la barre k (causale stricte) — référence.
Comparaison sur les barres étirées uniquement (z>=2), comme le moteur.
"""
import polars as pl
import numpy as np
from pathlib import Path

BARS = Path(r"C:\EAFarm\HISTORY - Copy\research\bars")
TF = 1800
ZTHR = 2.0
VA_PCT = 0.70
TICK = 1e-5

def load(sym):
    df = pl.read_parquet(BARS / f"{sym}_M1_signed.parquet").sort("time")
    df = df.with_columns(pl.from_epoch(pl.col("time"), time_unit="s").dt.truncate(f"{TF}s").dt.epoch("s").alias("tb"))
    g = (df.group_by("tb").agg([
        pl.col("bid_o").first().alias("o"), pl.col("bid_h").max().alias("h"),
        pl.col("bid_l").min().alias("l"), pl.col("bid_c").last().alias("c"),
        pl.col("vol_up").sum().alias("vol_up"), pl.col("vol_down").sum().alias("vol_down"),
    ]).rename({"tb": "time"}).sort("time"))
    return g

def zscore_rolling(c, per=20):
    # z = (c - SMA) / std ddof=1, vectorisé
    s = pl.Series("c", c)
    mean = s.rolling_mean(per)
    std = s.rolling_std(per, ddof=1)
    z = (s - mean) / std
    return z.to_numpy()

def vah_at_k(c0, v0, k, va_pct=VA_PCT):
    """VAH développante à la barre k (cumul 0..k inclus)."""
    sub_c = c0[:k + 1]; sub_v = v0[:k + 1]
    lo = int(np.floor(sub_c.min() / TICK)); hi = int(np.ceil(sub_c.max() / TICK))
    nlev = hi - lo + 1
    if nlev <= 0 or nlev > 200000:
        return np.nan
    lv = np.round(sub_c / TICK).astype(np.int64) - lo
    hist = np.zeros(nlev)
    np.add.at(hist, np.clip(lv, 0, nlev - 1), sub_v)
    tot = hist.sum()
    if tot <= 0:
        return np.nan
    poc = int(hist.argmax())
    acc = hist[poc]; lo2 = hi2 = poc
    while acc < va_pct * tot and (lo2 > 0 or hi2 < nlev - 1):
        vDn = hist[lo2 - 1] if lo2 > 0 else -1.0
        vUp = hist[hi2 + 1] if hi2 < nlev - 1 else -1.0
        if vUp >= vDn:
            hi2 += 1; acc += vUp
        else:
            lo2 -= 1; acc += vDn
    return (hi2 + lo) * TICK

def audit(sym):
    g = load(sym)
    c = g["c"].to_numpy(); h = g["h"].to_numpy(); l = g["l"].to_numpy()
    vol = (g["vol_up"] + g["vol_down"]).to_numpy()
    t = g["time"].to_numpy(); n = len(g)
    z = zscore_rolling(c)
    day = t // 86400
    uniq = np.unique(day)
    v1 = np.full(n, np.nan); v2 = np.full(n, np.nan)
    stretched = np.isfinite(z) & (np.abs(z) >= ZTHR)
    for d in uniq:
        idx = np.where(day == d)[0]
        if len(idx) < 4:
            continue
        want = idx[stretched[idx]]
        if len(want) == 0:
            continue
        cc = c[idx]; vv = vol[idx]
        for kk in range(len(want)):
            k = int(np.searchsorted(idx, want[kk]))
            v1[want[kk]] = vah_at_k(cc, vv, k)                    # inclusive (moteur)
            if k >= 1:
                v2[want[kk]] = vah_at_k(cc, vv, k - 1)            # exclusive (causale stricte)
    both = stretched & ~np.isnan(v1) & ~np.isnan(v2)
    sig1 = (stretched & ~np.isnan(v1) & (h > v1) & (c < v1)).astype(np.int8)
    sig2 = (stretched & ~np.isnan(v2) & (h > v2) & (c < v2)).astype(np.int8)
    n1 = int(sig1.sum()); n2 = int(sig2.sum())
    overlap = int(((sig1 == 1) & (sig2 == 1)).sum())
    only1 = int(((sig1 == 1) & (sig2 == 0)).sum())
    only2 = int(((sig1 == 0) & (sig2 == 1)).sum())
    print(f"{sym}: n={n} | signaux V1(incl)={n1} V2(excl)={n2} | communs={overlap} "
          f"V1-seul={only1} V2-seul={only2}")
    if both.sum() > 0:
        dvah = (v2[both] - v1[both]) / TICK
        print(f"   delta VAH (V2-V1) sur étirées : méd={np.median(dvah):+.0f} ticks "
              f"p25={np.percentile(dvah,25):+.0f} p75={np.percentile(dvah,75):+.0f} "
              f"%|d|>1tick={100*(np.abs(dvah)>1).mean():.1f}%")
    if n1 > 0:
        print(f"   -> {100*only1/max(n1,1):.1f}% des signaux V1 ne se confirment pas en V2 "
              f"(auto-référence de la barre)")
    print()

for sym in ["EURUSD", "USDJPY"]:
    audit(sym)
