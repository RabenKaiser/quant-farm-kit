"""combos_tf : moteur RAPIDE de combinaisons, pour enfin couvrir plusieurs TRAMES.

Pourquoi un second moteur. Le premier (`combos_facteurs.py`) est juste mais trop lent : il
recalcule la matrice de premier toucher une fois par annee pour la stabilite, soit sept
evaluations par cellule et par geometrie. Avec 50 facteurs en combinaisons de 3, cela n'a jamais
fini : la boucle de 12 h est restee bloquee 11 h sur sa premiere trame, donc M15, M30 et H1
n'ont JAMAIS ete testes. Or c'est la piste la plus ouverte : tout ce qu'on a teste en M5 est
negatif, et un facteur qui n'existe qu'a l'echelle superieure serait invisible.

Ce moteur-ci ne calcule le resultat de chaque transaction qu'UNE fois, puis agrege par annee avec
numpy : le cout par cellule tombe d'environ un facteur 7.

Usage : TF=15min TAILLE=2 CORPUS=m1_pos python SCRIPTS\\combos_tf.py
"""
import csv
import os
import sys
from collections import defaultdict
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import combos_facteurs as CF

B = Path(r"C:\EAFarm\HISTORY - Copy\research")


def resultat_grille(m5, atr, masque, sens, horizon, cible):
    """UNE passe : renvoie (n, p_tp global, p_tp par annee) sans rien recalculer."""
    c, h, l = m5.close.values, m5.high.values, m5.low.values
    n = len(c)
    idx = np.flatnonzero(masque)
    idx = idx[idx < n - horizon - 1]
    if len(idx) < 80:
        return None
    off = np.arange(1, horizon + 1)
    Hh, Ll = h[idx[:, None] + off], l[idx[:, None] + off]
    e, a = c[idx], atr[idx]
    if sens < 0:
        ht, hs = (Ll <= e[:, None] - cible * a[:, None]), (Hh >= e[:, None] + a[:, None])
    else:
        ht, hs = (Hh >= e[:, None] + cible * a[:, None]), (Ll <= e[:, None] - a[:, None])
    it = np.where(ht.any(1), ht.argmax(1), 10 ** 6)
    isl = np.where(hs.any(1), hs.argmax(1), 10 ** 6)
    gagne = (it < isl).astype(np.int8)
    an = m5.index.year.values[idx]
    annees, inv = np.unique(an, return_inverse=True)
    tot = np.bincount(inv, weights=gagne, minlength=len(annees))
    cnt = np.bincount(inv, minlength=len(annees))
    par_an = [(int(y), 100.0 * t / cc) for y, t, cc in zip(annees, tot, cnt) if cc >= 60]
    return len(idx), 100.0 * float(gagne.mean()), (min(p for _, p in par_an) if par_an else float("nan")), len(par_an)


def main():
    corpus = os.environ.get("CORPUS", "m1_pos")
    tf = os.environ.get("TF", "15min")
    taille = int(os.environ.get("TAILLE", "2"))
    paires = [p.stem.replace("_M1", "") for p in sorted((B / corpus).glob("*_M1.csv"))]
    sortie = B / ("COMBOS_%s_%s.csv" % (corpus, tf.replace("min", "M")))
    nouveau = not sortie.exists()
    f = sortie.open("a", newline="", encoding="utf-8")
    w = csv.writer(f)
    if nouveau:
        w.writerow(["corpus", "trame", "paire", "sens", "combo", "cible", "horizon",
                    "n", "p_tp", "pire_annee", "annees"])
    total = 0
    for paire in paires:
        try:
            ch = CF.charge(corpus, paire)
        except Exception as e:
            print("  %-9s erreur de chargement : %r" % (paire, e), flush=True)
            continue
        if ch is None:
            continue
        m5, atr = ch
        F = CF.facteurs(m5, atr)
        noms = list(F.keys())
        lignes = []
        for groupe in combinations(noms, taille):
            sens = [F[g][1] for g in groupe if F[g][1] != 0]
            if not sens or len(set(sens)) != 1:
                continue
            s = sens[0]
            masque = np.ones(len(m5), dtype=bool)
            for g in groupe:
                masque &= F[g][0]
            if masque.sum() < 400:
                continue
            for horizon in CF.HORIZONS:
                for cible in CF.CIBLES:
                    r = resultat_grille(m5, atr, masque, s, horizon, cible)
                    if not r:
                        continue
                    n, p, pire, nb_an = r
                    lignes.append([corpus, tf, paire, "COURT" if s < 0 else "LONG", "+".join(groupe),
                                   cible, horizon, n, round(p, 2),
                                   round(pire, 2) if np.isfinite(pire) else "", nb_an])
        w.writerows(lignes)
        f.flush()
        total += len(lignes)
        print("  %-9s %-6s %d lignes" % (paire, tf, len(lignes)), flush=True)
    f.close()
    print("ecrit %s (%d lignes)" % (sortie, total), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
