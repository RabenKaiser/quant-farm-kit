# -*- coding: utf-8 -*-
"""controle_aleatoire.py — NOS DECLENCHEURS VALENT-ILS MIEUX QUE LE HASARD ?

POURQUOI CE TEST EST LE PLUS IMPORTANT QUI RESTE (18/09, 01 h 30)
----------------------------------------------------------------
Mesure du soir, la plus honnete du projet : R hors derive, cotes annules,
toutes paires, toutes fenetres, a la meilleure geometrie (SL 12 x ATR / TP 1) :
        -0.0554 R par transaction, et 0 declencheur sur 101 au-dessus de zero.

Question evidente : d'ou vient cette perte ?
  - le SPREAD ? Il vaut environ 6 % de l'ATR sur EURUSD, or 1 R = 12 ATR, donc
    le spread ne coute que 6/12/100 = 0.5 % de R par cote, soit ~1 % aller-retour.
    Ca n'explique PAS 5.5 %.
  - la GEOMETRIE elle-meme ? Avec un objectif de 1 ATR et un stop de 12 ATR, une
    entree ALEATOIRE touche presque toujours l'objectif (payoff 1 contre 12) :
    l'esperance d'une marche aleatoire sans cout est proche de zero, et les
    effets de barriere et de spread la rendent legerement negative.

C'est exactement ce qu'il faut mesurer : la MEME geometrie, sur des entretes
ALEATOIRES, sur les MEMES donnees. Trois cas possibles, et chacun veut dire
quelque chose de different :

  A. l'aleatoire fait AUSSI -0.055 -> nos declencheurs n'apportent RIEN du tout.
     Toute la recherche de triggers est morte, et c'est demontre au niveau du
     mecanisme, pas par un classement.
  B. l'aleatoire fait PIRE (par ex. -0.15) -> nos declencheurs apportent une
     vraie information, mais elle ne suffit pas a payer le cout du mecanisme.
     C'est un resultat positif, et c'est la premiere bonne nouvelle possible.
  C. l'aleatoire fait MIEUX -> nos declencheurs detruisent de la valeur.

PROTOCOLE (ecrit avant de regarder)
  - paires : les moins cheres (EURUSD, USDJPY, GBPJPY, AUDJPY) ;
  - fenetres : les 5 trimestres du plan classique ;
  - barres M5 obtenues depuis nos CSV M1 (agregation max/min, spread moyen) ;
  - ATR(14) M5 par vrai true-range ;
  - entree : une barre sur DIX (echantillonnage regulier, pas de tirage) ;
  - stop = 12 x ATR, objectif = 1 x ATR, duree maximale 192 barres ;
  - spread paye a l'entree et a la sortie (aller-retour complet) ;
  - R = deplacement / distance de stop, comme dans le labo.

USAGE : python controle_aleatoire.py
"""
import statistics
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
M1 = BASE / "m1_pos"
PAIRES = ["EURUSD", "USDJPY", "GBPJPY", "AUDJPY"]
PERIODES = {"2024Q1": ("2024-01-01", "2024-04-01"),
            "2024Q2": ("2024-04-01", "2024-07-01"),
            "2024Q3": ("2024-07-01", "2024-10-01"),
            "2024Q4": ("2024-10-01", "2025-01-01"),
            "2025Q1": ("2025-01-01", "2025-04-01")}
PAS = 10          # une barre sur dix
HOLD = 192
SL_ATR = 12.0
TP_ATR = 1.0


def point_de(close):
    ex = close.dropna().astype(str)
    ex = ex[~ex.str.contains("e", case=False, na=False)].head(2000)
    dec = 0
    for x in ex:
        if "." in x:
            dec = max(dec, len(x.split(".")[1]))
    return 10.0 ** (-dec)


def simule(sym):
    import pandas as pd
    import numpy as np
    p = M1 / ("%s_M1.csv" % sym)
    if not p.exists():
        return None
    d = pd.read_csv(p, usecols=["time", "high", "low", "close", "spread"])
    d["time"] = pd.to_datetime(d["time"], unit="s", utc=True)
    d = d.set_index("time").sort_index()
    pt = point_de(d["close"])
    m5 = d.resample("5min").agg({"high": "max", "low": "min",
                                 "close": "last", "spread": "mean"}).dropna()
    m5["spread_px"] = m5["spread"] * pt
    pc = m5["close"].shift(1)
    tr = pd.concat([(m5["high"] - m5["low"]).abs(),
                    (m5["high"] - pc).abs(),
                    (m5["low"] - pc).abs()], axis=1).max(axis=1)
    m5["atr"] = tr.rolling(14).mean()
    H = m5["high"].to_numpy()
    L = m5["low"].to_numpy()
    C = m5["close"].to_numpy()
    A = m5["atr"].to_numpy()
    S = m5["spread_px"].to_numpy()
    idx = m5.index
    res = {}
    for per, (a, b) in PERIODES.items():
        deb = idx.searchsorted(pd.Timestamp(a, tz="UTC"))
        fin = idx.searchsorted(pd.Timestamp(b, tz="UTC"))
        if fin - deb < 1000:
            continue
        Rs = []
        for i in range(deb + 20, fin - HOLD, PAS):
            atr = A[i]
            if not (atr > 0):
                continue
            sp = S[i] if S[i] > 0 else 0.0
            dist = SL_ATR * atr
            for side in (1.0, -1.0):
                ent = C[i] + side * sp / 2.0          # on paye le spread
                sl = ent - side * dist
                tp = ent + side * TP_ATR * atr
                R = None
                for j in range(i + 1, min(i + 1 + HOLD, len(H))):
                    if side > 0:
                        if L[j] <= sl:
                            R = -1.0
                            break
                        if H[j] >= tp:
                            R = TP_ATR / SL_ATR
                            break
                    else:
                        if H[j] >= sl:
                            R = -1.0
                            break
                        if L[j] <= tp:
                            R = TP_ATR / SL_ATR
                            break
                if R is None:
                    sortie = C[min(i + HOLD, len(C) - 1)] - side * sp / 2.0
                    R = (sortie - ent) * side / dist
                heure = idx[i].hour
                Rs.append((R, heure))
        if Rs:
            res[per] = Rs
    return res


def main():
    print("=" * 96)
    print("CONTROLE PAR ENTREES ALEATOIRES — meme geometrie, memes donnees")
    print("=" * 96)
    print("   stop = %g x ATR, objectif = %g x ATR, duree max %d barres M5"
          % (SL_ATR, TP_ATR, HOLD))
    print("   entree : une barre sur %d, dans les DEUX sens, spread paye" % PAS)
    print()
    print("   %-8s %-9s %8s %10s %10s %10s"
          % ("paire", "fenetre", "entrees", "R aleatoire", "R labo", "ecart"))
    LABO = {"EURUSD": -0.030, "USDJPY": -0.028, "GBPJPY": -0.060,
            "AUDJPY": -0.043}       # pools symetriques mesures cette nuit
    tous = []
    par_heure = {}
    for sym in PAIRES:
        r = simule(sym)
        if not r:
            print("   %-8s pas de donnees M1" % sym)
            continue
        for per in sorted(r):
            v = [x[0] for x in r[per]]
            m = statistics.mean(v)
            tous += v
            for R, h in r[per]:
                par_heure.setdefault(h, []).append(R)
            print("   %-8s %-9s %8d %+10.4f %+10.4f %+10.4f"
                  % (sym, per, len(v), m, LABO.get(sym, float("nan")),
                     m - LABO.get(sym, float("nan"))))
    if not tous:
        return
    print()
    print("   R moyen des ENTREES ALEATOIRES : %+.4f  (%d entrees)"
          % (statistics.mean(tous), len(tous)))
    print("   erreur-type : %.4f" % (statistics.pstdev(tous) / len(tous) ** 0.5))
    print()
    print("   R mesure du LABO (cotes symetrises) : -0.0554")
    print()
    ecart = statistics.mean(tous) - (-0.0554)
    print("   ecart (aleatoire - labo) : %+.4f" % ecart)
    print()
    # SENS DE L'ECART (bug de lecture corrige a 01 h 55 : j'avais annonce
    # "le hasard fait pire" alors que c'est l'inverse) :
    #   ecart POSITIF -> l'aleatoire fait MIEUX -> les declencheurs DETRUISENT
    #   ecart NEGATIF -> l'aleatoire fait PIRE  -> les declencheurs apportent
    #                    une information (qui peut ne pas payer le mecanisme)
    if ecart > 0.02:
        print("   >>> LES DECLENCHEURS DETRUISENT DE LA VALEUR (%.4f R)." % ecart)
        print("       Une entree ALEATOIRE avec la MEME geometrie vaut ~0 R ;")
        print("       nos combinaisons valent -0.055 R. Le probleme n'est donc")
        print("       NI le cout (~1 % de R), NI la geometrie (l'aleatoire est a")
        print("       zero), mais la SELECTION DES ENTREES : elle choisit des")
        print("       moments pires que le hasard.")
    elif ecart < -0.02:
        print("   >>> LES DECLENCHEURS APPORTENT UNE INFORMATION REELLE")
        print("       (%.4f R) qui ne suffit pas a payer le mecanisme." % (-ecart))
        print("       C'est la premiere bonne nouvelle possible du projet.")
    else:
        print("   >>> LE HASARD FAIT AUSSI BIEN : les declencheurs n'apportent")
        print("       aucune information sur cette geometrie.")

    # --- explication concurrente : l'effet d'HORAIRE ---------------------
    print()
    print("=" * 96)
    print("   EXPLICATION CONCURRENTE : L'EFFET D'HORAIRE")
    print("=" * 96)
    print("   Mes entrees aleatoires sont reparties sur toute la journee ; nos")
    print("   declencheurs se concentrent a certaines heures. Si l'esperance")
    print("   varie fortement selon l'heure, une partie de l'ecart peut venir")
    print("   de la, et non du choix d'entree.")
    print()
    print("   %-6s %12s %10s" % ("heure", "R moyen", "entrees"))
    moyennes = []
    for h in sorted(par_heure):
        v = par_heure[h]
        if len(v) < 300:
            continue
        m = statistics.mean(v)
        moyennes.append(m)
        print("   %-6d %+12.4f %10d" % (h, m, len(v)))
    if len(moyennes) >= 3:
        etendue = max(moyennes) - min(moyennes)
        print()
        print("   amplitude entre les heures : de %+.4f a %+.4f (etendue %.4f)"
              % (min(moyennes), max(moyennes), etendue))
        # LE TEST QUI TRANCHE : comparer le R des declencheurs (-0.0554) a
        # CHAQUE heure de l'aleatoire. Si les declencheurs sont pires que
        # presque toutes les heures, alors aucune repartition horaire des
        # declencheurs ne peut expliquer l'ecart.
        pires = [m for m in moyennes if m < -0.0554]
        print("   heures ou l'ALEATOIRE fait PIRE que nos declencheurs "
              "(-0.0554) : %d sur %d" % (len(pires), len(moyennes)))
        if len(pires) <= 2:
            print("   -> AUCUNE repartition horaire ne peut expliquer l'ecart :")
            print("      nos declencheurs sont pires que l'aleatoire a presque")
            print("      toutes les heures. L'effet d'horaire est donc ecarte,")
            print("      et l'ecart de %.4f R est bien un probleme de CHOIX" % ecart)
            print("      D'ENTREE.")
        elif etendue < 0.75 * abs(ecart):
            print("   -> l'horaire explique au plus %.4f R sur un ecart de" % etendue)
            print("      %.4f R : l'essentiel n'est PAS un effet d'horaire." % ecart)
        else:
            print("   -> ATTENTION : l'horaire peut expliquer une part")
            print("      importante de l'ecart. A controler avant de conclure.")


if __name__ == "__main__":
    main()
