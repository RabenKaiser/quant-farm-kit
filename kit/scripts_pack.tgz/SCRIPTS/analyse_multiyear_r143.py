# -*- coding: utf-8 -*-
"""analyse_multiyear_r143.py — verdict carte multi-annees V3INT Farm (2017-2026):
par paire, nb fenetres positives, somme, pire fenetre, conclusion durabilite."""
import json, os, sys
import pandas as pd
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

P = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\v3int_farm_multiyear2_r53.jsonl"
rows = {}
with open(P, encoding="utf-8") as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        o = json.loads(line)
        sym = o["sym"]
        w = f"{o['from'][:4]}-{o['to'][:4]}"
        rows.setdefault(sym, {})[w] = o["r"]

order = ["EURUSD", "GBPJPY", "NZDJPY", "AUDUSD", "NZDUSD"]
print("=== V3INT Farm multi-annees (config comp050/055 sess 8-17, 0.1 lot) ===")
print(f"{'paire':8s} {'2017-19':>9} {'2019-21':>9} {'2021-23':>9} "
      f"{'2023-25':>9} {'2025-26':>9} {'2026':>8} | pos | somme")
for sym in order:
    cells = []
    pos = 0
    tot = 0.0
    for w in ["2017-2019", "2019-2021", "2021-2023", "2023-2025",
              "2025-2026", "2026-2026"]:
        r = rows.get(sym, {}).get(w)
        if r is None or r.get("profit") is None:
            cells.append("  --  ")
            continue
        p = float(r["profit"])
        tot += p
        if p > 0:
            pos += 1
        cells.append(f"{p:+8.0f}")
    print(f"{sym:8s} " + " ".join(cells) + f" | {pos:2d}/6 | {tot:+8.0f}")
print("\nverdict: paire durable si >=4/6 fenetres positives ET somme >0")
print("NB: 0.1 lot, ~20-60 trades/fenetre — pnl $ petit, lire le SIGNE surtout.")
print("FIN", flush=True)
