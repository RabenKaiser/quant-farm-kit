"""chaine_crest_farm : la configuration de reference, enfin lancee sur Dukascopy avec la BONNE trame.

Round 304. Ce qui vient d'etre etabli et corrige :

  - l'EA copiait `PERIOD_M5` EN DUR (`OnTickTrade`, ligne 3941) et comptait la detention en
    tranches de 300 secondes : une campagne lancee en `--tf M30` negociat donc un signal SR97
    calcule sur 50 barres M5, avec un stop de 1 x ATR(M5), 3 a 6 fois plus serre que l'ATR(M30)
    du modele. Mesure de cette configuration reelle (`mesure_m5_ea.py`) : -0,1145 R/tx et 29,5 %
    de gagnantes -- exactement l'ordre de grandeur des ordres reels (25,6 %, -0,25 R/tx) ;
  - apres correction des 8 constantes M5, le meme test EURCHF 2026Q1 rend 6 positions au lieu de
    28, la ou le modele M30 en attend 7. La densite reelle rejoint enfin le modele.

Il reste a lancer la configuration de reference (SR97S + MOM2 + hors 7-16 h, stop 1 ATR, cible 2 R,
64 barres M30 = 32 h, une position par paire) sur Dukascopy, avec `--hold-bars 64` puisque
`InpHoldBars` compte desormais des barres de la TRAME (et non plus des barres M5).

Ce lanceur enchaine, sans intervention :
  1. attend la fin de la campagne de la TABLE (`camp_table.log`) -- un seul test a la fois par
     profil : chaque test tue le terminal ;
  2. recompile le profil Dukascopy ;
  3. lance la campagne CREST-M corrigee sur toutes les paires et toutes les periodes.
"""
import os
import subprocess
import sys
import time
from pathlib import Path

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
SC = B / "SCRIPTS"
JOURNAL = B / "camp_cresti_farm.log"


def journalise(msg):
    ligne = "[%s] %s" % (time.strftime("%H:%M:%S"), msg)
    print(ligne, flush=True)
    with JOURNAL.open("a", encoding="utf-8") as f:
        f.write(ligne + "\n")


def _mot(f, mot):
    """Test sur les OCTETS, tous encodages : les journaux de `Tee-Object` sont en UTF-16."""
    try:
        b = f.read_bytes()[-4000:]
    except OSError:
        return False
    for enc in ("utf-8", "utf-16-le", "utf-16", "latin-1"):
        try:
            if mot in b.decode(enc, errors="ignore").lower():
                return True
        except (UnicodeDecodeError, LookupError):
            continue
    return False


def main():
    journalise("attente de la fin de la campagne de la table (plafond 9 h)")
    t0 = time.time()
    while time.time() - t0 < 9 * 3600:
        if (B / "camp_table.log").exists() and _mot(B / "camp_table.log", "termine"):
            break
        time.sleep(90)
    else:
        journalise("la campagne de la table n'a pas rendu la main : on ne lance RIEN")
        return 1
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    r = subprocess.run([sys.executable, str(SC / "compile_farm_seul.py")], cwd=str(SC), env=env,
                       capture_output=True, text=True, errors="replace", timeout=900)
    journalise("compilation Dukascopy : %s" % (r.stdout.strip().replace("\n", " | ")
                                               or r.stderr.strip()))
    if "erreurs=0" not in (r.stdout or ""):
        journalise("compilation en echec : on n'execute RIEN")
        return 1
    env["REARM"] = "64"
    env.pop("FENETRES", None)
    # ROUND 316 : le portefeuille retenu exige DEUX echelles de Donchian (RAPPORT_315). On valide
    # donc les DEUX moities, l'une apres l'autre, avec la meme geometrie (M30, 1 ATR, 2 R,
    # 64 barres = 32 h, REARM 64 = une position par paire) :
    #   A : SR97S (range de 50 barres)  -> NZDUSD, EURCHF, AUDUSD, CADJPY
    #   B : SR97W100S (range de 100)    -> EURGBP, GBPCHF, NZDJPY, AUDCAD
    campagnes = [
        ("crestiA_farm", "g_crest.txt", "NZDUSD,EURCHF,AUDUSD,CADJPY"),
        ("crestiB_farm", "g_crest100.txt", "EURGBP,GBPCHF,NZDJPY,AUDCAD"),
    ]
    for tag, jeu, jambes in campagnes:
        cmd = [sys.executable, str(SC / "lab_parallel.py"), "--only", "farm", "--annuel",
               "--setfile", jeu, "--tag", tag, "--holdout", "autorisation",
               "--syms", jambes,
               "--tf", "M30", "--sl-atr", "1", "--tp-r", "2", "--hold-bars", "64", "--resume"]
        journalise("lancement %s : %s sur %s" % (tag, jeu, jambes))
        with JOURNAL.open("a", encoding="utf-8") as f:
            p = subprocess.Popen(cmd, cwd=str(SC), env=env, stdout=f, stderr=subprocess.STDOUT)
            rc = p.wait()
        journalise("%s termine (code %d)" % (tag, rc))
    return 0


if __name__ == "__main__":
    sys.exit(main())
