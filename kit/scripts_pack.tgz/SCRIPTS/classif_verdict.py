# -*- coding: utf-8 -*-
r"""classif_verdict.py -- VERDICT HONNETE DES PREDICTIONS (10/13 21:30).

L'utilisateur demande : "les predictions sont-elles assez bonnes ?" et
"verifie les indicateurs, tu peux peut-etre y ajouter quelque chose".

Ce script fait deux choses :

1. MATRICE DE CONFUSION par classe (train 2020-23 -> valid 2024+) :
   le motif 6-lettres predit la classe +16h. On regarde OU il reussit et
   OU il echoue, classe par classe. On mesure aussi les predictions
   UTILES : les cas ou la proba conditionnelle s'ecarte de la base.

2. AJOUT D'INDICATEURS : le forecast actuel = score compose (11 variables
   quantile) + bonus motif. Test de 3 indicateurs NOUS MANQUANT en tant
   que discriminants additionnels du motif -> classe future :
     a) TICK-DENSITY M5 (proxy volume, vectorise) : les grosses mains
        laissent des traces de densite ; son pente 12 barres.
     b) CORPS/MECHE M5 dominant (fraction impulsif vs absorption).
     c) PENTE VWAP JOURNALIER (la derive de la valeur du jour).
   Methode : lift par quintile de chaque indicateur sur P(E|motif)
   pour chaque classe future. Si un indicateur ajoute du lift au-dela
   du motif seul, il entre dans le forecast.
"""
import os
import sys
from collections import defaultdict, Counter

import numpy as np
import pandas as pd

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parent))
import nuit_motifs as NM
from classif_m5 import er, adx_like, z_prix, pentes, charge_m5
import classif_m5_v2 as V2
from classif_patterns import etat_h4, lettre, H4, MOTIF_LEN, HORIZONS, MIN_N

JAMBES = [x.strip() for x in os.environ.get(
    "PAIRES", "EURUSD,GBPUSD,USDCHF,AUDUSD,NZDUSD,EURJPY,XAUUSD").split(",")
    if x.strip()]


def indicateurs_add(D30, D5):
    """Les 3 indicateurs additionnels alignes sur la trame M30."""
    n = len(D30["c"])
    out = {}
    if D5 is None:
        return None
    # a) tick-density M5 : pente du nombre de variations par barre M5
    tks = D5["tks"]
    td_p = pentes(pd.Series(tks).rolling(12).mean().values, 12)
    # aligne M5 (6x plus fin) -> M30 : moyenne des 6 barres M5
    m = (len(tks) // 6) * 6
    td30 = td_p[:m].reshape(-1, 6).mean(1)
    out["tickdens_pente"] = np.pad(td30, (n - len(td30), 0),
                                   mode="edge") if len(td30) < n else \
        td30[len(td30) - n:]
    # b) corps/meche M5 dominant
    body = np.abs(D5["c"] - D5["o"])
    rng = D5["h"] - D5["l"]
    with np.errstate(invalid="ignore", divide="ignore"):
        ratio = np.where(rng > 0, body / rng, np.nan)
    r30 = pd.Series(ratio[:m]).rolling(6).mean().values.reshape(-1, 6).mean(1)
    out["corps_mech"] = np.pad(r30, (n - len(r30), 0), mode="edge") \
        if len(r30) < n else r30[len(r30) - n:]
    # c) pente vwap jour (derive de la valeur)
    vwap = V2.vwap_jour(D30["idx"], D30["c"], D30["h"], D30["l"])
    out["vwap_pente"] = pentes(vwap, 12) / D30["a"]
    return out


def main():
    print("VERDICT DES PREDICTIONS + INDICATEURS ADDITIONNELS")
    # ---- matrices de confusion motif -> +16h (train vs valid) --------------
    conf_train = defaultdict(Counter)
    conf_valid = defaultdict(Counter)
    add_train = defaultdict(Counter)   # (classe_future, bin_indicateur) -> n
    add_vals = defaultdict(lambda: defaultdict(list))  # indicateur -> classe -> valeurs
    for p in JAMBES:
        D = NM.charge(p, "m1_pos")
        if D is None:
            continue
        D5 = charge_m5(p)
        add = indicateurs_add(D, D5) if D5 is not None else None
        lab, _ = V2.etats(D)
        n = (len(lab) // H4) * H4
        seq = etat_h4(lab)
        dts = np.asarray(D["idx"])[:n].reshape(-1, H4)[:, -1]
        for i in range(MOTIF_LEN, len(seq) - max(HORIZONS) // H4):
            motif = "".join(lettre(x) for x in seq[i - MOTIF_LEN:i])
            fut = lettre(seq[i + HORIZONS[1] // H4])
            annee = pd.Timestamp(dts[i]).year
            (conf_train if annee <= 2023 else conf_valid)[motif][fut] += 1
            if add is not None:
                j = min((i + HORIZONS[1] // H4) * H4, n - 1)
                for nom in ("tickdens_pente", "corps_mech", "vwap_pente"):
                    v = add[nom][j]
                    if np.isfinite(v):
                        add_vals[nom][fut].append(v)
    # ---- verdict par classe ------------------------------------------------
    bases_t, bases_v = Counter(), Counter()
    for m, c in conf_train.items():
        bases_t.update(c)
    for m, c in conf_valid.items():
        bases_v.update(c)
    tot_t = sum(bases_t.values())
    tot_v = sum(bases_v.values())
    print("\n=== BASES (train -> valid) ===")
    for cls in ("R", "E", "C", "T"):
        print("  %s : train %.1f%% -> valid %.1f%%"
              % (cls, 100.0 * bases_t[cls] / tot_t,
                 100.0 * bases_v[cls] / tot_v))
    print("\n=== MATRICE DE CONFUSION VALID 2024+ (lignes=pred, cols=real) ===")
    cls_list = ("R", "E", "C", "T")
    # la prediction du train pour chaque motif
    hdr = "        " + "  ".join("%6s" % c for c in cls_list)
    print(hdr)
    for pc in cls_list:
        row = []
        for rc in cls_list:
            row.append(0)
        print("  %s : (a remplir)" % pc)
    # vraie matrice : pred = top train, real = lettres valid
    mat = defaultdict(Counter)
    for motif, c in conf_valid.items():
        ct = conf_train.get(motif)
        if not ct or sum(ct.values()) < MIN_N:
            continue
        pred = max(ct.items(), key=lambda z: z[1])[0]
        for real, niv in c.items():
            mat[pred][real] += niv
    print("  pred\\real " + "  ".join("%6s" % c for c in cls_list))
    for pc in cls_list:
        tot = sum(mat[pc].values())
        ligne = "  %s      " % pc + "  ".join(
            "%5.1f%%" % (100.0 * mat[pc][rc] / tot) if tot else "  0.0"
            for rc in cls_list) + "   n=%d" % tot
        print(ligne)
    # ---- indicateurs additionnels : separation par classe future -----------
    print("\n=== INDICATEURS ADDITIONNELS : separation des classes futures ===")
    for nom, d in add_vals.items():
        tot = np.concatenate(list(d.values()))
        if len(tot) < 100:
            continue
        qs = np.nanquantile(tot, [0.2, 0.4, 0.6, 0.8])
        print("  %s :" % nom)
        for cls in cls_list:
            v = np.array(d.get(cls, []))
            if len(v) < 50:
                continue
            b = np.histogram(v, bins=[-np.inf, *qs, np.inf])[0]
            base_cls = bases_v[cls] / max(tot_v, 1)
            lifts = [x / len(v) / max(base_cls, 1e-9) for x in b]
            print("    %s : quintiles %s  (base %.2f)"
                  % (cls, " ".join("%.2f" % x for x in lifts), base_cls))


if __name__ == "__main__":
    main()