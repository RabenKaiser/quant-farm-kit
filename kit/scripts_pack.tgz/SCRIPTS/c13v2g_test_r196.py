# -*- coding: utf-8 -*-
"""c13v2g_test_r196.py — C13V2G (bias Gaussian filter H4, mode 1) vs EMA200:
EURUSD 2024-2025, config gagnante sinon (TP2.5 trail1.5 wick1.5)."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\c13v2g_test_r196.jsonl"


def cfg(mg, mode, glen):
    return dict(InpMagic=mg, InpLots=0.10, InpRiskPct=0.0, InpTpR=2.5,
                InpMagLookbackH4=60, InpTrailAtrMult=1.5, InpTrailAfterR=1.0,
                InpImpulseAtrMult=0.9, InpImpulseLook=6, InpAtrPeriod=14,
                InpHtfEmaPeriod=200, InpBiasMode=mode, InpGaussLen=glen,
                InpPinWickRatio=1.5, InpCloseInZoneMin=0.15,
                InpMinStopPips=2.5, InpBufferAtrFrac=0.25, InpMaxSpreadPts=80,
                InpUseHourFilter=True, InpExcludedHoursCSV="6,7,12,15,19,23",
                InpUseDailyStop=True, InpDailyStopR=3.0, InpMaxTradesDay=0,
                InpUtcOffset=2, InpVerbose=False)


def main():
    mg = 758000
    RUNS = [("EUR24-G30", "EURUSD", "2024.01.01", "2025.01.01", 1, 30),
            ("EUR24-G50", "EURUSD", "2024.01.01", "2025.01.01", 1, 50),
            ("EUR25-G30", "EURUSD", "2025.01.01", "2026.01.01", 1, 30),
            ("EUR24-EMA-ref", "EURUSD", "2024.01.01", "2025.01.01", 0, 30)]
    with open(OUT, "a", encoding="utf-8") as fo:
        for tag, sym, frm, to, mode, glen in RUNS:
            mg += 1
            c = cfg(mg, mode, glen)
            print(f"[r196 {tag}] mode={mode} gauss={glen} ...", flush=True)
            r = RF.run_backtest("C13V2G_EA", symbol=sym, tf="M5",
                                from_d=frm, to_d=to, deposit=10000,
                                max_wait=3600, inputs=c)
            fo.write(json.dumps({"tag": tag, "r": r}, default=str) + "\n")
            fo.flush()
            print(f"[{tag}] " + ("null" if r is None else
                  f"p={r.get('profit')} n={r.get('trades')} "
                  f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
            time.sleep(2)
    print("FIN r196", flush=True)


if __name__ == "__main__":
    main()
