﻿# reproduction exacte du probleme
tests = ["vol_"]
for tok in ["VOLLO","VOLHI","VOLCLX","VOLREGLO"]:
    print(f"  Has('vol_','{tok}') = {tok in 'vol_'.upper()}")
print()
print("=> 'vol_' (majuscule VOL_) ne contient NI VOLLO NI VOLHI -> aucun filtre")
print("   de volume applique. C'est le bug n18 deja identifie sur NZDUSD.")
print()
print("ORIGINE : night_build.py tronque la cle a 24 caracteres")
print("  ','.join(filt)[:24]  ->  'in_fvgB_1.0,in_fibM,vol_hi' devient '...vol_'")
print()
print("=> pos_build_fast.py lit les filtres depuis LE CHAMP filt (complet),")
print("   donc le cache est correct. C'est pos_select.py qui reconstruit la")
print("   cle tronquee dans son champ 'k', et mon baseline lit cette cle.")
