﻿import subprocess, time, glob, os, re
from pathlib import Path
FARM = Path(r"C:\EAFarm\MT5\Farm"); TM = FARM/"terminal64.exe"
COMMON = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")/"Common"/"Files"
LOGD = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")/"CF0B997454318B475CF01419AFE2BBF3"/"Tester"/"logs"
CFG = FARM/"Config"/"config_exp_shift.ini"
sym="GBPUSD"
# Le cache contient 2020 quand on demande 2021 (mesure ci-dessus).
# On demande donc 2021 mais on exporte la plage 2020.
cfg = (f"[Tester]\nExpert=eepeek\\EXPORT_M1.ex5\nSymbol={sym}\nPeriod=M1\n"
       f"Model=0\nOptimization=0\nFromDate=2021.01.01\nToDate=2021.12.31\n"   # <- pilote le cache
       f"Deposit=10000\nCurrency=USD\nLeverage=100\nReplaceReport=1\nShutdownTerminal=1\n"
       f"[TesterInputs]\nInpSymbol={sym}\nInpFrom=2020.01.01\nInpTo=2020.12.31\n")  # <- plage voulue
CFG.write_text(cfg)
src = COMMON/f"{sym}_M1.csv"
if src.exists(): src.unlink()
st=time.strftime("%Y%m%d_%H%M%S")
for lf in glob.glob(str(LOGD/"*.log")):
    try: os.rename(lf, lf+".sh"+st)
    except Exception: pass
p=subprocess.Popen([str(TM),"/config:"+str(CFG)],cwd=str(FARM),
                   creationflags=0x08000000,
                   stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
w=0; prev=-1; stable=0
while w<600:
    time.sleep(4); w+=4
    cur = src.stat().st_size if src.exists() else 0
    alive = "terminal64" in subprocess.run(["tasklist","/FI",f"PID eq {p.pid}"],
             capture_output=True,text=True).stdout
    stable = stable+1 if (cur>0 and cur==prev) else 0
    prev=cur
    if not alive: break
    if stable>=4 and cur>1000: break
subprocess.run(["taskkill","/F","/IM","terminal64.exe"],capture_output=True)
time.sleep(3)
print(f"duree {w}s")
if src.exists() and src.stat().st_size > 1000:
    print(f"  FICHIER : {src.stat().st_size/1e6:.1f} Mo")
    n=0; first=None; last=None
    for line in open(src, encoding="utf-8", errors="replace"):
        if line.strip():
            n+=1
            if first is None: first=line.split(",")[0]
            last=line.split(",")[0]
    print(f"  lignes : {n-1:,} barres M1")
else:
    print("  PAS DE FICHIER / vide")
best=None
for f in os.listdir(str(LOGD)):
    if ".log" not in f: continue
    pa=os.path.join(str(LOGD),f)
    if os.path.getsize(pa)<300: continue
    if best is None or os.path.getmtime(pa)>os.path.getmtime(best): best=pa
raw=open(best,"rb").read(4)
enc="utf-16" if raw[:2] in (b"\xff\xfe",b"\xfe\xff") else "utf-8"
txt=open(best,encoding=enc,errors="replace").read()
for mm in re.findall(r".*EXPORT.*", txt)[-3:]:
    print("  ", mm.split("Core")[-1].strip()[:110])
