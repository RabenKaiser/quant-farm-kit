# -*- coding: utf-8 -*-
"""c13mt5_test_r201.py — test C13V2_MT5_EA (design propre volume+frais+1er
retest+rejet vol) sur EURUSD 2023-2025 + GBPUSD 2024 + XAU 2025."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\c13mt5_test_r201.jsonl"


def cfg(mg):
    return dict(InpMagic=mg, InpLots=0.10, InpTpR=2.5, InpAtrPeriod=14,
                InpImpAtrMult=1.2, InpImpVolMult=1.5, InpVolLookback=50,
                InpImpLook=5, InpObMaxAge=32, InpRejWickRatio=1.5,
                InpRejVolMult=1.2, InpCloseInZone=0.20, InpBufferAtrFrac=0.25,
                InpMinStopPips=3.0, InpTrailAtrMult=2.0, InpTrailAfterR=1.0,
                InpBiasMode=1, InpVwapLen=96, InpHtfEmaPeriod=200,
                InpUseHourFilter=True, InpExcludedHours="6,7,12,15,19,23",
                InpUseDailyStop=True, InpDailyStopPct=2.0, InpMaxTradesDay=0,
                InpUtcOffset=2, InpVerbose=False)


def main():
    mg = 773000
    RUNS = [("EURUSD-2023", "EURUSD", "2023.01.01", "2024.01.01"),
            ("EURUSD-2024", "EURUSD", "2024.01.01", "2025.01.01"),
            ("EURUSD-2025", "EURUSD", "2025.01.01", "2026.01.01"),
            ("GBPUSD-2024", "GBPUSD", "2024.01.01", "2025.01.01"),
            ("XAU-2025", "XAUUSD", "2025.01.01", "2026.01.01")]
    with open(OUT, "a", encoding="utf-8") as fo:
        for tag, sym, frm, to in RUNS:
            mg += 1
            c = cfg(mg)
            print(f"[r201 {tag}] ...", flush=True)
            r = RF.run_backtest("C13V2_MT5_EA", symbol=sym, tf="M5",
                                from_d=frm, to_d=to, deposit=10000,
                                max_wait=3600, inputs=c)
            fo.write(json.dumps({"tag": tag, "r": r}, default=str) + "\n")
            fo.flush()
            print(f"[{tag}] " + ("null" if r is None else
                  f"p={r.get('profit')} n={r.get('trades')} "
                  f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
            time.sleep(2)
    print("FIN r201", flush=True)


if __name__ == "__main__":
    main()
