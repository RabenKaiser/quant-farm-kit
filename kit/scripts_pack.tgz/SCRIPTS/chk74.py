﻿import os, re
LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
files=[(os.path.getmtime(os.path.join(LOGD,f)), os.path.join(LOGD,f)) for f in os.listdir(LOGD) if ".log" in f]
files.sort(reverse=True)
for _,p in files[:5]:
    if os.path.getsize(p)<500: continue
    raw=open(p,"rb").read(4)
    enc="utf-16" if raw[:2] in (b"\xff\xfe",b"\xfe\xff") else "utf-8"
    try: txt=open(p,encoding=enc,errors="replace").read()
    except Exception: continue
    h = re.findall(r".*ORION TRIGY AUDJPY.*", txt)
    if h:
        print(f"--- {os.path.basename(p)} ---")
        for x in h: print("  ", x.split("Core")[-1].strip()[:95])
        break
    else:
        h2 = re.findall(r".*ORION TRIG. AUDJPY.*", txt)
        print(f"{os.path.basename(p)[:34]}: {len(h2)} lignes TRIG (pas de TRIGY)")
