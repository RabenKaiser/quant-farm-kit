# -*- coding: utf-8 -*-
"""CRIBLE DES INDICATEURS CLASSIQUES, UTILISES AUTREMENT.

DEMANDE DE L'UTILISATEUR (24/09) : « look more into basic indicators, Keltner channel, etc. try to
use them differently, try to find other edges ».

POURQUOI CE CRIBLE EXISTE. Toutes les familles testees jusqu'ici sont des extremes de range (SR97,
seuil 0,90) ou des ecarts a une moyenne (VWAP, AVWAP). Les indicateurs classiques -- Keltner,
Bollinger, Donchian, RSI, MACD, ADX -- n'avaient jamais ete passes au moteur honnete, et surtout
jamais dans leurs usages NON EVIDENTS : un canal ne sert pas qu'a casser, il sert aussi a mesurer un
etirement, une compression, une reprise de mediane ou une marche le long de la bande. Chaque
indicateur est donc decline en plusieurs usages, dont les usages « a contre-courant » de la lecture
naive.

MESURE. Moteur honnete du projet : sortie a la premiere touche, egalite = stop, echeance au prix,
cout deduit du corpus (spread median / (stop x ATR de la trame)), une position par couple a la fois
(`bloque`), R en multiples du RISQUE. Stop 3 ATR, cible 2 R (6 ATR), detention 128 barres en M15 et
64 en M30 -- soit 32 heures dans les deux cas, ce qui rend les deux trames comparables.

Env : CORPUS (auto), PAIRES (defaut : les survivants mesures en ordres reels + quelques temoins),
       TRAMES=15,30  SLR=3  TPR=2  BIAIS=aucun  SORTIE=CRIBLE_INDICATEURS.csv
"""
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

B = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
import barrieres_m1 as BM          # noqa: E402
import spread_barrieres as SB      # noqa: E402

SORTIE = B / os.environ.get("SORTIE", "CRIBLE_INDICATEURS.csv")
TRAMES = [int(x) for x in os.environ.get("TRAMES", "15,30").split(",")]
SLR = float(os.environ.get("SLR", "3"))
TPR = float(os.environ.get("TPR", "2"))
TENUE = {15: 128, 30: 64}          # 32 h dans les deux trames
# ROUND 508 : LA DETENTION DEVIENT REGLABLE. Beaucoup de signaux d'indicateurs classiques (divergence
# RSI, retour dans une bande) sont concus pour des horizons COURTS : les juger avec une detention de
# 32 heures et une cible de 2 R revient a leur demander autre chose que ce qu'ils disent. On peut donc
# imposer une detention en barres (TENUE_BARRES) et une cible (TPR) pour balayer les geometries.
if os.environ.get("TENUE_BARRES"):
    _tb = int(os.environ["TENUE_BARRES"])
    TENUE = {tf: _tb for tf in TRAMES}
N_MIN = int(os.environ.get("N_MIN", "40"))
PAIRES = [x for x in os.environ.get("PAIRES", "").split(",") if x]

# ---- MODE ANTI-ROLLOVER + SANS NEWS (directive utilisateur 07/10, 21 h 30 / precision 21 h 50) ----
# FLAT_HOUR  : heure serveur (float, 22.5 = 22 h 30) ou TOUTE position est fermee (kind 3), AVANT
#              le rollover/swap. None = mesure classique sans fermeture forcee.
# OPEN_HOUR  : les entrees sont admises seulement a partir de cette heure serveur (defaut 1 h) —
#              la pause 22:30 -> 01:00 evite le swap et la liquidite cassee.
# TZ_OFF     : decalage du serveur MT5 sur UTC (defaut +2).
# NEWS_MIN   : demi-fenetre (minutes) autour d'une news a fort impact pour le classement des
#              transactions ; 0 = desactive. Le R/tx « sans news » est emis dans le csv.
FLAT_HOUR = float(os.environ["FLAT_HOUR"]) if os.environ.get("FLAT_HOUR") else None
OPEN_HOUR = float(os.environ.get("OPEN_HOUR", "1"))
TZ_OFF = int(os.environ.get("TZ_OFF", "2"))
NEWS_MIN = int(os.environ.get("NEWS_MIN", "45"))
if NEWS_MIN > 0:
    import calendrier_news  # noqa: E402

# Les jambes survivantes (mesurees positives en ordres reels) et des temoins : indices du feed farm
# (m1_ext) et FX/metaux (m1_pos). Le corpus est choisi par paire, comme dans reel_empile.
SURVIVANTS = ["HKG.IDX", "USA30.IDX", "DEU.IDX", "CHI.IDX",
              "XAUUSD", "NZDUSD", "AUDCAD", "EURCHF",
              "AUS.IDX", "USSC2000.IDX", "GBPUSD", "CHFJPY"]
CORPUS_EXT = {p.name[:-7] for p in (B / "m1_ext").glob("*_M1.csv")} if (B / "m1_ext").exists() else set()


def ema(x, n):
    return pd.Series(x).ewm(span=n, adjust=False).mean().values


def sma(x, n):
    return pd.Series(x).rolling(n).mean().values


def rsi(c, n=14):
    d = np.diff(c, prepend=c[0])
    up = pd.Series(np.where(d > 0, d, 0.0)).ewm(alpha=1.0 / n, adjust=False).mean().values
    dn = pd.Series(np.where(d < 0, -d, 0.0)).ewm(alpha=1.0 / n, adjust=False).mean().values
    return 100.0 - 100.0 / (1.0 + up / np.where(dn > 0, dn, np.nan))


def macd(c, f=12, s=26, sig=9):
    m = ema(c, f) - ema(c, s)
    l = ema(m, sig)
    return m, l, m - l


def donchian(h, l, n):
    return (pd.Series(h).rolling(n).max().values, pd.Series(l).rolling(n).min().values)


def keltner(c, a, n=20, k=2.0):
    # ROUND 510 : LE CANAL DE KELTNER DE L'EA EST BATI SUR UNE MOYENNE SIMPLE, PAS EXPONENTIELLE.
    # Le declencheur KELTLOW/KELTHIGH de TRIGGER_LAB calcule m = somme des 20 dernieres cloture / 20
    # (moyenne SIMPLE) alors que le crible utilisait une EMA20 : les deux signaux ne se ressemblent que
    # de loin, et une campagne lancee sur la mesure EMA ne mesurerait pas le meme signal. On aligne le
    # crible sur l'EA, qui est l'arbitre (KELT_MOY=ema pour refaire l'ancienne mesure).
    mid = sma(c, n) if os.environ.get("KELT_MOY", "sma") == "sma" else ema(c, n)
    return mid, mid + k * a, mid - k * a


def bollinger(c, n=20, k=2.0):
    m = sma(c, n)
    sd = pd.Series(c).rolling(n).std().values
    return m, m + k * sd, m - k * sd


def croise(a, b, i):
    """Vrai quand la serie a passe au-dessus de b a la barre i (barres CLOTUREES)."""
    return (a[i] > b[i]) and (a[i - 1] <= b[i - 1])


def croise_bas(a, b, i):
    return (a[i] < b[i]) and (a[i - 1] >= b[i - 1])


def signaux(M, nom):
    """Rend une liste de (nom_signal, indices, sens) pour un usage d'indicateur donne."""
    c, h, l, a = M["c"], M["h"], M["l"], M["a"]
    n = len(c)
    out = []

    def ajoute(tag, idx, sens):
        idx = np.array([i for i in idx if 210 <= i < n - 20])
        if len(idx) >= 12:
            out.append((tag, idx, sens))

    # ---------------- KELTNER : mid = EMA20, bandes = 2 ATR ----------------
    kmid, kup, klo = keltner(c, a, 20, 2.0)
    largeur = (kup - klo) / np.where(np.abs(kmid) > 0, np.abs(kmid), np.nan)
    pct = pd.Series(largeur).rolling(200, min_periods=50).rank(pct=True).values
    dedans = (c > klo) & (c < kup)
    ajoute("KELT_BRK", [i for i in range(211, n - 20) if croise(c, kup, i)], "L")
    ajoute("KELT_BRK", [i for i in range(211, n - 20) if croise_bas(c, klo, i)], "S")
    # FADE : sorti au-dessus, rentre dedans -- l'echec de cassure, usage non evident du canal
    ajoute("KELT_FADE", [i for i in range(211, n - 20)
                         if c[i - 1] > kup[i - 1] and dedans[i]], "S")
    ajoute("KELT_FADE", [i for i in range(211, n - 20)
                         if c[i - 1] < klo[i - 1] and dedans[i]], "L")
    # SQUEEZE : canal en compression (percentile 200 barres < 25 %) puis cassure
    ajoute("KELT_SQ", [i for i in range(211, n - 20)
                       if np.isfinite(pct[i - 1]) and pct[i - 1] < 0.25 and croise(c, kup, i)], "L")
    ajoute("KELT_SQ", [i for i in range(211, n - 20)
                       if np.isfinite(pct[i - 1]) and pct[i - 1] < 0.25 and croise_bas(c, klo, i)], "S")
    # MARCHE LE LONG DE LA BANDE : 3 cloture au-dessus -- continuation, pas retour
    ajoute("KELT_WALK", [i for i in range(211, n - 20)
                         if c[i] > kup[i] and c[i - 1] > kup[i - 1] and c[i - 2] > kup[i - 2]], "L")
    ajoute("KELT_WALK", [i for i in range(211, n - 20)
                         if c[i] < klo[i] and c[i - 1] < klo[i - 1] and c[i - 2] < klo[i - 2]], "S")
    # ETIREMENT : distance a la bande en ATR >= 1 (prix 3 ATR au-dessus de la mediane)
    ajoute("KELT_EXT", [i for i in range(211, n - 20) if c[i] > kup[i] + 1.0 * a[i]], "S")
    ajoute("KELT_EXT", [i for i in range(211, n - 20) if c[i] < klo[i] - 1.0 * a[i]], "L")
    # REPRISE DE LA MEDIANE : etait sous la bande basse, repasse au-dessus
    ajoute("KELT_MID", [i for i in range(211, n - 20)
                        if c[i - 1] < klo[i - 1] and croise(c, kmid, i)], "L")
    ajoute("KELT_MID", [i for i in range(211, n - 20)
                        if c[i - 1] > kup[i - 1] and croise_bas(c, kmid, i)], "S")
    # TENDANCE + RAPPEL : EMA50 > EMA200 et mèche sous la bande basse -- acheter le rappel
    e50, e200 = ema(c, 50), ema(c, 200)
    ajoute("KELT_PULL", [i for i in range(211, n - 20)
                         if e50[i] > e200[i] and l[i] <= klo[i] and c[i] > kmid[i]], "L")
    ajoute("KELT_PULL", [i for i in range(211, n - 20)
                         if e50[i] < e200[i] and h[i] >= kup[i] and c[i] < kmid[i]], "S")

    # ---------------- BOLLINGER : SMA20 +/- 2 ecarts-types ----------------
    bmid, bup, blo = bollinger(c, 20, 2.0)
    bw = (bup - blo) / np.where(np.abs(bmid) > 0, np.abs(bmid), np.nan)
    bw_pct = pd.Series(bw).rolling(200, min_periods=50).rank(pct=True).values
    ajoute("BOLL_FADE", [i for i in range(211, n - 20)
                         if c[i - 1] > bup[i - 1] and c[i] <= bup[i]], "S")
    ajoute("BOLL_FADE", [i for i in range(211, n - 20)
                         if c[i - 1] < blo[i - 1] and c[i] >= blo[i]], "L")
    ajoute("BOLL_SQ", [i for i in range(211, n - 20)
                       if np.isfinite(bw_pct[i - 1]) and bw_pct[i - 1] < 0.2 and croise(c, bup, i)], "L")
    ajoute("BOLL_SQ", [i for i in range(211, n - 20)
                       if np.isfinite(bw_pct[i - 1]) and bw_pct[i - 1] < 0.2 and croise_bas(c, blo, i)], "S")
    ajoute("BOLL_MID", [i for i in range(211, n - 20)
                        if c[i - 1] < blo[i - 1] and croise(c, bmid, i)], "L")
    ajoute("BOLL_MID", [i for i in range(211, n - 20)
                        if c[i - 1] > bup[i - 1] and croise_bas(c, bmid, i)], "S")

    # ---------------- DONCHIAN ----------------
    dhi, dlo = donchian(h, l, 20)
    dmid = (dhi + dlo) / 2.0
    ajoute("DON_BRK", [i for i in range(211, n - 20) if h[i] >= dhi[i - 1]], "L")
    ajoute("DON_BRK", [i for i in range(211, n - 20) if l[i] <= dlo[i - 1]], "S")
    # ECHEC DE CASSURE : depasse le plus haut de 20 barres puis cloture en dessous dans les 3 barres
    echec_h, echec_b = [], []
    for i in range(211, n - 20):
        for j in (1, 2, 3):
            if h[i - j] >= dhi[i - j - 1] and c[i] < dhi[i - j - 1]:
                echec_h.append(i)
                break
        for j in (1, 2, 3):
            if l[i - j] <= dlo[i - j - 1] and c[i] > dlo[i - j - 1]:
                echec_b.append(i)
                break
    ajoute("DON_FAIL", echec_h, "S")
    ajoute("DON_FAIL", echec_b, "L")
    ajoute("DON_MID", [i for i in range(211, n - 20) if croise(c, dmid, i)], "L")
    ajoute("DON_MID", [i for i in range(211, n - 20) if croise_bas(c, dmid, i)], "S")

    # ---------------- RSI ----------------
    rs = rsi(c, 14)
    ajoute("RSI_TREND", [i for i in range(211, n - 20) if rs[i] < 30 and c[i] > e200[i]], "L")
    ajoute("RSI_TREND", [i for i in range(211, n - 20) if rs[i] > 70 and c[i] < e200[i]], "S")
    ajoute("RSI_RANGE", [i for i in range(211, n - 20) if c[i] > e200[i] and croise(rs, np.full(n, 40.0), i)], "L")
    ajoute("RSI_RANGE", [i for i in range(211, n - 20) if c[i] < e200[i] and croise_bas(rs, np.full(n, 60.0), i)], "S")
    # DIVERGENCE : plus haut de prix plus haut, RSI plus bas -- usage classique mais peu teste
    # ROUND 509 : LES DEUX PARAMETRES SORTENT DANS L'ENVIRONNEMENT. La divergence RSI est le premier
    # signal du projet positif six annees sur six ET sur plusieurs marches ; avant d'y mettre des
    # ordres reels, il faut savoir si l'edge survit au DEPLACEMENT de ses parametres (fenetre de
    # comparaison, ecart minimal du RSI). Un signal qui ne vit qu'avec W=20 et 3 points est un
    # artefact de calibration, pas un edge.
    w_div = int(os.environ.get("DIV_W", "20"))
    seuil_div = float(os.environ.get("DIV_SEUIL", "3"))
    div_s, div_l = [], []
    for i in range(210 + w_div, n - 20):
        w = w_div
        if h[i] >= np.max(h[i - w:i]) and rs[i] < np.max(rs[i - w:i]) - seuil_div:
            div_s.append(i)
        if l[i] <= np.min(l[i - w:i]) and rs[i] > np.min(rs[i - w:i]) + seuil_div:
            div_l.append(i)
    ajoute("RSI_DIV", div_s, "S")
    ajoute("RSI_DIV", div_l, "L")

    # ---------------- MACD ----------------
    _, _, hist = macd(c)
    ajoute("MACD_H0", [i for i in range(211, n - 20) if croise(hist, np.zeros(n), i)], "L")
    ajoute("MACD_H0", [i for i in range(211, n - 20) if croise_bas(hist, np.zeros(n), i)], "S")
    ajoute("MACD_PENTE", [i for i in range(211, n - 20)
                          if hist[i] > hist[i - 1] and hist[i - 1] > hist[i - 2] and hist[i] > 0], "L")
    ajoute("MACD_PENTE", [i for i in range(211, n - 20)
                          if hist[i] < hist[i - 1] and hist[i - 1] < hist[i - 2] and hist[i] < 0], "S")

    # ---------------- ADX / DI (approximation Wilder) ----------------
    up_m = h - np.roll(h, 1)
    dn_m = np.roll(l, 1) - l
    plus = np.where((up_m > dn_m) & (up_m > 0), up_m, 0.0)
    moins = np.where((dn_m > up_m) & (dn_m > 0), dn_m, 0.0)
    tr = pd.concat([pd.Series(h - l), pd.Series(np.abs(h - np.roll(c, 1))),
                    pd.Series(np.abs(l - np.roll(c, 1)))], axis=1).max(axis=1).values
    atr_w = pd.Series(tr).ewm(alpha=1.0 / 14, adjust=False).mean().values
    pdi = 100 * pd.Series(plus).ewm(alpha=1.0 / 14, adjust=False).mean().values / np.where(atr_w > 0, atr_w, np.nan)
    mdi = 100 * pd.Series(moins).ewm(alpha=1.0 / 14, adjust=False).mean().values / np.where(atr_w > 0, atr_w, np.nan)
    dx = 100 * np.abs(pdi - mdi) / np.where((pdi + mdi) > 0, pdi + mdi, np.nan)
    adx = pd.Series(dx).ewm(alpha=1.0 / 14, adjust=False).mean().values
    ajoute("ADX_DI", [i for i in range(211, n - 20)
                      if croise(pdi, mdi, i) and np.isfinite(adx[i]) and adx[i] > 20], "L")
    ajoute("ADX_DI", [i for i in range(211, n - 20)
                      if croise_bas(pdi, mdi, i) and np.isfinite(adx[i]) and adx[i] > 20], "S")
    # ADX BAS + EXTREME DE DONCHIAN : marche sans direction, on prend le retour
    ajoute("ADX_CALME", [i for i in range(211, n - 20)
                         if np.isfinite(adx[i]) and adx[i] < 15 and l[i] <= dlo[i - 1]], "L")
    ajoute("ADX_CALME", [i for i in range(211, n - 20)
                         if np.isfinite(adx[i]) and adx[i] < 15 and h[i] >= dhi[i - 1]], "S")
    return out


def mesure_dir(M, sig, sens, tenue, tpr=None, slr=SLR):
    # ROUND 508 : LA CIBLE SE DIT EN MULTIPLES DU RISQUE, PAS EN ATR. `issue` attend `tpr` et `slr` en
    # ATR, tandis que les campagnes en ordres reels recoivent `--tp-r` en multiples du RISQUE : le
    # crible passait donc la cible BRUTE (2 ATR) la ou l'EA visait 2 R (6 ATR), et il jugeait toute la
    # famille des indicateurs avec une cible trois fois plus serree que celle validee au banc. C'est la
    # meme erreur d'unite que le round 480, par l'autre bout : ici elle rendait les signaux artificiel-
    # lement mauvais (cible 0,67 R au lieu de 2 R).
    tp = (slr * TPR) if tpr is None else tpr
    n = len(M["idx"])
    idx, o, a = M["idx"], M["o"], M["a"]
    ent = np.array(sorted(set(sig + 1)))
    ent = ent[(ent >= 2) & (ent < n - 2)]
    if FLAT_HOUR is not None:
        # MODE ANTI-ROLLOVER (07/10) : pas d'entree pendant la pause 22:30 -> 01:00 serveur.
        # Les entrees sont admises seulement dans la fenetre [OPEN_HOUR, FLAT_HOUR).
        mn = ((idx[ent].astype(np.int64) // 10**9 + TZ_OFF * 3600) % 86400) // 60
        ouvre = mn >= int(round(OPEN_HOUR * 60))
        ferme = mn < int(round(FLAT_HOUR * 60))
        ent = ent[ouvre & ferme]
    if len(ent) < 12:
        return None
    res = []
    for k in ent:
        st = float(a[k - 1])
        if not np.isfinite(st) or st <= 0:
            continue
        r = BM.issue(M["m1"], int(pd.Timestamp(idx[k]).timestamp()), float(o[k]),
                     st, tp, slr, tenue * M["minutes"], sens, par_barres=True,
                     flat_hour=FLAT_HOUR, tz_off=TZ_OFF)
        if r is not None:
            res.append((k, r))
    if len(res) < 12:
        return None
    ent = np.array([k for k, _ in res])
    kind = np.array([r[0] for _, r in res])
    R = np.array([r[1] for _, r in res])
    garde = SB.bloque(idx, ent, R, kind)
    if len(garde) < 12:
        return None
    R, kind = R[garde], kind[garde]
    ts = np.array([int(pd.Timestamp(idx[ent[k]]).timestamp()) for k in garde])
    ans = defaultdict(list)
    for k, r_ in zip(garde, R):
        ans[idx[ent[k]].year].append(r_)
    aok = a[np.isfinite(a) & (a > 0)]
    cout = float(np.median(M["spr"][np.isfinite(M["spr"])]) / np.median(aok)) / slr if len(aok) else np.nan
    # OPTION SANS NEWS (07/10) : chaque transaction est classee par son instant d'entree — dans la
    # fenetre a risque d'une news (± NEWS_MIN minutes) ou non. Le R/tx « sans news » dit si l'edge
    # survit aux transactions de news ; un edge qui ne vit QUE des news est un edge de news, pas un
    # edge de regle.
    if NEWS_MIN > 0:
        near = np.array([calendrier_news.dans_fenetre(t_, NEWS_MIN) for t_ in ts])
    else:
        near = np.zeros(len(ts), dtype=bool)
    r_sn = float(np.mean(R[~near])) if (~near).sum() >= 12 else float("nan")
    r_news = float(np.mean(R[near])) if near.sum() >= 8 else float("nan")
    return dict(n=len(R), R=float(np.mean(R)), sd=float(np.std(R, ddof=1)),
                gagn=100.0 * float(np.mean(kind == 0)), cout=cout,
                n_an=len(ans), n_pos=sum(1 for v in ans.values() if np.mean(v) > 0),
                ans={y: round(float(np.mean(v)), 4) for y, v in sorted(ans.items())},
                n_news=int(near.sum()), R_news=r_news, R_sans_news=r_sn,
                kind3=100.0 * float(np.mean(kind == 3)))


def main():
    paires = PAIRES or SURVIVANTS
    print("CRIBLE INDICATEURS CLASSIQUES | trames %s | stop %.1f ATR | cible %.1f R | corpus par paire"
          % (TRAMES, SLR, TPR))
    lignes = []
    for p in paires:
        # CORPUS_FORCE : indispensable pour juger une paire sur les donnees du courtier prop lui-meme
        # (m1_upcomers), sinon une paire inconnue de m1_ext retombe sur le corpus FX de la ferme.
        corpus = os.environ.get("CORPUS_FORCE") or ("m1_ext" if p in CORPUS_EXT else "m1_pos")
        for tf in TRAMES:
            M = BM.charge_tf(p, corpus, minutes=tf)
            if M is None:
                print("  %-12s trame %2d : corpus absent" % (p, tf))
                continue
            for tag, idx_sig, sens in signaux(M, p):
                m = mesure_dir(M, idx_sig, sens, TENUE.get(tf, 64))
                if m is None:
                    continue
                attendu = m["R"] - m["cout"]
                lignes.append(dict(paire=p, trame=tf, signal=tag, sens=sens, n=m["n"], R=m["R"],
                                   sd=m["sd"], cout=m["cout"], attendu=attendu, gagn=m["gagn"],
                                   n_pos=m["n_pos"], n_an=m["n_an"],
                                   n_news=m.get("n_news", ""), R_news=m.get("R_news", ""),
                                   R_sans_news=m.get("R_sans_news", ""), kind3=m.get("kind3", ""),
                                   annees=" ".join("%d %+.3f" % (y, v) for y, v in m["ans"].items())))
                if m["n"] >= N_MIN and attendu > 0.05 and m["n_pos"] >= 2 * m["n_an"] / 3.0:
                    print("  %-12s %2d %-11s %s | n=%4d R=%+.4f cout=%.3f attendu=%+.4f gagn=%4.1f%% annees %d/%d"
                          % (p, tf, tag, sens, m["n"], m["R"], m["cout"], attendu, m["gagn"],
                             m["n_pos"], m["n_an"]))
    if not lignes:
        print("  aucune mesure")
        return 1
    df = pd.DataFrame(lignes).sort_values("attendu", ascending=False)
    df.to_csv(SORTIE, index=False, encoding="utf-8")
    print("\n  %d mesures -> %s" % (len(df), SORTIE.name))
    print("\n  === 25 MEILLEURES (n >= %d) ===" % N_MIN)
    print("  %-12s %4s %-11s %3s %6s %9s %7s %9s %6s %s"
          % ("paire", "trame", "signal", "sens", "n", "R/tx", "cout", "attendu", "annees", "detail"))
    for _, x in df[df.n >= N_MIN].head(25).iterrows():
        print("  %-12s %4d %-11s %3s %6d %+9.4f %7.3f %+9.4f %3d/%-2d %s"
              % (x.paire, x.trame, x.signal, x.sens, x.n, x.R, x.cout, x.attendu,
                 x.n_pos, x.n_an, x.annees))
    print("\n  === FAMILLES (attendu moyen, mesures n >= %d) ===" % N_MIN)
    g = df[df.n >= N_MIN].groupby("signal").agg(mesures=("attendu", "size"), attendu=("attendu", "mean"),
                                                positifs=("attendu", lambda s: int((s > 0).sum())))
    for tag, row in g.sort_values("attendu", ascending=False).iterrows():
        print("  %-11s %3d mesures | attendu moyen %+.4f | positifs %d" % (tag, row.mesures, row.attendu, row.positifs))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
