import os, sys
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
M1 = r"C:\EAFarm\HISTORY - Copy\research\m1_pos"
print("=== COUVERTURE REELLE DES DONNEES M1 PAR PAIRE ===")
print("paire     | jours | barres/jour median | annees couvertes")
for f in sorted(os.listdir(M1)):
    if not f.endswith("_M1.csv"):
        continue
    p = f.replace("_M1.csv", "")
    d = pd.read_csv(os.path.join(M1, f), usecols=["time"])
    t = pd.to_datetime(d["time"], unit="s", utc=True)
    j = t.dt.date.value_counts()
    an = sorted(set(t.dt.year))
    print("%-9s | %5d | %18.0f | %s"
          % (p, j.shape[0], j.median(), ",".join(str(a) for a in an)))

print("\n=== DETAIL 2024 : barres M5 disponibles par jour (extrait) ===")
for p in ("EURUSD", "USDCAD"):
    f = os.path.join(M1, "%s_M1.csv" % p)
    if not os.path.exists(f):
        continue
    d = pd.read_csv(f, usecols=["time", "high"])
    t = pd.to_datetime(d["time"], unit="s", utc=True)
    d = d.assign(t=t)
    d = d[(d.t >= "2024-01-01") & (d.t < "2024-04-01")]
    b = d.set_index("t").resample("5min").agg(high=("high", "count"))
    par_jour = b.groupby(b.index.date).size()
    print("  %s : %d jours avec des barres M5 en 2024Q1, median %.0f barres/jour (24h = 288)"
          % (p, par_jour.shape[0], par_jour.median()))
    print("     premiers jours : %s" % list(par_jour.index[:5]))
    print("     derniers jours : %s" % list(par_jour.index[-5:]))
