"""attrib : corpus d'ORDRES REELS avec ATTRIBUTION PAR LIGNE.

par_<profil>_<tag>.jsonl contient, pour chaque test, la liste des lignes du jeu
avec leur n, leur PnL et leur nombre de gagnants : c'est la seule donnee du
projet ou une combinaison est mesuree en ordres reels AVEC attribution (les
blocs "reel" du REGISTRE sont des paniers, donc inattribuables).

On agrege par (ligne, paire, campagne) -- jamais entre campagnes, car la
geometrie change -- et on regarde le SIGNE du PnL par fenetre : c'est
independant de la geometrie et du lot.
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
OUT = B / "attrib_report.md"
HOSTILE = ("2024Q1", "2024Q2", "2025Q2", "2025Q3", "2025Q4")
BON = ("2024Q3", "2024Q4")


def main():
    agg = defaultdict(dict)      # (id, sym, tag) -> {quart: (n, pnl, win)}
    nf = 0
    for f in sorted(B.glob("par_*.jsonl")):
        nom = f.stem.split("_", 2)
        if len(nom) < 3:
            continue
        nf += 1
        tag = nom[2]
        for ln in f.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                o = json.loads(ln)
            except ValueError:
                continue
            sym, quart = o.get("sym"), o.get("quarter")
            for c in o.get("combos") or []:
                if not (c.get("n") or 0):
                    continue
                d = agg[(c["id"], sym, tag)]
                n0, p0, w0 = d.get(quart, (0, 0.0, 0))
                d[quart] = (n0 + c["n"], p0 + (c.get("pnl") or 0),
                            w0 + (c.get("win") or 0))
    print("fichiers %d | series (ligne,paire,campagne) %d" % (nf, len(agg)), flush=True)

    res = []
    for (cid, sym, tag), parq in agg.items():
        n = sum(v[0] for v in parq.values())
        if n < 200 or len(parq) < 5:
            continue
        pnl = sum(v[1] for v in parq.values())
        win = sum(v[2] for v in parq.values())
        h = [v for q, v in parq.items() if q in HOSTILE]
        b = [v for q, v in parq.items() if q in BON]
        a = [v for q, v in parq.items() if q[:4].isdigit() and int(q[:4]) <= 2023]
        ph = sum(v[1] for v in h) if h else None
        pb = sum(v[1] for v in b) if b else None
        pa = sum(v[1] for v in a) if a else None
        res.append(dict(id=cid, sym=sym, tag=tag, n=n, fen=len(parq),
                        pnl=pnl, pnl_tx=pnl / n, win=win / n,
                        npos=sum(1 for v in parq.values() if v[1] > 0),
                        host=ph, bon=pb, ann=pa,
                        nh=len(h), nb=len(b), na=len(a)))
    res.sort(key=lambda d: -d["pnl_tx"])
    out = ["# Attribution par ligne, ordres reels (%d series >=200 tx et >=5 fenetres)" % len(res),
           "",
           "| ligne | paire | campagne | n | fen | +fen | PnL/tx | gagnants | hostile | bon | annuel |",
           "|---|---|---|---|---|---|---|---|---|---|---|"]
    for d in res[:50]:
        out.append("| %s | %s | %s | %d | %d | %d | %.2f | %.3f | %s | %s | %s |"
                   % (d["id"], d["sym"], d["tag"], d["n"], d["fen"], d["npos"],
                      d["pnl_tx"], d["win"],
                      "%.0f" % d["host"] if d["host"] is not None else "-",
                      "%.0f" % d["bon"] if d["bon"] is not None else "-",
                      "%.0f" % d["ann"] if d["ann"] is not None else "-"))
    out += ["", "## lignes strictement positives sur TOUTES leurs fenetres"]
    toutes = [d for d in res if d["npos"] == d["fen"] and d["fen"] >= 6]
    out.append("**%d series sur %d** (>=6 fenetres, 100%% positives) :" % (len(toutes), len(res)))
    for d in sorted(toutes, key=lambda d: -d["n"])[:20]:
        out.append("- `%s` %s [%s] n=%d fen=%d PnL/tx %.2f gagnants %.3f"
                   % (d["id"], d["sym"], d["tag"], d["n"], d["fen"], d["pnl_tx"], d["win"]))
    ok = [d for d in res if (d["host"] or -1) > 0 and (d["bon"] or -1) > 0]
    out += ["", "## positives sur hostile ET sur bon : **%d series sur %d**" % (len(ok), len(res))]
    for d in sorted(ok, key=lambda d: -(d["host"] or 0))[:20]:
        out.append("- `%s` %s [%s] n=%d hostile %+.0f bon %+.0f PnL/tx %.2f"
                   % (d["id"], d["sym"], d["tag"], d["n"], d["host"], d["bon"], d["pnl_tx"]))
    OUT.write_text("\n".join(out), encoding="utf-8")
    print("ecrit %s" % OUT, flush=True)
    print("positives partout : %d | host+bon positives : %d" % (len(toutes), len(ok)), flush=True)
    for l in out[8:20]:
        print(l, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
