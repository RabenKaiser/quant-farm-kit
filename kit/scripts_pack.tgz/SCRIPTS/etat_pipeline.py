# -*- coding: utf-8 -*-
r"""etat_pipeline.py -- L'ENTONNOIR EST-IL EN BON ETAT DE MARCHE ?

Verifie, etage par etage, que la chaine tourne VRAIMENT : processus, file de
campagnes, validite des setfiles, pool de paires, triage, porte du juge, et
l'age des derniers resultats. Sortie : un rapport lisible, avec ALERTE quand un
etage est casse ou silencieux.

Usage : python etat_pipeline.py
"""
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
SCRIPTS = BASE / "SCRIPTS"
COMMUN = Path(os.path.expandvars(r"%APPDATA%\MetaQuotes\Terminal\Common\Files"))
EA = Path(os.path.expandvars(
    r"%APPDATA%\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\MQL5\Experts\eepeek\TRIGGER_LAB.mq5"))
EX5 = EA.with_suffix(".ex5")


def age_min(p):
    try:
        return (time.time() - p.stat().st_mtime) / 60.0
    except OSError:
        return None


def procs(motif):
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
             "Where-Object {$_.CommandLine -like '*%s*'} | "
             "Select-Object -ExpandProperty ProcessId" % motif],
            capture_output=True, text=True, timeout=60)
        return [x for x in out.stdout.split() if x.strip()]
    except Exception:
        return []


def main():
    lin = []
    alerte = []

    # --- 0. EA compile ?
    a_mq5, a_ex5 = age_min(EA), age_min(EX5)
    if a_ex5 is None:
        alerte.append("aucun ex5 compile")
    elif a_mq5 is not None and a_ex5 < a_mq5 - 1:
        alerte.append("ex5 PLUS VIEUX que le source : recompiler")
    lin.append("EA : source il y a %.0f min, ex5 il y a %.0f min -- %s"
               % (a_mq5 or -1, a_ex5 or -1,
                  "a jour" if (a_ex5 is not None and (a_mq5 is None or a_ex5 >= a_mq5 - 1)) else "A RECOMPILER"))

    # --- 1. voie A : la boucle
    b = procs("boucle_nuit")
    lin.append("voie A (boucle de ferme) : %s" % ("VIVANTE (PID %s)" % ",".join(b) if b else "MORTE"))
    if not b:
        alerte.append("boucle de ferme morte")
    # voie B : superviseur deux voies
    d = procs("deux_voies")
    lin.append("voie B (superviseur triage) : %s" % ("VIVANT (PID %s)" % ",".join(d) if d else "ABSENT"))
    if not d:
        alerte.append("superviseur deux_voies absent")

    # --- 2. file de campagnes
    lots = json.loads((BASE / "LOTS_V6.json").read_text(encoding="utf-8"))
    lin.append("file : %d lots" % len(lots))

    # --- 3. setfiles valides
    r = subprocess.run([sys.executable, "-X", "utf8", str(SCRIPTS / "valide_setfiles.py")],
                       capture_output=True, text=True, cwd=str(BASE))
    m = re.search(r"setfiles valides : (\d+) \| fautifs : (\d+)", r.stdout or "")
    if m:
        lin.append("setfiles : %s valides, %s fautifs" % (m.group(1), m.group(2)))
        if int(m.group(2)):
            alerte.append("%s setfiles fautifs" % m.group(2))

    # --- 4. pool de paires
    r = subprocess.run([sys.executable, "-X", "utf8", str(SCRIPTS / "valide_univers.py")],
                       capture_output=True, text=True, cwd=str(BASE))
    m = re.search(r"HORS POOL : (\d+)", r.stdout or "")
    if m:
        lin.append("pool de paires : %s lot(s) hors pool" % m.group(1))
        if int(m.group(1)):
            alerte.append("%s lots hors pool" % m.group(1))
    m2 = re.search(r"cout de spread median de la file : ([\d.]+) R/tx", r.stdout or "")
    if m2:
        lin.append("cout de spread median de la file : %s R/tx" % m2.group(1))

    # --- 5. triage : idees en attente
    try:
        idees = json.loads((BASE / "TRIAGE_IDEES.json").read_text(encoding="utf-8"))["idees"]
        faites = set(json.loads((BASE / "TRIAGE_IDEES_FAITES.json").read_text(encoding="utf-8")))
        rest = [i["nom"] for i in idees if i["nom"] not in faites]
        lin.append("triage : %d idees, %d faites, %d en attente" % (len(idees), len(faites), len(rest)))
    except Exception as e:
        lin.append("triage : illisible (%s)" % e)
        alerte.append("fichiers de triage illisibles")

    # --- 6. verdicts et derniers resultats
    v = BASE / "TRIAGE_VERDICTS.json"
    if v.exists():
        n_verdicts = len(json.loads(v.read_text(encoding="utf-8")))
        lin.append("verdicts de triage : %d (dernier il y a %.0f min)" % (n_verdicts, age_min(v) or -1))
    res = sorted(BASE.glob("par_farm_*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)
    res = [p for p in res if not p.name.endswith("_deals.jsonl")]
    if res:
        lin.append("dernier resultat de campagne : %s il y a %.0f min" % (res[0].name[9:-6], age_min(res[0]) or -1))
        if (age_min(res[0]) or 1e9) > 120 and b:
            alerte.append("aucun resultat de campagne depuis plus de 2 h")
    # la campagne en cours
    camps = sorted((BASE).glob("camp_*.log"), key=lambda p: p.stat().st_mtime, reverse=True)
    if camps:
        lin.append("campagne la plus recente : %s il y a %.0f min" % (camps[0].name[5:-4], age_min(camps[0]) or -1))

    print("=" * 76)
    print("ETAT DE L'ENTONNOIR -- %s" % datetime.now().strftime("%d/%m %H:%M"))
    print("=" * 76)
    for l in lin:
        print("  " + l)
    print()
    if alerte:
        print("ALERTES :")
        for a in alerte:
            print("  !! " + a)
    else:
        print("AUCUNE ALERTE : tous les etages repondent.")


if __name__ == "__main__":
    main()