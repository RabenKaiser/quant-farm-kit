# -*- coding: utf-8 -*-
"""chk_xau_vol2_r43.py — volumes exacts des runs XAU retenus (equity CSVs)."""
import sys, glob, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
# cibles: VWAPFADE n=110 bal=14629 ; VWAPTREND n=128 bal=19738
for EA, nT, bT in [("VWAPFADE", 110, 14629), ("VWAPTREND", 128, 19738)]:
    for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-60:]:
        try:
            runs = F.parse_stream(lp, EA)
        except Exception:
            continue
        for key, data in runs.items():
            if "XAUUSD" not in key or "H1" not in key:
                continue
            closed = [t for t in data["trades"].values() if t["close"] is not None]
            if len(closed) != nT or abs((data.get("balance") or 0) - bT) > 3:
                continue
            vols = sorted({round(t.get("vol", 0), 2) for t in closed})
            sides = {}
            for t in closed:
                sides[t.get("side")] = sides.get(t.get("side"), 0) + 1
            t0 = closed[0]
            print(f"{EA} n={nT} bal={data.get('balance'):.0f} vols={vols} "
                  f"sides={sides}")
            print(f"  ex: {t0}")
            sys.exit(0)
print("pas trouve")
