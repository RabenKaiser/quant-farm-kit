# -*- coding: utf-8 -*-
"""chk_xau_vol_r43.py — volumes + details logs VWAPFADE/VWAPTREND XAU."""
import sys, glob, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
for EA in ("VWAPFADE", "VWAPTREND"):
    print(f"===== {EA} =====")
    n = 0
    for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-60:]:
        try:
            runs = F.parse_stream(lp, EA)
        except Exception:
            continue
        for key, data in runs.items():
            if "XAUUSD" not in key or "2026" not in key.replace(".", ""):
                continue
            closed = [t for t in data["trades"].values() if t["close"] is not None]
            if len(closed) < 5:
                continue
            # raw fields d'un trade clos
            t0 = closed[0]
            print(f"{os.path.basename(lp)[:24]} | {key.split(' ')[0][:12]} "
                  f"n={len(closed)} bal={data.get('balance'):.0f} | "
                  f"champs: {sorted(t0.keys())[:14]}")
            n += 1
            if n > 8:
                break
        if n > 8:
            break
print("FIN")
