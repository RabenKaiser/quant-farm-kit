﻿import sys, numpy as np, gc
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT
G._cache.clear(); gc.collect()
F = G.get_frames("EURAUD"); m5,m1=F["m5"],F["m1"]
h1z,hh,ll,a1,gb,gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd,zlo,zhi = MT.project(m5.index,h1z,hh,ll,gb,gr,max_age_h=48)
M = NL.build(m5,F,zd,zlo,zhi); M.update(FE.more(m5,F,m1))
n=len(m5)
# taux de vrai de big_bear SEUL et avec vol_lo
bb = np.asarray(M["big_bear"]); vl = np.asarray(M["vol_lo"])
print(f"big_bear seul           : {100*bb.mean():.2f} %")
print(f"vol_lo seul             : {100*vl.mean():.2f} %")
both = bb & vl
print(f"big_bear ET vol_lo      : {100*both.mean():.2f} %  ({both.sum()} barres)")
print()
# combien de signaux NL.sig produit-il ?
s = NL.sig(M, "big_bear", ["vol_lo"])
print(f"NL.sig(big_bear,[vol_lo]) : {int((s!=0).sum())} signaux")
print()
print("RAPPEL : le fetch MT5 doit donner ~1349 entrees. 449/1349 = 33 %.")
print("=> si les taux de vrai concordent, l'ecart vient du NB DE POSITIONS")
print("   simultanees (InpMaxPos=4) ou du no-hedging, pas des conditions.")
