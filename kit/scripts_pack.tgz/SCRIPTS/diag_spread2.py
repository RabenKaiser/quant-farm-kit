# -*- coding: utf-8 -*-
"""diag_spread2.py — LE SPREAD REEL, MESURE DANS LES DONNEES DUKASCOPY.

Le fichier M1 Dukascopy contient une colonne 'spread'. C'est une mesure
DIRECTE, pas un proxy. On peut donc repondre precisement a :

  1. Quel est le spread CADJPY par heure ?
  2. Le spread explique-t-il les sorties SL en 40 secondes vues en MT5 ?
  3. L'EA applique-t-il le spread correctement ?

RAPPEL DU MECANISME
-------------------
L'EA ACHETE a l'ASK et pose le SL sous l'ASK. Le SL se declenche quand le BID
passe dessous. A l'instant de l'entree, bid = ask - spread. Donc la distance
REELLE entre le prix de sortie potentiel (bid) et le SL est :

    distance_effective = 2 ATR - spread

Si le spread vaut 2 ATR, le SL est touche IMMEDIATEMENT.

UNITE : sur les CSV Dukascopy, la colonne 'spread' est en POINTS entiers.
CADJPY cote 3 decimales -> 1 point = 0.001.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
SYM = "CADJPY"

df = pd.read_csv(BASE / "m1_pos" / f"{SYM}_M1.csv",
                 usecols=["time", "open", "high", "low", "close", "spread"])
df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
df = df.set_index("time").sort_index()
print(f"{SYM} : {len(df)} barres M1")

pt = 0.001                      # 1 point CADJPY
sp = df["spread"].to_numpy(float)

print()
print("=" * 88)
print("DISTRIBUTION DU SPREAD (points entiers)")
print("=" * 88)
for q in (5, 25, 50, 75, 90, 95, 99, 99.9):
    print(f"  percentile {q:>5} : {np.percentile(sp, q):>8.1f} points "
          f"= {np.percentile(sp,q)*pt:.4f}")
print(f"  maximum          : {sp.max():>8.1f} points = {sp.max()*pt:.4f}")
print(f"  moyenne          : {sp.mean():>8.1f} points = {sp.mean()*pt:.4f}")

print()
print("=" * 88)
print("SPREAD MOYEN PAR HEURE (heure UTC du fichier)")
print("=" * 88)
hr = df.index.hour.to_numpy()
print(f"{'heure':>6}{'spread moy':>12}{'spread p90':>12}{'n':>10}")
print("-" * 88)
for hh in range(24):
    m = hr == hh
    if m.sum() == 0:
        continue
    print(f"{hh:>6}{sp[m].mean():>12.1f}{np.percentile(sp[m],90):>12.1f}"
          f"{int(m.sum()):>10}")

# ---- effet sur la strategie ----
print()
print("=" * 88)
print("EFFET DU SPREAD REEL SUR LE TAUX DE SL")
print("=" * 88)

m5 = pd.DataFrame({
    "open": df["open"].resample("5min").first(),
    "high": df["high"].resample("5min").max(),
    "low": df["low"].resample("5min").min(),
    "close": df["close"].resample("5min").last(),
    "spread": df["spread"].resample("5min").mean()}).dropna()

h = m5["high"].to_numpy(float); l = m5["low"].to_numpy(float)
c = m5["close"].to_numpy(float); o = m5["open"].to_numpy(float)
sp5 = m5["spread"].to_numpy(float) * pt      # en unite de prix
pc = np.roll(c, 1); pc[0] = c[0]
tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
atr = pd.Series(tr).ewm(alpha=1/14, adjust=False).mean().to_numpy()
sig = h < (np.roll(l, 2) - 1.0 * atr)
sig[:5] = False

print(f"  signaux : {int(sig.sum())}")
print(f"  ATR M5 median : {np.nanmedian(atr):.5f}")
print(f"  spread M5 median : {np.nanmedian(sp5):.5f}  "
      f"= {100*np.nanmedian(sp5)/np.nanmedian(atr):.1f} % de l'ATR")
print(f"  SL = 2 ATR = {2*np.nanmedian(atr):.5f}")
print()

N = len(c)
for label, use_spread in (("sans spread", False), ("AVEC spread reel", True)):
    last = -1
    rets = []; nsl = ntp = nmx = 0
    for i in np.where(sig)[0]:
        if i <= last or i + 2 >= N:
            continue
        e = i + 1
        a = atr[i]
        if not np.isfinite(a) or a <= 0:
            continue
        cost = sp5[i] if use_spread else 0.0
        entry = o[e] + cost            # achat a l'ask
        risk = 2.0 * a
        sl = entry - risk
        tp = entry + 3.0 * risk
        got = None
        for k in range(e, min(e + 48, N)):
            if l[k] <= sl:
                got = -1.0; nsl += 1; last = k; break
            if h[k] >= tp:
                got = 3.0; ntp += 1; last = k; break
        if got is None:
            k = min(e + 48 - 1, N - 1)
            # sortie au bid
            got = (c[k] - cost - entry) / risk; nmx += 1; last = k
        rets.append(got)
    x = np.array(rets)
    print(f"  {label:<18} n={len(x):>5} SL={100*nsl/len(x):>5.1f}% "
          f"TP={100*ntp/len(x):>5.1f}% MAX={100*nmx/len(x):>5.1f}% "
          f"win={100*(x>0).mean():>5.1f}% R={x.sum():>8.0f}")

print()
print("=" * 88)
print("COMPARAISON MT5")
print("=" * 88)
print("  MT5 apres fix n56 : 144 sorties | SL 86% | TP 3% | win 12.5% | -634")
print("  python            : 3299 trades | SL 60% | TP 18% | win 37%   | +538")
print()
print("  Si 'AVEC spread reel' reste autour de 60% de SL, le spread n'est")
print("  PAS la cause et il faut chercher ailleurs (modele de test, slippage,")
print("  ou la facon dont l'EA gere les positions multiples).")
