﻿import subprocess, time, glob, os, re
from pathlib import Path
FARM = Path(r"C:\EAFarm\MT5\Farm"); TM = FARM/"terminal64.exe"
COMMON = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")/"Common"/"Files"
LOGD = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")/"CF0B997454318B475CF01419AFE2BBF3"/"Tester"/"logs"
CFG = FARM/"Config"/"config_exp_dec.ini"
sym="GBPUSD"
# Testeur en 2021 => la serie M1 disponible est 2020 (mesure par la sonde).
# On demande donc a l'EA d'exporter 2020.
cfg = (f"[Tester]\nExpert=eepeek\\EXPORT_M1.ex5\nSymbol={sym}\nPeriod=M1\n"
       f"Model=0\nOptimization=0\nFromDate=2021.01.01\nToDate=2021.12.31\n"
       f"Deposit=10000\nCurrency=USD\nLeverage=100\nReplaceReport=1\nShutdownTerminal=1\n"
       f"[TesterInputs]\nInpSymbol={sym}\nInpFrom=2020.01.01\nInpTo=2020.12.31\n")
CFG.write_text(cfg)
src = COMMON/f"{sym}_M1.csv"
if src.exists(): src.unlink()
p=subprocess.Popen([str(TM),"/config:"+str(CFG)],cwd=str(FARM),
                   creationflags=0x08000000,
                   stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
w=0; prev=-1; stable=0
while w<900:
    time.sleep(4); w+=4
    cur = src.stat().st_size if src.exists() else 0
    alive = "terminal64" in subprocess.run(["tasklist","/FI",f"PID eq {p.pid}"],
             capture_output=True,text=True).stdout
    stable = stable+1 if (cur>0 and cur==prev) else 0
    prev=cur
    if not alive: break
    if stable>=5 and cur>1000: break
subprocess.run(["taskkill","/F","/IM","terminal64.exe"],capture_output=True)
time.sleep(3)
print(f"duree {w}s")
if src.exists() and src.stat().st_size>1000:
    n=sum(1 for _ in open(src,encoding="utf-8",errors="replace"))-1
    from datetime import datetime, timezone
    with open(src,encoding="utf-8",errors="replace") as f:
        next(f); first=f.readline().split(",")[0]
    last=None
    for line in open(src,encoding="utf-8",errors="replace"):
        if line.strip(): last=line.split(",")[0]
    print(f"  SUCCES : {n:,} barres M1 ({src.stat().st_size/1e6:.1f} Mo)")
    print(f"  {datetime.fromtimestamp(int(first),tz=timezone.utc)} -> {datetime.fromtimestamp(int(last),tz=timezone.utc)}")
else:
    print("  echec / vide")
