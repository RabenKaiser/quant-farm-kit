# -*- coding: utf-8 -*-
"""diag_cadjpy.py — CADJPY : pourquoi MT5 fait 86% de SL et python 60% ?

ETAT DES MESURES
----------------
  python, SL=2 ATR_M5, TP=3R, hold=48, signal fvg_dn_10 sur vraies bougies :
      3299 trades | SL 60% | TP 18% | R total +538
  MT5 apres fix n56 (stop M5) :
      144 sorties | SL 86% | TP 3%  | pnl -634

Le nombre de trades differe enormement (3299 vs 144) : c'est NORMAL, l'EA a
des portes (spread, sessions, maxpos=4, no-hedge, une position par jambe) que
le backtest python n'a pas. Ce n'est pas le probleme.

LE PROBLEME EST LE TAUX DE SL : 60% en python, 86% en MT5.

HYPOTHESE A TESTER : le DECALAGE D'ENTREE.
  python  : entry = OPEN de la barre i+1 (la barre qui suit le signal)
  MT5     : ordre au MARCHE, donc au prix du tick courant, qui est le prix
            APRES le signal — typiquement le CLOSE de la barre de signal,
            et surtout APRES que le marche a deja bouge.

Si le signal fvg_dn se declenche sur une barre violemment baissiere, alors :
  - en python on entre a l'open de la barre suivante (prix calme) ;
  - en MT5 on entre a la fin de la barre de signal (prix deja bas), MAIS le
    SL est place a 2 ATR sous le prix d'entree — donc plus bas encore.
  Or le TP est a 3R au-dessus. Un prix d'entree plus HAUT rend le SL plus
  facile a toucher.

Autre composante : le SPREAD. L'EA achete a l'ASK et le SL est pose sous
l'ask, mais le SL se declenche sur le BID. Le spread est donc un cout
systematique qui rapproche le SL.

CE SCRIPT MESURE, sur CADJPY :
  1. le taux de SL/TP selon le decalage d'entree (open i+1 vs close i)
  2. l'effet du spread en entrant a l'ask et en sortant au bid
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
SYM = "CADJPY"


def m5(sym):
    p = BASE / "m1_pos" / f"{sym}_M1.csv"
    df = pd.read_csv(p, usecols=["time", "open", "high", "low", "close"])
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time").sort_index()
    return pd.DataFrame({
        "open": df["open"].resample("5min").first(),
        "high": df["high"].resample("5min").max(),
        "low": df["low"].resample("5min").min(),
        "close": df["close"].resample("5min").last()}).dropna()


def atr_series(h, l, c, n=14):
    pc = np.roll(c, 1); pc[0] = c[0]
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    return pd.Series(tr).ewm(alpha=1/n, adjust=False).mean().to_numpy()


def sim(d, sig, sl_atr=2.0, tp_r=3.0, hold=48, entry_mode="open_next",
        spread=0.0):
    """entry_mode :
         'open_next' -> entree a l'open de i+1  (ce que fait python)
         'close_sig' -> entree au close de la barre de signal (approche MT5)
       spread : cout en unites de prix, applique a l'entree (achat a l'ask).
    """
    h = d["high"].to_numpy(float); l = d["low"].to_numpy(float)
    o = d["open"].to_numpy(float); c = d["close"].to_numpy(float)
    a = atr_series(h, l, c)
    N = len(c)
    kinds = []; rets = []; last = -1
    for i in np.where(sig)[0]:
        if i <= last:
            continue
        if entry_mode == "open_next":
            e = i + 1
            if i + 2 >= N:
                continue
            entry0 = o[e]
        else:
            e = i + 1
            if i + 2 >= N:
                continue
            entry0 = c[i]
        if not np.isfinite(a[i]) or a[i] <= 0:
            continue
        entry = entry0 + spread
        risk = sl_atr * a[i]
        sl = entry - risk; tp = entry + tp_r * risk
        out = None
        for k in range(e, min(e + hold, N)):
            if l[k] <= sl:
                out = ("SL", -1.0); last = k; break
            if h[k] >= tp:
                out = ("TP", tp_r); last = k; break
        if out is None:
            k = min(e + hold - 1, N - 1)
            out = ("MAX", (c[k] - entry) / risk); last = k
        kinds.append(out[0]); rets.append(out[1])
    return np.array(rets), kinds


d = m5(SYM)
h = d["high"].to_numpy(float); l = d["low"].to_numpy(float)
c = d["close"].to_numpy(float)
a = atr_series(h, l, c)
sig = h < (np.roll(l, 2) - 1.0 * a)
sig[:5] = False
atr_med = float(np.nanmedian(a))
print(f"{SYM} : {len(d)} barres M5 | {int(sig.sum())} signaux fvg_dn_10 | "
      f"ATR M5 median {atr_med:.5f}")
print()

# spread typique CADJPY : 1 point ≈ 0.001 sur un JPY a 3 decimales.
# On teste plusieurs valeurs pour voir la sensibilite.
print("=" * 92)
print("EFFET DU MODE D'ENTREE ET DU SPREAD (SL=2 ATR, TP=3R, hold=48)")
print("=" * 92)
print(f"{'mode':<14}{'spread':>9}{'n':>7}{'SL%':>7}{'TP%':>7}{'MAX%':>7}"
      f"{'win%':>7}{'R total':>9}")
print("-" * 92)
for mode in ("open_next", "close_sig"):
    for sp in (0.0, 0.001, 0.002, 0.005):
        x, k = sim(d, sig, entry_mode=mode, spread=sp)
        if len(x) == 0:
            continue
        nsl = 100 * k.count("SL") / len(k)
        ntp = 100 * k.count("TP") / len(k)
        nmx = 100 * k.count("MAX") / len(k)
        print(f"{mode:<14}{sp:>9.3f}{len(x):>7}{nsl:>6.0f}%{ntp:>6.0f}%"
              f"{nmx:>6.0f}%{100*(x>0).mean():>6.1f}%{x.sum():>9.0f}")

print()
print("=" * 92)
print("REFERENCE MT5 (apres fix n56)")
print("=" * 92)
print("  144 sorties | SL 86% | TP 3% | MAXHOLD 10% | win 12.5% | pnl -634")
print()
print("  Si aucune ligne ci-dessus n'approche 86% de SL, alors la difference")
print("  ne vient NI du mode d'entree NI du spread : il faut regarder")
print("  l'execution intra-barre (l'EA peut entrer plusieurs fois, ou le SL")
print("  peut etre declenche par le spread bid/ask que le modele ignore).")
