﻿import pickle, re
# les declencheurs du cache POS (AUDJPY)
d = pickle.load(open(r"C:\EAFarm\HISTORY - Copy\research\pos_cache\AUDJPY.pkl","rb"))
trigs = sorted(set(v["trig"] for v in d.values()))
print(f"declencheurs utilises par AUDJPY : {len(trigs)}")
for t in trigs: print("   ", t)
# ceux geres par l'EA
src = open(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\MQL5\Experts\eepeek\ORION_ROBOT.mq5", encoding="utf-8").read()
handled = set(re.findall(r't\s*==\s*"([A-Z0-9]+)"', src))
print(f"\ndeclencheurs geres par Trigger() : {len(handled)}")
print("   ", sorted(handled))
# mapping python -> MQL5
gen = open("gen_duka_legs.py", encoding="utf-8").read()
block = gen.split("TRIGMAP = {")[1].split("}")[0]
mapped = set(re.findall(r'"([^"]+)":', block))
print(f"\nmapping python->MQL5 : {len(mapped)} entrees")
manque = [t for t in trigs if t not in mapped]
print(f"declencheurs SANS mapping : {manque if manque else 'aucun'}")
