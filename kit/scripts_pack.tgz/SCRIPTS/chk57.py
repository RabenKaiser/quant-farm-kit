﻿import sys, numpy as np, gc
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT
G._cache.clear(); gc.collect()
F = G.get_frames("EURAUD"); m5,m1=F["m5"],F["m1"]
h1z,hh,ll,a1,gb,gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd,zlo,zhi = MT.project(m5.index,h1z,hh,ll,gb,gr,max_age_h=48)
M = NL.build(m5,F,zd,zlo,zhi); M.update(FE.more(m5,F,m1))
s = NL.sig(M, "big_bear", ["vol_lo"])
o5=F["o5"]; c5=F["c5"]; h5=F["h5"]; l5=F["l5"]; a15i=F["a15i"]
n5=len(m5)
cand=np.nonzero(s)[0]
durs=[]; last_exit=-1; nacc=0
for i in cand:
    if i+1>=n5-1: break
    b0=i+1
    if b0<=last_exit: continue
    a5=a15i[i]
    if not np.isfinite(a5) or a5<=0: continue
    entry=o5[i+1]; sl0=entry-1.5*a5; risk=abs(entry-sl0)
    if risk<0.15*a5 or risk>12*a5: continue
    tp=entry+99.0*risk
    kend=min(i+1+192, n5-1)
    H=h5[b0:kend+1]; L=l5[b0:kend+1]
    hit_sl=np.nonzero(L<=sl0)[0]; hit_tp=np.nonzero(H>=tp)[0]
    ksl=int(hit_sl[0]) if len(hit_sl) else 10**9
    ktp=int(hit_tp[0]) if len(hit_tp) else 10**9
    if ksl<=ktp and ksl<10**9: j=b0+ksl; how="SL"
    elif ktp<10**9: j=b0+ktp; how="TP"
    else: j=kend; how="MAXHOLD"
    durs.append((j-b0, how)); last_exit=j; nacc+=1
import collections
d=[x[0] for x in durs]; hw=collections.Counter(x[1] for x in durs)
print(f"trades acceptes : {nacc}")
print(f"duree mediane   : {np.median(d):.0f} barres M5")
print(f"duree moyenne   : {np.mean(d):.0f} barres M5")
print(f"types de sortie : {dict(hw)}")
print(f"  => {100*hw['MAXHOLD']/nacc:.0f} % des trades vont jusqu'a maxhold (192)")
