"""crible_rearm : quels motifs ont un edge NET une fois le re-armement applique ?

Verdict du round 163 : avec re-armement, SR n=50 court atteint 50,6 % de gagnants
= le seuil d'equilibre a 1 R, donc edge net NUL apres couts. Deux paires sortent
neanmoins positives (USDCHF 54,6 %, EURGBP 54,7 %) : le terrain existe.

Ici on balaie TOUS les motifs disponibles (SR 50/100, CRT k=1/k=3, SEQ-FORT,
ALIGN) dans les deux sens, sur les 11 paires FX, avec :
  - re-armement (au moins 8 barres entre deux entrees, et condition retombee)
  - couts Upcomers reels
  - stop 1 ATR, objectif 1 R
et on classe par R/tx net. On cherche un taux de gagnants > 55 %.
"""
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import portefeuille_large as PL

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
OUT = B / "crible_rearm.md"
C = {"EURUSD": 0.10, "GBPUSD": 0.10, "AUDUSD": 0.10, "NZDUSD": 0.10,
     "USDCAD": 0.20, "USDCHF": 0.10, "EURGBP": 0.10, "EURJPY": 0.50,
     "GBPJPY": 0.70, "AUDJPY": 0.20, "CADJPY": 0.40}
MIN_ECART = 8


def main():
    PL.STOP, PL.RR = 1.0, 1.0
    agg = defaultdict(lambda: [0, 0.0, 0, 0])
    par_motif_paire = defaultdict(dict)
    for p, b, cout_duka in PL.charge_tout():
        if p not in C:
            continue
        pip = 0.01 if p.endswith("JPY") else 0.0001
        cout = C[p] * pip / float(b.atr.median())
        for (motif, sens), idx in PL.motifs(b).items():
            idx = idx[idx < len(b) - 34]
            if len(idx) < 200:
                continue
            keep, dern = [], None
            for k in idx:
                if dern is not None and k - dern < MIN_ECART:
                    continue
                keep.append(k)
                dern = k
            keep = np.array(keep, dtype=int)
            if len(keep) < 100:
                continue
            R, T = PL.r_par_trade(b, keep, sens, cout)
            if R is None:
                continue
            a = agg[(motif, sens)]
            a[0] += len(R)
            a[1] += float(np.sum(R))
            a[2] += int(np.sum(R > 0))
            a[3] += 1
            par_motif_paire[(motif, sens)][p] = float(np.mean(R))
        print("  %s" % p, flush=True)

    res = []
    for (m, s), (n, som, g, npa) in agg.items():
        if n < 2000:
            continue
        res.append(dict(motif=m, sens=s, n=n, rt=som / n, gagn=100.0 * g / n,
                        paires=npa,
                        pp=sum(1 for v in par_motif_paire[(m, s)].values() if v > 0)))
    res.sort(key=lambda d: -d["rt"])
    out = ["# Crible des motifs AVEC re-armement (couts Upcomers, 1 ATR / 1 R)", "",
           "Re-armement : au moins %d barres entre deux entrees. On cherche un taux "
           "de gagnants > 55 %% (le seuil d'equilibre a 1 R etant 50 %%)." % MIN_ECART,
           "",
           "| motif | sens | trades | R/tx net | gagnants | paires | paires + |",
           "|---|---|---|---|---|---|---|"]
    for d in res[:20]:
        out.append("| %s | %s | %d | %+.4f | %.1f%% | %d | %d |"
                   % (d["motif"], "L" if d["sens"] > 0 else "S", d["n"], d["rt"],
                      d["gagn"], d["paires"], d["pp"]))
        print("%-24s %-2s %8d %+9.4f %7.1f%% paires+ %d/%d"
              % (d["motif"], "L" if d["sens"] > 0 else "S", d["n"], d["rt"],
                 d["gagn"], d["pp"], d["paires"]), flush=True)
    OUT.write_text("\n".join(out), encoding="utf-8")
    print("ecrit %s" % OUT, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
