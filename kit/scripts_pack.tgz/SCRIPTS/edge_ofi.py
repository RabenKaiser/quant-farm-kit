﻿"""Edge research on M1 bars built from tick data.

Priorities (from prior dossiers):
  1. Order-flow imbalance (OFI) at M5/M15 â€” the only signal that previously had
     the right magnitude vs. cost on the US100 index.
  2. Session/time-of-day conditioning (07-19h established on 6E).
  3. Cost model from actual spreads in the data.

Protocol (from RAPPORT_COMPLET_6E):
  - entry at the OPEN of the bar AFTER the signal bar
  - intrabar resolution: SL vs TP in chronological order (we only have M1;
    for M5 signals we resolve at M1 granularity by scanning the M1 path)
  - cost = spread (measured per entry) + slippage, in R units
  - split into sub-periods; effect must have same sign in IS-1, IS-2, OOS
"""
import polars as pl
import numpy as np
from pathlib import Path

RESEARCH = Path(r"C:\EAFarm\HISTORY - Copy\research")
BARS = RESEARCH / "bars"

POINT = {"EURUSD": 0.00001, "USDJPY": 0.001, "EURCAD": 0.00001, "USATECHIDXUSD": 0.001}
PIP = {"EURUSD": 0.0001, "USDJPY": 0.01, "EURCAD": 0.0001, "USATECHIDXUSD": 1.0}

def load_m1(sym: str) -> pl.DataFrame:
    p = BARS / f"{sym}_M1.parquet"
    if not p.exists():
        return None
    return pl.read_parquet(p).sort("time")

def to_m5(m1: pl.DataFrame) -> pl.DataFrame:
    """Aggregate M1 -> M5 keeping order-flow info."""
    return (
        m1.with_columns(pl.col("time").alias("t5"))
        .with_columns((pl.col("time") // 300 * 300).alias("time"))
        .group_by("time")
        .agg(
            pl.col("bid_o").first().alias("bid_o"),
            pl.col("bid_h").max().alias("bid_h"),
            pl.col("bid_l").min().alias("bid_l"),
            pl.col("bid_c").last().alias("bid_c"),
            pl.col("ask_o").first().alias("ask_o"),
            pl.col("ask_h").max().alias("ask_h"),
            pl.col("ask_l").min().alias("ask_l"),
            pl.col("ask_c").last().alias("ask_c"),
            pl.col("bid_vol").sum().alias("bid_vol"),
            pl.col("ask_vol").sum().alias("ask_vol"),
            pl.col("n_ticks").sum().alias("n_ticks"),
            pl.col("spread_med").median().alias("spread_med"),
            pl.col("spread_max").max().alias("spread_max"),
        )
        .sort("time")
    )

def ofi_features(m5: pl.DataFrame, w: int = 6) -> pl.DataFrame:
    """Rolling order-flow imbalance + session/vol features. Causal (shifted)."""
    return (
        m5.with_columns(
            ((pl.col("ask_vol") - pl.col("bid_vol")) / (pl.col("ask_vol") + pl.col("bid_vol"))).alias("ofi_bar"),
        )
        .with_columns(
            pl.col("ofi_bar").rolling_mean(w).shift(1).alias("ofi_w"),
            pl.col("bid_vol").rolling_sum(w).shift(1).alias("bv_w"),
            pl.col("ask_vol").rolling_sum(w).shift(1).alias("av_w"),
            pl.col("bid_c").rolling_max(2).shift(1).alias("hh2"),
            pl.col("bid_l").rolling_min(2).shift(1).alias("ll2"),
        )
        .with_columns(
            pl.col("time").cast(pl.Int64).alias("ts"),
        )
    )

def split_segments(df: pl.DataFrame) -> dict:
    """Split M5 bars into IS-1, IS-2, OOS by date (2022 halves)."""
    # for 2-year data: IS-1 = 2022H1, IS-2 = 2022H2, OOS = 2023
    df = df.with_columns(pl.col("time").alias("ts")).with_columns(
        pl.when(pl.col("ts") < 1654041600).then(pl.lit("IS-1"))            # < 2022-06-01
        .when(pl.col("ts") < 1672531200).then(pl.lit("IS-2"))              # < 2023-01-01
        .otherwise(pl.lit("OOS")).alias("seg")
    )
    return {s: df.filter(pl.col("seg") == s) for s in ["IS-1", "IS-2", "OOS"]}

def backtest_m5(m5: pl.DataFrame, sym: str, cfg: dict) -> dict:
    """Vectorized M5 backtest.

    Signal: buy if ofi_w > thr, sell if ofi_w < -thr.
    Entry: next M5 bar open (bid for sell / ask for buy at open of bar t+1).
    SL: atr_mult * ATR(M5, 14) points; TP: rr * SL.
    Cost: spread at entry bar (in points) + slippage_pts, in R units.
    Resolution: intrabar M1 scan (approximation: use M5 high/low vs entry levels;
      then refine with M1 in validate step).
    """
    pt = POINT[sym]
    # ATR
    tr = m5.with_columns(
        pl.max_horizontal(
            pl.col("bid_h") - pl.col("bid_l"),
            (pl.col("bid_h") - pl.col("bid_c").shift(1)).abs(),
            (pl.col("bid_l") - pl.col("bid_c").shift(1)).abs(),
        ).alias("tr")
    ).with_columns(pl.col("tr").rolling_mean(14).shift(1).alias("atr"))

    df = ofi_features(tr, w=cfg.get("w", 6))

    thr = cfg.get("thr", 0.15)
    sl_pts = cfg.get("sl_pts", None)          # fixed SL in points
    sl_atr = cfg.get("sl_atr", None)          # SL = sl_atr * atr / pt
    rr = cfg.get("rr", 2.0)
    sess = cfg.get("session", None)           # (start_h, end_h) UTC inclusive
    spread_max_pts = cfg.get("spread_max_pts", None)

    # session filter
    if sess:
        hr = (df["ts"] % 86400) // 3600
        df = df.filter((hr >= sess[0]) & (hr <= sess[1]))

    if spread_max_pts is not None:
        df = df.filter(pl.col("spread_med") / pt <= spread_max_pts)

    sig = (df["ofi_w"] > thr).cast(pl.Int8) - (df["ofi_w"] < -thr).cast(pl.Int8)
    df = df.with_columns(pl.Series("sig", sig))

    # entry at open of next bar
    bid_o_next = df["bid_o"].shift(-1).to_numpy()
    ask_o_next = df["ask_o"].shift(-1).to_numpy()
    bid_c = df["bid_c"].to_numpy()
    bid_h = df["bid_h"].to_numpy()
    bid_l = df["bid_l"].to_numpy()
    atr = df["atr"].to_numpy()
    sigs = df["sig"].to_numpy()
    ts_arr = df["ts"].to_numpy()
    spread_arr = (df["spread_med"] / pt).to_numpy()

    n = len(df)
    results = []
    for i in range(n - 1):
        s = int(sigs[i])
        if s == 0:
            continue
        if np.isnan(atr[i]) or atr[i] <= 0:
            continue
        if sl_atr:
            sl_dist_pts = sl_atr * atr[i] / pt
        else:
            sl_dist_pts = sl_pts
        if sl_dist_pts <= 0:
            continue
        tp_dist_pts = rr * sl_dist_pts
        entry = ask_o_next[i] if s == 1 else bid_o_next[i]
        if np.isnan(entry):
            continue
        # intrabar: does the next bar hit SL or TP first? Use M5 OHLC as approx;
        # direction buy: SL below entry, TP above
        hb, lb = bid_h[i + 1], bid_l[i + 1]
        if s == 1:
            sl_px = entry - sl_dist_pts * pt
            tp_px = entry + tp_dist_pts * pt
            if lb <= sl_px and hb >= tp_px:
                r = -1.0
            elif lb <= sl_px:
                r = -1.0
            elif hb >= tp_px:
                r = rr
            else:
                r = (bid_c[i + 1] - entry) / (sl_dist_pts * pt)
        else:
            sl_px = entry + sl_dist_pts * pt
            tp_px = entry - tp_dist_pts * pt
            if hb >= sl_px and lb <= tp_px:
                r = -1.0
            elif hb >= sl_px:
                r = -1.0
            elif lb <= tp_px:
                r = rr
            else:
                r = (entry - bid_c[i + 1]) / (sl_dist_pts * pt)
        # cost in R
        spread_pts = spread_arr[i]
        cost_pts = spread_pts + cfg.get("slippage_pts", 0.5)
        cost_r = cost_pts / sl_dist_pts
        results.append({"ts": ts_arr[i + 1], "r": r, "cost_r": cost_r, "spread_pts": spread_pts,
                        "sl_pts": sl_dist_pts})

    if not results:
        return {"n": 0}
    res = pl.DataFrame(results)
    res = res.with_columns((pl.col("r") - pl.col("cost_r")).alias("net_r"))
    n_t = len(res)
    gross = res["r"].sum() / n_t
    net = res["net_r"].sum() / n_t
    wr = (res["r"] > 0).mean()
    t_stat = res["net_r"].mean() / (res["net_r"].std() / np.sqrt(n_t)) if n_t > 1 and res["net_r"].std() > 0 else 0
    return {
        "n": n_t, "gross_ev": round(gross, 4), "net_ev": round(net, 4),
        "win_rate": round(wr * 100, 1), "t": round(t_stat, 2),
        "med_sl_pts": round(float(res["sl_pts"].median()), 1),
        "med_spread_pts": round(float(res["spread_pts"].median()), 2),
        "cost_ev": round(float((res["cost_r"].sum() / n_t)), 4),
    }

if __name__ == "__main__":
    import sys, json
    sym = sys.argv[1] if len(sys.argv) > 1 else "EURUSD"
    m1 = load_m1(sym)
    if m1 is None:
        print(f"no M1 bars for {sym}")
        sys.exit(1)
    m5 = to_m5(m1)
    print(f"{sym}: M1={len(m1)} M5={len(m5)}  range {m5['time'].min()}..{m5['time'].max()}")
    segs = split_segments(m5)
    for name, seg in segs.items():
        print(f"  {name}: {len(seg)} M5 bars")

    # grid over a few key configs
    grid = []
    for thr in [0.10, 0.15, 0.20]:
        for w in [4, 6, 12]:
            for sl_atr in [2.0, 3.0]:
                for rr in [1.5, 2.0, 3.0]:
                    cfg = {"w": w, "thr": thr, "sl_atr": sl_atr, "rr": rr,
                           "slippage_pts": 0.5, "session": (7, 19)}
                    row = {"cfg": cfg}
                    for name, seg in segs.items():
                        r = backtest_m5(seg, sym, cfg)
                        row[name] = r
                    if all(row[s]["n"] >= 30 for s in segs):
                        evs = [row[s]["net_ev"] for s in ["IS-1", "IS-2", "OOS"]]
                        same_sign = all(e > 0 for e in evs) or all(e < 0 for e in evs)
                        if same_sign:
                            row["_sign"] = "ALL+" if evs[0] > 0 else "ALL-"
                            row["_mean"] = round(sum(evs) / 3, 4)
                            grid.append(row)
    grid.sort(key=lambda r: r.get("_mean", -9), reverse=True)
    print(f"\n=== Configs with same sign across IS-1/IS-2/OOS (n>=30 each) ===")
    for r in grid[:15]:
        c = r["cfg"]
        print(f"  w={c['w']} thr={c['thr']} sl_atr={c['sl_atr']} rr={c['rr']} sess={c.get('session')} "
              f"sign={r.get('_sign')} mean={r.get('_mean')}")
        for s in ["IS-1", "IS-2", "OOS"]:
            x = r[s]
            print(f"    {s}: n={x['n']} net={x['net_ev']} gross={x['gross_ev']} wr={x['win_rate']}% t={x['t']} sl={x['med_sl_pts']}pt sprd={x['med_spread_pts']}pt")
    out = RESEARCH / f"grid_{sym}.json"
    out.write_text(json.dumps(grid, indent=1, default=str))
    print(f"\nsaved -> {out}")
