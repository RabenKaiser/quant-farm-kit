# -*- coding: utf-8 -*-
"""diag_fvg.py — POURQUOI FVGDN20 ne tire que 0.07x alors que FVGDN10 tire 0.25x ?

CONTEXTE
--------
Le backtest MT5 (14 marches, SL=2/TP=3/hold=48) donne 3 819 entrees contre
15 763 en python. Le ratio global est 0.24 — acceptable et explique par les
portes de l'EA (spread, sessions, maxpos, no-hedge).

MAIS le ratio n'est PAS homogene selon le declencheur :
    BRKLL100  0.63
    BRKLL50   0.41
    FVGDN10   0.25
    VWAPXDN   0.17
    FVGDN20   0.07   <-- 3.5x plus faible que FVGDN10

FVGDN20 et FVGDN10 sont le MEME code MQL5, seuls les multiplicateurs ATR
different (2.0 vs 1.0). Un ecart de 3.5x sur le meme code trahit soit
  (a) une difference reelle de frequence (un gap de 2 ATR est bien plus rare
      qu'un gap de 1 ATR), soit
  (b) un probleme d'acces aux donnees.

CE SCRIPT TRANCHE : il calcule, sur les donnees M5 REELLES du cache, la
frequence du masque fvg_dn pour mult=1.0 et mult=2.0, puis la compare au
ratio observe.

CE QU'IL FAUT REGARDER
----------------------
Si freq(2.0)/freq(1.0) ~ 0.07/0.25 = 0.28, alors la difference est REELLE et
le declencheur est correct : un gap de 2 ATR est simplement 3.5x plus rare.
Si le rapport theorique est proche de 0.25/0.25 = 1.0, alors il y a un BUG.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
UP = BASE / "up_new"
POS = BASE / "pos_cache"

PORT = json.load(open(BASE / "portfolio_v2.json", encoding="utf-8"))


def atr14(h, l, c):
    pc = np.roll(c, 1); pc[0] = c[0]
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    return pd.Series(tr).ewm(alpha=1/14, adjust=False).mean().to_numpy()


def load_m5(sym, src="duka"):
    """M5 comme le fait robust_structures.py.

    ATTENTION (erreur commise ici) : `pos_cache/*.pkl` ne contient PAS des
    bougies — c'est un dict de RESULTATS de backtest deja calcules
    (cles 'sym|trig|filt|side|params', valeurs avec 'R','n','s1','s2','s3').
    Il n'y a ni 'high' ni 'low' dedans -> KeyError: 'high'.
    Les vraies bougies sont :
      - Dukascopy : m1_pos/<SYM>_M1.csv  (M1, a reechantillonner en M5)
      - Upcomers  : up_new/<SYM>_M5.csv  (M5 direct)
    """
    if src == "duka":
        p = BASE / "m1_pos" / f"{sym}_M1.csv"
        if not p.exists():
            return None
        df = pd.read_csv(p, usecols=["time", "open", "high", "low", "close",
                                     "tick_volume"])
        df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
        df = df.set_index("time").sort_index()
        return pd.DataFrame({
            "high": df["high"].resample("5min").max(),
            "low": df["low"].resample("5min").min(),
            "close": df["close"].resample("5min").last()}).dropna()
    p = BASE / "up_new" / f"{sym}_M5.csv"
    if not p.exists():
        return None
    df = pd.read_csv(p)
    df["time"] = pd.to_datetime(df["time"], utc=True)
    df = df.set_index("time").sort_index()
    return pd.DataFrame({"high": df["high"], "low": df["low"],
                         "close": df["close"]}).dropna()


def count_fvg(df, mult):
    h = df["high"].to_numpy(float)
    l = df["low"].to_numpy(float)
    c = df["close"].to_numpy(float)
    a = atr14(h, l, c)
    m = h < (np.roll(l, 2) - mult * a)
    m[:5] = False
    return int(m.sum())


print("=" * 88)
print("DIAGNOSTIC FVGDN10 vs FVGDN20 — la frequence explique-t-elle le ratio ?")
print("=" * 88)

res = json.load(open(BASE / "mt5_pos_results.json", encoding="utf-8"))
legs = json.load(open(BASE / "legs_v2.json", encoding="utf-8"))
byk = {(r["sym"], r["struct"], r["filt"]): r for r in legs}

for srctag in ("duka", "up"):
    print(f"\n--- source : {srctag} ---")
    print(f"{'marche':<9}{'barres':>8}{'fvg1':>8}{'fvg2':>7}"
          f"{'f2/f1':>7}{'ratio_MT5_D':>13}{'ratio_MT5_U':>13}")
    print("-" * 88)
    allf, allr = [], []
    for sym in sorted(PORT):
        df = load_m5(sym, srctag)
        if df is None or len(df) < 1000:
            continue
        n1 = count_fvg(df, 1.0)
        n2 = count_fvg(df, 2.0)
        f = (n2 / n1) if n1 else 0
        # ratios MT5 observes, par jambe FVG
        rd, ru = [], []
        for L in PORT[sym]:
            if not L["t"].startswith("FVGDN"):
                continue
            r0 = byk.get((sym, L["struct"], L["filt_py"]))
            if not r0:
                continue
            m = sum(v for k, v in res[sym].get("counts", {}).items()
                    if k.split("|")[0] == L["t"])
            is20 = L["t"] == "FVGDN20"
            if r0.get("n_d"):
                rd.append((m / r0["n_d"], is20))
            if r0.get("n_u"):
                ru.append((m / r0["n_u"], is20))
        # ratio moyen par niveau
        d20 = [x for x, b in rd if b]; d10 = [x for x, b in rd if not b]
        u20 = [x for x, b in ru if b]; u10 = [x for x, b in ru if not b]
        s20 = float(np.mean(d20)) if d20 else float("nan")
        s10 = float(np.mean(d10)) if d10 else float("nan")
        n20 = float(np.mean(u20)) if u20 else float("nan")
        n10 = float(np.mean(u10)) if u10 else float("nan")
        print(f"{sym:<9}{len(df):>8}{n1:>8}{n2:>7}{f:>7.2f}"
              f"{s20:>13.2f}{n20:>13.2f}")
        print(f"{'':<9}{'':>8}{'':>8}{'':>7}{'':>7}"
              f"{'  (fvg10 ' + format(s10, '.2f') + ')':>13}"
              f"{'  (fvg10 ' + format(n10, '.2f') + ')':>13}")
        if n1:
            allf.append(f)
        if d20 and d10:
            allr.append(s20 / s10 if s10 else float("nan"))

    mf = float(np.nanmean(allf)) if allf else float("nan")
    mr = float(np.nanmean(allr)) if allr else float("nan")
    print("-" * 88)
    print(f"  MOYENNE  freq(fvg2)/freq(fvg1) = {mf:.2f}   "
          f"ratio_MT5(fvg20)/ratio_MT5(fvg10) = {mr:.2f}")

print()
print("=" * 88)
print("VERDICT")
print("=" * 88)
print("  Si freq(fvg2)/freq(fvg1) ~ ratio_MT5(fvg20)/ratio_MT5(fvg10),")
print("  alors l'ecart vient de la RARETE REELLE du gap a 2 ATR : aucun bug.")
print("  Si les deux rapports divergent franchement, chercher un bug de mapping.")
