"""attendre_AB : lire automatiquement les deux campagnes six ans des qu'elles apparaissent.

Round 338. La chaine `chaine_crest_farm.py` lance campagne A (50 barres : NZDUSD, EURCHF, AUDUSD,
CADJPY) puis campagne B (100 barres : EURGBP, GBPCHF, NZDJPY, AUDCAD), et chacune ecrit
`par_farm_<tag>.jsonl`. Plutot que d'attendre le prochain round pour lire, ce script surveille
l'apparition des deux fichiers, lance le lecteur (`lit_campagnes_6ans.py`, dont les references ont ete
verifiees au round 330 et le nommage au round 331) et ecrit le resultat dans `VALIDATION_6ANS.md`.

Il n'ecrit QUE ce fichier, ne touche a aucun processus et ne lance aucun test : il ne peut pas
deranger les campagnes en cours. S'il n'a rien a lire au bout du delai, il le dit au lieu d'inventer.
"""
import subprocess
import sys
import time
from pathlib import Path

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
SC = B / "SCRIPTS"
ATTENDUS = ["par_farm_crestiA_farm.jsonl", "par_farm_crestiB_farm.jsonl"]
SORTIE = B / "VALIDATION_6ANS.md"
JOURNAL = B / "attente_AB.log"


def journalise(msg):
    ligne = "[%s] %s" % (time.strftime("%H:%M:%S"), msg)
    print(ligne, flush=True)
    with JOURNAL.open("a", encoding="utf-8") as f:
        f.write(ligne + "\n")


def main():
    plafond_h = float(sys.argv[1]) if len(sys.argv) > 1 else 4.0
    t0 = time.time()
    journalise("surveillance des deux campagnes six ans (plafond %.1f h)" % plafond_h)
    vu = {}
    while time.time() - t0 < plafond_h * 3600:
        etat = []
        for nom in ATTENDUS:
            f = B / nom
            if f.exists() and f.stat().st_size > 200:
                if nom not in vu:
                    vu[nom] = True
                    journalise("%s apparu (%d octets)" % (nom, f.stat().st_size))
            etat.append(nom in vu)
        if all(etat):
            break
        time.sleep(120)
    if not all(vu.get(n, False) for n in ATTENDUS):
        journalise("delai epuise : campagnes absentes (%s)" % ", ".join(
            "%s=%s" % (n, "vu" if vu.get(n) else "absent") for n in ATTENDUS))
        return 1
    journalise("les deux campagnes sont la : lecture")
    r = subprocess.run([sys.executable, str(SC / "lit_campagnes_6ans.py")],
                       cwd=str(SC), capture_output=True, text=True, errors="replace",
                       timeout=600)
    texte = (r.stdout or "") + (("\n" + r.stderr) if r.stderr else "")
    SORTIE.write_text("# VALIDATION SIX ANS EN ORDRES REELS\n\n```\n" + texte + "\n```\n",
                      encoding="utf-8")
    for ln in texte.strip().splitlines():
        journalise("  %s" % ln)
    journalise("ecrit %s" % SORTIE.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
