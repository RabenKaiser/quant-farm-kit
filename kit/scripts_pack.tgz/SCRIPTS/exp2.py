﻿import os,re
LOGD=r'C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs'
files=[(f,os.path.getmtime(os.path.join(LOGD,f)),os.path.getsize(os.path.join(LOGD,f))) for f in os.listdir(LOGD) if '.log' in f]
files.sort(key=lambda x:-x[1])
for f,m,s in files[:3]:
    p=os.path.join(LOGD,f)
    raw=open(p,'rb').read(4)
    enc='utf-16' if raw[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8'
    try: txt=open(p,encoding=enc,errors='replace').read()
    except Exception: continue
    print('FICHIER', f)
    for ln in txt.splitlines():
        if any(k in ln for k in ('GBPUSD','history','synchron','EXPORT','not exist','quality')):
            print('  ', ln.split('Core')[-1].strip()[:125])
    break
