﻿import os, re
LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
rows=[]
for f in os.listdir(LOGD):
    if ".log" not in f: continue
    p=os.path.join(LOGD,f)
    if os.path.getsize(p)<500: continue
    raw=open(p,"rb").read(4)
    enc="utf-16" if raw[:2] in (b"\xff\xfe",b"\xfe\xff") else "utf-8"
    try: txt=open(p,encoding=enc,errors="replace").read()
    except Exception: continue
    eu = len(re.findall(r"ORION OPEN EURAUD", txt))
    cj = len(re.findall(r"ORION OPEN CADJPY", txt))
    az = len(re.findall(r"ORION OPEN AUDNZD", txt))
    tot = txt.count("ORION OPEN")
    if eu or cj or az:
        rows.append((os.path.getmtime(p), f, tot, eu, cj, az))
rows.sort(reverse=True)
print(f"{'fichier':<46}{'total':>7}{'EURAUD':>8}{'CADJPY':>8}{'AUDNZD':>8}")
for m,f,t,eu,cj,az in rows[:6]:
    print(f"{f[:44]:<46}{t:>7}{eu:>8}{cj:>8}{az:>8}")
