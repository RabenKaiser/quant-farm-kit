import os
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM
import portefeuille_tp2 as P2
import edge_sweep as E

os.environ["SOURCE"] = "m1_pos"
for leg in ("EURCHF:SR50:C", "EURGBP:SR100:C", "GBPCHF:SR50:C"):
    paire, motif, sens = leg.split(":")
    D = NM.charge(paire, "m1_pos")
    m = NM.motifs(D)
    brut = np.asarray(m[motif][0 if sens == "C" else 1])
    sel = P2.masque_selectif(D, brut)
    sig, R, barre = E.base_leg(D, motif, -1 if sens == "C" else 1, 2.0, 32)
    g = E.bloque(D["idx"], sig, R, barre, 32)
    print("%-16s brut %5d | selectif %5d | base_leg %5d | apres blocage %5d | R/tx %+.4f"
          % (leg, len(brut), len(sel), len(sig), len(g), np.mean(R[g]) if len(g) else 0), flush=True)
    if len(sig):
        c, a = D["c"], D["a"]
        garde = np.abs(c[sig] - np.roll(c, 8)[sig]) <= 2.0 * a[sig]
        print("     MOM 2ATR/8 -> %d signaux" % garde.sum(), flush=True)
