﻿"""ALPHA LOOP â€” runner paramÃ©trÃ© (instrument, timeframe, familles, filtres).

Usage: python alpha_loop_gen.py --sym EURUSD --tf 900 --gen G3 \
       --families range_fade,ofi_cont,range_break,mom_rev,sweep_rej \
       [--spread_max 3.0] [--session 7,19] [--atr_lo 0.5] [--atr_hi 2.5]

Protocole P0->P3 + retenue 4 conditions + stockage alpha/gen_{id}/*.json.
MÃ©diane de famille calculÃ©e sur la GRILLE COMPLÃˆTE en IS-1 (pas sur les survivants).
"""
import sys, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import json, time, argparse
from pathlib import Path
from collections import defaultdict

import polars as pl
import numpy as np

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
from edge_correct import (load_m1, to_tf, seg_of, backtest_m1, summarize,
                          POINT, COMMISSION_RT, TICK_VALUE_PER_PT)
from edge_correct import make_signals as ms_base

RESEARCH = Path(r"C:\EAFarm\HISTORY - Copy\research")
ALPHA = RESEARCH / "alpha"

def add_costs(sym, cfg):
    cfg = dict(cfg)
    cfg["commission_rt"] = COMMISSION_RT.get(sym, 0.0)
    cfg["tick_value_per_pt"] = TICK_VALUE_PER_PT.get(sym, 1.0)
    return cfg

def make_sig(tf, kind, cfg):
    # combo: range_fade confirmed by flow (sfi) â€” buy extreme low only when
    # sellers exhausted (sfi_w < -thr) ; sell extreme high only when sfi_w > thr
    if kind == "rf_flow":
        f = ms_base(tf, "range_fade", cfg)
        base = ms_base(tf, "range_fade", dict(cfg))
        fl = ms_base(tf, "ofi_cont", dict(cfg))
        # reuse sfi_w from ofi_cont signals: ofi_cont sig = +1 when sfi_w > thr
        # rf_flow buy: range_fade buy (sig=+1) AND sfi_w < -thr (sellers exhausted)
        rfsig = base["sig"].to_numpy()
        ofisig = fl["sig"].to_numpy()
        new = np.where((rfsig == 1) & (ofisig == -1), 1,
               np.where((rfsig == -1) & (ofisig == 1), -1, 0)).astype(np.int8)
        return base.with_columns(pl.Series("sig", new))
    return ms_base(tf, kind, cfg)

def apply_filters(tf, sym, cfg):
    pt = POINT[sym]
    f = tf
    if cfg.get("spread_max_pts"):
        f = f.filter((f["spread_med"] / pt) <= cfg["spread_max_pts"])
    if cfg.get("session"):
        if "hr" not in f.columns:
            f = f.with_columns(((pl.col("time") % 86400) // 3600).cast(pl.Int64).alias("hr"))
        f = f.filter((f["hr"] >= cfg["session"][0]) & (f["hr"] <= cfg["session"][1]))
    if cfg.get("atr_lo") or cfg.get("atr_hi"):
        # ATR percentile band (volatility regime) - causal, computed on the fly
        rng = (f["bid_h"] - f["bid_l"]).to_numpy()
        atr = np.full(len(rng), np.nan)
        for i in range(14, len(rng)):
            atr[i] = np.mean(rng[i - 14:i])
        f = f.with_columns(pl.Series("_atr", atr))
        if cfg.get("atr_lo"):
            f = f.filter(pl.col("_atr") / pt >= cfg["atr_lo"])
        if cfg.get("atr_hi"):
            f = f.filter(pl.col("_atr") / pt <= cfg["atr_hi"])
    return f

def run_cfg(sym, frames, kind, cfg):
    cfg = add_costs(sym, cfg)
    out = {}
    for sname, (m1seg, tfseg) in frames.items():
        f = make_sig(apply_filters(tfseg, sym, cfg), kind, cfg)
        tr = backtest_m1(m1seg, tfseg, f, sym, cfg)
        out[sname] = summarize(tr)
    return out

def load_frames(sym, tf_sec, seg_bounds):
    m1 = load_m1(sym)
    tf = to_tf(m1, tf_sec)
    df = seg_of(tf)
    m1s = seg_of(m1)
    frames = {}
    for sname, (t0, t1) in seg_bounds.items():
        frames[sname] = (m1s.filter((pl.col("ts") >= t0) & (pl.col("ts") < t1)),
                         df.filter((pl.col("ts") >= t0) & (pl.col("ts") < t1)))
    return frames

import datetime as _dt
def E(d):
    return int(_dt.datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=_dt.timezone.utc).timestamp())

def grid_for(sym, tf_sec, family, base_cfg, stage):
    """Grid over sl/rr (and w/thr for OFI), inheriting filters from base_cfg."""
    c = []
    lb = [20, 40]
    sl = [1.5, 2.5, 4.0]
    rr = [1.5, 2.5, 4.0]
    if stage == "P0":
        sl, rr = [1.5, 2.5], [1.5, 2.5]
    for l in lb:
        for s in sl:
            for r in rr:
                cfg = dict(base_cfg)
                cfg.update({"lookback": l, "sl_atr": s, "rr": r})
                if family in ("ofi_cont", "ofi_rev", "rf_flow"):
                    cfg.update({"w": 6, "thr": 0.15})
                c.append(cfg)
    return c

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sym", default="EURUSD")
    ap.add_argument("--tf", type=int, default=900)
    ap.add_argument("--gen", required=True)
    ap.add_argument("--families", default="range_fade,ofi_cont,range_break,mom_rev,sweep_rej,ofi_rev,mom")
    ap.add_argument("--spread_max", type=float, default=None)
    ap.add_argument("--session", default=None)
    ap.add_argument("--atr_lo", type=float, default=None)
    ap.add_argument("--atr_hi", type=float, default=None)
    args = ap.parse_args()
    SYM, TF = args.sym, args.tf
    families = [f.strip() for f in args.families.split(",") if f.strip()]
    base_cfg = {"slippage_pts": 0.5}
    if args.spread_max:
        base_cfg["spread_max_pts"] = args.spread_max
    if args.session:
        a, b = args.session.split(",")
        base_cfg["session"] = (int(a), int(b))
    if args.atr_lo:
        base_cfg["atr_lo"] = args.atr_lo
    if args.atr_hi:
        base_cfg["atr_hi"] = args.atr_hi

    outdir = ALPHA / f"gen_{args.gen}"
    outdir.mkdir(parents=True, exist_ok=True)

    span = 24 * 30 * 86400  # assume >= 12 months
    # adaptive bounds by data length
    m1 = load_m1(SYM)
    tmin = int(m1["time"].min()); tmax = int(m1["time"].max())
    dur = tmax - tmin
    if dur < 400 * 86400:
        # short instrument (EURCAD ~2.5mo, US100 ~3mo): toy/P1/IS halves/OOS none
        mid = tmin + dur // 2
        B = {
            "P0": {"toy": (tmin, tmin + 30 * 86400)},
            "P1": {"p1": (tmin, mid)},
            "IS": {"IS-1": (tmin, mid), "IS-2": (mid, tmax)},
            "OOS": {"OOS": (tmin + int(0.7 * dur), tmax)},  # last 30%
            "REPRO": {"M5": (tmin, tmax), "M30": (tmin, tmax)},
        }
    else:
        B = {
            "P0": {"toy": (E("2022-01-01"), E("2022-02-01"))},
            "P1": {"p1": (E("2022-01-01"), E("2022-04-01"))},
            "IS": {"IS-1": (E("2022-01-01"), E("2022-07-01")),
                   "IS-2": (E("2022-07-01"), E("2023-01-01"))},
            "OOS": {"OOS": (E("2023-01-01"), E("2024-01-01"))},
            "REPRO": {"M5": (E("2022-01-01"), E("2023-01-01")),
                      "M30": (E("2022-01-01"), E("2023-01-01"))},
        }
    # repro tf must differ from entry tf
    repro_tfs = [tf for tf in (300, 900, 1800, 3600) if tf != TF]
    if len(repro_tfs) < 2:
        repro_tfs = [300, 3600]

    t0 = time.time()
    log = {"generation": args.gen, "sym": SYM, "tf": TF, "families": families,
           "filters": {k: v for k, v in base_cfg.items() if k != "slippage_pts"}, "stages": {}}

    # ---------------- P0 ----------------
    f0 = load_frames(SYM, TF, B["P0"])
    n0 = 0
    for fam in families:
        for cfg in grid_for(SYM, TF, fam, base_cfg, "P0"):
            n0 += 1
            run_cfg(SYM, f0, fam, cfg)
    log["stages"]["P0"] = {"tested": n0}
    print(f"[{args.gen}] P0: {n0} configs en {time.time()-t0:.0f}s", flush=True)

    # ---------------- P1 (gross>0) ----------------
    f1 = load_frames(SYM, TF, B["P1"])
    p1 = {}
    n1 = 0
    for fam in families:
        for cfg in grid_for(SYM, TF, fam, base_cfg, "P1"):
            n1 += 1
            r = run_cfg(SYM, f1, fam, cfg)
            if r["p1"]["n"] >= 15 and r["p1"]["gross"] > 0:
                p1[f"{fam}|{json.dumps(cfg, sort_keys=True)}"] = (fam, cfg, r)
    log["stages"]["P1"] = {"tested": n1, "gross_pos": len(p1)}
    print(f"[{args.gen}] P1: {n1} testÃ©s, {len(p1)} brut>0", flush=True)

    # ---------------- P2 (IS retention) ----------------
    fIS = load_frames(SYM, TF, B["IS"])
    fam_all = defaultdict(list)   # family median over FULL grid
    for fam in families:
        for cfg in grid_for(SYM, TF, fam, base_cfg, "P1"):
            r = run_cfg(SYM, fIS, fam, cfg)
            if r["IS-1"]["n"] >= 15:
                fam_all[fam].append(r["IS-1"]["net"])
    fam_med = {f: float(np.median(v)) for f, v in fam_all.items()}

    p2 = {}
    for key, (fam, cfg, r) in p1.items():
        res = run_cfg(SYM, fIS, fam, cfg)
        e1, e2 = res["IS-1"], res["IS-2"]
        if e1["n"] >= 15 and e2["n"] >= 15 and e1["net"] > 0 and e2["net"] > 0:
            p2[key] = (fam, cfg, res)
    # c: minus top-5 winners IS-1 ; d: family median > 0
    p2k = {}
    for key, (fam, cfg, res) in p2.items():
        if fam_med.get(fam, -1) <= 0:
            continue
        f = make_sig(apply_filters(fIS["IS-1"][1], SYM, add_costs(SYM, cfg)), fam, add_costs(SYM, cfg))
        tr = backtest_m1(fIS["IS-1"][0], fIS["IS-1"][1], f, SYM, add_costs(SYM, cfg))
        if not tr:
            continue
        r5 = np.sort([t["r"] for t in tr])[:-5]
        if r5.mean() - np.mean([t["cost_r"] for t in tr]) <= 0:
            continue
        p2k[key] = (fam, cfg, res)
    log["stages"]["P2"] = {"cands_ab": len(p2), "kept_dc": len(p2k),
                           "family_median_IS1": {k: round(v, 4) for k, v in fam_med.items()}}
    print(f"[{args.gen}] P2: {len(p2)} candidats, {len(p2k)} aprÃ¨s c+d; mÃ©dianes=" +
          json.dumps({k: round(v, 4) for k, v in fam_med.items()}), flush=True)

    # ---------------- P3 (OOS once) ----------------
    fOOS = load_frames(SYM, TF, B["OOS"])
    finals = []
    for key, (fam, cfg, res) in p2k.items():
        ro = run_cfg(SYM, fOOS, fam, cfg)
        finals.append({"id": key, "family": fam, "cfg": cfg,
                       "IS1": res["IS-1"], "IS2": res["IS-2"], "OOS": ro["OOS"]})
    log["stages"]["P3"] = {"oos_looks": len(finals),
                           "oos_positive": sum(1 for x in finals if x["OOS"]["net"] > 0)}
    print(f"[{args.gen}] P3: {len(finals)} regards OOS, {sum(1 for x in finals if x['OOS']['net']>0)} positifs", flush=True)

    # ---------------- reproduction en timeframe ----------------
    keeps = []
    for x in finals:
        fam, cfg = x["family"], x["cfg"]
        tf_ok = False
        m5 = m30 = None
        for rtf in repro_tfs:
            fR = load_frames(SYM, rtf, B["REPRO"])
            r = run_cfg(SYM, fR, fam, cfg)
            key = list(B["REPRO"].keys())[0]
            if r[key]["net"] > 0:
                tf_ok = True
            if rtf == 300:
                m5 = r[key]["net"]
            if rtf == 1800:
                m30 = r[key]["net"]
        keeps.append({"id": x["id"], "family": fam, "cfg": cfg,
                      "IS1_net": x["IS1"]["net"], "IS2_net": x["IS2"]["net"],
                      "OOS_net": x["OOS"]["net"], "M5_net": m5, "M30_net": m30,
                      "a": x["IS1"]["net"] > 0 and x["IS2"]["net"] > 0 and x["OOS"]["net"] > 0,
                      "b": tf_ok, "d": fam_med.get(fam, -1) > 0,
                      "GARDE": x["IS1"]["net"] > 0 and x["IS2"]["net"] > 0 and x["OOS"]["net"] > 0 and tf_ok})

    deg = []
    for x in finals:
        deg.append(((x["IS1"]["net"] + x["IS2"]["net"]) / 2, x["OOS"]["net"]))
    if deg:
        im = float(np.mean([d[0] for d in deg])); om = float(np.mean([d[1] for d in deg]))
        log["degradation"] = {"mean_IS": round(im, 4), "mean_OOS": round(om, 4),
                              "factor": round(om / im, 2) if im > 0 else None}

    (outdir / "strategies_all.json").write_text(json.dumps(finals, indent=1, default=str))
    (outdir / "strategies_keep.json").write_text(json.dumps(keeps, indent=1, default=str))
    (outdir / "strategies_best.json").write_text(json.dumps(
        sorted(keeps, key=lambda k: k["OOS_net"], reverse=True)[:10], indent=1, default=str))
    log["elapsed_s"] = round(time.time() - t0, 1)
    (outdir / "generation_log.json").write_text(json.dumps(log, indent=1, default=str))
    (outdir / "summary.md").write_text(
        f"# Gen {args.gen} ({SYM} M{TF//60})\n\n"
        f"- P0 {log['stages']['P0']['tested']} | P1 {log['stages']['P1']['tested']}->{log['stages']['P1']['gross_pos']} | "
        f"P2 {log['stages']['P2']['cands_ab']}->{log['stages']['P2']['kept_dc']} | "
        f"P3 {log['stages']['P3']['oos_looks']}->{log['stages']['P3']['oos_positive']}\n"
        f"- MÃ©dianes famille: {json.dumps({k: round(v,4) for k,v in fam_med.items()})}\n"
        f"- DÃ©gradation: {log.get('degradation')}\n"
        f"- GARDE: {sum(1 for k in keeps if k['GARDE'])}\n",
        encoding="utf-8")
    print(f"[{args.gen}] terminÃ©e en {log['elapsed_s']}s; GARDE={sum(1 for k in keeps if k['GARDE'])}", flush=True)

if __name__ == "__main__":
    main()
