# -*- coding: utf-8 -*-
"""c13v2x_test_r199.py — test C13V2X: mix VWAP (1), CHoCH (2), VWAP+CHoCH (3)
vs aucun (0). EURUSD 2024-2025 + XAU 2025 (pf4.93 spotte)."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\c13v2x_test_r199.jsonl"


def cfg(mg, mode):
    return dict(InpMagic=mg, InpLots=0.10, InpRiskPct=0.0, InpTpR=2.5,
                InpMagLookbackH4=60, InpTrailAtrMult=1.5, InpTrailAfterR=1.0,
                InpImpulseAtrMult=0.9, InpImpulseLook=6, InpAtrPeriod=14,
                InpHtfEmaPeriod=200, InpPinWickRatio=1.5, InpCloseInZoneMin=0.15,
                InpMinStopPips=2.5, InpBufferAtrFrac=0.25, InpMaxSpreadPts=80,
                InpUseHourFilter=True, InpExcludedHoursCSV="6,7,12,15,19,23",
                InpUseDailyStop=True, InpDailyStopR=3.0, InpMaxTradesDay=0,
                InpUtcOffset=2, InpMixMode=mode, InpVwapLookback=96,
                InpChoChSwing=5, InpVerbose=False)


def main():
    mg = 771000
    RUNS = [("EUR24-MIX0", "EURUSD", "2024.01.01", "2025.01.01", 0),
            ("EUR24-VWAP", "EURUSD", "2024.01.01", "2025.01.01", 1),
            ("EUR24-CHOCH", "EURUSD", "2024.01.01", "2025.01.01", 2),
            ("EUR24-BOTH", "EURUSD", "2024.01.01", "2025.01.01", 3),
            ("EUR25-VWAP", "EURUSD", "2025.01.01", "2026.01.01", 1),
            ("EUR25-CHOCH", "EURUSD", "2025.01.01", "2026.01.01", 2),
            ("XAU25-VWAP", "XAUUSD", "2025.01.01", "2026.01.01", 1),
            ("XAU25-CHOCH", "XAUUSD", "2025.01.01", "2026.01.01", 2),
            ("XAU25-BOTH", "XAUUSD", "2025.01.01", "2026.01.01", 3)]
    with open(OUT, "a", encoding="utf-8") as fo:
        for tag, sym, frm, to, mode in RUNS:
            mg += 1
            c = cfg(mg, mode)
            print(f"[r199 {tag}] mix={mode} ...", flush=True)
            r = RF.run_backtest("C13V2X_EA", symbol=sym, tf="M5",
                                from_d=frm, to_d=to, deposit=10000,
                                max_wait=3600, inputs=c)
            fo.write(json.dumps({"tag": tag, "mode": mode, "r": r},
                                default=str) + "\n")
            fo.flush()
            print(f"[{tag}] " + ("null" if r is None else
                  f"p={r.get('profit')} n={r.get('trades')} "
                  f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
            time.sleep(2)
    print("FIN r199", flush=True)


if __name__ == "__main__":
    main()
