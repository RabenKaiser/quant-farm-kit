# -*- coding: utf-8 -*-
"""duka_otherpairs_long_r146.py — USDJPY + crosses epaisses Duka en fenetre
longue 2017-2024 (V3INT config Farm comp050/055 sess 8-17). Cherche des legs
Duka durables au-dela de EURUSD/GBPJPY/NZDJPY."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\duka_otherpairs_long_r146.jsonl"


def v3(comp, mg):
    return dict(InpLots=0.10, InpMagic=mg, InpMaxDailyLossPct=3.0, InpUtcOffset=2,
                InpSlippage=30, InpStartH=8, InpEndH=17, InpCloseHH=20, InpCloseMM=30,
                InpTpAtr=1.0, InpSlAtr=2.0, InpMaxHold=96, InpAtrPct=comp,
                InpDonPct=comp, InpObvMode=0, InpMfiMode=0, InpVerbose=False)


def main():
    mg = 726000
    RUNS = [("USDJPY-c050", "USDJPY", 0.50), ("USDJPY-c055", "USDJPY", 0.55),
            ("EURCHF-c050", "EURCHF", 0.50), ("EURGBP-c050", "EURGBP", 0.50),
            ("EURAUD-c050", "EURAUD", 0.50), ("AUDCAD-c050", "AUDCAD", 0.50),
            ("USDCAD-c050", "USDCAD", 0.50), ("AUDNZD-c050", "AUDNZD", 0.50)]
    with open(OUT, "a", encoding="utf-8") as fo:
        for tag, sym, comp in RUNS:
            mg += 1
            c = v3(comp, mg)
            print(f"[r146 {tag}] {sym} H1 2017.01->2024.01 ...", flush=True)
            r = RF.run_backtest("V3INT_EA", symbol=sym, tf="H1",
                                from_d="2017.01.01", to_d="2024.01.01",
                                deposit=10000, max_wait=3600, inputs=c)
            fo.write(json.dumps({"tag": tag, "sym": sym, "comp": comp, "r": r},
                                default=str) + "\n")
            fo.flush()
            print(f"[{tag}] " + ("ABSENT/null" if r is None else
                  f"profit={r.get('profit')} n={r.get('trades')} "
                  f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
            time.sleep(2)
    print("FIN r146", flush=True)


if __name__ == "__main__":
    main()
