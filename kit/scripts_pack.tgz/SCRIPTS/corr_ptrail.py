"""Analyse de corrélation entre variants ptrail : les trades se chevauchent-ils ?
Si les variants font les mêmes trades aux mêmes dates -> corrélation haute -> la
diversification ne sert à rien. Sinon -> portefeuille combiné potentiellement stable.
Utilise les archives MT5_RUNS créées par mt5_runner (une par run)."""
import sys, json, re
from pathlib import Path

FARM = Path(r"C:\EAFarm\MT5\Farm\MT5_RUNS")
runs = sorted(FARM.glob("PTRAIL_*_2024*"))
print(f"archives ptrail 2024 trouvées: {len(runs)}")
for r in runs:
    print("  ", r.name)

def extract_entries(log_path):
    """Extrait (date, dir) des entrées depuis un log agent archivé."""
    raw = log_path.read_text("utf-16", errors="replace")
    entries = []
    for l in raw.splitlines():
        m = re.search(r"(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s+market (buy|sell) [\d.]+ USDJPY", l)
        if m:
            entries.append((m.group(1), m.group(2)))
    return entries

per_run = {}
for r in runs:
    log = r / "tester_agent.log"
    if log.exists():
        per_run[r.name] = extract_entries(log)
        print(f"  {r.name}: {len(per_run[r.name])} entrées")

# corrélation : Jaccard sur les dates d'entrée (même jour = même signal potentiel)
import itertools
names = list(per_run.keys())
for a, b in itertools.combinations(names, 2):
    da = set(d for d, _ in per_run[a])
    db = set(d for d, _ in per_run[b])
    inter = len(da & db)
    union = len(da | db)
    jac = inter / union if union else 0
    print(f"  {a[:12]} vs {b[:12]}: dates communes {inter}/{union} (Jaccard {jac:.2f})")
