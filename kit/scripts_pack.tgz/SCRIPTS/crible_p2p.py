# -*- coding: utf-8 -*-
r"""crible_p2p.py -- STRATEGIE 1 de Tring.txt (Pips2Profit) au moteur honnete.

« Volatility-Expansion Trend Follower » : filtre de tendance SMA20, deux
bougies consecutive dont les lows (L) / highs (S) sont ENTIEREMENT au-dessus
(dessous) de la SMA, entree a l'ouverture suivante (convention du projet),
stop 1 ATR ou 3 ATR, cible 2 R, detention 64 barres M30.

C'est un modele de CONTINUATION DE TENDANCE -- famille que le portefeuille
n'a pas encore (SR97/KELT = range et canaux). Diversification directe du
portefeuille si le gate WF passe.

Gate : train (2020-23) > 0 ET valid (2024-26) > 0, >= 2/3 annees positives.
Sortie : CRIBLE_P2P_WF.csv (colonne annees standard pour chasse_15.py).
"""
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM

HOLD = int(os.environ.get("HOLD", "64"))
TPR = 2.0
SLRS = [float(x) for x in os.environ.get("SLRS", "1,3").split(",")]
JAMBES = [x.strip() for x in os.environ.get(
    "PAIRES", "NZDUSD,EURGBP,EURCHF,GBPCHF,AUDCAD,NZDJPY,AUDUSD,CADJPY,"
    "EURUSD,GBPUSD,USDCHF,EURJPY").split(",") if x.strip()]
SORTIE = Path(__file__).resolve().parent.parent / "CRIBLE_P2P_WF.csv"


def p2p_signaux(D):
    """SMA20 + deux bougies entieres au-dessus/dessous -> sens du signal."""
    c, h, l = D["c"], D["h"], D["l"]
    sma = pd.Series(c).rolling(20).mean().values
    tr = np.maximum(h - l, np.maximum(np.abs(h - np.roll(c, 1)),
                                      np.abs(l - np.roll(c, 1))))
    atr5 = pd.Series(tr).rolling(5).mean().values
    dessus = (l > np.roll(sma, 1)) & (np.roll(l, 2) > np.roll(sma, 2))
    dessous = (h < np.roll(sma, 1)) & (np.roll(h, 2) < np.roll(sma, 2))
    long_ok = dessus & (c > sma)
    short_ok = dessous & (c < sma)
    return np.flatnonzero(np.nan_to_num(long_ok)), np.flatnonzero(
        np.nan_to_num(short_ok)), atr5


def resultat(D, sig, slr, atr5, sens="L"):
    c, h, l, o, a = D["c"], D["h"], D["l"], D["o"], D["a"]
    sig = sig[(sig >= 60) & (sig < len(c) - HOLD - 3)]
    sig = sig[np.isfinite(a[sig]) & (a[sig] > 0) & np.isfinite(atr5[sig])
              & (atr5[sig] > 0)]
    if len(sig) < 30:
        return None
    ent = sig + 1
    ent = ent[ent < len(c) - HOLD - 2]
    e, st = o[ent], atr5[sig[:len(ent)]]
    sp = D["cout"]
    # TP = TPR x STOP (R = slr x ATR). BUG DU 10/12 corrige : tp etait pose a
    # TPR x ATR au lieu de TPR x R -> +2R annonces pour 0.67R reels (le temoin
    # aleatoire faisait +0.7 R/tx : artefact, pas edge).
    if sens == "L":
        tp, sl = e + (TPR * slr + sp) * st, e - max(slr - sp, 0.1) * st
    else:
        tp, sl = e - (TPR * slr + sp) * st, e + max(slr - sp, 0.1) * st
    off = np.arange(1, HOLD + 1)
    Hh, Ll = h[ent[:, None] + off], l[ent[:, None] + off]
    if sens == "L":
        htp, hsl = Hh >= tp[:, None], Ll <= sl[:, None]
    else:
        htp, hsl = Ll <= tp[:, None], Hh >= sl[:, None]
    it = np.where(htp.any(1), htp.argmax(1), 10 ** 6)
    isl = np.where(hsl.any(1), hsl.argmax(1), 10 ** 6)
    tph, slh = htp.any(1), hsl.any(1)
    kind = np.where(tph & (~slh | (it < isl)), 0, np.where(slh, 1, 2))
    fin = ((c[ent + HOLD] - e) / st if sens == "L"
           else (e - c[ent + HOLD]) / st)
    R = np.where(kind == 0, TPR, np.where(kind == 1, -1.0,
                                          fin + (sp if sens == "L" else -sp)))
    garde, fin_bloc = [], None
    for k, i in enumerate(ent):
        t = D["idx"][i]
        if fin_bloc is not None and t < fin_bloc:
            continue
        garde.append(k)
        fin_bloc = t + pd.Timedelta(minutes=30 * HOLD)
    g = np.array(garde, dtype=int)
    ok = np.isfinite(R[g])
    if ok.sum() < 30:
        return None
    g = g[ok]
    R = R[g]
    annees = np.array([D["idx"][ent[k]].year for k in g])
    par_an = {int(y): float(np.mean(R[annees == y]))
              for y in np.unique(annees)}
    train = [v for y, v in par_an.items() if 2020 <= y <= 2023]
    valid = [v for y, v in par_an.items() if y >= 2024]
    return dict(n=len(R), mu=float(np.mean(R)), sd=float(np.std(R)),
                gagn=100.0 * float(np.mean(kind[g] == 0)),
                train_mu=float(np.mean(train)) if train else None,
                valid_mu=float(np.mean(valid)) if valid else None,
                annees=par_an)


def main():
    print("P2P (Tring.txt S1) : SMA20 + 2 bougies entieres | trame M30 | "
          "gate WF | SLR %s" % SLRS)
    lignes = []
    for p in JAMBES:
        D = NM.charge(p, "m1_pos")
        if D is None:
            print("  %-8s : corpus absent" % p)
            continue
        sig_l, sig_s, atr5 = p2p_signaux(D)
        for slr in SLRS:
            for sens, sig, nom in (("L", sig_l, "P2P_L"), ("S", sig_s, "P2P_S")):
                r = resultat(D, sig, slr, atr5, sens)
                if r is None:
                    continue
                ans = " ".join("%d %+.2f" % (y, v)
                               for y, v in sorted(r["annees"].items()))
                wf_ok = (r["train_mu"] is not None and r["train_mu"] > 0
                         and r["valid_mu"] is not None and r["valid_mu"] > 0)
                npo = sum(1 for v in r["annees"].values() if v > 0)
                print("  %-8s %s slr=%.0f n=%4.0f mu=%+.3f train=%+.3f "
                      "valid=%+.3f ans-pos=%d/%d %s"
                      % (p, sens, slr, r["n"], r["mu"], r["train_mu"] or 0,
                         r["valid_mu"] or 0, npo, len(r["annees"]),
                         "WF-OK" if wf_ok else "wf-fail"))
                lignes.append(dict(jambe=p, famille="%s_SLR%g" % (nom, slr),
                                   n=r["n"], mu=r["mu"], sd=r["sd"],
                                   train=r["train_mu"], valid=r["valid_mu"],
                                   gagnants=r["gagn"], wf_ok=int(wf_ok),
                                   annees=ans))
    if lignes:
        import csv
        with open(SORTIE, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(lignes[0].keys()))
            w.writeheader()
            w.writerows(lignes)
        print("ecrit %s (%d lignes)" % (SORTIE.name, len(lignes)))


if __name__ == "__main__":
    main()
