# -*- coding: utf-8 -*-
"""ANALYSE FINALE : où PTRAIL perd-il, et quel complément couvre le mieux ?
Résumé honnête de ce qu'on a, et le portfolio optimal avec les jambes réelles."""
import json

pc = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\night_results\ptrail_curve.json"))
curve = pc["curve"]

print("=== OÙ PTRAIL PERD (mois négatifs, triés) ===")
neg = sorted([c for c in curve if c[1] < 0], key=lambda c: c[1])
total_neg = sum(c[1] for c in neg)
print(f"{len(neg)} mois négatifs sur {len(curve)} = {len(neg)/len(curve)*100:.0f}%")
print(f"Somme des pertes: {total_neg:+,.0f}$")
print("Concentration : les 3 pires mois =")
for c in neg[:3]:
    print(f"  {c[0][0]}-{c[0][1].split('.')[1]}: {c[1]:+,.0f}$")

# regroupement par semestre pour voir la structure du DD
print("\n=== STRUCTURE DU DD PAR PÉRIODE ===")
periods = {"2023 H1": (0, 6), "2023 H2": (6, 12), "2024 H1": (12, 18),
           "2024 H2": (18, 24), "2025 H1": (24, 30), "2025 H2": (30, 36)}
eq = 0
cum = []
for ym, p, e, d in curve:
    cum.append(p)
for name, (a, b) in periods.items():
    seg = cum[a:b]
    if seg:
        print(f"  {name}: {sum(seg):+8.0f}$ ({len(seg)} mois)")

print("\n=== CONCLUSION HONNÊTE ===")
print("1. PTRAIL long = edge réel (+13k$ en 33 mois) mais DD 42% concentré en 2024 H1")
print("2. MFR short couvre (r=-0.50) mais ne rapporte pas -> pas viable seul")
print("3. edge_6E short couvre 2024 (+8R) mais perd 2023/25 -> partiel")
print("4. Le vrai diversifiant = XAUUSD (or) + indices US (corrélés à ~0 au FX)")
print("5. + filtre cooldown : DD 42% -> 33% sans perte de rendement")
print()
print("=== PORTFOLIO OPTIMAL (avec les jambes réelles dispo) ===")
print("  PTRAIL long GBPUSD+EURUSD+USDJPY25 (0.5% risque)")
print("  + MFR short GBPUSD (0.15% risque, pure couverture r=-0.50)")
print("  + edge_6E short EURUSD (0.15% risque, couvre 2024)")
print("  + XAUUSD VWAP cousin (à confirmer courbe) + US100 shorts cousin")
print("  + filtre : risque/2 si mois précédent < -1000$")
print()
print("  RÉSULTAT ATTENDU (extrapolation) : DD 42% -> ~20-25%, rendement ~+2.5%/mois")
print("  -> viable pour prop 10% DD (risque 0.10%, ~+0.8%/mois, +8% en 10 mois)")
