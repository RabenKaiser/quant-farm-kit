﻿import pandas as pd
p = r"C:\EAFarm\HISTORY - Copy\research\m1_pos\EURAUD_M1.csv"
df = pd.read_csv(p, nrows=5)
print("colonnes :", list(df.columns))
df2 = pd.read_csv(p, usecols=["spread"])
import numpy as np
s = df2["spread"].to_numpy()
print(f"spread : median={np.median(s):.1f}  moyenne={s.mean():.1f}  p90={np.percentile(s,90):.1f}  max={s.max():.0f}")
print(f"  part des barres avec spread > 2.5 x mediane : {100*(s > 2.5*np.median(s)).mean():.2f} %")
