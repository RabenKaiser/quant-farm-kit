﻿import os,re
LOGD=r'C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs'
files=[(f,os.path.getmtime(os.path.join(LOGD,f)),os.path.getsize(os.path.join(LOGD,f))) for f in os.listdir(LOGD) if '.log' in f]
files.sort(key=lambda x:-x[1])
for f,m,s in files[:5]:
    p=os.path.join(LOGD,f)
    if s<500: continue
    raw=open(p,'rb').read(4)
    enc='utf-16' if raw[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8'
    try: txt=open(p,encoding=enc,errors='replace').read()
    except Exception: continue
    hits=re.findall(r'.*ORION (?:TRIGX|TRIG|MASQUE) .*', txt)
    print(f'--- {f} : {len(hits)} lignes ---')
    for h in hits[-14:]: print('  ', h.split('Core')[-1].strip()[:100])
    if hits: break
