# -*- coding: utf-8 -*-
"""etat_file_indus.py -- etat de la file industrielle (SQLite) construite le 10/12."""
import os
import sqlite3

P = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "usine_indus.db")
print("file :", P, "|", round(os.path.getsize(P) / 1024), "Ko")
c = sqlite3.connect(P)
tables = [r[0] for r in c.execute("select name from sqlite_master where type='table'")]
print("tables :", tables)
for n in tables:
    try:
        n_lignes = c.execute("select count(*) from %s" % n).fetchone()[0]
        cols = [d[1] for d in c.execute("pragma table_info(%s)" % n)]
        print("  %-14s %6d lignes | %s" % (n, n_lignes, ", ".join(cols)))
    except Exception as e:
        print("  %-14s illisible (%s)" % (n, e))
try:
    print("statuts :", list(c.execute("select statut, count(*) from jobs group by statut")))
except Exception as e:
    print("statuts indisponibles :", e)
