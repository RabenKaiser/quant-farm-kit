"""audit_v3int : verifier V3INT sur ses RESULTATS REELS MT5, par annee.

Round 456. `TEAM_PORTFOLIO.md` annonce pour V3INT_GBPUSD un t de +10,1 sur 7 annees positives, et
`V3INT_EURUSD` un rejet (-176 sur 7 ans, 2 annees positives sur 7) -- pourtant deploye. Ces chiffres
venaient de courbes JOURNALIERES, une classe de mesure qui a produit un faux +103 % dans cette session.
Mais les fichiers `v3int_*.jsonl` de `RESULTS_C13V2/` contiennent autre chose : les **resultats reels du
testeur MT5 par fenetre**, avec le nombre de transactions, les gagnantes, le profit factor, le net en
dollars, la source du journal et le chemin du rapport `.htm`. C'est verifiable.

Ce script agrege ces resultats par (EA, symbole, unite de temps), reconstitue l'annee de chaque fenetre,
et publie : transactions, taux de gagnants, profit factor, net, R/tx sous trois hypotheses de R:R, et
**le nombre d'annees positives** -- le critere de la regle de decision de l'objectif.

Usage : python SCRIPTS\\audit_v3int.py
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
# fenetre -> annee : on prend l'annee de DEBUT (les fenetres sont non chevauchantes dans ces fichiers)
RR_HYPOTHESES = {"TP=1xSL (cible serree)": 1.0, "TP=2xSL (reference)": 2.0}


def annee(o, r):
    """Annee de DEBUT de la fenetre, cherchee a TROIS endroits.

    ROUND 453 : le premier jet ne lisait que `o["from"]` ; quand il manquait, la fenetre tombait dans un
    seau « annee 0 » qui absorbait 2 076 transactions sur 2 982 pour EURUSD-H1 -- et donc l'essentiel du
    gain, ce qui rendait le « 7/7 annees positives » trompeur. Or la date est aussi dans `r["from"]`
    (le rapport du testeur la porte) et dans le `tag` (« EURUSD-2017-2019 »). On essaie les trois, dans
    cet ordre, et on retourne None si aucun ne donne une annee plausible -- mieux vaut une fenetre
    SIGNALEE comme non datee qu'un seau silencieux qui fausse le total.
    """
    for src in (o.get("from"), r.get("from")):
        if src and str(src)[:4].isdigit() and str(src)[:4] != "0000":
            return int(str(src)[:4])
    m = re.search(r"(19|20)\d{2}", str(o.get("tag") or ""))
    return int(m.group(0)) if m else None


def fenetres():
    out, non_datees = [], 0
    for f in list(B.rglob("v3int_*.jsonl")) + list(B.rglob("*v3int*.jsonl")):
        try:
            for ligne in f.read_text(encoding="utf-8", errors="replace").splitlines():
                ligne = ligne.strip()
                if not ligne.startswith("{"):
                    continue
                o = json.loads(ligne)
                r = o.get("r") or {}
                if not r.get("trades"):
                    continue
                a = annee(o, r)
                if a is None:
                    non_datees += 1
                out.append(dict(fichier=f.name, tag=o.get("tag"), sym=o.get("sym") or r.get("symbol"),
                                tf=r.get("tf"), an=a,
                                trades=int(r["trades"]), wins=int(r.get("wins") or 0),
                                net=float(r.get("net_usd") or r.get("profit") or 0.0),
                                pf=r.get("pf"), ea=r.get("ea"), source=r.get("_source")))
        except (OSError, ValueError):
            continue
    if non_datees:
        print("  ATTENTION : %d fenetres SANS date exploitable (comptees a part, jamais fondues dans les"
              " annees)" % non_datees)
    return out


def main():
    fx = fenetres()
    if not fx:
        print("  aucun resultat V3INT lisible")
        return 1
    print("  %d fenetres reelles lues dans %d fichiers\n" % (len(fx), len({x['fichier'] for x in fx})))
    par_cle = defaultdict(list)
    for x in fx:
        par_cle[(x["ea"] or "?", x["sym"] or "?", x["tf"] or "?")].append(x)
    for (ea, sym, tf), lst in sorted(par_cle.items(), key=lambda kv: -sum(x["net"] for x in kv[1])):
        n = sum(x["trades"] for x in lst)
        w = sum(x["wins"] for x in lst)
        net = sum(x["net"] for x in lst)
        an = defaultdict(float)
        an_tr = defaultdict(int)
        for x in lst:
            an[x["an"]] += x["net"]
            an_tr[x["an"]] += x["trades"]
        pos = sum(1 for v in an.values() if v > 0)
        wr = 100.0 * w / n if n else 0.0
        # R/tx sous hypothese de R:R (une cible = RR x le risque, une perte = -1)
        rtxt = " | ".join("%s : %+.4f" % (k, (wr / 100.0) * v - (1 - wr / 100.0)) for k, v in RR_HYPOTHESES.items())
        print("=== %s %s %s ===" % (ea, sym, tf))
        print("  %d transactions | gagnantes %.1f %% | net %+.1f USD | annees positives %d/%d"
              % (n, wr, net, pos, len(an)))
        print("  R/tx sous hypothese de R:R -> %s" % rtxt)
        print("  par annee : %s\n"
              % " ".join("%d %+.1f (%dtx)" % (y, an[y], an_tr[y]) for y in sorted(an)), flush=True)
    # regroupement tous EA confondus
    n = sum(x["trades"] for x in fx)
    w = sum(x["wins"] for x in fx)
    net = sum(x["net"] for x in fx)
    an = defaultdict(float)
    for x in fx:
        an[x["an"]] += x["net"]
    pos = sum(1 for v in an.values() if v > 0)
    print("=== TOTAL V3INT ===")
    print("  %d transactions | gagnantes %.1f %% | net %+.1f USD | annees positives %d/%d"
          % (n, 100.0 * w / n, net, pos, len(an)))
    print("  ATTENTION : ce total melange des EA et des symboles differents -- il n'a de sens que comme")
    print("  inventaire. La comparaison avec l'objectif se fait EA par EA.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
