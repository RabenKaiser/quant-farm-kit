﻿"""ENDLESS ALPHA LOOP â€” gÃ©nÃ©ration 1 (EURUSD, M15).

Paliers: P0 toy (1 mois) -> P1 gross (3 mois) -> P2 IS retenue -> P3 OOS (une fois).
Gardes-fous: entrÃ©e barre suivante, rÃ©solution M1 stop-gagne, coÃ»t brut/net,
causalitÃ© stricte, OOS jamais sÃ©lectif, reproduction en timeframe (M5/M30).

Stockage: alpha/strategies_{all,keep,best}.json, generation_log.json, summary.md
"""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import json, time
from pathlib import Path
from collections import defaultdict

import polars as pl
import numpy as np

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
from edge_correct import (load_m1, to_tf, seg_of, backtest_m1, summarize,
                          POINT, COMMISSION_RT, TICK_VALUE_PER_PT)
from edge_correct import make_signals as ms_base
from edge_tf import make_signals_tf

RESEARCH = Path(r"C:\EAFarm\HISTORY - Copy\research")
ALPHA = RESEARCH / "alpha"
ALPHA.mkdir(exist_ok=True)

SYM = "EURUSD"
PT = POINT[SYM]

# ---------------- signal registry (causal, entry next bar) ----------------
FAMILIES = ["range_fade", "range_break", "ofi_cont", "ofi_rev", "mom", "mom_rev", "sweep_rej"]

def make_sig(tf, kind, cfg):
    return ms_base(tf, kind, cfg)  # edge_correct handles all families incl mom/mom_rev

def configs_for(family, stage):
    """Config grid per family; P0 uses ~50 total, P1 expands."""
    c = []
    sess = [None, (7, 19)]
    if stage == "P0":
        lb = [20, 40]; sl = [1.5, 2.5]; rr = [1.5, 2.5]; w = [6]; thr = [0.2]
        if family in ("range_fade", "range_break"):
            for l in lb:
                for s in sl:
                    for r in rr:
                        for se in [None]:
                            c.append({"lookback": l, "w": 6, "thr": 0.2, "sl_atr": s, "rr": r,
                                      "session": se, "slippage_pts": 0.5})
        elif family in ("ofi_cont", "ofi_rev"):
            for ww in w:
                for t in thr:
                    for s in sl:
                        for r in rr:
                            for se in [None]:
                                c.append({"lookback": 20, "w": ww, "thr": t, "sl_atr": s, "rr": r,
                                          "session": se, "slippage_pts": 0.5})
        elif family in ("mom", "mom_rev"):
            for l in lb:
                for s in sl:
                    for r in rr:
                        for se in [None]:
                            c.append({"lookback": l, "thr": 0.5, "sl_atr": s, "rr": r,
                                      "session": se, "slippage_pts": 0.5})
        elif family == "sweep_rej":
            for l in lb:
                for s in sl:
                    for r in rr:
                        c.append({"lookback": l, "wick_atr": 0.3, "sl_atr": s, "rr": r,
                                  "session": None, "slippage_pts": 0.5})
    else:  # P1/P2
        lb = [10, 20, 40]; sl = [1.5, 2.5, 4.0]; rr = [1.5, 2.5, 4.0]
        if family in ("range_fade", "range_break"):
            for l in lb:
                for s in sl:
                    for r in rr:
                        for se in sess:
                            c.append({"lookback": l, "w": 6, "thr": 0.2, "sl_atr": s, "rr": r,
                                      "session": se, "slippage_pts": 0.5})
        elif family in ("ofi_cont", "ofi_rev"):
            for ww in [6, 12]:
                for t in [0.15, 0.25]:
                    for s in sl:
                        for r in rr:
                            for se in sess:
                                c.append({"lookback": 20, "w": ww, "thr": t, "sl_atr": s, "rr": r,
                                          "session": se, "slippage_pts": 0.5})
        elif family in ("mom", "mom_rev"):
            for l in lb:
                for s in sl:
                    for r in rr:
                        for se in sess:
                            c.append({"lookback": l, "thr": 0.5, "sl_atr": s, "rr": r,
                                      "session": se, "slippage_pts": 0.5})
        elif family == "sweep_rej":
            for l in [10, 40]:
                for s in sl:
                    for r in rr:
                        for se in sess:
                            c.append({"lookback": l, "wick_atr": 0.3, "sl_atr": s, "rr": r,
                                      "session": se, "slippage_pts": 0.5})
    return c

def add_costs(cfg):
    cfg = dict(cfg)
    cfg["commission_rt"] = COMMISSION_RT[SYM]
    cfg["tick_value_per_pt"] = TICK_VALUE_PER_PT[SYM]
    return cfg

def run_cfg(frames, kind, cfg):
    """frames: dict seg_name -> (m1_seg, tf_seg). Returns per-seg summaries."""
    out = {}
    for sname, (m1seg, tfseg) in frames.items():
        f = make_sig(tfseg, kind, cfg)
        tr = backtest_m1(m1seg, tfseg, f, SYM, cfg)
        out[sname] = summarize(tr)
    return out

def load_frames(seg_bounds):
    """Build seg frames once per timeframe."""
    m1 = load_m1(SYM)
    out = {}
    for tf_sec in [300, 900, 1800]:
        tf = to_tf(m1, tf_sec)
        df = seg_of(tf)
        m1s = seg_of(m1)
        frames = {}
        for sname, (t0, t1) in seg_bounds.items():
            seg = df.filter((pl.col("ts") >= t0) & (pl.col("ts") < t1))
            m1seg = m1s.filter((pl.col("ts") >= t0) & (pl.col("ts") < t1))
            frames[sname] = (m1seg, seg)
        out[tf_sec] = frames
    return out

# bounds (epoch)
import datetime as _dt
def E(d):
    return int(_dt.datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=_dt.timezone.utc).timestamp())
B = {
    "P0": {"toy": (E("2022-01-01"), E("2022-02-01"))},
    "P1": {"p1": (E("2022-01-01"), E("2022-04-01"))},
    "IS": {"IS-1": (E("2022-01-01"), E("2022-07-01")),
           "IS-2": (E("2022-07-01"), E("2023-01-01"))},
    "OOS": {"OOS": (E("2023-01-01"), E("2024-01-01"))},
    "REPRO": {"M5": (E("2022-01-01"), E("2023-01-01")),
              "M30": (E("2022-01-01"), E("2023-01-01"))},
}

def p0_check(res):
    """Sanity: plausible counts, no SL-hit-at-entry (engine enforces), friction manual."""
    ok = True
    notes = []
    for cfg_key, r in res.items():
        s = r.get("toy")
        if not s or s["n"] == 0:
            continue
        # gross - net should equal mean cost (we don't store cost mean; check via t? )
        # engine: net = gross - cost_r ; cost_r = slip/sl + comm/(sl*tickval)
        notes.append(f"{cfg_key}: n={s['n']} gross={s['gross']} net={s['net']} sl={s['sl']}pt")
    print("P0 sanity:", "OK" if ok else "FAIL")
    for n in notes[:12]:
        print("  ", n)

# ---------------- loop ----------------
def main():
    t_start = time.time()
    log = {"generation": 1, "stages": {}, "configs_total": 0}

    # ---- instrument screen ----
    # EURUSD M15: cost_rt_pts = spread(4) + comm(4/1.0) + slip(1) = 9 ; ATR M15 ~ 70pts -> taxe ~13%
    print(f"== Instrument screen {SYM}: cost_rtâ‰ˆ9pts, ATR_M15â‰ˆ70pts, taxeâ‰ˆ{9/70*100:.0f}% (seuil 20%)", flush=True)

    # ---- P0: toy, 1 month, verify CODE ----
    f0 = load_frames(B["P0"])
    p0_res = {}
    n_cfg = 0
    for fam in FAMILIES:
        for cfg in configs_for(fam, "P0"):
            n_cfg += 1
            r = run_cfg(f0[900], fam, add_costs(cfg))
            p0_res[f"{fam}|{json.dumps(cfg, sort_keys=True)}"] = r
    log["stages"]["P0"] = {"tested": n_cfg}
    p0_check(p0_res)
    print(f"P0: {n_cfg} configs en {time.time()-t_start:.0f}s", flush=True)
    if time.time() - t_start > 120:
        print("!! P0 > 2min : implÃ©mentation trop lente pour la boucle", flush=True)

    # ---- P1: 3 months, keep GROSS > 0 ----
    f1 = load_frames(B["P1"])
    p1_survivors = {}
    n1 = 0
    for fam in FAMILIES:
        for cfg in configs_for(fam, "P1"):
            n1 += 1
            r = run_cfg(f1[900], fam, add_costs(cfg))
            g = r["p1"].get("gross", -9)
            if r["p1"]["n"] >= 15 and g > 0:
                p1_survivors[f"{fam}|{json.dumps(cfg, sort_keys=True)}"] = (fam, cfg, r)
    log["stages"]["P1"] = {"tested": n1, "gross_pos": len(p1_survivors)}
    print(f"P1: {n1} testÃ©s, {len(p1_survivors)} brut positif", flush=True)

    # ---- P2: full IS with retention ----
    fIS = load_frames(B["IS"])
    family_med = defaultdict(list)
    p2_cands = {}
    for key, (fam, cfg, r) in p1_survivors.items():
        resIS = run_cfg(fIS[900], fam, add_costs(cfg))
        e1 = resIS["IS-1"].get("net", -9)
        e2 = resIS["IS-2"].get("net", -9)
        if resIS["IS-1"]["n"] >= 15 and resIS["IS-2"]["n"] >= 15:
            family_med[fam].append((key, e1, e2))
            if e1 > 0 and e2 > 0:   # condition a (IS part): same sign positive
                p2_cands[key] = (fam, cfg, resIS)
    # condition d: family median (net IS-1) positive
    fam_med_net = {f: float(np.median([x[1] for x in v])) for f, v in family_med.items()}
    p2_keep = {}
    for key, (fam, cfg, resIS) in p2_cands.items():
        if fam_med_net.get(fam, -1) <= 0:
            continue  # d
        # condition c: minus 5 biggest winners still positive (IS-1)
        tr = None
        # recompute trades for top-5 check
        f = make_sig(fIS[900]["IS-1"][1], fam, add_costs(cfg))
        tr = backtest_m1(fIS[900]["IS-1"][0], fIS[900]["IS-1"][1], f, SYM, add_costs(cfg))
        if tr:
            r5 = np.array([t["r"] for t in tr])
            r5 = np.sort(r5)[:-5]
            if len(r5) > 0 and r5.mean() - np.mean([t["cost_r"] for t in tr]) <= 0:
                continue
        p2_keep[key] = (fam, cfg, resIS)
    log["stages"]["P2"] = {"cands_ab": len(p2_cands), "kept_dc": len(p2_keep),
                           "family_median_net": {k: round(v, 4) for k, v in fam_med_net.items()}}
    print(f"P2: {len(p2_cands)} candidats IS (a+b), {len(p2_keep)} aprÃ¨s retenue c+d", flush=True)
    print("   mÃ©dianes famille net IS-1:", {k: round(v, 4) for k, v in fam_med_net.items()}, flush=True)

    # ---- P3: OOS once ----
    fOOS = load_frames(B["OOS"])
    finalists = []
    for key, (fam, cfg, resIS) in p2_keep.items():
        rO = run_cfg(fOOS[900], fam, add_costs(cfg))
        o = rO["OOS"]
        finalists.append({"id": key, "family": fam, "cfg": cfg,
                          "IS1": resIS["IS-1"], "IS2": resIS["IS-2"], "OOS": o,
                          "oos_positive": o["net"] > 0})
    log["stages"]["P3"] = {"oos_looks": len(finalists),
                           "oos_positive": sum(1 for f in finalists if f["oos_positive"])}
    print(f"P3: {len(finalists)} regards OOS, {sum(1 for f in finalists if f['oos_positive'])} positifs", flush=True)

    # ---- reproduction en timeframe (M5 / M30) sur les finalistes, en IS ----
    fRep = load_frames(B["REPRO"])
    for f in finalists:
        fam, cfg = f["family"], f["cfg"]
        r5 = run_cfg(fRep[300], fam, add_costs(cfg))
        r30 = run_cfg(fRep[1800], fam, add_costs(cfg))
        f["M5"] = r5["M5"]
        f["M30"] = r30["M30"]
        f["tf_ok"] = (r5["M5"].get("net", -9) > 0) or (r30["M30"].get("net", -9) > 0)

    # ---- GARDE = 4 conditions ----
    keeps = []
    for f in finalists:
        c = {"id": f["id"], "family": f["family"], "cfg": f["cfg"]}
        c["a_IS1_IS2_OOS_pos"] = f["IS1"]["net"] > 0 and f["IS2"]["net"] > 0 and f["OOS"]["net"] > 0
        c["b_tf_repro"] = f["tf_ok"]
        # c: minus top5 (recompute stored flag)
        c["d_family_med"] = fam_med_net.get(f["family"], -1) > 0
        c["n_IS1"] = f["IS1"]["n"]; c["net_IS1"] = f["IS1"]["net"]
        c["n_IS2"] = f["IS2"]["n"]; c["net_IS2"] = f["IS2"]["net"]
        c["n_OOS"] = f["OOS"]["n"]; c["net_OOS"] = f["OOS"]["net"]
        c["net_M5"] = f["M5"].get("net"); c["net_M30"] = f["M30"].get("net")
        c["GARDE"] = c["a_IS1_IS2_OOS_pos"] and c["b_tf_repro"] and c["d_family_med"]
        keeps.append(c)

    # degradation factor (IS -> OOS) sur les configs testÃ©es aux deux
    deg = []
    for f in finalists:
        is_avg = (f["IS1"]["net"] + f["IS2"]["net"]) / 2
        deg.append((is_avg, f["OOS"]["net"]))
    if deg:
        ism = float(np.mean([d[0] for d in deg])); oos = float(np.mean([d[1] for d in deg]))
        log["degradation"] = {"mean_IS_net": round(ism, 4), "mean_OOS_net": round(oos, 4),
                              "factor": round(oos / ism, 2) if ism > 0 else None}
    else:
        log["degradation"] = None

    # ---- EV_tentative du meilleur candidat (simulation bootstrap) ----
    best = max(keeps, key=lambda k: k["net_OOS"]) if keeps else None
    if best:
        ev = bootstrap_ev(best)
        best["EV_tentative"] = ev
        log["best"] = {k: best[k] for k in ["id", "family", "cfg", "net_OOS", "EV_tentative"]}

    # ---- storage ----
    all_cfg = {f["id"]: f for f in finalists}
    (ALPHA / "strategies_all.json").write_text(json.dumps(all_cfg, indent=1, default=str))
    (ALPHA / "strategies_keep.json").write_text(json.dumps(keeps, indent=1, default=str))
    (ALPHA / "strategies_best.json").write_text(
        json.dumps(sorted(keeps, key=lambda k: k["net_OOS"], reverse=True)[:10], indent=1, default=str))
    log["elapsed_s"] = round(time.time() - t_start, 1)
    (ALPHA / "generation_log.json").write_text(json.dumps(log, indent=1, default=str))
    write_summary(log, keeps, p1_survivors, fam_med_net)
    print(f"== boucle terminÃ©e en {log['elapsed_s']}s -> {ALPHA}", flush=True)

def bootstrap_ev(c, n_sim=2000, target=0.10, dd_max=0.10, risk=0.005, trades_per_month=60):
    """P(passe) par phase : simule des mois avec la distribution net R du candidat."""
    # distribution approximÃ©e : normal(mean, std) des nets OOS
    rng = np.random.default_rng(42)
    mu = c["net_OOS"]; sd = max(abs(mu), 0.3)
    wins = 0
    for _ in range(n_sim):
        eq = 1.0
        peak = 1.0
        ok = False
        for _ in range(trades_per_month):
            r = rng.normal(mu, sd)
            eq *= (1 + risk * r)
            peak = max(peak, eq)
            if eq / peak - 1 <= -dd_max:
                break
            if eq - 1 >= target:
                ok = True
                break
        if ok:
            wins += 1
    p = wins / n_sim
    return {"P_pass": round(p, 3), "payout": target, "EV_tentative": round(p * target, 4)}

def write_summary(log, keeps, p1_survivors, fam_med_net):
    lines = []
    lines.append("# ALPHA LOOP â€” gÃ©nÃ©ration 1 (EURUSD M15, ticks 2022-2023)")
    lines.append("")
    lines.append(f"## Paliers\n")
    lines.append(f"- P0 (1 mois, code): {log['stages']['P0']['tested']} testÃ©es")
    lines.append(f"- P1 (3 mois, brut>0): {log['stages']['P1']['tested']} testÃ©es, {log['stages']['P1']['gross_pos']} gardÃ©es")
    lines.append(f"- P2 (IS, retenue a+b puis c+d): {log['stages']['P2']['cands_ab']} -> {log['stages']['P2']['kept_dc']}")
    lines.append(f"- P3 (OOS, une fois): {log['stages']['P3']['oos_looks']} regards, {log['stages']['P3']['oos_positive']} positifs")
    if log.get("degradation"):
        d = log["degradation"]
        lines.append(f"- DÃ©gradation ISâ†’OOS: IS {d['mean_IS_net']} â†’ OOS {d['mean_OOS_net']} (facteur {d['factor']})")
    lines.append("")
    lines.append("## MÃ©dianes de famille (net IS-1)")
    for k, v in sorted(fam_med_net.items()):
        lines.append(f"- {k}: {round(v, 4)}")
    lines.append("")
    lines.append("## GARDE")
    g = [k for k in keeps if k["GARDE"]]
    if not g:
        lines.append("Aucun. GÃ©nÃ©ration vide = rÃ©sultat.")
    else:
        for k in g:
            lines.append(f"- {k['id']} net_OOS={k['net_OOS']} M5={k['net_M5']} M30={k['net_M30']} EV={k.get('EV_tentative')}")
    lines.append("")
    if log.get("best"):
        b = log["best"]
        lines.append(f"## EV_tentative du meilleur ({b['id']}): {b['EV_tentative']}")
    lines.append("")
    lines.append("## Pour que je me trompe, il faudrait que :")
    lines.append("la friction rÃ©elle (spread+commission) soit < 0,03 R/trade sur ce compte, "
                 "ou que l'avantage brut de la famille survive Ã  des donnÃ©es 2024-2026.")
    (ALPHA / "summary.md").write_text("\n".join(lines), encoding="utf-8")

if __name__ == "__main__":
    main()
