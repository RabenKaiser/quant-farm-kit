# -*- coding: utf-8 -*-
"""candidats.py — LA LISTE DES CANDIDATS, avec leur niveau de preuve.

DEMANDE DE L'UTILISATEUR (16/09, 17 h)
--------------------------------------
    "Qu'est-ce qu'on a des triggers quand meme ? On avait des combinaisons qui
     donnaient quelque chose, les combinaisons inverses, la non ? Commence a
     faire une petite liste des choses qui marchent quand meme, des choses qui
     commencaient, qui semblaient."

Ce script construit cette liste A PARTIR DES DONNEES, pas de memoire. Chaque
ligne porte :

  * ce qui est mesure (le chiffre) ;
  * sur quoi (nombre de trades, nombre de fenetres) ;
  * et surtout son NIVEAU DE PREUVE, en quatre echelons :
       [1] mesure sur une fenetre          -> ne compte pas
       [2] mesure sur >=2 fenetres         -> indice
       [3] tient hors fenetre (3/2)        -> candidat
       [4] positif en VRAIS ORDRES         -> le seul qui compte

Le laboratoire a produit beaucoup de faux positifs en presentant des mesures
d'echelon [1] ou [2] comme des decouvertes. La colonne PREUVE existe pour que
ca ne recommence pas.

USAGE : python candidats.py
"""
import collections
import json
import statistics
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
OUT = BASE / "CANDIDATS.md"
QF = ["2024Q1", "2024Q2", "2024Q3", "2024Q4", "2025Q1"]
SEL = ["2024Q1", "2024Q2", "2024Q3"]
VAL = ["2024Q4", "2025Q1"]
CP = [6, 12, 24, 36, 48, 72, 96, 144, 192]
H = [c * 5 / 60.0 for c in CP]


def charge():
    """(base, sym, periode) -> {L:{...}, S:{...}}"""
    B = collections.defaultdict(dict)
    with open(BASE / "lab_results.jsonl", encoding="utf-8") as fh:
        for line in fh:
            if not line.strip():
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            p = str(r.get("period", ""))
            q = r["id"].split("|")
            if len(q) != 4 or p not in QF or r["n"] < 3 or "r_x2" not in r:
                continue
            d = dict(r2=r["r_x2"], n=r["n"])
            if r.get("mae") and r["mae"] > 0:
                d["q"] = r["mfe"] / r["mae"]
            if r.get("t_f8") is not None:
                d["t"] = [r.get("t_f%d" % k) for k in range(9)]
            B[("|".join(q[:3]), r["sym"], p)][q[3]] = d
    return B


def main():
    B = charge()
    if not B:
        print("aucune donnee")
        return
    # effet fixe (paire, periode) sur le R : retire l'effet de derive/regime
    fx = collections.defaultdict(list)
    for (b, s, p), d in B.items():
        for side, v in d.items():
            fx[(s, p)].append(v["r2"])
    fx = {k: statistics.mean(v) for k, v in fx.items()}

    # --- 1. le cote : delta = R(short) - R(long), par declencheur --------
    delta = collections.defaultdict(list)
    for (b, s, p), d in B.items():
        if "L" in d and "S" in d:
            delta[(b.split("|")[0], p)].append(d["S"]["r2"] - d["L"]["r2"])
    par_t = collections.defaultdict(dict)
    for (t, p), v in delta.items():
        par_t[t].setdefault("sel", []).extend(v if p in SEL else [])
        par_t[t].setdefault("val", []).extend(v if p in VAL else [])
    cotes = []
    for t, d in par_t.items():
        if len(d.get("sel", [])) < 40:
            continue
        a = statistics.mean(d["sel"])
        bb = statistics.mean(d["val"]) if len(d.get("val", [])) > 20 else None
        cotes.append((t, a, bb, 'S' if a > 0 else 'L'))

    # --- 2. le R absolu du cote choisi, hors fenetre ----------------------
    lignes = []
    for t, a, bb, side in cotes:
        v = [B[k][side]["r2"] - fx[(k[1], k[2])]
             for k in B if k[0].split("|")[0] == t and k[2] in VAL and side in B[k]]
        if len(v) < 20:
            continue
        stable = (bb is not None and (a > 0) == (bb > 0))
        lignes.append(dict(t=t, side=side, delta_sel=a, delta_val=bb,
                           R=statistics.mean(v), n=len(v),
                           pos=100 * sum(1 for x in v if x > 0) / len(v),
                           stable=stable))
    lignes.sort(key=lambda x: -x["R"])

    # --- 3. la forme des courbes ------------------------------------------
    par_ct = collections.defaultdict(list)
    for cid, d in B.items():
        pass
    courbes = collections.defaultdict(list)
    for (b, s, p), d in B.items():
        for side, v in d.items():
            if "t" in v and v["t"][0] is not None:
                courbes[b.split("|")[0]].append(v["t"])
    formes = []
    for t, cs in courbes.items():
        if len(cs) < 20:
            continue
        f = [statistics.mean([c[k] for c in cs if c[k] is not None]) for k in range(9)]
        k = max(range(9), key=lambda i: f[i])
        formes.append(dict(t=t, n=len(cs), f=f, k=k, aire=statistics.mean(f)))
    formes.sort(key=lambda x: -x["aire"])

    # --- 4. le fichier ----------------------------------------------------
    L = ["# LISTE DES CANDIDATS — ce qui a donné quelque chose",
         "",
         "> Genere par `SCRIPTS/candidats.py` a partir de `lab_results.jsonl`.",
         "> **Niveau de preuve** : [1] une fenetre = ne compte pas | [2] >=2",
         "> fenetres = indice | [3] tient hors fenetre = candidat | [4] positif",
         "> en vrais ordres = le seul qui compte.",
         "",
         "## 1. Les DECLENCHEURS INVERSES (le short bat le long)",
         "",
         "Mesure : `R(short) − R(long)` par declencheur, effet de paire et de",
         "periode retire. Choisi sur 2024Q1-Q3, juge sur 2024Q4 + 2025Q1.",
         "",
         "| Declencheur | Cote a prendre | delta Q1-Q3 | delta Q4-Q1 | "
         "R hors fenetre | n | % positif | stable | preuve |",
         "|---|---|---|---|---|---|---|---|---|"]
    for x in lignes[:20]:
        L.append("| `%s` | %s | %+.3f | %s | **%+.3f** | %d | %.0f%% | %s | [3] |"
                 % (x["t"], "SHORT" if x["side"] == "S" else "LONG",
                    x["delta_sel"],
                    "%+.3f" % x["delta_val"] if x["delta_val"] is not None else "-",
                    x["R"], x["n"], x["pos"],
                    "oui" if x["stable"] else "non"))
    L += ["",
          "⚠️ Le signe du delta ne se conserve que pour 23 % des 113 declencheurs",
          "entre les deux periodes : la plupart des lignes ci-dessus sont du bruit.",
          "Ce qui les distingue : un delta LARGE (>= 0.05) et stable.",
          "",
          "## 2. La FORME DES COURBES (round 89)",
          "",
          "Valeur moyenne de la position (en ATR) au fil du hold, par declencheur.",
          "`sommet` = moment ou la position vaut le maximum.",
          "",
          "| Declencheur | n | 0.5 h | 1 h | 2 h | aire | sommet | lecture |",
          "|---|---|---|---|---|---|---|---|"]
    for x in formes[:15]:
        f = x["f"]
        lec = ("montee lente -> tenir longtemps" if x["k"] >= 7 else
               ("pic precoce -> sortir tot" if x["k"] <= 2 else "plat -> rien"))
        if x["aire"] > 0:
            lec = "POSITIVE en moyenne -> " + lec
        L.append("| `%s` | %d | %+.2f | %+.2f | %+.2f | **%+.2f** | %.1f h | %s |"
                 % (x["t"], x["n"], f[0], f[1], f[2], x["aire"], H[x["k"]], lec))
    L += ["",
          "## 3. Ce qui est etabli NEGATIF (ne pas y retourner)",
          "",
          "| Piste | Ce qui a ete mesure |",
          "|---|---|",
          "| Mèches en declencheur | 0.91 de ratio, 2.9 % d'asymetrie, **0/5** fenetres |",
          "| Oscillateurs (Godmode) | 0.91, 4.1 %, 0/5 |",
          "| Biais EMA200 H4 | 1.70 contre 1.83 sans biais : **degrade** |",
          "| Stop serre (1x distance a l'extreme) | R reel **−0.13** |",
          "| Trailing | pire des 7 reglages (−0.13) |",
          "| Le stop comme cause des pertes | touche dans **28 %** des cas seulement |",
          "| Filtres conjoints (empiler) | gagne 45.7 % des tests apparies : **pas de gain de niveau** |",
          "| Criteres de selection testes hors fenetre | asymetrie, ordre des extremes, MFE−MAE : **les trois s'effondrent** |",
          "| Set de 83 combinaisons (choisi sur R simule) | **−16 483 USD** en vrais ordres |",
          "| Set TOP8 (choisi honnetement) | **−33 318 USD**, negatif dans 7/7 fenetres |",
          "",
          "## 4. L'INSTRUMENT (l'acquis reel de ces deux jours)",
          "",
          "Ce qui a le plus progresse n'est pas une strategie, c'est la **maniere",
          "de mesurer** :",
          "",
          "1. **Metrique corrigee** : ratio des MOYENNES et non moyenne des ratios",
          "   (l'ancienne gonflait de 16 % : 0.990 au lieu de 0.857).",
          "2. **Protocole hors fenetre** : choisir sur 3 fenetres, juger sur 2,",
          "   **contre un tirage aleatoire de meme taille**. Sans ce temoin, on ne",
          "   peut pas distinguer un avantage d'un artefact.",
          "3. **Profil temporel** : l'excursion courante aux jalons 0.5 h a 16 h.",
          "   Montre que la position culmine a 1 h et se degrade ensuite.",
          "4. **Grille de sortie 2D en ATR absolu** : 6 stops x 8 objectifs.",
          "5. **Test d'inversion** : comparer les deux sens, derive retiree.",
          "6. **Vrais ordres** : le seul juge final (commission et swap separes).",
          ""]
    OUT.write_text("\n".join(L) + "\n", encoding="utf-8")
    print("-> %s" % OUT)
    print()
    print("CANDIDATS (cote choisi, R hors fenetre, hors effet de periode) :")
    for x in lignes[:12]:
        print("   %-16s %-6s R %+.3f  n=%-5d %.0f%% positifs  stable=%s"
              % (x["t"], "SHORT" if x["side"] == "S" else "LONG", x["R"],
                 x["n"], x["pos"], "oui" if x["stable"] else "NON"))
    print()
    print("COURBES les plus favorables :")
    for x in formes[:8]:
        print("   %-16s aire %+.2f ATR | sommet a %.1f h | n=%d"
              % (x["t"], x["aire"], H[x["k"]], x["n"]))


if __name__ == "__main__":
    main()
