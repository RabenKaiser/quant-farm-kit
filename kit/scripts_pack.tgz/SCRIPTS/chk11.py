﻿import sys, numpy as np
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT
G._cache.clear()
F = G.get_frames("GBPUSD")
m5, m1 = F["m5"], F["m1"]
print(f"GBPUSD : M1={len(m1):,}  M5={len(m5):,}")
print(f"  M5 de {m5.index[0].date()} a {m5.index[-1].date()}")
h1z,hh,ll,a1,gb,gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd,zlo,zhi = MT.project(m5.index,h1z,hh,ll,gb,gr,max_age_h=48)
M = NL.build(m5,F,zd,zlo,zhi); M.update(FE.more(m5,F,m1))
MB = {k:v for k,v in M.items() if hasattr(v,'dtype') and v.dtype==bool and len(v)==len(m5)}
print(f"  masques booleens : {len(MB)}")
# un signal test
s = NL.sig(MB, "rej_bull", ["in_fvgB_1.0"])
print(f"  rej_bull + in_fvgB_1.0 : {int((s!=0).sum())} signaux")
print("  => PIPELINE FONCTIONNEL sur un marche POS")
