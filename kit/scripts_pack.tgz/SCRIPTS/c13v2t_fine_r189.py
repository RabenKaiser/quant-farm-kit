# -*- coding: utf-8 -*-
"""c13v2t_fine_r189.py — sweep fin EURUSD 2024 (pf1.02 atteint): TP
2.0-3.0, trail 1.0-1.5ATR, lookahead 3-5, wick 1.2-2.0. But: franchir pf 1.1+"""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\c13v2t_fine_r189.jsonl"


def cfg(mg, tpr, trail, after, wick, imp, look):
    return dict(InpMagic=mg, InpLots=0.10, InpRiskPct=0.0, InpTpR=tpr,
                InpMagLookbackH4=60, InpTrailAtrMult=trail, InpTrailAfterR=after,
                InpImpulseAtrMult=imp, InpImpulseLook=look, InpAtrPeriod=14,
                InpHtfEmaPeriod=200, InpPinWickRatio=wick, InpCloseInZoneMin=0.15,
                InpMinStopPips=2.5, InpBufferAtrFrac=0.25, InpMaxSpreadPts=80,
                InpUseHourFilter=True, InpExcludedHoursCSV="6,7,12,15,19,23",
                InpUseDailyStop=True, InpDailyStopR=3.0, InpMaxTradesDay=0,
                InpUtcOffset=2, InpVerbose=False)


def main():
    mg = 755000
    RUNS = [
        ("T20-A05-TR15-W15", 2.0, 1.5, 0.5, 1.5, 0.9, 6),
        ("T20-A05-TR10-W12", 2.0, 1.0, 0.5, 1.2, 0.9, 6),
        ("T25-A05-TR15-W12", 2.5, 1.5, 0.5, 1.2, 0.9, 6),
        ("T25-A10-TR15-W15", 2.5, 1.5, 1.0, 1.5, 0.9, 6),
        ("T30-A05-TR15-W20", 3.0, 1.5, 0.5, 2.0, 0.9, 6),
        ("T20-A05-LOOK4", 2.0, 1.5, 0.5, 1.5, 0.9, 4),
        ("T20-A05-IMP12", 2.0, 1.5, 0.5, 1.5, 1.2, 6),
        ("T20-A05-W12-IMP12", 2.0, 1.5, 0.5, 1.2, 1.2, 6),
    ]
    with open(OUT, "a", encoding="utf-8") as fo:
        for tag, tpr, trail, after, wick, imp, look in RUNS:
            mg += 1
            c = cfg(mg, tpr, trail, after, wick, imp, look)
            print(f"[r189 {tag}] EURUSD 2024 ...", flush=True)
            r = RF.run_backtest("C13V2T_EA", symbol="EURUSD", tf="M5",
                                from_d="2024.01.01", to_d="2025.01.01",
                                deposit=10000, max_wait=3600, inputs=c)
            fo.write(json.dumps({"tag": tag, "r": r}, default=str) + "\n")
            fo.flush()
            print(f"[{tag}] " + ("null" if r is None else
                  f"p={r.get('profit')} n={r.get('trades')} "
                  f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
            time.sleep(2)
    print("FIN r189", flush=True)


if __name__ == "__main__":
    main()
