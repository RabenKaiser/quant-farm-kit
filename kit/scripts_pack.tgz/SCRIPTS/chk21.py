﻿import pickle, numpy as np
p = r"C:\EAFarm\HISTORY - Copy\research\pos_cache\AUDJPY.pkl"
d = pickle.load(open(p,"rb"))
print(f"jambes : {len(d)}")
k = list(d)[0]; v = d[k]
print(f"champs : {list(v.keys())}")
print(f"exemple: {k[:60]}")
print()
# LA VERIFICATION CRITIQUE : y a-t-il des jambes PERDANTES ?
R = np.array([x["R"] for x in d.values()])
s1 = np.array([x["s1"]["rdd"] for x in d.values()])
s2 = np.array([x["s2"]["rdd"] for x in d.values()])
s3 = np.array([x["s3"]["rdd"] for x in d.values()])
print(f"R<0 : {(R<0).sum()} / {len(R)} = {100*(R<0).mean():.0f}%")
print(f"  <- DOIT etre ~50% : un cache non filtre contient des perdantes")
print()
print("=== PERSISTANCE s1 -> s3 (le test qui compte) ===")
ok = (s1>0)&(s3>0)
print(f"  rdd>0 sur s1 et s3 : {ok.sum()} / {len(s1)} = {100*ok.mean():.1f}%")
print(f"  correlation        : {np.corrcoef(s1,s3)[0,1]:+.3f}")
q = np.quantile(s1,[0.25,0.75])
top = s3[s1>=q[1]]; bot = s3[s1<=q[0]]
print(f"  top25% s1 -> s3 median = {np.median(top):+.3f}")
print(f"  bot25% s1 -> s3 median = {np.median(bot):+.3f}")
print(f"  ECART = {np.median(top)-np.median(bot):+.3f}")
