# -*- coding: utf-8 -*-
"""edge_test2.py — version CORRIGEE de edge_test (bug du dropna).

LE BUG
------
Dans `edge_test.py`, T1 faisait :
    v = ALL[k].dropna()          # <-- FAUX
    ... v.iloc[a:b] pour les tiers
`dropna()` supprime les jours sans trade. La serie se raccourcit (ex. 439 jours
au lieu de 1414). Les indices de tiers (0..471, 471..942, 942..1414) tombent
alors HORS de la serie -> s2 et s3 affichaient 0.00.

Cela a produit un faux diagnostic alarmant ("6 jambes sur 7 a zero en s2/s3")
alors que les trades existent bien (mesure : 102, 266, 165 trades en s2/s3).

CORRECTION : on garde la serie ALIGNEE sur l'index complet (fillna(0)) et on
decoupe les tiers par POSITION CALENDAIRE, pas par position dans la serie
fil tree.
"""
import os, sys, json, pickle
import numpy as np
import pandas as pd

BASE = r"C:\EAFarm\HISTORY - Copy\research"
S = pickle.load(open(os.path.join(BASE, "final7_series.pkl"), "rb"))
series, meta = S["series"], S["meta"]

ALL = pd.DataFrame(series).sort_index()
n = len(ALL); third = n // 3
segs_idx = [(0, third), (third, 2*third), (2*third, n)]
print(f"index complet : {n} jours, tiers de {third}")
for i, (a, b) in enumerate(segs_idx, 1):
    print(f"  s{i} : {ALL.index[a].date()} -> {ALL.index[b-1].date()}")


def rdd(v):
    if len(v) == 0:
        return 0.0
    x = v.to_numpy()
    eq = np.cumsum(x); R = float(x.sum())
    dd = float((np.maximum.accumulate(eq) - eq).max())
    return (R/dd) if dd > 0 else 0.0


print("\n" + "=" * 92)
print("T1 CORRIGE — chaque jambe SEULE, par segment calendaire")
print("=" * 92)
print(f"{'jambe':<42}{'s1':>9}{'s2':>9}{'s3':>9}{'prog':>8}")
t1 = {}
for k in ALL.columns:
    v = ALL[k].fillna(0.0)          # <-- ALIGNE, pas dropna
    rr = [rdd(v.iloc[a:b]) for a, b in segs_idx]
    t1[k] = rr
    prog = (rr[2]/rr[0]) if rr[0] > 0 else float('inf')
    nm = k.split("|")
    short = f"{nm[0]} {nm[1]}"
    print(f"{short[:41]:<42}{rr[0]:>9.2f}{rr[1]:>9.2f}{rr[2]:>9.2f}{prog:>8.1f}")

print("\n" + "=" * 92)
print("PROGRESSION s1 -> s3 : les jambes progresent-elles ENSEMBLE ?")
print("=" * 92)
progs = []
for k in ALL.columns:
    rr = t1[k]
    p = (rr[2]/rr[0]) if rr[0] > 0 else float('nan')
    progs.append(p)
    print(f"  {k[:56]:<58} {rr[0]:7.2f} -> {rr[2]:7.2f}  x{p:.1f}")
arr = np.array([p for p in progs if np.isfinite(p)])
print(f"\n  progression mediane : x{np.median(arr):.1f}")
print(f"  min x{arr.min():.1f}  max x{arr.max():.1f}")
if np.median(arr) > 3:
    print("  -> progression FORTE et generale : coherent avec un regime de")
    print("     reversion favorable en 2024-2025, PAS avec un artefact de calcul")
    print("     (un artefact toucherait les jambes differemment).")
else:
    print("  -> progression moderee")

# ---------- correlation et paris effectifs ----------
print("\n" + "=" * 92)
print("T2/T3 — CORRELATION et NOMBRE EFFECTIF DE PARIS")
print("=" * 92)
C = ALL.corr(min_periods=30)
off = C.where(~np.eye(len(C), dtype=bool))
print(f"  correlation moyenne : {float(off.stack().mean()):+.3f}")
print(f"  max {float(off.max().max()):+.3f}  min {float(off.min().min()):+.3f}")
print(f"  paires |rho|>0.5 : {int((off.abs() > 0.5).sum().sum()//2)}")
ev = np.sort(np.linalg.eigvalsh(C.fillna(0.0).to_numpy()))[::-1]
ev = ev[ev > 0]
neff = float(ev.sum()**2/(ev**2).sum())
print(f"  valeurs propres : " + " ".join(f"{v:.2f}" for v in ev))
print(f"  part 1re valeur propre : {100*ev[0]/ev.sum():.1f} %")
print(f"  NOMBRE EFFECTIF DE PARIS : {neff:.2f} sur {len(ALL.columns)}")

# ---------- mois par mois ----------
print("\n" + "=" * 92)
print("MOIS PAR MOIS (portefeuille complet)")
print("=" * 92)
x = ALL.fillna(0.0).mean(axis=1)
mo = x.groupby([x.index.year, x.index.month]).sum()
print(f"  {len(mo)} mois | positifs {int((mo>0).sum())} ({(mo>0).mean():.1%})")
print(f"  moyenne {mo.mean():+.3f} | mediane {mo.median():+.3f} | "
      f"ecart-type {mo.std():.3f}")
print(f"  pire {mo.min():+.3f} | meilleur {mo.max():+.3f}")
neg = mo[mo < 0]
print(f"\n  MOIS NEGATIFS ({len(neg)}) :")
for (y, m_), v in neg.items():
    print(f"    {y}-{m_:02d}  {v:+.3f}")

json.dump(dict(t1=t1, months=[float(v) for v in mo.values],
               corr_mean=float(off.stack().mean()), n_eff=neff,
               eigen=[float(v) for v in ev],
               progression=[float(p) for p in progs]),
          open(os.path.join(BASE, "edge_corrected.json"), "w"), indent=1)
print("\n-> edge_corrected.json")
