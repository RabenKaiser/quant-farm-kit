"""crest_exitaware : la difference d'execution qui separe CREST de MT5.

CREST (Python) occupe le creneau d'une paire pendant 32 barres MEME si le stop ou l'objectif
est touche avant. L'EA, elle, libere le creneau des que la position est fermee (SL ou TP) :
c'est pourquoi MT5 prend 437 positions par paire et par trimestre la ou CREST en prend 73.

La question qui decide de tout : l'esperance de CREST depend-elle de cette occupation longue ?
  - si OUI : MT5 ne peut pas reproduire CREST avec InpRearmBars=1, il faut un re-armement de
    32 barres, et la campagne a 437 positions mesure autre chose ;
  - si NON : alors le resultat MT5 (-0,25 R/tx sur 145 425 positions) juge bien CREST, et le
    modele Python est refute en ordres reels.

On mesure donc les deux regles cote a cote : occupation 32 barres (CREST) contre occupation
jusqu'a la sortie reelle (EA).
"""
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM
import portefeuille_tp2 as P2

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
H = 32


def detail(D, motif, sens, tpr=2.0):
    """R + index de sortie (0 = objectif, 1 = stop, 2 = echeance) pour chaque signal."""
    m = NM.motifs(D)
    sig = m[motif][0 if sens == "C" else 1]
    sig = P2.masque_selectif(D, sig)              # selectivite CREST (pos >= 0,97, vol normale)
    c, h, l, a = D["c"], D["h"], D["l"], D["a"]
    sig = np.asarray(sig, dtype=int)
    sig = sig[sig < len(c) - H - 2]
    sig = sig[np.isfinite(a[sig]) & (a[sig] > 0)]
    e, st = c[sig], a[sig]
    tp, sl = (e - tpr * st, e + st) if sens == "C" else (e + tpr * st, e - st)
    off = np.arange(1, H + 1)
    Hh, Ll, cl = h[sig[:, None] + off], l[sig[:, None] + off], c[sig + H]
    htp = (Ll <= tp[:, None]) if sens == "C" else (Hh >= tp[:, None])
    hsl = (Hh >= sl[:, None]) if sens == "C" else (Ll <= sl[:, None])
    it = np.where(htp.any(1), htp.argmax(1), 10 ** 6)
    isl = np.where(hsl.any(1), hsl.argmax(1), 10 ** 6)
    tp_hit, sl_hit = htp.any(1), hsl.any(1)
    kind = np.where(tp_hit & (~sl_hit | (it < isl)), 0, np.where(sl_hit, 1, 2))
    barre = np.where(kind == 0, it + 1, np.where(kind == 1, isl + 1, H))
    fin = ((e - cl) if sens == "C" else (cl - e)) / st
    R = np.where(kind == 0, tpr, np.where(kind == 1, -1.0, fin)) - D["cout"]
    ok = np.isfinite(R)
    return sig[ok], R[ok], barre[ok], kind[ok]


def bloque(idx, sig, R, barre, regle):
    """regle 'crest' = creneau occupe 32 barres ; regle 'ea' = libere a la sortie reelle."""
    garde, fin = [], None
    for k, i in enumerate(sig):
        t = idx[i]
        if fin is not None and t < fin:
            continue
        garde.append(k)
        duree = H if regle == "crest" else int(barre[k])
        fin = t + pd.Timedelta(minutes=30 * max(1, duree))
    g = np.array(garde, dtype=int)
    return g


def main():
    legs = [x for x in os.environ.get("LEGS", "EURCHF:SR50:C,EURGBP:SR100:C,GBPCHF:SR50:C").split(",") if x]
    tpr = float(os.environ.get("TP_R", "2.0"))
    print("cible %.1f R | selectivite actif | %d jambes" % (tpr, len(legs)), flush=True)
    for source in ("m1_pos", "m1_upcomers"):
        os.environ["SOURCE"] = source
        print("\n########## %s" % source, flush=True)
        for leg in legs:
            paire, motif, sens = leg.split(":")
            D = NM.charge(paire, source)
            if D is None:
                continue
            sig, R, barre, kind = detail(D, motif, sens, tpr)
            if len(R) < 30:
                print("  %-18s %-11s : %d signaux filtres (trop peu)" % (leg, source, len(R)), flush=True)
                continue
            part_early = float(np.mean(barre < 16))
            l1 = bloque(D["idx"], sig, R, barre, "crest")
            l2 = bloque(D["idx"], sig, R, barre, "ea")
            pj1 = defaultdict(float)
            pj2 = defaultdict(float)
            for k in l1:
                pj1[D["idx"][sig[k]].date()] += R[k]
            for k in l2:
                pj2[D["idx"][sig[k]].date()] += R[k]
            v1, v2 = sorted(pj1.values()), sorted(pj2.values())
            print("  %-18s %-11s signaux %5d | sortie avant 16 h dans %4.1f %% des cas"
                  % (leg, source, len(R), 100 * part_early), flush=True)
            print("      CREST (creneau 32 barres)   : %4d positions | R/tx %+.4f | R/jour moy %+.3f | pire %+.1f"
                  % (len(l1), np.mean(R[l1]), np.mean(v1), v1[0]), flush=True)
            print("      EA (creneau jusqu'a sortie) : %4d positions | R/tx %+.4f | R/jour moy %+.3f | pire %+.1f"
                  % (len(l2), np.mean(R[l2]), np.mean(v2), v2[0]), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
