﻿import pandas as pd
from datetime import datetime, timezone
p = r"C:\EAFarm\HISTORY - Copy\research\m1_real\XAUUSD_M1.csv"
# lit juste la colonne time (rapide)
t = pd.read_csv(p, usecols=["time"])
print("XAUUSD_M1.csv :", len(t), "barres")
d0 = datetime.fromtimestamp(int(t["time"].iloc[0]), tz=timezone.utc)
d1 = datetime.fromtimestamp(int(t["time"].iloc[-1]), tz=timezone.utc)
print("  plage :", d0, "->", d1)
# et la version upc ? (m1_page = ce que je viens d'exporter)
import os
q = r"C:\EAFarm\HISTORY - Copy\research\m1_page\GBPUSD_M1.csv"
if os.path.exists(q):
    t2 = pd.read_csv(q, usecols=["time"])
    a = datetime.fromtimestamp(int(t2["time"].iloc[0]), tz=timezone.utc)
    b = datetime.fromtimestamp(int(t2["time"].iloc[-1]), tz=timezone.utc)
    print(f"\nm1_page/GBPUSD : {len(t2)} barres  {a} -> {b}")
