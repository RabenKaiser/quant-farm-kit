# -*- coding: utf-8 -*-
"""audusd_duka_fix_r145.py — AUDUSD V3INT sur Duka 2017-2024: balayer
compression + sessions pour trouver une config durable (la 8-17 c050 est
negative). Fenetre longue 2017-2024 = ~60-80 trades, verdict robuste."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\audusd_duka_fix_r145.jsonl"


def v3(comp, mg, h1, h2):
    return dict(InpLots=0.10, InpMagic=mg, InpMaxDailyLossPct=3.0, InpUtcOffset=2,
                InpSlippage=30, InpStartH=h1, InpEndH=h2, InpCloseHH=20, InpCloseMM=30,
                InpTpAtr=1.0, InpSlAtr=2.0, InpMaxHold=96, InpAtrPct=comp,
                InpDonPct=comp, InpObvMode=0, InpMfiMode=0, InpVerbose=False)


def main():
    mg = 725000
    RUNS = [("c050-817", 0.50, 8, 17), ("c055-817", 0.55, 8, 17),
            ("c045-817", 0.45, 8, 17), ("c060-817", 0.60, 8, 17),
            ("c050-620", 0.50, 6, 20), ("c055-620", 0.55, 6, 20),
            ("c050-921", 0.50, 9, 21), ("c050-1017", 0.50, 10, 17)]
    with open(OUT, "a", encoding="utf-8") as fo:
        for tag, comp, h1, h2 in RUNS:
            mg += 1
            c = v3(comp, mg, h1, h2)
            print(f"[r145 AUDUSD {tag}] H1 2017.01->2024.01 ...", flush=True)
            r = RF.run_backtest("V3INT_EA", symbol="AUDUSD", tf="H1",
                                from_d="2017.01.01", to_d="2024.01.01",
                                deposit=10000, max_wait=3600, inputs=c)
            fo.write(json.dumps({"tag": tag, "comp": comp, "sess": f"{h1}-{h2}",
                                 "r": r}, default=str) + "\n")
            fo.flush()
            print(f"[{tag}] " + ("null" if r is None else
                  f"profit={r.get('profit')} n={r.get('trades')} "
                  f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
            time.sleep(2)
    print("FIN r145", flush=True)


if __name__ == "__main__":
    main()
