﻿import json
d = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\pos_baseline_6y.json", encoding="utf-8"))
print("contenu :", d)
print()
print("=> il manque le detail PAR JAMBE, indispensable pour un croisement par jambe.")
print("   et 'n3' dans pos_selection.json = segment s3 (2 ans), pas 6 ans.")
