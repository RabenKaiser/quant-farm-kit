# -*- coding: utf-8 -*-
"""add_risk_sizing.py — ajoute le sizing RISQUE FIXE a V3INT_EA:
- input InpRiskPct (>0) : risque % du capital par trade
- si >0, lots calcules a l'ouverture = risque$ / perte_SL_par_lot
- sinon InpLots fixe (comportement actuel)
Cree V3INT_EA_RISK.mq5 (copie patchee) dans eepeek + stack_eas."""
import io, sys, shutil
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

SRC = r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS\stack_eas\V3INT_EA.mq5"
DST1 = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\MQL5\Experts\eepeek\V3INT_EA_RISK.mq5"

with io.open(SRC, "r", encoding="utf-8-sig") as f:
    src = f.read()

# 1) input risque
old_in = "input double   InpLots        = 0.10;     // volume (0.10 lot GBPUSD ~= $1/pip)"
new_in = (old_in +
"\ninput double   InpRiskPct     = 0.0;     // RISQUE FIXE: % capital/trade (0 = lots fixes InpLots). Ex 1.0 = 1%")
assert old_in in src
src = src.replace(old_in, new_in)

# 2) prototype
old_p = "void OpenPos(int dirn, double px, double tp, double sl, double atr_i);"
new_p = old_p + "\ndouble RiskLots(double px, double sl);"
assert old_p in src
src = src.replace(old_p, new_p)

# 3) calcul lots dans OpenPos (remplacer req.volume = InpLots)
old_v = "   req.volume = InpLots;"
new_v = "   req.volume = (InpRiskPct > 0.0) ? RiskLots(px, sl) : InpLots;"
assert old_v in src
src = src.replace(old_v, new_v)

# 4) fonction RiskLots avant OpenPos
anchor = "void OpenPos(int dirn, double px, double tp, double sl, double atr_i) {"
fn = '''
//+------------------------------------------------------------------+
double RiskLots(double px, double sl) {
   // risque FIXE en % du capital: lots = risque$ / perte_SL_par_lot
   double riskUsd = AccountInfoDouble(ACCOUNT_EQUITY) * InpRiskPct / 100.0;
   if (riskUsd <= 0) return InpLots;
   double slDist = MathAbs(px - sl);
   if (slDist <= 0) return InpLots;
   // perte en $ pour 1.0 lot si le prix parcourt slDist:
   double tickVal = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if (tickVal <= 0 || tickSize <= 0) return InpLots;
   double perLot = slDist / tickSize * tickVal;
   if (perLot <= 0) return InpLots;
   double lots = riskUsd / perLot;
   double minL = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxL = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double stepL = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   if (stepL > 0) lots = MathFloor(lots / stepL) * stepL;
   if (lots < minL) lots = minL;
   if (lots > maxL) lots = maxL;
   return lots;
}

'''
assert anchor in src
src = src.replace(anchor, fn + anchor, 1)

with io.open(DST1, "w", encoding="utf-8") as f:
    f.write(src)
print("V3INT_EA_RISK.mq5 ecrit (eepeek) OK")
