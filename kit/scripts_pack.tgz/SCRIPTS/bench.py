# -*- coding: utf-8 -*-
"""bench.py — BANC DE TEST COURT, EVERY TICK, PLEIN DE STRUCTURES.

LA METHODE (demandee par l'utilisateur)
---------------------------------------
  1. On prend 2-3 mois. On lance PLEIN de structures en every tick (ticks reels).
  2. On garde celles qui marchent sur cette periode -> DECOUVERTE.
  3. On les revalide sur 3 AUTRES mois jamais vus -> VALIDATION.

Pourquoi ca marche mieux que ce qu'on faisait :
  - "Every tick" (Model=4) utilise les VRAIS ticks : pas de OHLC approximatif.
  - Court = rapide : 3 mois en every tick = ~30-60 s par run.
  - Beaucoup de structures en parallele = on balaye large au lieu de deviner.
  - Periodes DISJOINTES : ce qui marche sur mars ne doit pas etre du hasard
    d'avril. C'est la seule protection contre le surapprentissage.

DECOUPAGE
---------
  DECOUVERTE : 2024.01.01 -> 2024.04.01   (3 mois)
  VALIDATION : 2024.07.01 -> 2024.10.01   (3 mois, disjoint)
  CONFIRMATION: 2025.01.01 -> 2025.04.01  (3 mois, disjoint)

RESULTAT : on ne retient QUE les structures positives sur les 3 periodes.

USAGE
  python -u bench.py                  # decouverte, toutes structures
  python -u bench.py VAL              # validation
  python -u bench.py CONF             # confirmation
"""
import os, sys, json, time, glob, subprocess, re
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
FARM = Path(r"C:\EAFarm\MT5\Farm")
TM = FARM / "terminal64.exe"
DATA = (Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")
        / "CF0B997454318B475CF01419AFE2BBF3")
LOGD = DATA / "Tester" / "logs"
COMM = (Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")
        / "Common" / "Files")
CFGD = FARM / "Config"
OUT = BASE / "bench.json"

PERIODS = {
    "DISC": ("2024.01.01", "2024.04.01"),
    "VAL":  ("2024.07.01", "2024.10.01"),
    "CONF": ("2025.01.01", "2025.04.01"),
}

MODEL = 4          # 4 = EVERY TICK BASED ON REAL TICKS

# ---- TOUTES les structures VWAP / FVG / wick dispo dans l'EA ----
STRUCTS = [
    "FVGDN10", "FVGDN20",
    "VWAPXDN", "VWAPWXDN", "VWAPMXDN", "VWAP24XDN",
    "REJBULL", "PINBULL", "NOWICKDN",
    "SWEEPLO", "SWEEPLO20", "SWEEPLO50", "SWEEPLO100",
    "BRKLL20", "BRKLL50", "BRKLL100", "LLLH",
]
FILTS = ["", "VOLLO", "HQUIET"]

# sorties testees : le sweep a montre que tp_r=1.5 bat tp_r=3.0
EXITS = [
    (2.0, 1.5, 48),
    (2.0, 2.0, 48),
    (1.5, 1.5, 48),
]

SYMS = ["CADJPY", "EURUSD", "GBPJPY", "AUDUSD", "USDCHF", "EURJPY",
        "NZDUSD", "USDCAD", "EURGBP", "AUDJPY"]


def kill():
    """Tue UNIQUEMENT le terminal Dukascopy.

    BUG CORRIGE (round 61) : `taskkill /IM terminal64.exe` tue TOUS les
    terminaux MetaTrader, y compris celui d'Upcomers. Les deux benches
    lances en parallele s'entretuaient donc a chaque run.
    On cible le PID par le chemin du binaire.
    """
    subprocess.run(["taskkill", "/F", "/FI", "IMAGENAME eq terminal64.exe",
                    "/FI", "PID eq 0"], stdout=subprocess.DEVNULL,
                   stderr=subprocess.DEVNULL)
    # methode fiable : parcourir les processus et tuer ceux dont le chemin
    # correspond a NOTRE ferme
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='terminal64.exe'\" | "
          "Where-Object { $_.ExecutablePath -like 'C:\\EAFarm\\MT5\\Farm\\*' } | "
          "ForEach-Object { Stop-Process -Id $_.ProcessId -Force "
          "-ErrorAction SilentlyContinue }")
    subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def rotate():
    stamp = time.strftime("%Y%m%d_%H%M%S")
    for lf in glob.glob(str(LOGD / "*log*")):
        try:
            os.rename(lf, lf + ".old" + stamp)
        except Exception:
            try:
                open(lf, "w").close()
            except Exception:
                pass
    olds = sorted(glob.glob(str(LOGD / "*.old*")),
                  key=lambda p: os.path.getmtime(p))
    for p in olds[:-8]:
        try:
            os.remove(p)
        except Exception:
            pass


def write_tables(sym, sl, tp, hold):
    """Une table PAR structure, pour isoler chaque test."""
    files = {}
    for i, st in enumerate(STRUCTS):
        for j, fl in enumerate(FILTS):
            fn = f"BN_{sym}_{st}_{fl or 'N'}.csv"
            (COMM / fn).write_text(
                "%s,1,%s,%.3f,%.1f,%.3f,%d,%d\n"
                % (st, fl, sl, tp, 0.0, hold, 998000 + i * 10 + j),
                encoding="ascii")
            files[(st, fl)] = fn
    return files


def run(sym, fn, p0, p1, wait=900):
    cfg = CFGD / "bench.ini"
    cfg.write_text(
        "[Tester]\nExpert=eepeek\\ORION_ROBOT.ex5\nSymbol=%s\nPeriod=M5\n"
        "Model=%d\nOptimization=0\nFromDate=%s\nToDate=%s\nDeposit=100000\n"
        "Currency=USD\nLeverage=100\nReplaceReport=1\nShutdownTerminal=1\n"
        "[TesterInputs]\nInpLots=0.10\nInpMaxPos=1\nInpMaxPerSide=1\n"
        "InpLegsFile=%s\nInpMaxSpreadMult=0\nInpMaxSpreadAtr=0.6\n"
        "InpSessStart=0\nInpSessEnd=24\n"
        "InpDayStopPct=0\nInpMaxDDStopPct=0\n"
        "InpVerbose=true\nInpTrace=false\nInpNoHedge=true\n"
        % (sym, MODEL, p0, p1, fn))
    kill(); time.sleep(2); rotate()
    p = subprocess.Popen([str(TM), "/config:" + str(cfg)], cwd=str(FARM),
                         creationflags=0x08000000,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    w = 0
    while w < wait:
        time.sleep(2); w += 2
        rr = subprocess.run(["tasklist", "/FI", "PID eq %d" % p.pid],
                            capture_output=True, text=True)
        if "terminal64" not in rr.stdout:
            break
    kill(); time.sleep(2)
    best, bt = None, 0
    for lf in glob.glob(str(LOGD / "*log*")):
        try:
            if os.path.getsize(lf) < 300:
                continue
            t = os.path.getmtime(lf)
        except OSError:
            continue
        if t > bt:
            best, bt = lf, t
    if not best:
        return None
    raw = open(best, "rb").read()
    txt = (raw.decode("utf-16") if raw[:2] in (b"\xff\xfe", b"\xfe\xff")
           else raw.decode("utf-8", errors="replace"))
    mb = re.search(r"ORION BILAN %s sorties=(\d+) SL=(\d+) TP=(\d+) "
                   r"MAXHOLD=(\d+) autres=(\d+) gagnantes=(\d+) "
                   r"win=([\d.]+)%% pnl=(-?[\d.]+)" % sym, txt)
    if not mb:
        return None
    g = mb.groups()
    return dict(n=int(g[0]), sl=int(g[1]), tp=int(g[2]), mx=int(g[3]),
                win_n=int(g[5]), win=float(g[6]), pnl=float(g[7]))


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "DISC"
    p0, p1 = PERIODS[which]
    sl, tp, hold = 2.0, 1.5, 48
    res = json.load(open(OUT, encoding="utf-8")) if OUT.exists() else {}
    res.setdefault(which, {})

    total = len(SYMS) * len(STRUCTS) * len(FILTS)
    print("=" * 96)
    print(f"BANC DE TEST — {which}  ({p0} -> {p1})")
    print(f"Model=4 EVERY TICK (ticks reels) | {total} runs "
          f"({len(SYMS)} paires x {len(STRUCTS)} structures x {len(FILTS)} filtres)")
    print("=" * 96)
    t0 = time.time()
    done = 0
    for sym in SYMS:
        files = write_tables(sym, sl, tp, hold)
        res[which].setdefault(sym, {})
        for (st, fl), fn in files.items():
            k = f"{st}|{fl or 'N'}"
            if k in res[which][sym]:
                continue
            r = run(sym, fn, p0, p1)
            res[which][sym][k] = r
            done += 1
            if r and r["n"] >= 5:
                print(f"  [{done}/{total}] {sym:<7}{st:<11}{fl or '-':<8}"
                      f"n={r['n']:>3} SL={100*r['sl']/r['n']:>3.0f}% "
                      f"TP={100*r['tp']/r['n']:>3.0f}% win={r['win']:>5.1f}% "
                      f"pnl={r['pnl']:>8.2f}", flush=True)
            json.dump(res, open(OUT, "w"), indent=1)
        print(f"  --- {sym} fait ({time.time()-t0:.0f}s) ---", flush=True)

    print()
    print("=" * 96)
    print(f"SYNTHESE {which} — structures positives")
    print("=" * 96)
    agg = {}
    for sym in SYMS:
        for k, r in res[which].get(sym, {}).items():
            if not r or r["n"] < 5:
                continue
            a = agg.setdefault(k, dict(n=0, pnl=0.0, pos=0, tot=0, wins=0.0))
            a["n"] += r["n"]; a["pnl"] += r["pnl"]; a["tot"] += 1
            a["wins"] += r["win"] * r["n"]
            if r["pnl"] > 0:
                a["pos"] += 1
    rows = sorted(agg.items(), key=lambda kv: -kv[1]["pnl"])
    print(f"{'structure|filtre':<24}{'n':>7}{'pnl':>11}{'pos/tot':>10}{'win%':>8}")
    print("-" * 96)
    for k, a in rows[:25]:
        print(f"{k:<24}{a['n']:>7}{a['pnl']:>11.2f}"
              f"{a['pos']:>6}/{a['tot']:<4}{100*a['wins']/max(1,a['n']):>7.1f}%")
    print(f"\n-> {OUT}")
