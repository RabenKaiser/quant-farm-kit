﻿import glob, os, pickle
for name, pat in (("up_cache2 (UPC 8 mois)", r"C:\EAFarm\HISTORY - Copy\research\up_cache2\U_*.pkl"),
                  ("pos_cache (POS 6 ans)", r"C:\EAFarm\HISTORY - Copy\research\pos_cache\*.pkl"),
                  ("night_cache (duka 6 ans)", r"C:\EAFarm\HISTORY - Copy\research\night_cache\*.pkl")):
    fs = glob.glob(pat)
    tot = 0
    for f in fs:
        try:
            d = pickle.load(open(f,"rb")); tot += len(d)
        except Exception: pass
    mb = sum(os.path.getsize(f) for f in fs)/1e6
    print(f"  {name:<26} {len(fs):>3} fichiers  {tot:>8,} jambes  {mb:>8.1f} Mo")
