﻿import os
LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
for f in sorted(os.listdir(LOGD), key=lambda x: -os.path.getmtime(os.path.join(LOGD,x)))[:12]:
    p = os.path.join(LOGD, f)
    if os.path.getsize(p) < 500: continue
    raw=open(p,"rb").read(4)
    enc="utf-16" if raw[:2] in (b"\xff\xfe",b"\xfe\xff") else "utf-8"
    try: txt=open(p,encoding=enc,errors="replace").read()
    except Exception: continue
    n = txt.count("ORION OPEN")
    if n: print(f"  {f[:46]:<48} ORION OPEN = {n}")
