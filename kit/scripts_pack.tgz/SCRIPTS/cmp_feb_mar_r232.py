# -*- coding: utf-8 -*-
"""cmp_feb_mar_r232.py — comparaison EQUITABLE sur fevrier-mars 2024
(periode ou le parquet python a des donnees)."""
import sys, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F
import c13v2_py_v3 as PY
import c13v2_engine as ENG
import pandas as pd

# verifier le trou de donnees
m1 = PY.load_m1("EURUSD")
w = m1.loc["2024-01-01":"2024-02-05"]
print(f"parquet EURUSD entre 2024-01-01 et 2024-02-05: {len(w)} barres M1")
print(f"  min={w.index.min()} max={w.index.max()}")
print(f"parquet global: {m1.index.min()} -> {m1.index.max()}, {len(m1)} barres")

# MT5 trades fevrier-mars
LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
lp = os.path.join(LOGD, "20260910.log")
runs = F.parse_stream(lp, "C13V2")
mt5 = []
for key, data in runs.items():
    for t in data["trades"].values():
        if t["close"] is not None:
            d = str(t["ts_entry"])[:10]
            if d >= "2024.02.01":
                mt5.append((str(t["ts_entry"])[:16], t.get("ctype")))
mt5.sort()
print(f"\nMT5 fevrier-mars: {len(mt5)} trades")
for x in mt5:
    print(f"   {x[0]} {x[1]}")

# python fevrier-mars
BASE = {"imp_atr": 0.9, "imp_vol": 1.0, "imp_look": 6, "ob_age": 16,
        "rej_wick": 0.8, "rej_vol": 1.0, "close_zone": 0.15, "tp_r": 2.0,
        "bias": "vwap", "excl_hours": [6, 7, 12, 15, 19, 23],
        "min_stop": 0.00025, "buf_atr": 0.25, "lookahead": False, "vwap_len": 96}
start = pd.Timestamp("2024-02-01", tz="UTC")
end = pd.Timestamp("2024-04-01", tz="UTC")
wu = start - pd.Timedelta(days=260)
m5 = PY.resample(m1.loc[wu:end], "5min").loc[start:end]
m15 = PY.resample(m1.loc[wu:end], "15min")
h4 = PY.resample(m1.loc[wu:end], "4h")
r = ENG.run_exit(m5, m15, h4, dict(BASE), exit_mode="tp", tp_r=2.0)
print(f"\nPYTHON fevrier-mars: n={r['n']} pf={r['pf']:.2f} wr={r['wr']:.1f}%")
for t in sorted(r["trades"], key=lambda x: x[1]):
    print(f"   {pd.Timestamp(t[1]).strftime('%Y.%m.%d %H:%M')} R={t[0]:+.2f}")
