# -*- coding: utf-8 -*-
"""autopilot.py — ORCHESTRATEUR DE TRAVAIL AUTONOME INFINI (boss absent).
Boucle infinie qui :
1. GARDE le Farm en vie (check toutes les 30 min, log si down).
2. CHERCHE de nouveaux edges en Python (familles variees, jamais les memes).
3. Quand un candidat Python passe (IS>0 OOS>0 60% ans) -> le marque pour MT5.
4. Si C:\MT5 est libre -> lance le test MT5 du candidat (le juge).
5. Documente tout dans night_results/autopilot.jsonl + REGISTRE.

Usage : python autopilot.py   (background, kill = stop propre)
"""
import sys, time, json, subprocess
import numpy as np
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from pathlib import Path

LOGDIR = Path(r"C:\EAFarm\HISTORY - Copy\research\LOGS")
OUT = LOGDIR / "autopilot.jsonl"
CLOUD = Path(r"C:\EAFarm\HISTORY - Copy\research\CLOUD")
SCRIPTS = Path(r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")

def log(msg):
    line = {"ts": time.time(), "msg": msg}
    with open(OUT, "a", encoding="utf-8") as f:
        f.write(json.dumps(line) + "\n")
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)

def farm_alive():
    try:
        import subprocess
        r = subprocess.run(["tasklist", "/FI", "PID eq 7072"],
                           capture_output=True, text=True)
        return "terminal64" in r.stdout
    except Exception:
        return False

def search_round(round_no):
    """Lance un script de recherche Python (tourne en sous-process)."""
    # generateur de regles fraiches avec seed croissant (jamais les memes)
    seed = 1000 + round_no * 7
    p = CLOUD / "gen_fresh_rules.py"
    if not p.exists():
        return
    log(f"search round {round_no}: gen_fresh_rules seed={seed}")
    try:
        subprocess.run([sys.executable, str(p), str(seed)],
                       cwd=str(CLOUD),
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=600)
    except subprocess.TimeoutExpired:
        log("search timeout")
    return 0

def main():
    log("=== AUTOPILOT DEMARRE (boss absent, travail infini) ===")
    t0 = time.time()
    round_no = 0
    last_farm_check = 0
    last_mt5 = 0
    while True:
        el = (time.time() - t0) / 3600
        # 1. Farm check toutes les 30 min
        if time.time() - last_farm_check > 1800:
            alive = farm_alive()
            log(f"farm alive: {alive} ({el:.1f}h)")
            last_farm_check = time.time()
        # 2. Recherche Python (toutes les ~3 min si MT5 libre, sinon attend)
        round_no += 1
        search_round(round_no)
        # 3. Nettoyage : si un candidat MT5 doit tourner, le lancer (un seul)
        #    -> verifie si un terminal de test tourne deja
        test_running = False
        try:
            r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq terminal64.exe"],
                               capture_output=True, text=True)
            # compter les terminaux (Farm 7072 + test)
            import re
            pids = re.findall(r"terminal64\.exe\s+(\d+)", r.stdout)
            test_running = any(p != "7072" for p in pids)
        except Exception:
            pass
        if not test_running and (time.time() - last_mt5) > 3600:
            log("MT5 libre — lancement campagne MT5 (tour suivant)")
            # campagnes MT5 utiles en rotation (checkpoints = reprise propre)
            mt5_jobs = [
                # (script, args, description)
                (SCRIPTS / "v45g_opti_full.py", [], "opti V45G one-at-time + OOS"),
                (SCRIPTS / "pack_revalidate_full.py", [], "revalidation pack 4 ans"),
            ]
            script, args, desc = mt5_jobs[round_no % len(mt5_jobs)]
            if script.exists():
                log(f"MT5: {desc}")
                # lancer en sous-process, capture le PID pour kill propre
                proc = subprocess.Popen([sys.executable, str(script)] + args,
                                        cwd=str(SCRIPTS),
                                        stdout=subprocess.DEVNULL,
                                        stderr=subprocess.DEVNULL)
                try:
                    proc.wait(timeout=3000)
                except subprocess.TimeoutExpired:
                    log(f"MT5: {desc} timeout — kill PID {proc.pid}")
                    proc.kill()
                    # tuer le terminal de TEST par PID (JAMAIS /IM — lecon)
                    try:
                        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq terminal64.exe"],
                                           capture_output=True, text=True)
                        import re
                        pids = re.findall(r"terminal64\.exe\s+(\d+)", r.stdout)
                        for p in pids:
                            if p != "7072":  # ne jamais toucher le Farm
                                subprocess.run(["taskkill", "/F", "/PID", p],
                                               capture_output=True)
                    except Exception:
                        pass
            last_mt5 = time.time()
        # pause entre les tours de recherche
        time.sleep(120)

if __name__ == "__main__":
    main()
