﻿src = open(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\MQL5\Experts\eepeek\ORION_ROBOT.mq5", encoding="utf-8").read()
i = src.find('t == "RSIXUP"')
print(src[i-60:i+420])
