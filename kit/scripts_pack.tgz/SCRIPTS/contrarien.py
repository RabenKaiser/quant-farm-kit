"""contrarien.py — ROUND 68 : SHORTER CE QUI A LE PLUS TENDU ?

Le round 67 a etabli deux choses.
  1. La derive NE predit PAS le plafond suivant (-0,264 hors echantillon).
  2. MAIS la derive est tres persistante (Spearman +0,865) alors que le PLAFOND
     de la tendance s'inverse : plafond long moyen 0,882 pour les couples a
     faible derive contre 0,141 pour ceux a forte derive.
Ce qui persiste est le mouvement ; ce qui s'inverse est la rentabilite du
mouvement. D'ou la regle candidate : SHORTER les couples qui ont le plus tendu.

POURQUOI CETTE PISTE MERTE UN TEST. Elle est entierement connaissable d'avance --
la derive de 2020-2023 est connue avant de trader 2024-2026 -- elle ne demande
aucune donnee exterieure et aucun modele. C'est la premiere piste contrarienne,
ex-ante et gratuite du projet.

PROTOCOLE, fixe avant resultat.
  - Trame M30, stop 2 ATR, objectif 6 ATR (1:3, centre de la bande demandee),
    detention 32 barres, cout deduit de chaque transaction.
  - Derive de chaque paire sur 2020-2023, sur les cloches M30.
  - Groupe FORT = tiers superieur de derive, groupe FAIBLE = tiers inferieur.
  - On mesure le R/tx SHORT et le R/tx LONG sur 2024-2026 dans chaque groupe,
    plus le R/DD mensuel du panier short du groupe fort.
  - Reserves annoncees d'avance : ~5 paires par groupe, donc un ou deux outliers
    peuvent tout faire. Les COMPTES (combien de paires positives) comptent plus
    que les moyennes.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
M1 = Path(r"C:\EAFarm\HISTORY - Copy\research\m1_pos")
PAIRES = ["EURUSD", "GBPUSD", "AUDUSD", "NZDUSD", "USDCAD", "USDCHF", "EURGBP",
          "USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "CADJPY", "CHFJPY",
          "SPXUSD", "NSXUSD", "UDXUSD"]
POINT = {"EURUSD": 1e-5, "GBPUSD": 1e-5, "AUDUSD": 1e-5, "NZDUSD": 1e-5,
         "USDCAD": 1e-5, "USDCHF": 1e-5, "EURGBP": 1e-5,
         "USDJPY": 1e-3, "EURJPY": 1e-3, "GBPJPY": 1e-3,
         "AUDJPY": 1e-3, "CADJPY": 1e-3, "CHFJPY": 1e-3,
         "SPXUSD": 1.0, "NSXUSD": 1.0, "UDXUSD": 1e-3}
HOLD, STOP_ATR, RR = 32, 2.0, 3.0
AN = (2020, 2021, 2022, 2023)
RE = (2024, 2025, 2026)


def charge(p):
    f = M1 / ("%s_M1.csv" % p)
    if not f.exists():
        return None
    d = pd.read_csv(f, usecols=["time", "high", "low", "close", "spread"])
    d["t"] = pd.to_datetime(d["time"], unit="s", utc=True)
    b = d.set_index("t").resample("30min").agg(
        high=("high", "max"), low=("low", "min"), close=("close", "last"),
        sp=("spread", "median")).dropna()
    tr = pd.concat([b.high - b.low, (b.high - b.close.shift()).abs(),
                    (b.low - b.close.shift()).abs()], axis=1).max(axis=1)
    b["atr"] = tr.rolling(14).mean()
    b = b.dropna()
    b.attrs["cout"] = float(d["spread"].median() or 0) * POINT[p] / float(b.atr.median())
    return b


def simule(b, sens):
    h, l, c, a = b.high.values, b.low.values, b.close.values, b.atr.values
    t = b.index
    n = len(b) - HOLD - 1
    idx = np.arange(20, n)
    at = a[idx]
    ok = at > 0
    idx, at = idx[ok], at[ok]
    off = np.arange(1, HOLD + 1)
    R, T = [], []
    for d0 in range(0, len(idx), 20000):
        ii = idx[d0:d0 + 20000]
        e = c[ii]
        stop = STOP_ATR * at[d0:d0 + 20000]
        H = h[ii[:, None] + off]
        L = l[ii[:, None] + off]
        if sens > 0:
            ht, hs = H >= (e + RR * stop)[:, None], L <= (e - stop)[:, None]
        else:
            ht, hs = L <= (e - RR * stop)[:, None], H >= (e + stop)[:, None]
        it = np.where(ht.any(1), ht.argmax(1), 10 ** 6)
        isl = np.where(hs.any(1), hs.argmax(1), 10 ** 6)
        cl = c[ii + HOLD]
        fin = (cl - e) / stop if sens > 0 else (e - cl) / stop
        R.append(np.where(it < isl, RR, np.where(isl < it, -1.0, fin)))
        T.append(t[ii])
    return np.concatenate(R), pd.DatetimeIndex(np.concatenate(T))


lignes = []
for p in PAIRES:
    b = charge(p)
    if b is None:
        continue
    an = b[b.index.year.isin(AN)].close
    if len(an) < 5000:
        continue
    derive = float(np.log(float(an.iloc[-1]) / float(an.iloc[0])))
    cout = b.attrs["cout"] / STOP_ATR
    Rl, Tl = simule(b, +1)
    Rs, Ts = simule(b, -1)
    ml = np.isin(Tl.year, RE)
    ms = np.isin(Ts.year, RE)
    lignes.append(dict(p=p, derive=derive, cout=cout,
                       long=Rl[ml].mean() - cout, short=Rs[ms].mean() - cout,
                       ml=pd.Series(Rl[ml] - cout,
                                    index=pd.DatetimeIndex(Tl[ml])).resample("ME").mean(),
                       msh=pd.Series(Rs[ms] - cout,
                                     index=pd.DatetimeIndex(Ts[ms])).resample("ME").mean()))

tiers = max(3, len(lignes) // 3)
trie = sorted(lignes, key=lambda x: -x["derive"])
fort, faible = trie[:tiers], trie[-tiers:]
print("couples mesures : %d | groupe fort %d | groupe faible %d"
      % (len(lignes), len(fort), len(faible)))
print("\n=== LA REGLE CONTRARIENNE : SHORTER CE QUI A LE PLUS TENDU ===")
print("%-8s | %8s | %9s | %9s | %8s" % ("paire", "derive A", "SHORT net", "LONG net", "cout R"))
for x in fort:
    print("%-8s | %+8.1f | %+9.4f | %+9.4f | %8.4f"
          % (x["p"], 100 * x["derive"], x["short"], x["long"], x["cout"]))

print("\n=== COMPARAISON DES GROUPES (R/tx net 2024-2026) ===")
for nom, g in (("derive FORTE (tiers haut)", fort), ("derive FAIBLE (tiers bas)", faible)):
    sh = [x["short"] for x in g]
    lo = [x["long"] for x in g]
    print("   %-26s n=%d | SHORT %+.4f (%d/%d positifs) | LONG %+.4f (%d/%d positifs)"
          % (nom, len(g), np.mean(sh), sum(1 for v in sh if v > 0), len(sh),
             np.mean(lo), sum(1 for v in lo if v > 0), len(lo)))
print("   %-26s      | SHORT %+.4f (%d/%d positifs)"
      % ("TOUTES paires", np.mean([x["short"] for x in lignes]),
         sum(1 for x in lignes if x["short"] > 0), len(lignes)))

# panier : short du groupe fort, une jambe par paire
pan = pd.DataFrame({x["p"]: x["msh"] for x in fort}).fillna(0.0)
tot = pan.sum(axis=1)
cum = tot.cumsum()
dd = float((cum - cum.cummax()).min())
print("\n=== PANIER CONTRARIEN : SHORT des %d couples du tiers fort ===" % len(fort))
print("   mois %s -> %s (%d mois)" % (tot.index[0].date(), tot.index[-1].date(), len(tot)))
print("   R mensuel moyen %+.4f | mois positifs %d/%d | R cumule %+.2f | DD %.2f | R/DD %.2f"
      % (tot.mean(), int((tot > 0).sum()), len(tot), cum.iloc[-1], dd,
         (cum.iloc[-1] / abs(dd)) if dd else 99.0))
print("   critere de gel : R/DD >= 3 -> %s"
      % ("ATTEINT" if dd and cum.iloc[-1] / abs(dd) >= 3 else "NON ATTEINT"))
