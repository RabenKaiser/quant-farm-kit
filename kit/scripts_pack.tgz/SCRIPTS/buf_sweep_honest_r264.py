# -*- coding: utf-8 -*-
"""buf_sweep_honest_r264.py — Le buf_atr optimal se deplace-t-il quand on
passe au python HONNETE (ATR15 + seuil + slippage) ?

Motivation: buf16 etait optimal en ATR5 sans slippage. Avec slippage 1pt et
ATR15, la distance de SL change de nature (ATR15 ~1.8x ATR5) -> la valeur
optimale de buf doit etre re-balayee.

Grille: buf in {1.5, 2, 3, 4, 6, 8, 10, 12, 16, 20, 24} x ext in {2,3,4,6,8,12}
sur les marches PROPRES, SEQ 2020-2023 + VAL 2024-2025.
"""
import sys, json, itertools, time
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import c13v2_py_v3 as F
import c13v2_engine as ENG
import pandas as pd, numpy as np

CLEAN = {"AUDUSD": (0.0001, 1.5), "NZDUSD": (0.0001, 2.0), "USDCAD": (0.0001, 1.8),
         "AUDCAD": (0.0001, 2.0), "XAUUSD": (0.01, 20.0)}

BASE = {"imp_atr": 0.7, "imp_vol": 1.0, "imp_look": 6, "ob_age": 32,
        "rej_wick": 0.4, "rej_vol": 1.0, "close_zone": 0.15,
        "bias": "vwap", "excl_hours": [6, 7, 12, 15, 19, 23],
        "lookahead": False, "vwap_len": 96, "tp_r": 99, "min_stop": 0.00025}

BUFS = [1.5, 2.0, 3.0, 4.0, 6.0, 8.0, 10.0, 12.0, 16.0, 20.0, 24.0]
EXTS = [2.0, 3.0, 4.0, 6.0, 8.0, 12.0]

def frames(sym, y0, y1):
    m1 = F.load_m1(sym)
    s = pd.Timestamp(f"{y0}-01-01", tz="UTC"); e = pd.Timestamp(f"{y1+1}-01-01", tz="UTC")
    wu = s - pd.Timedelta(days=260)
    w = m1.loc[wu:e]
    m5 = F.resample(w, "5min").loc[s:e]
    m15 = F.resample(w, "15min")
    h4 = F.resample(w, "4h")
    a15 = ENG.SW.F.atr_s(m15, 14)
    a15i = a15.reindex(a15.index.union(m5.index)).ffill().reindex(m5.index)
    return m5, m15, h4, a15i.to_numpy()

CACHE = {}
def get(sym, y0, y1):
    k = (sym, y0, y1)
    if k not in CACHE:
        CACHE[k] = frames(sym, y0, y1)
    return CACHE[k]

def bt(sym, ps, sp, buf, ext, y0, y1):
    m5, m15, h4, a15 = get(sym, y0, y1)
    cf = dict(BASE); cf["buf_atr"] = buf
    r = ENG.run_exit(m5, m15, h4, cf, exit_mode="extend", ext_atr=ext, tp_r=99,
                     spread_pips=sp, point_size=ps,
                     atr_ref=a15, ext_fill="thresh", slip_points=1.0)
    return r["n"], r["R"], r["pf"]

print("=" * 100)
print("R264 — RE-BALAYAGE buf_atr x ext_atr EN PYTHON HONNETE (ATR15+seuil+slip1)")
print("=" * 100)
print(f"grille: {len(BUFS)} bufs x {len(EXTS)} exts x 5 marches x 2 phases = "
      f"{len(BUFS)*len(EXTS)*5*2} backtests")

t0 = time.time()
rows = []
for buf in BUFS:
    for ext in EXTS:
        seqR = valR = 0.0; seqn = valn = 0; seqpf = []; valpf = []
        for sym, (ps, sp) in CLEAN.items():
            n, R, p = bt(sym, ps, sp, buf, ext, 2020, 2023)
            seqR += R; seqn += n
            if n >= 15: seqpf.append(p)
            n2, R2, p2 = bt(sym, ps, sp, buf, ext, 2024, 2025)
            valR += R2; valn += n2
            if n2 >= 15: valpf.append(p2)
        spf = float(np.mean(seqpf)) if seqpf else 0
        vpf = float(np.mean(valpf)) if valpf else 0
        rows.append(dict(buf=buf, ext=ext, seqn=seqn, seqR=seqR, seqpf=spf,
                         valn=valn, valR=valR, valpf=vpf,
                         ratio=valR / seqR if seqR else 0))
        print(f"buf{buf:5.1f} ext{ext:5.1f} | SEQ n={seqn:4d} R={seqR:+7.0f} pf={spf:5.2f} "
              f"| VAL n={valn:4d} R={valR:+7.0f} pf={vpf:5.2f} | ratio={rows[-1]['ratio']:.3f}")

print(f"\nduree: {time.time()-t0:.0f}s")
rows.sort(key=lambda r: -(r["valpf"] * (1 if r["valR"] > 0 else 0)))
print("\n=== TOP 10 par pf VALIDATION (R>0) ===")
for r in rows[:10]:
    print(f"  buf{r['buf']:5.1f} ext{r['ext']:5.1f} | SEQ {r['seqR']:+7.0f}R pf{r['seqpf']:.2f} "
          f"| VAL {r['valR']:+7.0f}R pf{r['valpf']:.2f} | n={r['valn']}")

print("\n=== TOP 10 par R VALIDATION ===")
for r in sorted(rows, key=lambda x: -x["valR"])[:10]:
    print(f"  buf{r['buf']:5.1f} ext{r['ext']:5.1f} | SEQ {r['seqR']:+7.0f}R pf{r['seqpf']:.2f} "
          f"| VAL {r['valR']:+7.0f}R pf{r['valpf']:.2f} | n={r['valn']}")

# robustesse: meilleur par pf minimum des deux phases
print("\n=== TOP 10 par min(pf SEQ, pf VAL) = robustesse ===")
for r in sorted(rows, key=lambda x: -min(x["seqpf"], x["valpf"]))[:10]:
    print(f"  buf{r['buf']:5.1f} ext{r['ext']:5.1f} | SEQ pf{r['seqpf']:.2f} | "
          f"VAL pf{r['valpf']:.2f} | R seq {r['seqR']:+.0f} val {r['valR']:+.0f}")

json.dump(rows, open(r"C:\EAFarm\HISTORY - Copy\research\RESULTS_C13V2\r264_bufsweep_honest.json", "w"),
          indent=1)
print("\nSaved r264_bufsweep_honest.json")
print("FIN", flush=True)
