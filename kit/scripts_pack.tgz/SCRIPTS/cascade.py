# -*- coding: utf-8 -*-
"""cascade.py — CASCADE DE QUALITE DE DONNEES.

IDEE DIRECTRICE (utilisateur)
-----------------------------
On a plusieurs jeux de donnees de qualites ET de durees differentes. On les
utilise EN CASCADE :

  ETAGE 1 — H1 longue duree  (indices Dukascopy 2019-2026, 21-45 k barres)
            -> EXPLORER LARGE : quelles structures tiennent sur 7 ans et sur
               des marches TRES differents (13 indices de pays distincts) ?

  ETAGE 2 — M5 duree moyenne (FX + metaux Dukascopy, 6 ans, ~450 k barres)
            -> AFFINER : la structure tient-elle en intraday sur du FX ?

  ETAGE 3 — M5 courte duree  (Upcomers, 8 mois) + ticks reels
            -> VALIDER : est-elle executables sur un 2e flux ?

  ETAGE 4 — M1 15 jours (extraits Dukascopy) + ticks reels
            -> CONFIRMER : le SL serre est-il touche par le VRAI marche ?

Une structure qui passe les 4 etages est solide.
Une structure qui echoue a un etage est ecartee.

CE SCRIPT : ETAGE 1 — indices en H1.
  - charge les 13 indices Dukascopy en H1 (copie MT5 -> CSV)
  - calcule les structures robustes identifiees (fvg_dn, brk_ll, ll_lh, vwap)
  - mesure sur 3 tiers disjoints
  - ne retient que celles positives sur les 3 tiers ET sur >= 10/13 indices

SORTIE : cascade_h1_indices.json
"""
import os, sys, json, time
from pathlib import Path
from collections import defaultdict
import numpy as np
import pandas as pd
try:
    import MetaTrader5 as mt5     # cache CSV deja rempli -> import facultatif
except ImportError:
    mt5 = None

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
OUT = BASE / "cascade_h1_indices.json"
CACHE = BASE / "h1_idx"
CACHE.mkdir(exist_ok=True)

INDICES = ["USA500.IDX", "USATECH.IDX", "DEU.IDX", "GBR.IDX", "JPN.IDX",
           "EUS.IDX", "AUS.IDX", "HKG.IDX", "CHI.IDX", "ESP.IDX",
           "NLD.IDX", "CHE.IDX", "USSC2000.IDX", "VOL.IDX"]
# Round 59 : sl_tp_sweep.py a montre que SL=1/TP=6 n'est pas le bon reglage.
# Le rapport gagnant est 2:3 avec un hold court (48 barres sur les 2 etages).
SL, TP, HOLD = 2.0, 3.0, 48        # H1 : 48 barres = 2 jours


def load_h1(sym):
    p = CACHE / f"{sym.replace('.', '_')}_H1.csv"
    if p.exists() and p.stat().st_size > 100_000:
        return pd.read_csv(p, parse_dates=["time"])
    ok = mt5.initialize(path=r"C:\EAFarm\MT5\Farm\terminal64.exe")
    if not ok:
        return None
    i = mt5.symbol_info(sym)
    if i is None:
        mt5.shutdown(); return None
    if not i.visible:
        mt5.symbol_select(sym, True); time.sleep(0.3)
    r = mt5.copy_rates_from_pos(sym, mt5.TIMEFRAME_H1, 0, 60000)
    mt5.shutdown()
    if r is None or len(r) < 5000:
        return None
    df = pd.DataFrame(r)
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df[["time", "open", "high", "low", "close", "tick_volume"]]
    df.to_csv(p, index=False)
    return df


def masks(df):
    h = df["high"].to_numpy(float); l = df["low"].to_numpy(float)
    o = df["open"].to_numpy(float); c = df["close"].to_numpy(float)
    v = df["tick_volume"].to_numpy(float)
    pc = np.roll(c, 1); pc[0] = c[0]
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    atr = pd.Series(tr).ewm(alpha=1/14, adjust=False).mean().to_numpy()
    M = {}
    for W in (20, 50, 100):
        hi = pd.Series(h).rolling(W).max().shift(1).to_numpy()
        lo = pd.Series(l).rolling(W).min().shift(1).to_numpy()
        M[f"brk_ll_{W}"] = (c < lo) & (np.roll(c, 1) >= np.roll(lo, 1))
        M[f"ll_lh_{W}"] = (h < hi) & (l < lo)
        M[f"sweep_lo_{W}"] = (l < lo) & (c > o)
    for mu, tag in ((1.0, "10"), (2.0, "20")):
        gd = h < (np.roll(l, 2) - mu * atr); gd[:3] = False
        M[f"fvg_dn_{tag}"] = gd
    idx = df["time"]
    tp_ = (h + l + c) / 3.0
    day = idx.dt.normalize().to_numpy()
    week = (idx.dt.isocalendar().year.astype(str) + "_" +
            idx.dt.isocalendar().week.astype(str)).to_numpy()
    for key_, nm in ((day, "D"), (week, "W")):
        pv = pd.Series(tp_ * v).groupby(key_).cumsum().to_numpy()
        vv = pd.Series(v).groupby(key_).cumsum().to_numpy()
        vw = pv / np.where(vv > 0, vv, np.nan)
        M[f"xdn_vwap{nm}"] = (c < vw) & (np.roll(c, 1) >= np.roll(vw, 1))
    hr = idx.dt.hour.to_numpy()
    M["h_quiet"] = (hr >= 22) | (hr < 6)
    vma = pd.Series(v).rolling(50).mean().shift(1).to_numpy()
    M["vol_lo"] = v < 0.6 * vma
    m50 = pd.Series(c).rolling(50).mean().shift(1).to_numpy()
    s50 = pd.Series(c).rolling(50).std().shift(1).to_numpy()
    z = (c - m50) / np.where(s50 > 0, s50, np.nan)
    M["bb_low"] = z < -2.0
    return M, atr


def bt(df, mask, atr):
    h = df["high"].to_numpy(float); l = df["low"].to_numpy(float)
    c = df["close"].to_numpy(float); o = df["open"].to_numpy(float)
    N = len(c); idx = np.where(mask)[0]
    rets = []; last = -1
    for i in idx:
        if i <= last or i + 2 >= N:
            continue
        e = i + 1; a = atr[i]
        if not np.isfinite(a) or a <= 0:
            continue
        entry = o[e]; sl = entry - SL * a; tp = entry + TP * a
        r = None
        for k in range(e, min(e + HOLD, N)):
            if l[k] <= sl:
                r = -SL; last = k; break
            if h[k] >= tp:
                r = TP; last = k; break
        if r is None:
            k = min(e + HOLD - 1, N - 1)
            r = (c[k] - entry) / a; last = k
        rets.append(r)
    if not rets:
        return None
    x = np.array(rets); n = len(x); t3 = max(n // 3, 1)
    return dict(n=n, R=float(x.sum()), Rmoy=float(x.mean()),
                win=float((x > 0).mean()),
                s1=float(x[:t3].sum()), s2=float(x[t3:2*t3].sum()),
                s3=float(x[2*t3:].sum()),
                stable=bool(all(float(x[k:k+t3].sum()) > 0
                                for k in (0, t3, 2*t3))))


STRUCTS = ["fvg_dn_10", "fvg_dn_20", "brk_ll_20", "brk_ll_50", "brk_ll_100",
           "ll_lh_50", "ll_lh_100", "sweep_lo_50", "xdn_vwapD", "xdn_vwapW"]
FILTS = ["h_quiet", "bb_low", "vol_lo", ""]

if __name__ == "__main__":
    res = defaultdict(dict)
    print("=" * 92)
    print("ETAGE 1 — INDICES EN H1 (2019-2026) : ou les structures tiennent-elles ?")
    print("=" * 92)
    for sym in INDICES:
        df = load_h1(sym)
        if df is None or len(df) < 5000:
            print(f"  {sym:<14} donnees insuffisantes"); continue
        M, atr = masks(df)
        nb = 0
        for st in STRUCTS:
            if st not in M:
                continue
            for f in FILTS:
                m = M[st] & M[f] if f else M[st]
                if m.sum() < 30:
                    continue
                r = bt(df, m, atr)
                if r is None:
                    continue
                res[(st, f or "-")][sym] = r
                nb += 1
        print(f"  {sym:<14}{len(df):>7} barres H1  {nb:>4} mesures"
              f"  du {df['time'].iloc[0].date()} au {df['time'].iloc[-1].date()}")

    print()
    print("=" * 92)
    print("REPLICATION SUR LES INDICES (structure x filtre)")
    print("=" * 92)
    print(f"{'structure|filtre':<24}{'idx':>5}{'positifs':>10}{'STABLES':>9}"
          f"{'R moy':>9}{'win':>7}")
    out = []
    for k, d in res.items():
        if len(d) < 6:
            continue
        pos = sum(1 for v in d.values() if v["R"] > 0)
        stab = sum(1 for v in d.values() if v["stable"])
        Rm = float(np.mean([v["R"] for v in d.values()]))
        w = float(np.mean([v["win"] for v in d.values()]))
        out.append(dict(key=k, n=len(d), pos=pos, stable=stab, Rmoy=Rm, win=w))
    out.sort(key=lambda r: -r["stable"])
    for r in out:
        # BUG CORRIGE (round 59) : `r['key']` est un TUPLE (structure, filtre),
        # pas une chaine -> `r['key'][:23]` levait
        # "unsupported format string passed to tuple.__format__".
        lbl = "%s|%s" % (r["key"][0], r["key"][1])
        print(f"{lbl[:23]:<24}{r['n']:>5}{r['pos']:>10}{r['stable']:>9}"
              f"{r['Rmoy']:>9.1f}{100*r['win']:>6.0f}%")
    json.dump(out, open(OUT, "w"), indent=1, default=str)
    print(f"\n-> {OUT}")
    print()
    print("=" * 92)
    print("STRUCTURES LES PLUS ROBUSTES SUR LES INDICES")
    print("=" * 92)
    for r in out[:12]:
        lbl = "%s|%s" % (r["key"][0], r["key"][1])
        print(f"  {lbl:<24} stables {r['stable']}/{r['n']}  "
              f"R moy {r['Rmoy']:+.1f}  win {100*r['win']:.0f}%")
