# -*- coding: utf-8 -*-
"""cout_volatilite.py — POURQUOI LA VOLATILITE PREDIT LA PERFORMANCE.

CONSTAT (16/09, 23 h 30). En croisant les estimateurs de volatilite (idee de
l'utilisateur : Garman-Klass, Rogers-Satchell, Yang-Zhang) avec les resultats
mesures, le NIVEAU de volatilite correle a +0.57 avec le R, alors que
l'efficacite directionnelle (RS/GK) ne correle pas du tout (-0.03).

HYPOTHESE A TESTER : c'est un effet de COUT, pas de signal. Le spread est
FIXE en pips. Sur une paire peu volatile (EURGBP : ~1 pip de spread pour ~10
pips d'ATR), le spread represente 10 % du mouvement. Sur une paire volatile
(GBPJPY : ~1.5 pip pour ~30 pips d'ATR), il n'en represente que 5 %. Le meme
signal coute donc DEUX FOIS PLUS CHER en R sur la paire calme.

Si l'hypothese est vraie, la correlation doit passer par le rapport
spread / ATR, et non par la volatilite elle-meme. C'est testable : les CSV M1
contiennent la colonne spread.

USAGE : python cout_volatilite.py
"""
import collections
import json
import math
import statistics
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
PERIODES = {"2024Q1": ("2024-01-01", "2024-04-01"),
            "2024Q2": ("2024-04-01", "2024-07-01"),
            "2024Q3": ("2024-07-01", "2024-10-01"),
            "2024Q4": ("2024-10-01", "2025-01-01"),
            "2025Q1": ("2025-01-01", "2025-04-01")}


def spearman(a, b):
    def rank(x):
        s = sorted(range(len(x)), key=lambda i: x[i])
        rk = [0] * len(x)
        for j, i in enumerate(s):
            rk[i] = j
        return rk
    ra, rb = rank(a), rank(b)
    n = len(a)
    ma, mb = statistics.mean(ra), statistics.mean(rb)
    num = sum((ra[i] - ma) * (rb[i] - mb) for i in range(n))
    den = (sum((x - ma) ** 2 for x in ra) * sum((x - mb) ** 2 for x in rb)) ** 0.5
    return num / den if den else 0


def stats_paire(csv):
    """spread moyen, ATR M5 REEL et leur rapport, par periode.

    BUG CORRIGE LE 16/09 A 23 h 50. La premiere version calculait
    `d["tr"] = high - low` sur les barres M1 PUIS en prenait la moyenne dans
    chaque tranche de 5 minutes. Ce n'est pas l'ATR M5 : c'est la moyenne des
    ranges M1, soit 2 a 3 fois plus petit que le range de la barre M5. Le
    rapport spread/ATR etait donc gonfle d'autant (EURUSD affiche a 15.7 %
    au lieu de ~6 %). L'utilisateur l'a vu tout de suite : "ton spread la,
    c'est pas un peu eleve ?"

    On agrege correctement : high = max des highs, low = min des lows sur la
    tranche, et le true range inclut l'ecart avec la cloture precedente.
    """
    import pandas as pd
    d = pd.read_csv(csv, usecols=["time", "high", "low", "close", "spread"])
    d["time"] = pd.to_datetime(d["time"], unit="s", utc=True)
    d = d.set_index("time").sort_index()
    m5 = d.resample("5min").agg({"high": "max", "low": "min",
                                 "close": "last", "spread": "mean"}).dropna()
    pc = m5["close"].shift(1)
    m5["tr"] = pd.concat([(m5["high"] - m5["low"]).abs(),
                          (m5["high"] - pc).abs(),
                          (m5["low"] - pc).abs()], axis=1).max(axis=1)
    out = {}
    for per, (a, b) in PERIODES.items():
        s = m5.loc[a:b]
        if len(s) < 500:
            continue
        atr = float(s["tr"].mean())
        sp = float(s["spread"].mean())
        if atr <= 0:
            continue
        out[per] = dict(atr=atr, spread_pts=sp)
    return out


def main():
    perf = collections.defaultdict(list)
    with open(BASE / "lab_results.jsonl", encoding="utf-8") as fh:
        for line in fh:
            if not line.strip():
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            p = str(r.get("period", ""))
            if p in PERIODES and r["n"] >= 3 and "r_x54" in r:
                perf[(r["sym"], p)].append(r["r_x54"])
    perf = {k: statistics.mean(v) for k, v in perf.items() if len(v) >= 30}
    print("cibles mesurees : %d" % len(perf))

    lignes = []
    for csv in sorted((BASE / "m1_pos").glob("*_M1.csv")):
        sym = csv.name.split("_")[0]
        try:
            st = stats_paire(str(csv))
        except Exception as e:
            print("   %-8s : %s" % (sym, e))
            continue
        for per, v in st.items():
            if (sym, per) not in perf:
                continue
            # facteur point -> prix : JPY = 0.001, le reste = 0.00001
            f = 0.001 if "JPY" in sym else 0.00001
            # ... et le PIP vaut 10 points pour les non-JPY, 100 pour les JPY
            pip = 0.01 if "JPY" in sym else 0.0001
            cout = v["spread_pts"] * f / v["atr"]      # spread / ATR
            lignes.append(dict(sym=sym, per=per, R=perf[(sym, per)],
                               atr=v["atr"], cout=cout,
                               atr_pips=v["atr"] / pip,
                               spread_pips=v["spread_pts"] * f / pip))
        print("   %-8s ok" % sym)
    if len(lignes) < 25:
        print("trop peu de points")
        return
    print("\n=== %d points (paire x periode) ===" % len(lignes))
    print("%-8s %-8s %9s %9s %9s %11s"
          % ("paire", "periode", "R moyen", "ATR(pips)", "sprd(pips)",
             "spread/ATR"))
    for x in sorted(lignes, key=lambda y: y["cout"])[:12]:
        print("%-8s %-8s %+9.3f %9.1f %9.1f %10.1f %%"
              % (x["sym"], x["per"], x["R"], x["atr_pips"], x["spread_pips"],
                 100 * x["cout"]))
    print("   ...")
    for x in sorted(lignes, key=lambda y: y["cout"])[-6:]:
        print("%-8s %-8s %+9.3f %9.1f %9.1f %10.1f %%"
              % (x["sym"], x["per"], x["R"], x["atr_pips"], x["spread_pips"],
                 100 * x["cout"]))
    print("\n=== CORRELATIONS AVEC LE R (Spearman) ===")
    # On ECARTE les paires dont la colonne spread est vide dans le CSV
    # (USDJPY : spread = 0 partout) : les compter fausserait le classement.
    valides = [x for x in lignes if x["spread_pips"] > 0]
    print("   (%d points sur %d ont un spread renseigne)" % (len(valides), len(lignes)))
    for nom, cle in (("spread / ATR  (le COUT)", "cout"),
                     ("ATR brut       (la volatilite)", "atr"),
                     ("spread en pips", "spread_pips")):
        print("   %-34s : %+.3f"
              % (nom, spearman([x[cle] for x in valides],
                               [x["R"] for x in valides])))
    tri = sorted(valides, key=lambda x: x["cout"])
    t = len(tri) // 3
    print("\n=== R MOYEN PAR TIERS DE COUT (spread/ATR) ===")
    for nom, grp in (("cout FAIBLE (volatilite forte)", tri[:t]),
                     ("cout moyen", tri[t:2 * t]),
                     ("cout ELEVE (volatilite faible)", tri[2 * t:])):
        print("   %-32s spread/ATR %.1f %% -> R moyen %+.3f  (%d points)"
              % (nom, 100 * statistics.mean([x["cout"] for x in grp]),
                 statistics.mean([x["R"] for x in grp]), len(grp)))


if __name__ == "__main__":
    main()
