﻿"""Investigate ofi_cont: the one family with positive median. Why did retention kill it?"""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import json
from pathlib import Path
import numpy as np

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
from alpha_loop import (FAMILIES, configs_for, add_costs, run_cfg, load_frames, B, SYM, make_sig)
from edge_correct import backtest_m1

fIS = load_frames(B["IS"])
res_rows = []
for fam in ["ofi_cont", "ofi_rev"]:
    for cfg in configs_for(fam, "P1"):
        r = run_cfg(fIS[900], fam, add_costs(cfg))
        e1, e2 = r["IS-1"], r["IS-2"]
        if e1["n"] < 15 or e2["n"] < 15:
            continue
        # top-5 removal on IS-1
        f = make_sig(fIS[900]["IS-1"][1], fam, add_costs(cfg))
        tr = backtest_m1(fIS[900]["IS-1"][0], fIS[900]["IS-1"][1], f, SYM, add_costs(cfg))
        r5 = np.array([t["r"] for t in tr])
        r5m = np.sort(r5)[:-5].mean() - np.mean([t["cost_r"] for t in tr])
        res_rows.append({
            "fam": fam, "cfg": cfg,
            "n1": e1["n"], "g1": e1["gross"], "n1_net": e1["net"],
            "n2": e2["n"], "g2": e2["gross"], "n2_net": e2["net"],
            "top5_IS1_net": round(float(r5m), 4),
            "both_pos": e1["net"] > 0 and e2["net"] > 0,
        })

print("=== ofi_cont / ofi_rev M15 IS-1 & IS-2 ===")
res_rows.sort(key=lambda r: r["n1_net"], reverse=True)
for r in res_rows[:15]:
    print(f"  {r['fam']:9s} w={r['cfg']['w']} thr={r['cfg']['thr']} sl={r['cfg']['sl_atr']} rr={r['cfg']['rr']} sess={r['cfg']['session']} "
          f"| IS1 n={r['n1']} gross={r['g1']:.4f} net={r['n1_net']:.4f} | IS2 n={r['n2']} gross={r['g2']:.4f} net={r['n2_net']:.4f} "
          f"| top5 IS1={r['top5_IS1_net']:.4f} | both_pos={r['both_pos']}")

# how many both_pos and how many survive top5?
bp = [r for r in res_rows if r["both_pos"]]
print(f"\nboth_pos: {len(bp)}")
for r in bp:
    print(f"  {r['fam']} {r['cfg']} net1={r['n1_net']:.4f} net2={r['n2_net']:.4f} top5={r['top5_IS1_net']:.4f} survive_c={'Y' if r['top5_IS1_net']>0 else 'N'}")
