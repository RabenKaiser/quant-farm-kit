﻿p = r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS\mt5_up_run.py"
s = open(p, encoding="utf-8").read()
s2 = s.replace("InpMaxSpreadMult=2.5", "InpMaxSpreadMult=0")
assert s2 != s, "remplacement echoue"
open(p, "w", encoding="utf-8").write(s2)
print("InpMaxSpreadMult -> 0 (filtre desactive)")
