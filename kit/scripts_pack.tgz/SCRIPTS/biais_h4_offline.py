"""LE FILTRE DE BIAIS, MESURE HORS LIGNE SUR LES ORDRES REELS.

POURQUOI (26/09, 01 h 05). Les six lots `g3_keltb_*` (Keltner + biais EMA200 H4) ont rendu « aucun bilan
du jeu » sur la ferme : le terminal ne produit AUCUNE ligne TRD, donc le filtre de trame ne declenche pas
dans l'EA. Plutot que de passer la nuit a relancer des fenetres vides (10 min chacune), on repond a la
vraie question hors ligne : le biais H4 AMELIORE-T-IL le mu des ordres reels deja mesures ?

On a tout ce qu'il faut : 800 transactions reelles d'or (Keltner 32 h achat ET vente) lues dans le texte
brut de la ferme, et le M1 d'or depuis le 02/01/2020 (131 Mo) pour reconstruire l'EMA200 H4. La condition
est evaluee sur la DERNIERE Bougie H4 CLOTUREE avant l'entree (aucun regard vers l'avant), avec le prix
d'entree reel du terminal.

CE QUE CA DECIDE. Si le biais augmente le mu de facon nette sur les deux sens, la famille vaut la peine
qu'on repare le chemin EA. S'il ne fait rien (ou pire), on retire les lots et on economise la nuit.
"""
import sys
import pathlib
from datetime import datetime

import numpy as np
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import reel_sans_constante as RS  # noqa: E402

B = pathlib.Path(r"C:\EAFarm\HISTORY - Copy\research")
CSV = B / "m1_real" / "XAUUSD_M1.csv"
RAW = B / "raw_farm_g3_kelt32_xauusd.txt"


def ema_h4(chemin, periode, heures=4):
    """EMA sur des bougies de `heures` heures, rendue comme une fonction du temps.

    Le decoupage est fait sur l'heure serveur du fichier M1 (epoch brut), sans conversion de fuseau : un
    decalage d'une heure decale les barres H4 d'une heure, ce qui ne peut pas changer le signe d'un filtre
    de tendance a 200 periodes (33 jours). On le dit plutot que de faire semblant d'etre exact a l'heure.
    """
    df = pd.read_csv(chemin, usecols=["time", "close"])
    df["t"] = pd.to_datetime(df["time"], unit="s")
    df = df.set_index("t")["close"]
    h = df.resample("%dh" % heures).last().dropna()
    e = h.ewm(span=periode, adjust=False).mean()
    return e


def gate(serie, t, p, sens, heures=4):
    """Valeur de l'EMA sur la derniere bougie CLOTUREE avant t, et si le prix est du bon cote.

    On decale d'une periode : la bougie en cours a l'instant de l'entree n'est pas connue du marche.
    """
    fin = t.floor("%dh" % heures) - pd.Timedelta(hours=heures)
    try:
        v = serie.loc[:fin].iloc[-1]
    except IndexError:
        return None
    if not np.isfinite(v):
        return None
    return (p > v) if sens == "L" else (p < v)


def stats(tx):
    if not tx:
        return None
    R = np.array([x["R"] for x in tx], dtype=float)
    n = len(R)
    mu = float(R.mean())
    sd = float(R.std(ddof=1)) if n > 1 else 0.0
    t = mu / (sd / np.sqrt(n)) if sd > 0 else 0.0
    return {"n": n, "mu": mu, "sd": sd, "t": t, "somme": float(R.sum()),
            "queue": float((R < -1.5).mean()), "gagne": float((R > 0).mean())}


def fmt(cle, s):
    if s is None:
        return "  %-28s  aucune transaction" % cle
    return ("  %-28s  n=%4d  mu=%+.4f R  somme=%+7.1f R  t=%+5.2f  gagnantes=%4.0f%%  queue=%.0f%%"
            % (cle, s["n"], s["mu"], s["somme"], s["t"], 100 * s["gagne"], 100 * s["queue"]))


def main():
    print("=" * 118)
    print("LE BIAIS DE TENDANCE SUR LES ORDRES REELS D'OR (Keltner 32 h)")
    print("=" * 118)
    tx = RS.transactions_texte(RAW.read_text(encoding="utf-8", errors="replace"), symboles=["XAUUSD"])
    print("  transactions reelles lues : %d" % len(tx))
    if not tx:
        print("  RIEN A MESURER.")
        return
    print("  periode : %s -> %s" % (tx[0]["t_in"].date(), tx[-1]["t_in"].date()))

    series = {("H4", 200): ema_h4(CSV, 200, 4), ("H4", 100): ema_h4(CSV, 100, 4),
              ("H1", 200): ema_h4(CSV, 200, 1), ("D1", 100): ema_h4(CSV, 100, 24)}

    rapport = []
    for sens, nom_ligne in (("L", "KELTHIGH"), ("S", "KELTLOW")):
        sous = [x for x in tx if x["ligne"] == nom_ligne]
        print("")
        print("-" * 118)
        print("%s (%s) -- %d transactions" % (nom_ligne, "achat" if sens == "L" else "vente", len(sous)))
        print("-" * 118)
        s0 = stats(sous)
        print(fmt("SANS filtre", s0))
        rapport.append(("SANS filtre " + nom_ligne, s0))
        for (tf, per), serie in series.items():
            dedans, dehors = [], []
            for x in sous:
                g = gate(serie, pd.Timestamp(x["t_in"]), x["p_in"], sens, 4 if tf == "H4" else (1 if tf == "H1" else 24))
                if g is None:
                    continue
                (dedans if g else dehors).append(x)
            sa, sb = stats(dedans), stats(dehors)
            print(fmt("AVEC biais EMA%d %s" % (per, tf), sa))
            print(fmt("  (contre le biais)", sb))
            rapport.append(("biais EMA%d %s %s" % (per, tf, nom_ligne), sa))
            rapport.append(("contre EMA%d %s %s" % (per, tf, nom_ligne), sb))
            # par annee, pour la seule variante demandee (EMA200 H4) : la doctrine dit qu'un reglage qui
            # ne vit que sur une annee ne vaut rien.
            if (tf, per) == ("H4", 200) and dedans:
                par_an = {}
                for x in dedans:
                    par_an.setdefault(x["t_in"].year, []).append(x)
                print("      par annee :", " | ".join(
                    "%d n=%d mu=%+.3f" % (a, len(v), float(np.mean([z["R"] for z in v])))
                    for a, v in sorted(par_an.items())))

    lignes = ["# LE BIAIS DE TENDANCE, MESURE SUR LES ORDRES REELS (or, Keltner 32 h)", "",
              "Filtre : prix d'entree du terminal compare a l'EMA (200 ou 100 periodes) de la derniere",
              "bougie CLOTUREE avant l'entree. Source : `raw_farm_g3_kelt32_xauusd.txt` (ordres reels de",
              "la ferme) et `m1_real/XAUUSD_M1.csv`. R positif = gain, calcule sur le stop reel du",
              "terminal, signe corrige le 26/09.", "",
              "| variante | n | mu (R/tx) | somme (R) | t | gagnantes | queue < -1,5 R |",
              "|---|---|---|---|---|---|---|"]
    for cle, s in rapport:
        if s is None:
            continue
        lignes.append("| %s | %d | %+.4f | %+.1f | %+.2f | %.0f%% | %.0f%% |"
                      % (cle, s["n"], s["mu"], s["somme"], s["t"], 100 * s["gagne"], 100 * s["queue"]))
    (B / "BIAIS_H4_OFFLINE.md").write_text("\n".join(lignes) + "\n", encoding="utf-8")
    print("")
    print("  rapport ecrit dans BIAIS_H4_OFFLINE.md")


if __name__ == "__main__":
    main()
