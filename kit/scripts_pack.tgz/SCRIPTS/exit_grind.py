# -*- coding: utf-8 -*-
"""exit_grind.py — LE VRAI LEVIER : LA SORTIE.

CONSTAT MESURE (grind CADJPY, 7 reglages MT5)
---------------------------------------------
  TOUS les reglages donnent SL 81-87 % et TP 5-8 %.
  Le stop est touche presque toujours, la cible presque jamais.

Ce n'est NI le spread, NI la session, NI la structure : c'est que le stop
est trop SERRE par rapport au bruit normal du M5.

ORDRE DE GRANDEUR
  ATR M5 CADJPY ~ 42.6 points. Stop actuel = 2 ATR = 85 points.
  TP = 3R = 6 ATR = 256 points.
  Or le prix parcourt facilement 85 points de bruit en 4 heures.
  Resultat : le SL tombe avant que le TP soit approche.

CE QU'ON TESTE
--------------
On fait varier sl_atr et tp_r DANS LA TABLE (donc dans MT5, sans recompiler),
en gardant le ratio >= 1 pour que l'esperance reste positive.

  sl_atr : 1.5 / 2.0 / 3.0 / 4.0 / 6.0
  tp_r   : 1.0 / 1.5 / 2.0 / 3.0
  hold   : 48 / 96 / 192

On mesure le nombre de TP : c'est LUI qui doit monter pour que la courbe
monte. Une strategie a SL 85 % ne peut pas gagner, meme avec un bon ratio.

USAGE
  python -u exit_grind.py CADJPY 6       # 6 paires
"""
import os, sys, json, time, glob, subprocess, re
from pathlib import Path
import MetaTrader5 as mt5

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
FARM = Path(r"C:\EAFarm\MT5\Farm")
TM = FARM / "terminal64.exe"
DATA = (Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")
        / "CF0B997454318B475CF01419AFE2BBF3")
LOGD = DATA / "Tester" / "logs"
COMM = (Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")
        / "Common" / "Files")
FILES = DATA / "MQL5" / "Files"
CFG = FARM / "Config" / "config_exit.ini"
OUT = BASE / "exit_grind.json"

FROM_DATE = "2020.01.01"
TO_DATE = "2025.12.31"
MODEL = 1

# (sl_atr, tp_r, hold)
EXITS = [
    (2.0, 3.0, 48),    # reference
    (1.5, 1.5, 48),
    (2.0, 1.5, 48),
    (2.0, 2.0, 48),
    (3.0, 1.5, 96),
    (3.0, 2.0, 96),
    (4.0, 1.5, 96),
    (4.0, 2.0, 192),
    (6.0, 1.5, 192),
]

SPREAD_ATR = 0.6
H0, H1 = 8, 20


def kill_farm():
    subprocess.run(["taskkill", "/F", "/IM", "terminal64.exe"],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def rotate():
    stamp = time.strftime("%Y%m%d_%H%M%S")
    for lf in glob.glob(str(LOGD / "*log*")):
        try:
            os.rename(lf, lf + ".old" + stamp)
        except Exception:
            try:
                open(lf, "w").close()
            except Exception:
                pass
    olds = sorted(glob.glob(str(LOGD / "*.old*")),
                  key=lambda p: os.path.getmtime(p))
    for p in olds[:-10]:
        try:
            os.remove(p)
        except Exception:
            pass


def write_table(sym, sl, tp, hold, sp_atr):
    """Ecrit la table avec les nouveaux parametres de sortie."""
    d = json.load(open(BASE / "port_wfvg.json", encoding="utf-8"))
    legs = d.get(sym)
    if not legs:
        return 0
    TRIG = {"fvg_dn_10": "FVGDN10", "fvg_dn_20": "FVGDN20",
            "vwap_xdn": "VWAPXDN", "xdn_vwapW": "VWAPWXDN",
            "vwapmx_dn": "VWAPMXDN", "vwap24_dn": "VWAP24XDN",
            "rej_bull": "REJBULL", "pin_bull": "PINBULL",
            "sweep_lo_50": "SWEEPLO50", "sweep_lo_100": "SWEEPLO100",
            "no_wick_dn": "NOWICKDN", "brk_ll_50": "BRKLL50",
            "brk_ll_100": "BRKLL100", "ll_lh_50": "LLLH"}
    FILT = {"h_quiet": "HQUIET", "vol_lo": "VOLLO", "": ""}
    lines = []
    for j, L in enumerate(legs):
        t = TRIG.get(L["struct"]); fm = FILT.get(L["filt"], "")
        if not t:
            continue
        lines.append("%s,1,%s,%.3f,%.1f,%.3f,%d,%d"
                     % (t, fm, sl, tp, 0.0, hold, 997000 + j))
    if not lines:
        return 0
    txt = "\n".join(lines) + "\n"
    for dd in (COMM, FILES):
        (dd / f"ORION_{sym}.csv").write_text(txt, encoding="ascii")
    return len(lines)


def run_mt5(sym, sp_atr, wait=2400):
    cfg = ("[Tester]\nExpert=eepeek\\ORION_ROBOT.ex5\nSymbol=%s\nPeriod=M5\n"
           "Model=%d\nOptimization=0\nFromDate=%s\nToDate=%s\nDeposit=100000\n"
           "Currency=USD\nLeverage=100\nReplaceReport=1\nShutdownTerminal=1\n"
           "[TesterInputs]\nInpLots=0.10\nInpMaxPos=4\nInpMaxPerSide=4\n"
           "InpMaxSpreadMult=0\nInpMaxSpreadAtr=%.3f\n"
           "InpSessStart=%d\nInpSessEnd=%d\n"
           "InpDayStopPct=0\nInpMaxDDStopPct=0\n"
           "InpVerbose=true\nInpTrace=false\nInpNoHedge=true\n"
           % (sym, MODEL, FROM_DATE, TO_DATE, sp_atr, H0, H1))
    CFG.write_text(cfg)
    kill_farm(); time.sleep(3); rotate()
    p = subprocess.Popen([str(TM), "/config:" + str(CFG)], cwd=str(FARM),
                         creationflags=0x08000000,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    w = 0
    while w < wait:
        time.sleep(3); w += 3
        rr = subprocess.run(["tasklist", "/FI", "PID eq %d" % p.pid],
                            capture_output=True, text=True)
        if "terminal64" not in rr.stdout:
            break
    kill_farm(); time.sleep(3)
    best, bt = None, 0
    for pat in ("*.log", "*.log.old*", "*.log.pb*"):
        for lf in glob.glob(str(LOGD / pat)):
            try:
                if os.path.getsize(lf) < 500:
                    continue
                t = os.path.getmtime(lf)
            except OSError:
                continue
            if t > bt:
                best, bt = lf, t
    return best


def read_txt(lf):
    raw = open(lf, "rb").read()
    return (raw.decode("utf-16") if raw[:2] in (b"\xff\xfe", b"\xfe\xff")
            else raw.decode("utf-8", errors="replace"))


def parse(txt, sym):
    b = re.search(
        r"ORION BILAN %s sorties=(\d+) SL=(\d+) TP=(\d+) MAXHOLD=(\d+) "
        r"autres=(\d+) gagnantes=(\d+) win=([\d.]+)%% pnl=(-?[\d.]+)" % sym, txt)
    if not b:
        return None
    g = b.groups()
    return dict(n=int(g[0]), sl=int(g[1]), tp=int(g[2]), mx=int(g[3]),
                win_n=int(g[5]), win=float(g[6]), pnl=float(g[7]))


if __name__ == "__main__":
    port = json.load(open(BASE / "port_wfvg.json", encoding="utf-8"))
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 6
    syms = ([s.strip() for s in sys.argv[1].split(",")] if len(sys.argv) > 1
            and not sys.argv[1].isdigit() else sorted(port)[:n])
    res = json.load(open(OUT, encoding="utf-8")) if OUT.exists() else {}

    print("=" * 96)
    print("GRIND DES SORTIES — MT5 Dukascopy")
    print(f"{len(syms)} paires x {len(EXITS)} sorties = {len(syms)*len(EXITS)} runs")
    print(f"spread filter={SPREAD_ATR}  session={H0}-{H1}h")
    print("=" * 96)

    for sym in syms:
        res.setdefault(sym, {})
        print(f"\n##### {sym} #####", flush=True)
        for sl, tp, hd in EXITS:
            k = f"sl{sl}_tp{tp}_h{hd}"
            if k in res[sym]:
                r = res[sym][k]
            else:
                write_table(sym, sl, tp, hd, SPREAD_ATR)
                lf = run_mt5(sym, SPREAD_ATR)
                r = parse(read_txt(lf), sym) if lf else None
                res[sym][k] = r
                json.dump(res, open(OUT, "w"), indent=1)
            if not r:
                print(f"  {k:<18} pas de bilan", flush=True); continue
            print(f"  {k:<18} n={r['n']:>4} SL={r['sl']:>4}({100*r['sl']/max(1,r['n']):>3.0f}%) "
                  f"TP={r['tp']:>3}({100*r['tp']/max(1,r['n']):>3.0f}%) "
                  f"MX={r['mx']:>3} win={r['win']:>5.1f}% pnl={r['pnl']:>9.2f}",
                  flush=True)

    print()
    print("=" * 96)
    print("MEILLEURE SORTIE PAR PAIRE")
    print("=" * 96)
    print(f"{'paire':<9}{'sortie':<18}{'n':>5}{'SL%':>6}{'TP%':>6}{'win%':>7}{'pnl':>11}")
    print("-" * 96)
    for sym in syms:
        c = [(k, v) for k, v in res.get(sym, {}).items() if v]
        if not c:
            continue
        k, v = max(c, key=lambda kv: kv[1]["pnl"])
        n = max(1, v["n"])
        print(f"{sym:<9}{k:<18}{v['n']:>5}{100*v['sl']/n:>5.0f}%"
              f"{100*v['tp']/n:>5.0f}%{v['win']:>6.1f}%{v['pnl']:>11.2f}")
    print(f"\n-> {OUT}")
