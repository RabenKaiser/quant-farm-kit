﻿import json
d = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\pos_selection.json", encoding="utf-8"))
for L in d["legs"]:
    if "vol_" in L["k"] or "at_PP" in L["k"]:
        print(f"  k    = {L['k']}")
        print(f"  trig = {L['trig']}")
        print(f"  R3={L['R3']}")
