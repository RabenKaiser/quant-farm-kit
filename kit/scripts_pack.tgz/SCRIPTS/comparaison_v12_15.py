# -*- coding: utf-8 -*-
"""COMPARAISON V12 vs 15 JAMBES — meme moteur, memes regles (08/10).

L'utilisateur remarque que V12 (le portefeuille vivant de la conversation precedente,
V12_RENDEMENT.md : mediane +4.9 %/mois a 0.5 % de risque) rapportait PLUS que le portefeuille
15 jambes (+2.8 %). Deux hypotheses, testees separement :
  H1. la fenetre : V12 etait mesuree sur 2025-01 -> 2026-03, le portefeuille 15 sur 2024-01
      -> 2026-03 (2024 dilue et tranchait des jambes) ;
  H2. le panier : V12 = 7 jambes concentrees, 15 jambes = pool large a 34 symboles.

Moteur : les transactions HORODATEES ferme (ordres reels Dukascopy), la MECANIQUE de
simu_prop_15 (coupe journaliere -3 % dure, arret total -5 %, tx/j max), sans cible.
Sortie : une table par fenetre x panier, risque en grille.
"""
import re
import sys
from datetime import datetime, timedelta

import numpy as np

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
import simu_prop_15 as SP                      # noqa: E402
import portefeuille_15 as PF                   # noqa: E402

B = PF.B
DAILY_CUT = 3.0
TOTAL_STOP = 5.0
RISQUES = (0.35, 0.5, 0.75, 1.0, 1.5)


def panier_v12(jambes):
    """Les jambes de la famille kelt32/SR100 qui composaient l'esprit V12 : T1 seulement."""
    return [c for c in jambes if c.get("tier") == 1]


def fenetres(dmin, dmax, jours=30, pas=5):
    d = dmin
    while d + timedelta(days=jours) <= dmax:
        yield d, d + timedelta(days=jours)
        d += timedelta(days=pas)


def rejoue(txs, risque, d0, d1, max_tj=12, sans_news=None):
    """Rend (final_pct, arret) : coupe journaliere -3 % DURE et arret total -5 % honnetes."""
    eq, jour, pj, nj = 100.0, None, 0.0, 0
    arret = False
    for t in txs:
        d = t["t_in"].date()
        if d != jour:
            jour, pj, nj = d, 0.0, 0
        if sans_news is not None and t.get("tag") and t["t_in"] in sans_news:
            continue
        if d < d0 or d >= d1 or nj >= max_tj or pj <= -DAILY_CUT:
            continue
        delta = t["R"] * risque
        eq += delta
        pj += min(0.0, delta)
        nj += 1
        if eq - 100.0 <= -TOTAL_STOP:
            arret = True
            break
    return eq - 100.0, arret


def main():
    jambes = SP.charger_jambes()
    if not jambes:
        print("aucune jambe chargeable")
        return 1
    print("jambes chargees : %d (T1=%d, T2=%d)" % (
        len(jambes), sum(1 for c in jambes if c.get("tier") == 1),
        sum(1 for c in jambes if c.get("tier") == 2)))
    # transactions + variante sans news (mecanique identique a simu_prop_15)
    import calendrier_news
    cache, cache_sn = {}, {}
    for c in jambes:
        txs = [t for t in SP.transactions_jambe(c["tag"]) if t["t_in"] >= datetime(2024, 1, 1)]
        for t in txs:
            t["tag"] = c["tag"]
        cache[c["tag"]] = txs
        cache_sn[c["tag"]] = [t for t in txs
                              if not calendrier_news.dans_fenetre(t["t_in"].timestamp(), 45)]
    lignes = ["# COMPARAISON V12 vs 15 JAMBES (08/10, moteur unique, coupe -3 %/j, arret -5 %)", "",
              "Reference V12_RENDEMENT.md (fenetre 2025-01 -> 2026-03) : mediane +4.92 % (0.5 %),"
              " +5.02 % (0.75 %), +5.32 % (1.0 %) ; mu = +0.0663 R/tx, 137.5 tx/mois.", "",
              "| panier | fenetre | variante | risque %/tx | tx/j | mois median | mois moyen | pire | tx/j util |",
              "|---|---|---|---|---|---|---|---|---|"]
    paniers = [
        ("V12 (7 T1)", [c["tag"] for c in panier_v12(jambes)]),
        ("15 JAMBES", None),   # None = selection CLASSIQUE du portefeuille
    ]
    # fenetres : fenetre V12 pure (2025-01 -> 2026-03) et fenetre longue (2024-01 -> 2026-03)
    dmin_l = min(min(t["t_in"] for t in cache[c["tag"]]) for c in jambes
                 if cache[c["tag"]]).date()
    dmax_l = max(max(t["t_in"] for t in cache[c["tag"]]) for c in jambes
                 if cache[c["tag"]]).date()
    dmin_v12, dmax_v12 = datetime(2025, 1, 1).date(), dmax_l
    for nom_v12 in ("2025-01->2026-03",):
        pass
    for nom_p, tags in paniers:
        if tags is None:
            ordre = sorted(jambes, key=lambda c: (c.get("tier", 3), -(c["R"] * (c["n"] ** 0.5))))
            tags = [c["tag"] for c in ordre[:PF.JAMBES]]
        for nom_f, (d0, d1) in (("2025-01->2026-03", (dmin_v12, dmax_v12)),
                                ("2024-01->2026-03", (dmin_l, dmax_l))):
            for variante, cach in (("TOUTES", cache), ("SANS NEWS", cache_sn)):
                sous = []
                for tg in tags:
                    sous += cach.get(tg, [])
                sous.sort(key=lambda t: t["t_in"])
                if not sous:
                    continue
                dmin_f = min(t["t_in"] for t in sous).date()
                dmax_f = max(t["t_in"] for t in sous).date()
                a0, a1 = max(d0, dmin_f), min(d1, dmax_f)
                for max_tj in (12,):
                    for risque in RISQUES:
                        fins, njs, arrets = [], [], 0
                        for f0, f1 in fenetres(a0, a1):
                            f, ar = rejoue(sous, risque, f0, f1, max_tj)
                            fins.append(f)
                            arrets += 1 if ar else 0
                            njs.append(len([t for t in sous if f0 <= t["t_in"].date() < f1]) / 30.0)
                        if not fins:
                            continue
                        a = np.array(fins)
                        lignes.append("| %s | %s | %s | %.2f | %d | %+.2f%% | %+.2f%% | %+.2f%% | %.0f%% | %.1f |" % (
                            nom_p, nom_f, variante, risque, max_tj,
                            float(np.median(a)), float(a.mean()), float(a.min()),
                            100.0 * arrets / len(fins), float(np.mean(njs))))
                        print("  %-11s %s %-9s r %.2f : med %+.2f%% moy %+.2f%% pire %+.2f%% P(-5%%) %.0f%% tx/j %.1f" % (
                            nom_p, nom_f, variante, risque, float(np.median(a)),
                            float(a.mean()), float(a.min()), 100.0 * arrets / len(fins),
                            float(np.mean(njs))))
    out = B / "COMPARAISON_V12_15.md"
    out.write_text("\n".join(lignes) + "\n", encoding="utf-8")
    print("-> COMPARAISON_V12_15.md")
    return 0


if __name__ == "__main__":
    sys.exit(main())
