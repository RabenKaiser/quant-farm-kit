﻿import sys, numpy as np, gc, pandas as pd
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT, deep_lib as D
G._cache.clear(); gc.collect()
F = G.get_frames("EURAUD"); m5,m1=F["m5"],F["m1"]
h1z,hh,ll,a1,gb,gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd,zlo,zhi = MT.project(m5.index,h1z,hh,ll,gb,gr,max_age_h=48)
M = NL.build(m5,F,zd,zlo,zhi); M.update(FE.more(m5,F,m1))
s = NL.sig(M, "big_bear", ["vol_lo"])
st = D.run_ex("EURAUD", s, 1.5, 99.0, 192, trail_atr=3.5,
              t0=m5.index[0], t1=m5.index[-1], use_m1=False, collect=True)
print("cles renvoyees :", list(st.keys()))
print(f"n trades : {st.get('n')}")
ts = st.get("tse"); rets = st.get("rets")
if ts is not None:
    ts = np.asarray(ts)
    d = np.diff(ts)
    print(f"duree mediane entre sorties : {np.median(d)/60:.0f} min = {np.median(d)/300:.1f} barres M5")
    print(f"duree moyenne              : {d.mean()/300:.1f} barres M5")
    print(f"maxhold = 192 barres M5")
    print(f"  part des intervalles > 192 barres : {100*(d>192*300).mean():.0f} %")
