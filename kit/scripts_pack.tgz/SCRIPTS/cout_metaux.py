# -*- coding: utf-8 -*-
"""cout_metaux.py — L'OR ET L'ARGENT SONT-ILS VRAIMENT BON MARCHE ?

POURQUOI (18/09). Le seul fait etabli est que le COUT detruit le R (-0.736
dans le labo, -0.71/-0.79 en vrais ordres). La conclusion pratique serait donc
de chercher ou le cout relatif est petit. Les indices n'ont PAS d'historique M1
chez nous (verifie : 19 paires FX + XAUUSD + XAGUSD seulement, et un seul
indice a des ticks). Restent l'or et l'argent.

Ce script VERIFIE LA PREMISSE avant qu'on depense des heures de calcul. Il
applique la methodologie exacte de cout_volatilite.py : agregation M5 par
max/min, vrai true-range (avec l'ecart a la cloture precedente). Le bug corrige
le 16/09 est respecte : on ne moyenne PAS des ranges M1.

USAGE : python cout_metaux.py
"""
import statistics
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
M1 = BASE / "m1_pos"
PERIODES = {"2024Q1": ("2024-01-01", "2024-04-01"),
            "2024Q2": ("2024-04-01", "2024-07-01"),
            "2024Q3": ("2024-07-01", "2024-10-01"),
            "2024Q4": ("2024-10-01", "2025-01-01"),
            "2025Q1": ("2025-01-01", "2025-04-01")}


def point_de(close):
    """Taille du point (en prix) deduite du nombre de decimales cotees.

    POURQUOI C'EST INDISPENSABLE. Dans les CSV M1, la colonne `spread` est en
    POINTS et les colonnes de prix sont en PRIX. Les diviser directement donne
    un rapport faux d'un facteur 100 000 (mesure : EURUSD a 629 753 % au lieu
    de 6.3 %). Il faut convertir : cout = spread_points x point / ATR_prix.
    Le point se deduit des decimales cotees : 1.12132 -> 1e-5, 1520.26 -> 1e-2.
    """
    ex = close.dropna().astype(str)
    ex = ex[~ex.str.contains("e", case=False, na=False)].head(2000)
    dec = 0
    for x in ex:
        if "." in x:
            dec = max(dec, len(x.split(".")[1]))
    return 10.0 ** (-dec)


def stats_paire(sym):
    import pandas as pd
    p = M1 / ("%s_M1.csv" % sym)
    if not p.exists():
        return None
    d = pd.read_csv(p, usecols=["time", "high", "low", "close", "spread"])
    d["time"] = pd.to_datetime(d["time"], unit="s", utc=True)
    d = d.set_index("time").sort_index()
    pt = point_de(d["close"])
    m5 = d.resample("5min").agg({"high": "max", "low": "min",
                                 "close": "last", "spread": "mean"}).dropna()
    pc = m5["close"].shift(1)
    m5["tr"] = pd.concat([(m5["high"] - m5["low"]).abs(),
                          (m5["high"] - pc).abs(),
                          (m5["low"] - pc).abs()], axis=1).max(axis=1)
    out = {}
    for per, (a, b) in PERIODES.items():
        s = m5.loc[a:b]
        if len(s) < 500:
            continue
        atr = float(s["tr"].mean())
        sp = float(s["spread"].mean()) * pt          # <- conversion en prix
        if atr > 0 and sp > 0:
            out[per] = (sp, atr)
    return out


def main():
    print("=" * 92)
    print("LE COUT RELATIF (spread / ATR M5) — OU PEUT-ON TROUVER MOINS CHER ?")
    print("=" * 92)
    print("   %-9s %10s %10s %14s   %s"
          % ("instrument", "spread pts", "ATR M5 pts", "cout relatif", "par trimestre"))
    res = {}
    for sym in ("EURUSD", "USDJPY", "GBPJPY", "AUDNZD", "XAUUSD", "XAGUSD"):
        st = stats_paire(sym)
        if not st:
            print("   %-9s  pas de CSV M1 exploitable" % sym)
            continue
        ratios = {k: 100.0 * v[0] / v[1] for k, v in st.items()}
        moy = statistics.mean(ratios.values())
        res[sym] = moy
        sp = statistics.mean(v[0] for v in st.values())
        at = statistics.mean(v[1] for v in st.values())
        d = " ".join("%s=%.0f%%" % (k[-2:], v) for k, v in sorted(ratios.items()))
        print("   %-9s %10.2f %10.2f %13.1f %%   %s" % (sym, sp, at, moy, d))
    print()
    print("=" * 92)
    print("VERDICT")
    print("=" * 92)
    for sym in ("XAUUSD", "XAGUSD", "EURUSD"):
        if sym in res:
            print("   %-8s : %.1f %% de cout relatif" % (sym, res[sym]))
    if res:
        meilleur = min(res.values())
        noms = [k for k, v in res.items() if v == meilleur]
        print()
        print("   le moins cher disponible : %s (%.1f %%)" % (", ".join(noms), meilleur))
        print()
        if meilleur > 25.0:
            print("   >>> AUCUN instrument disponible n'est bon marche. La piste")
            print("       'aller la ou le cout est faible' n'est pas praticable")
            print("       avec nos donnees actuelles.")
        else:
            print("   >>> il existe un instrument sous 25 % : candidate pour")
            print("       le prochain test de persistance.")
    print()
    print("   SEUIL A BATTRE : +0.14 R par transaction (base labo -0.05 R +")
    print("   ecart d'execution -0.09 R, mesures cette nuit).")


if __name__ == "__main__":
    main()
