# -*- coding: utf-8 -*-
r"""cloner_mt5.py -- fabrique des coureurs MT5 supplementaires SANS recopier
l'historique.

POURQUOI CE SCRIPT
------------------
Question de l'utilisateur (18/09) : "faut-il tous les installer, ou peut-on
juste prendre le testeur et lui mettre des donnees M1 ?"

Ni l'un ni l'autre integralement. Ce qu'un testeur a besoin de lire, c'est le
dossier `bases` du terminal (l'historique du serveur, 15 a 20 Go). On le
PARTAGE par lien de dossier (junction) : chaque instance a son propre dossier de
donnees, son propre cache de testeur et son propre fichier de configuration,
mais une seule copie des donnees sur le disque.

CE QUE LE SCRIPT FAIT, ET CE QU'IL REFUSE DE FAIRE
--------------------------------------------------
  - il verifie l'espace disque et REFUSE de creer plus d'instances qu'il n'y a
    de coeurs (un test "chaque tique" sature un coeur : au-dela, tout le monde
    ralentit sans que le debit augmente) ;
  - il cree : le dossier de donnees, la junction `bases`, le dossier `Tester`,
    les dossiers `MQL5\Experts\eepeek` (avec l'EA copie), et un `lab.ini` modele
    qui ecrit TOUS les parametres (jamais d'heritage) ;
  - il ne touche JAMAIS aux instances existantes : il refuse d'ecraser.

Usage :
    python SCRIPTS\\cloner_mt5.py --liste
    python SCRIPTS\\cloner_mt5.py --creer 2 --profil-source mt5   (dry-run)
    python SCRIPTS\\cloner_mt5.py --creer 2 --profil-source mt5 --appliquer
"""
import argparse
import shutil
import subprocess
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

PROFILS = {
    "mt5": dict(
        exe=Path(r"C:\MT5\terminal64.exe"),
        racine=Path(r"C:\MT5"),
        data=Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes"
                  r"\Terminal\E23367DD11DBEB0EF97D08185EAB7295"),
    ),
    "farm": dict(
        exe=Path(r"C:\EAFarm\MT5\Farm\terminal64.exe"),
        racine=Path(r"C:\EAFarm\MT5\Farm"),
        data=Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes"
                  r"\Terminal\CF0B997454318B475CF01419AFE2BBF3"),
    ),
}
RACINE_INSTANCES = Path(r"C:\MT5INST")


def coeurs():
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "(Get-CimInstance Win32_Processor).NumberOfLogicalProcessors"],
            capture_output=True, text=True, timeout=40)
        return int((r.stdout or "1").strip().splitlines()[-1])
    except Exception:
        return 1


def espace_libre_go():
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "[math]::Round((Get-PSDrive C).Free/1GB,1)"],
            capture_output=True, text=True, timeout=40)
        return float((r.stdout or "0").strip().splitlines()[-1])
    except Exception:
        return 0.0


def instances_existantes():
    if not RACINE_INSTANCES.exists():
        return []
    return sorted(p.name for p in RACINE_INSTANCES.iterdir() if p.is_dir())


def liste():
    print("profils disponibles :")
    for nom, p in PROFILS.items():
        ok_exe = "oui" if p["exe"].exists() else "NON"
        ok_data = "oui" if p["data"].exists() else "NON"
        print("  %-6s programme=%s  dossier de donnees=%s  %s"
              % (nom, ok_exe, ok_data, p["data"]))
    print("coeurs logiques : %d" % coeurs())
    print("espace libre C: : %.1f Go" % espace_libre_go())
    ex = instances_existantes()
    print("instances deja creees : %s" % (", ".join(ex) if ex else "aucune"))
    print("emplacement : %s" % RACINE_INSTANCES)


def creer(n, profil, appliquer):
    src = PROFILS[profil]
    if not src["exe"].exists() or not src["data"].exists():
        print("profil %s incomplet : programme=%s data=%s"
              % (profil, src["exe"].exists(), src["data"].exists()))
        return 2
    nc = coeurs()
    deja = len(instances_existantes())
    if deja + n > nc:
        print("REFUS : %d instance(s) existante(s) + %d demandee(s) > %d coeur(s)."
              % (deja, n, nc))
        print("       Un test 'chaque tique' sature un coeur. Au-dela, chaque")
        print("       test ralentit d'autant sans que le debit augmente.")
        return 1
    # Chaque instance a besoin de : son dossier de donnees (petit), son dossier
    # Tester (cache), l'EA, et un lien vers `bases` (15 Go partages, pas copies).
    libre = espace_libre_go()
    besoin = 0.6 * n          # dossier de donnees + cache du premier test
    if libre < besoin + 2.0:
        print("REFUS : %.1f Go libres, %.1f Go estimes necessaires."
              % (libre, besoin))
        return 1
    for i in range(1, n + 1):
        nom = "inst%d" % (deja + i)
        d = RACINE_INSTANCES / nom
        data = d / "data"
        if d.exists():
            print("REFUS : %s existe deja (ce script n'ecrase jamais)" % d)
            return 1
        print("\n-- instance %s" % nom)
        print("   dossier        : %s" % d)
        print("   donnees        : %s" % data)
        print("   junction bases : %s\\bases -> %s"
              % (data, src["data"] / "bases"))
        print("   EA copie       : MQL5\\Experts\\eepeek\\TRIGGER_LAB.ex5")
        print("   lancement      : %s /config:%s\\lab.ini"
              % (src["exe"], data))
        if not appliquer:
            continue
        (data / "MQL5" / "Experts" / "eepeek").mkdir(parents=True, exist_ok=True)
        (data / "Tester").mkdir(parents=True, exist_ok=True)
        (data / "config").mkdir(parents=True, exist_ok=True)
        for f in ("TRIGGER_LAB.ex5", "TRIGGER_LAB.mq5"):
            s = src["data"] / "MQL5" / "Experts" / "eepeek" / f
            if s.exists():
                shutil.copy2(s, data / "MQL5" / "Experts" / "eepeek" / f)
        bases = src["data"] / "bases"
        cible = data / "bases"
        if bases.exists() and not cible.exists():
            r = subprocess.run(["cmd", "/c", "mklink", "/J", str(cible),
                                str(bases)], capture_output=True, text=True)
            print("   junction : %s" % (r.stdout or r.stderr).strip())
        cfg = ("[Tester]\nExpert=eepeek\\TRIGGER_LAB.ex5\nSymbol=EURUSD\n"
               "Period=M5\nModel=4\nOptimization=0\n"
               "FromDate=2024.01.01\nToDate=2024.04.01\nDeposit=100000\n"
               "Currency=USD\nLeverage=100\nReplaceReport=1\n"
               "ShutdownTerminal=1\n[TesterInputs]\nInpHoldBars=192\n"
               "InpMinN=3\nInpVerbose=false\nInpLegacyExit=false\n"
               "InpTradeMode=false\nInpLots=0.10\nInpSLatr=12\nInpTPR=2\n"
               "InpSetFile=\nInpTri=false\nInpCrossDouble=false\n"
               "InpCrossFam=0\nInpSliceMod=1\nInpSliceIdx=0\n")
        (data / "lab.ini").write_text(cfg, encoding="ascii")
        print("   lab.ini ecrit (tous les parametres, aucun heritage)")
    if not appliquer:
        print("\n(dry-run : rien n'a ete ecrit. Ajouter --appliquer)")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--liste", action="store_true")
    ap.add_argument("--creer", type=int, default=0)
    ap.add_argument("--profil-source", default="mt5", choices=list(PROFILS))
    ap.add_argument("--appliquer", action="store_true")
    a = ap.parse_args()
    if a.liste or not a.creer:
        liste()
        return 0
    return creer(a.creer, a.profil_source, a.appliquer)


if __name__ == "__main__":
    sys.exit(main())
