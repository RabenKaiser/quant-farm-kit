# -*- coding: utf-8 -*-
"""clarify_h1m15_r179.py — CLARIFIER: les stats des presets deploy (ex GBPUSD
24t pf2.17, EURGBP 15t) viennent de runs H1 ou M15 ? Comparer n de chaque
paire deploy en H1 vs M15 sur Upcomers 2026."""
import sys, os, glob
import pandas as pd
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
# lister tous les runs V3INT des logs recents (H1 et M15) avec sym/tf/n/bal
seen = {}
for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime, reverse=True)[:25]:
    if os.path.getsize(lp) > 5 * 1024 * 1024:
        continue
    try:
        runs = F.parse_stream(lp, "V3INT")
    except Exception:
        continue
    for key, data in runs.items():
        k = key.split(" ")[0]
        if "," not in k:
            continue
        sym, tf = k.split(",")
        closed = [t for t in data["trades"].values() if t["close"] is not None]
        n = len(closed)
        b = data.get("balance") or 0
        tag = (sym, tf)
        if tag not in seen or abs(b - 10000) < abs(seen[tag][1] - 10000):
            seen[tag] = (n, b)
for (sym, tf), (n, b) in sorted(seen.items()):
    print(f"{sym:10s} {tf:4s} n={n:3d} bal={b:7.0f} (reel {b-10000:+5.0f})")
print("FIN", flush=True)
