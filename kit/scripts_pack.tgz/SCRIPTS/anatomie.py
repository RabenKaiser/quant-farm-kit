# -*- coding: utf-8 -*-
"""anatomie.py — ANATOMIE DU PORTEFEUILLE : QUE CHANGE LA PERIODE PERDANTE ?

DEMANDE DE L'UTILISATEUR (18/09, 02 h) : "le portefeuille qu'on a construit
valait +84 % par an. Est-ce qu'on a fait tourner le MEME portefeuille sur les
donnees ou il perd, pour voir les courbes de MFE et MAE pendant les periodes
perdantes ?"

Non, on ne l'avait pas fait. C'est ce que fait ce script.

CE QU'ON COMPARE, pour chacune des 24 lignes du portefeuille
  - la periode GAGNANTE : les 5 trimestres 2024Q1 a 2025Q1, sur lesquels le
    portefeuille a ete choisi (c'est la ou il vaut +0.5 R par transaction) ;
  - la periode PERDANTE : 2020-2021, mesuree cette nuit par le plan VINTAGE,
    qui n'a jamais servi a choisir quoi que ce soit.

CE QU'ON REGARDE, parce que chacun raconte une histoire differente
  - R a la geometrie de reference (SL 12 / TP 24) et a la meilleure
    (SL 12 / TP 1) ;
  - MFE et MAE moyens et leurs 75e centiles : l'excursion favorable a-t-elle
    disparu, ou est-ce l'adverse qui a grossi ?
  - b_mfe contre b_mae : l'indice de barre MOYEN du maximum favorable et du
    maximum adverse. Si le MAE arrive avant le MFE dans la periode perdante,
    le trade part contre nous d'abord -- c'est une signature de regime.
  - stop_sl12 : le pourcentage de trades stoppes.
  - pos : la position moyenne de l'entree dans le range.

GARDE-FOU : on n'annonce un ecart que sur les lignes ou les DEUX periodes sont
mesurees ; si moins de 8 lignes sont comparables, on refuse de conclure.

USAGE : python anatomie.py
"""
import collections
import json
import statistics
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
LIVE = BASE / "lab_results.jsonl"
Q5 = ["2024Q1", "2024Q2", "2024Q3", "2024Q4", "2025Q1"]
VINT = ["2020.01", "2020.07", "2021.01", "2021.07"]
PAIRES = ["EURUSD", "USDJPY", "EURJPY", "AUDJPY", "GBPJPY",
          "USDCAD", "CADJPY", "NZDUSD"]
NTOP = 3
CH = ["n", "r_x47", "r_x54", "mfe", "mae", "mfe_p75", "mae_p75", "ratio",
      "b_mfe", "b_mae", "stop_sl12", "pos"]


def charge():
    g = collections.defaultdict(dict)
    with open(LIVE, encoding="utf-8") as fh:
        for line in fh:
            if '"r_x47"' not in line:
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            p = str(r.get("period", ""))
            if p not in Q5 + VINT or r["n"] < 3:
                continue
            g[(r["id"], r["sym"])][p] = r
    return g


def agg(rows, ch):
    """Moyenne ponderee par le nombre de transactions quand c'est un R."""
    if not rows:
        return None
    if ch in ("r_x47", "r_x54"):
        n = sum(r["n"] for r in rows)
        return sum(r[ch] * r["n"] for r in rows) / n if n else None
    v = [r[ch] for r in rows if r.get(ch) is not None]
    return statistics.mean(v) if v else None


def main():
    g = charge()
    # --- le portefeuille : 3 meilleures lignes par paire sur 2024-2025 -----
    par = collections.defaultdict(list)
    for (cid, sym), d in g.items():
        if sym not in PAIRES:
            continue
        rows = [d[p] for p in Q5 if p in d]
        if len(rows) < 4:
            continue
        par[sym].append((cid, agg(rows, "r_x47"), rows))
    porto = []
    for sym in sorted(par):
        par[sym].sort(key=lambda x: -(x[1] if x[1] is not None else -9))
        for cid, R, rows in par[sym][:NTOP]:
            porto.append((cid, sym, rows))
    print("=" * 108)
    print("ANATOMIE DU PORTEFEUILLE — periode gagnante (2024-2025) contre "
          "periode perdante (2020-2021)")
    print("=" * 108)
    print("   portefeuille reconstruit : %d lignes sur %d paires"
          % (len(porto), len(set(p[1] for p in porto))))
    # --- AVERTISSEMENT D'ARTEFACT (ajoute le 18/09 a 01 h 45) -------------
    # r_x47 = SL 12 x ATR / TP 1 x ATR a un MAXIMUM : quand tous les trades
    # touchent l'objectif de 1 ATR avant le stop de 12 ATR, R = 1/12 = 0.0833.
    # 8.5 % des couples sont exactement a ce plafond, et le portefeuille ayant
    # ete choisi en prenant les 3 meilleurs par paire, ses lignes y sont
    # TOUTES. Comparer leur R a celui d'une autre periode mesure donc surtout
    # une REGRESSION VERS LA MOYENNE, pas un changement de marche. En le
    # disant ici, le rapport du matin ne peut plus induire en erreur.
    PLAFOND = round(1.0 / 12.0, 2)
    auplafond = sum(1 for cid, sym, rows in porto
                    if agg(rows, "r_x47") is not None
                    and abs(agg(rows, "r_x47") - PLAFOND) < 0.005)
    print()
    print("   *** AVERTISSEMENT D'ARTEFACT ***")
    print("   la sortie SL 12 / TP 1 a un MAXIMUM theorique de 1/12 = %.2f" % PLAFOND)
    print("   (tous les trades touchent l'objectif avant le stop).")
    print("   %d lignes du portefeuille sur %d sont EXACTEMENT a ce plafond."
          % (auplafond, len(porto)))
    print("   Le portefeuille a donc ete choisi AU MAXIMUM d'une variable bornee :")
    print("   toute comparaison avec une autre periode subit une regression vers")
    print("   la moyenne et NE DIT RIEN sur le changement de regime. Seul le")
    print("   NIVEAU hors periode est interpretable.")
    print()
    print("   %-34s %-7s %8s %8s %8s %8s %8s %8s %8s"
          % ("combinaison", "paire", "R x47", "R x54", "MFE", "MAE",
             "MAE/MFE", "b_mfe", "b_mae"))
    lignes = []
    for cid, sym, rows_q in porto:
        rows_v = [g[(cid, sym)][p] for p in VINT if p in g[(cid, sym)]]
        A = {ch: agg(rows_q, ch) for ch in CH}
        B = {ch: agg(rows_v, ch) for ch in CH} if rows_v else None
        lignes.append((cid, sym, A, B, len(rows_q), len(rows_v)))
        if B is None:
            print("   %-34s %-7s %+8.3f %+8.3f %8.2f %8.2f %8.2f %8.1f %8.1f"
                  % (cid[:34], sym, A["r_x47"] or 0, A["r_x54"] or 0,
                     A["mfe"] or 0, A["mae"] or 0,
                     (A["mae"] / A["mfe"]) if A["mfe"] else 0,
                     A["b_mfe"] or 0, A["b_mae"] or 0))
    print("   (les lignes sans donnee 2020-2021 ne sont pas affichees ici)")
    comp = [x for x in lignes if x[3] is not None]
    print()
    print("=" * 108)
    print("   LIGNES COMPARABLES : %d sur %d" % (len(comp), len(lignes)))
    print("=" * 108)
    if len(comp) < 8:
        print("   >>> COUVERTURE INSUFFISANTE (%d lignes, 8 requises)."
              % len(comp))
        print("       Le plan VINTAGE mesure encore 2020-2021. On refuse de")
        print("       conclure sur un morceau de periode ; la boucle autonome")
        print("       relancera ce script a 3 h, 5 h, 7 h, 9 h et 11 h.")
        return
    print("   %-34s %-7s %17s %17s"
          % ("combinaison", "paire", "2024-2025", "2020-2021"))
    print("   %-34s %-7s %8s %8s %8s %8s"
          % ("", "", "R x47", "MAE/MFE", "R x47", "MAE/MFE"))
    for cid, sym, A, B, nq, nv in comp:
        rq = A["mae"] / A["mfe"] if A["mfe"] else 0
        rv = B["mae"] / B["mfe"] if B["mfe"] else 0
        print("   %-34s %-7s %+8.3f %8.2f %+8.3f %8.2f"
              % (cid[:34], sym, A["r_x47"] or 0, rq, B["r_x47"] or 0, rv))

    def m(ch, idx):
        v = [x[idx][ch] for x in comp if x[idx].get(ch) is not None]
        return statistics.mean(v) if v else None

    print()
    print("   MOYENNES SUR LES LIGNES COMPARABLES")
    print("   %-22s %14s %14s %12s" % ("grandeur", "2024-2025", "2020-2021",
                                       "variation"))
    for ch, nom in (("r_x47", "R (SL12/TP1)"), ("r_x54", "R (SL12/TP24)"),
                    ("mfe", "MFE moyen"), ("mae", "MAE moyen"),
                    ("mfe_p75", "MFE p75"), ("mae_p75", "MAE p75"),
                    ("b_mfe", "barre du MFE"), ("b_mae", "barre du MAE"),
                    ("stop_sl12", "% stoppes SL12"), ("pos", "position entree")):
        a, b = m(ch, 2), m(ch, 3)
        var = ("%+.3f" % (b - a)) if (a is not None and b is not None) else "-"
        print("   %-22s %14s %14s %12s"
              % (nom,
                 ("%+.3f" % a) if a is not None else "-",
                 ("%+.3f" % b) if b is not None else "-", var))
    print()
    # --- lecture --------------------------------------------------------
    rq, rv = m("r_x47", 2), m("r_x47", 3)
    mq, mv = m("mae", 2), m("mae", 3)
    fq, fv = m("mfe", 2), m("mfe", 3)
    bf_q, bf_v = m("b_mfe", 2), m("b_mfe", 3)
    ba_q, ba_v = m("b_mae", 2), m("b_mae", 3)
    print("   LECTURE")
    print("   R moyen        : %+.3f  ->  %+.3f" % (rq, rv))
    print("   MFE moyen      : %+.2f  ->  %+.2f" % (fq, fv))
    print("   MAE moyen      : %+.2f  ->  %+.2f" % (mq, mv))
    print("   barre du MFE   : %.1f  ->  %.1f" % (bf_q, bf_v))
    print("   barre du MAE   : %.1f  ->  %.1f" % (ba_q, ba_v))
    print()
    if fv < fq * 0.8:
        print("   -> L'EXCURSION FAVORABLE S'EFFONDRE (%.2f -> %.2f). Le signal"
              % (fq, fv))
        print("      ne va plus chercher son objectif : ce n'est pas un probleme")
        print("      de cout, c'est le comportement du marche qui a change.")
    elif mv > mq * 1.2:
        print("   -> L'EXCURSION ADVERSE GROSSIT (%.2f -> %.2f). Les trades"
              % (mq, mv))
        print("      partent contre nous plus loin : stop touche plus souvent.")
    else:
        print("   -> MFE et MAE sont du meme ordre dans les deux periodes. La")
        print("      perte ne vient donc NI de l'excursion favorable NI de")
        print("      l'adverse : elle vient du COUT et de l'execution, ce qui")
        print("      est coherent avec l'ecart labo/reel mesure (-0.09 R).")
    if bf_v > ba_v:
        print("   -> EN 2020-2021, LE MAE ARRIVE AVANT LE MFE (%.1f contre %.1f"
              % (ba_v, bf_v))
        print("      barres) : les trades partent contre nous d'abord. C'est la")
        print("      signature d'un regime ou le retour a la moyenne domine le")
        print("      suivi de tendance -- exactement l'inverse de 2024-2025.")
    print()
    print("   NOTE : le 84 % par an etait calcule sur la periode GAGNANTE,")
    print("   celle qui a servi a choisir les lignes. Ce tableau montre ce qui")
    print("   se passe quand on les sort de cette periode.")


if __name__ == "__main__":
    main()
