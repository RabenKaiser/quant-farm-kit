"""cout_vs_edge : l'edge honnete est-il une fonction du COUT en R (spread / ATR) ?

Round 384. La famille CREST-M a un edge BRUT mesure de +0,13 a +0,16 R/tx, et un cout d'aller-retour
qui vaut spread/ATR en R. Avec un stop de 1 ATR et un spread effectif de 0,19 ATR, le cout mange tout
l'edge. Deux consequences verifiables, et c'est l'objet de ce script :

  1. elargir le stop (2, 3, 4 ATR) reduit le cout RELATIF sans toucher a l'edge brut, qui est
     invariant d'echelle : la table honnete passe de 0 RETENUS (stop 1 ATR) a 2 RETENUS (stops 3 et
     4 ATR), et les deux survivants sont AUDCAD r=50 et AUDCAD r=100 ;
  2. si le mecanisme est bien le cout, alors l'edge honnete doit etre une FONCTION DECROISSANTE du
     cout en R de la paire -- et cette relation est une regle de selection, pas un choix de paire
     apres coup.

Ce script mesure, pour chaque paire du corpus : le cout en R (spread median M1 / ATR median M30),
puis le R/tx honnete avec un stop large, sur les deux ranges. Il imprime la table triee par cout et
la correlation. Env : SLR (defaut 3), TPR (defaut 6), SOURCE, SORTIE.
"""
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import barrieres_m1 as BM  # noqa: E402
import table_honnete as TH  # noqa: E402

B = Path(r"C:\EAFarm\HISTORY - Copy\research")


def main():
    source = os.environ.get("SOURCE", "m1_pos")
    TH.SLR = float(os.environ.get("SLR", "3"))
    TH.TPR = 2.0 * TH.SLR
    ranges = [int(x) for x in os.environ.get("RANGES", "50,100").split(",")]
    lignes = []
    for p in TH.paires(source):
        M = BM.charge_m30(p, source)
        if M is None:
            continue
        a, spr = M["a"], M["spr"]
        ok = np.isfinite(a) & (a > 0)
        if ok.sum() < 100:
            continue
        cout_m = float(np.median(spr[ok]) / np.median(a[ok]))
        cout_x = float(np.mean(spr[ok]) / np.median(a[ok]))
        res = {}
        for r_ in ranges:
            m = TH.mesure(p, source, r_)
            res[r_] = m
        lignes.append((p, cout_m, cout_x, res))
        print("  %-8s cout median %.4f R (moyen %.4f) | %s" % (
            p, cout_m, cout_x,
            " | ".join("r=%d %s" % (r_, ("%+.4f (%d tx, pire %+.3f)"
                                         % (res[r_]["R"], res[r_]["n"], res[r_]["pire"]))
                                    if res[r_] else "echec") for r_ in ranges)), flush=True)
    lignes.sort(key=lambda x: x[1])
    print("\n  TABLE TRIEE PAR COUT EN R (stop %.1f ATR / cible %.1f ATR)" % (TH.SLR, TH.TPR))
    print("  paire     cout R   " + "".join("  R/tx r=%-4d" % r_ for r_ in ranges))
    for p, cm, cx, res in lignes:
        print("  %-8s %7.4f  " % (p, cm)
              + "".join("  %+10.4f" % res[r_]["R"] if res[r_] else "  %10s" % "--"
                        for r_ in ranges))
    dest = Path(os.environ.get("SORTIE", str(B / "COUT_VS_EDGE.md")))
    out = ["# Edge honnete contre cout en R (spread / ATR)", "",
           "Moteur a la minute, sortie a l'ask. Stop %.1f ATR, cible %.1f ATR, 64 barres M30."
           % (TH.SLR, TH.TPR), "",
           "| paire | cout median R | cout moyen R | "
           + " | ".join("R/tx r=%d" % r_ for r_ in ranges) + " | pire annee |",
           "|---|---|---|" + "---|" * (len(ranges) + 1)]
    for p, cm, cx, res in lignes:
        pir = " | ".join("%+.3f" % res[r_]["pire"] if res[r_] else "--"
                         for r_ in ranges)
        out.append("| %s | %.4f | %.4f | " % (p, cm, cx)
                   + " | ".join("%+.4f" % res[r_]["R"] if res[r_] else "--"
                                for r_ in ranges) + " | " + pir + " |")
    # correlation cout / edge
    for r_ in ranges:
        x = np.array([cm for _, cm, _, res in lignes if res[r_]])
        y = np.array([res[r_]["R"] for _, _, _, res in lignes if res[r_]])
        if len(x) > 4:
            out += ["", "r=%d : correlation cout/edge = %+.3f sur %d paires"
                    % (r_, float(np.corrcoef(x, y)[0, 1]), len(x))]
    dest.write_text("\n".join(out), encoding="utf-8")
    print("\n  -> %s" % dest.name, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
