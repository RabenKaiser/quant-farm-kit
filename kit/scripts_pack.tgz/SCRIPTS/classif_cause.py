# -*- coding: utf-8 -*-
r"""classif_cause.py -- LE DICTIONNAIRE DES TRANSITIONS (v3, 10/13 19:30).

L'utilisateur a raison (10/13 18:55) : le dictionnaire d'etats est TARDIF.
Preuve mesuree : quand une tendance M30 demarre vraiment, le classificateur
ER(64) ne la reconnait qu'apres ~30 HEURES (median 59 barres, p25 44,
p75 64). Un etat qui arrive apres le mouvement ne sert pas a trader.

LA QUESTION DEVIENT : QU'EST-CE QUI PRECEDE ET ANNONCE UN CHANGEMENT D'ETAT ?

METHODE
-------
1. Les labels d'etat (v2) donnent une sequence d'etats par paire.
2. On extrait les TRANSITIONS (A -> B, A != B, stables >= 6 barres avant et
   apres pour eviter le bruit).
3. Pour chaque transition, on mesure l'ETAT-CAUSE : l'etat des variables
   DEJA DISPONIBLES k barres AVANT la transition (k = 4, 8, 16, 32) :
     - ER (efficacite) et sa pente
     - percentile ATR et sa pente
     - ADX-like, pente ADX
     - RSI, extremite RSI
     - distance au VWAP du jour et pente
     - largeur Donchian normalisee et pente
     - tick-density proxy volume et sa pente (M5 seulement)
     - z-prix
4. SORTIE : pour chaque transition (A->B), la table des variables triees
   par VRAI POSITIF : quelle valeur de quelle variable "annonce" B avec le
   meilleur taux. Le seuil de chaque variable est pris dans les quantiles
   OBSERVES (pas un chiffre magique).

Le produit final : une table PREDICTEURS (variable, cote, quantile, hit-rate)
par transition. Ce sont les DECLENCHEURS DE REGIME du dictionnaire.
"""
import os
import sys

import numpy as np
import pandas as pd

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parent))
import nuit_motifs as NM
from classif_m5 import er, adx_like, z_prix, pentes
import classif_m5_v2 as V2

JAMBES = [x.strip() for x in os.environ.get(
    "PAIRES", "EURUSD,GBPUSD,USDCHF,AUDUSD,NZDUSD,EURJPY,XAUUSD").split(",")
    if x.strip()]
KS = (4, 8, 16, 32)
STAB = 6          # barres d'etablissement avant/apres la transition


def variables(D):
    """Toutes les variables candidates, ALIGNees sur le passe (aucune fuite)."""
    c, h, l, a = D["c"], D["h"], D["l"], D["a"]
    e = er(c, 64)
    v = {}
    v["er"] = e
    v["er_pente"] = pentes(e, 8)
    atr_p = pd.Series(a).rolling(1000).rank(pct=True).values
    v["atr_pct"] = atr_p
    v["atr_pente"] = pentes(atr_p, 12)
    adx, pdi, mdi = adx_like(D)
    v["adx"] = adx
    v["adx_pente"] = pentes(adx, 8)
    rsi = NM.rsi(c, 14)
    v["rsi"] = rsi
    v["rsi_ext"] = np.abs(rsi - 50.0)
    vwap = V2.vwap_jour(D["idx"], c, h, l)
    d_v = (c - vwap) / a
    v["d_vwap"] = d_v
    v["d_vwap_pente"] = pentes(d_v, 8)
    dw = (pd.Series(h).rolling(50).max().values
          - pd.Series(l).rolling(50).min().values) / a
    v["donch_w"] = dw
    v["donch_pente"] = pentes(dw, 12)
    v["z_prix"] = z_prix(D)
    return v


def transitions(lab):
    """Liste (i, A, B) : a la barre i, l'etat passe de A (stable >= STAB) a B."""
    out = []
    n = len(lab)
    i = STAB
    while i < n - STAB:
        if lab[i] != lab[i - 1]:
            A, B = lab[i - 1], lab[i]
            if all(lab[i - 1 - k] == A for k in range(STAB)) and \
               all(lab[i + k] == B for k in range(STAB)):
                out.append((i, A, B))
                i += STAB
                continue
        i += 1
    return out


def quantile_table(vals, pos, nbins=5):
    """Taux de VRAI positif par quantile de la variable : les valeurs HAUTES
    ou BASSES de la variable annoncent-elles la transition ?"""
    v = vals[~np.isnan(vals)]
    if len(v) < 50:
        return None
    qs = np.quantile(v, np.linspace(0, 1, nbins + 1))
    tab = []
    for b in range(nbins):
        m = (vals >= qs[b]) & (vals <= qs[b + 1]) if b == nbins - 1 else \
            (vals >= qs[b]) & (vals < qs[b + 1])
        mp = m & pos
        tab.append((b, float(np.nanmean(m)),
                    float(np.sum(mp)) / max(float(np.sum(m)), 1.0)))
    return tab


def main():
    print("DICTIONNAIRE DES TRANSITIONS | lag du classificateur v2 : ~30 h "
          "(mesure 10/13) -> on cherche les PREDICTEURS k barres AVANT")
    base = float(np.nanmean([np.mean([0.15, 0.2, 0.1])] * 1))  # base ~15%
    par_trans = {}
    for p in JAMBES:
        D = NM.charge(p, "m1_pos")
        if D is None:
            print("  %-8s : corpus absent" % p)
            continue
        lab, _ = V2.etats(D)
        vv = variables(D)
        trans = transitions(lab)
        print("  %-8s : %d transitions stables" % (p, len(trans)))
        for (i, A, B) in trans:
            cle = "%s->%s" % (A, B)
            par_trans.setdefault(cle, []).append((i, vv))
        break  # v1 : une paire (EURUSD) pour valider la methode d'abord
    print("\nTABLE DES PREDICTEURS (transition -> variables quiannoncent) :")
    for cle, obs in sorted(par_trans.items(), key=lambda x: -len(x[1])):
        n = len(obs)
        if n < 20:
            continue
        print("\n== %s (n=%d) ==" % (cle, n))
        # construit le tableau de toutes les barres : pos = barre dont la
        # transition arrive k barres plus tard
        premier_i = [o[0] for o in obs]
        vv = obs[0][1]
        # tableau global : pour chaque variable, hit-rate du quintile le plus
        # extrem (haut et bas) quand la transition arrive dans <= 32 barres
        pos_window = np.zeros(len(vv["er"]), dtype=bool)
        for i in premier_i:
            pos_window[max(0, i - 32):i] = True
        scores = []
        for nom, x in vv.items():
            t = quantile_table(x, pos_window)
            if t is None:
                continue
            # quintile le plus extreme en hit
            best = max(t, key=lambda z: z[2])
            base_rate = float(np.mean(pos_window))
            lift = best[2] / max(base_rate, 1e-9)
            scores.append((lift, nom, best[0], best[2], base_rate))
        scores.sort(reverse=True)
        for lift, nom, q, hit, base_rate in scores[:8]:
            print("   %-14s q%d  hit=%.2f (base %.2f) lift=%.2f"
                  % (nom, q, hit, base_rate, lift))


if __name__ == "__main__":
    main()
