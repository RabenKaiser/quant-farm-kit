"""chaine_vwap : enchainer la campagne VWAP sur le feed cible apres celle du corpus long.

La campagne `vwap1` tourne sur le farm (Dukascopy, 22 paires x 9 periodes, M5, stop 1 ATR,
cible 2 R, 48 barres, jeu `g_vwap.txt` qui contient maintenant les DEUX definitions du biais :
`VWAP_M30` = etat, `VWAP_M30_X` = croisement frais). Ce script attend qu'un terminal se libere,
puis lance la meme campagne sur le feed cible Upcomers (fenetres 2026Q1 : c'est le seul
historique de ce compte), et enfin reprend la campagne du farm pour couvrir les fenetres
restantes.

Pourquoi enchainer plutot que lancer en parallele : chaque test mobilise un terminal et le
lanceur tue le terminal avant de commencer. Deux campagnes en parallele sur le meme profil se
detruiraient mutuellement.
"""
import os
import subprocess
import sys
import time
from pathlib import Path

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
LOG = B / "chaine_vwap.log"
SYMS = "EURCHF,GBPCHF,EURGBP,USDCHF,EURJPY,AUDJPY,NZDJPY"


def note(m):
    with LOG.open("a", encoding="utf-8") as f:
        f.write("%s %s\n" % (time.strftime("%d/%m %H:%M:%S"), m))


def libre():
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
          "Where-Object { $_.CommandLine -match 'lab_parallel' } | Measure-Object | "
          "Select-Object -ExpandProperty Count")
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True)
    try:
        return int((r.stdout or "0").strip() or 0) == 0
    except ValueError:
        return False


def campagne(nom, args, env_sup):
    while not libre():
        time.sleep(60)
    note("%s : lancement" % nom)
    env = dict(os.environ)
    env.update(env_sup)
    with (B / ("camp_%s.log" % nom)).open("a", encoding="utf-8") as f:
        subprocess.run([sys.executable, str(B / "SCRIPTS" / "lab_parallel.py")] + args,
                       cwd=str(B), env=env, stdout=f, stderr=f)
    note("%s : termine" % nom)


def main():
    note("chaine vwap demarree")
    campagne("vwap_up", ["--only", "mt5", "--annuel", "--setfile", "g_vwap.txt",
                         "--tag", "vwapup", "--tf", "M5", "--sl-atr", "1", "--tp-r", "2.0",
                         "--hold-bars", "48", "--resume",
                         "--holdout", "autorisation utilisateur 21/09",
                         "--syms", SYMS], {"REARM": "1"})
    campagne("vwap1", ["--only", "farm", "--annuel", "--setfile", "g_vwap.txt",
                       "--tag", "vwap1", "--tf", "M5", "--sl-atr", "1", "--tp-r", "2.0",
                       "--hold-bars", "48", "--resume"], {"REARM": "1"})
    note("chaine vwap terminee")
    return 0


if __name__ == "__main__":
    sys.exit(main())
