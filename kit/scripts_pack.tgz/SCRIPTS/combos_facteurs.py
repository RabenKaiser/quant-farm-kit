"""combos_facteurs : le moteur de COMBINAISONS - et la question « qui est touche en premier ».

Ce que les pistes fermees ont appris : aucune condition ISOLEE ne bat le hasard sur ce corpus
(probas_marche.py : MFE/MAE entre 0,92 et 1,10), et la conjonction mot x TPO ne change rien non
plus (dico_tpo.py : 4 560 cellules a 19,5 % de p(2R avant stop)). Mais ces deux tests avaient un
angle mort : ils ne regardaient que des conditions binaires simples ou des mots, jamais des
COMBINAISONS DE FACTEURS de marche (mecHe + VWAP + structure + volatilite + heure + niveaux de la
veille), et jamais la question que l'utilisateur a posee explicitement :

    QU'EST-CE QUI EST TOUCHE EN PREMIER, l'objectif ou le stop ?

C'est la seule statistique qui decide de la rentabilite d'une geometrie : avec MFE ~ MAE, une cible
2 R est condamnee d'avance (il faut 33,3 % de premieres touches favorables), alors qu'une cible 1 R
n'a besoin que de 50 % et une cible 0,5 R de 66 %. On mesure donc, pour chaque combinaison ET
chaque geometrie, la frequence de premiere touche, plus les MFE/MAE moyens et medians.

Tout est causal : les facteurs n'utilisent que les barres jusqu'a t, les niveaux TPO sont ceux de
la session precedente. Les resultats s'ecrivent en continu dans COMBOS_resultats.csv.
"""
import csv
import os
import sys
from collections import defaultdict
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
HORIZONS = (12, 24)                       # 1 h et 2 h en M5
CIBLES = (0.5, 1.0, 2.0)                  # objectifs en multiples du stop
NBIN = 50


def charge(corpus, paire):
    f = B / corpus / ("%s_M1.csv" % paire)
    if not f.exists():
        return None
    d = pd.read_csv(f, usecols=["time", "open", "high", "low", "close"])
    if len(d) < 100000:
        return None
    d["t"] = pd.to_datetime(d["time"], unit="s")
    d = d.set_index("t")
    # TRAME reglable (M5 par defaut) : le meme moteur doit pouvoir tourner sur M15, M30 et H1,
    # comme demande - un facteur peut n'exister qu'a une echelle donnee.
    tf = os.environ.get("TF", "5min")
    m5 = d.resample(tf).agg(o=("open", "first"), high=("high", "max"),
                            low=("low", "min"), close=("close", "last")).dropna()
    # MINBAR : seuil de barres minimal pour accepter une paire a une trame donnee. Le feed cible
    # (Upcomers) n'a que 8 mois d'historique : en M15 cela fait ~16 000 barres, sous le seuil de
    # 20 000 qui etait code en dur - d'ou le fichier vide. Reglable pour pouvoir faire quand meme
    # le controle croise entre feeds.
    if len(m5) < int(os.environ.get("MINBAR", "20000")):
        return None
    tr = pd.concat([m5.high - m5.low, (m5.high - m5.close.shift()).abs(),
                    (m5.low - m5.close.shift()).abs()], axis=1).max(axis=1)
    return m5, tr.rolling(14).mean().values


def rsi(c, n=14):
    d = np.diff(c, prepend=c[0])
    su = pd.Series(np.where(d > 0, d, 0.0)).rolling(n).mean().values
    sd = pd.Series(np.where(d < 0, -d, 0.0)).rolling(n).mean().values
    with np.errstate(divide="ignore", invalid="ignore"):
        return 100.0 - 100.0 / (1.0 + np.where(sd > 0, su / np.where(sd == 0, np.nan, sd), np.inf))


def vwap_session(m5):
    tp = (m5.high + m5.low + m5.close) / 3.0
    j = pd.Series(m5.index.date, index=m5.index)
    return (tp.groupby(j).cumsum() / (tp.groupby(j).cumcount() + 1)).values


def niveaux_veille(m5):
    j = pd.Series(m5.index.date, index=m5.index).values
    poc = np.full(len(m5), np.nan); vah = np.full(len(m5), np.nan)
    val = np.full(len(m5), np.nan); haut = np.full(len(m5), np.nan); bas = np.full(len(m5), np.nan)
    niv = {}
    for d in sorted(set(j)):
        m = (j == d)
        h, l = m5.high.values[m], m5.low.values[m]
        if len(h) < 10:
            continue
        lo, hi = l.min(), h.max()
        if hi <= lo:
            continue
        bords = np.linspace(lo, hi, NBIN + 1)
        idx = np.clip(np.searchsorted(bords, (h + l) / 2.0) - 1, 0, NBIN - 1)
        tpo = np.bincount(idx, minlength=NBIN).astype(float)
        p = int(np.argmax(tpo)); acc = tpo[p]; cible = 0.7 * tpo.sum(); a = b = p
        while acc < cible and (a > 0 or b < NBIN - 1):
            g = tpo[a - 1] if a > 0 else -1.0
            dr = tpo[b + 1] if b < NBIN - 1 else -1.0
            if dr >= g:
                b += 1; acc += tpo[b]
            else:
                a -= 1; acc += tpo[a]
        niv[d] = (0.5 * (bords[p] + bords[p + 1]), bords[b + 1], bords[a], hi, lo)
    prec = None
    for d in sorted(set(j)):
        m = (j == d)
        if prec is not None and prec in niv:
            p0, vh0, vl0, h0, l0 = niv[prec]
            poc[m], vah[m], val[m], haut[m], bas[m] = p0, vh0, vl0, h0, l0
        prec = d
    return poc, vah, val, haut, bas


def facteurs(m5, atr):
    """Facteurs binaires causaux, avec leur SENS naturel (vendre ou acheter)."""
    c, o, h, l = m5.close.values, m5.o.values, m5.high.values, m5.low.values
    v = vwap_session(m5)
    poc, vah, val, haut, bas = niveaux_veille(m5)
    r = rsi(c)
    lo10 = pd.Series(l).rolling(10).min().shift(1).values
    hi10 = pd.Series(h).rolling(10).max().shift(1).values
    amed = pd.Series(atr).rolling(500, min_periods=50).median().values
    rng = h - l
    mh = h - np.maximum(o, c)
    mb = np.minimum(o, c) - l
    cross_bas = np.zeros(len(c), dtype=bool)
    cross_haut = np.zeros(len(c), dtype=bool)
    m30 = np.arange(0, len(c), 6)
    v30 = v[m30]
    c30 = c[m30]
    for k in range(1, len(m30)):
        if c30[k] < v30[k] and c30[k - 1] >= v30[k - 1]:
            cross_bas[m30[k]:min(m30[k] + 6, len(c))] = True
        if c30[k] > v30[k] and c30[k - 1] <= v30[k - 1]:
            cross_haut[m30[k]:min(m30[k] + 6, len(c))] = True
    ok = np.isfinite(atr) & (atr > 0)
    heure = m5.index.hour.values

    # ---- AXE DEMANDE PAR L'UTILISATEUR : oscillateurs, ecarts au VWAP en sigmas, ----
    # ---- dictionnaire de marche, volatilite Yang-Zhang et GARCH-proxy.            ----
    def ema(x, n):
        return pd.Series(x).ewm(span=n, adjust=False).mean().values

    # stochastique %K (14)
    lo14 = pd.Series(l).rolling(14).min().values
    hi14 = pd.Series(h).rolling(14).max().values
    stoch = 100.0 * (c - lo14) / np.where(hi14 - lo14 > 0, hi14 - lo14, np.nan)
    # MACD (12, 26, 9)
    macd = ema(c, 12) - ema(c, 26)
    sig = ema(macd, 9)
    hist = macd - sig
    # CCI (20)
    tp = (h + l + c) / 3.0
    sma20 = pd.Series(tp).rolling(20).mean().values
    dev20 = pd.Series(np.abs(tp - sma20)).rolling(20).mean().values
    cci = (tp - sma20) / np.where(0.015 * dev20 > 0, 0.015 * dev20, np.nan)
    # Williams %R (14)
    wr = -100.0 * (hi14 - c) / np.where(hi14 - lo14 > 0, hi14 - lo14, np.nan)
    # OBV sans volume (les CSV n'en ont pas) : cumul du signe des variations de cloture
    obv = np.cumsum(np.sign(np.diff(c, prepend=c[0])))
    obv_pente = pd.Series(obv).diff(10).values
    # ecart au VWAP en sigmas, sur M5 et sur M30
    ec5 = c - v
    sd5 = pd.Series(ec5).rolling(200).std().values
    dev5 = ec5 / np.where(sd5 > 0, sd5, np.nan)
    v30f = pd.Series(v[::6], index=m5.index[::6]).reindex(m5.index, method="ffill").values
    c30f = pd.Series(c[::6], index=m5.index[::6]).reindex(m5.index, method="ffill").values
    ec30 = c - v30f
    sd30 = pd.Series(c30f - v30f).rolling(200).std().values
    dev30 = ec30 / np.where(sd30 > 0, sd30, np.nan)
    # volatilite Yang-Zhang (20 barres) rapportee a sa mediane longue
    loghl = np.log(h / l)
    logco = np.log(c / o)
    yz = np.sqrt(pd.Series(loghl ** 2).rolling(20).mean().values * 0.5
                 + pd.Series(logco ** 2).rolling(20).mean().values)
    yzmed = pd.Series(yz).rolling(500, min_periods=50).median().values
    yzr = yz / np.where(np.nan_to_num(yzmed) > 0, yzmed, np.nan)
    # GARCH-proxy : variance EWMA (lambda 0.94) des rendements / variance longue
    # ATTENTION : ne PAS nommer cette variable `r` - `r` porte le RSI plus haut, et l'ecraser
    # faisait calculer les facteurs RSI sur les rendements au lieu du RSI (piege classique).
    ret = np.diff(np.log(c), prepend=np.log(c[0]))
    ew = pd.Series(ret ** 2).ewm(alpha=0.06, adjust=False).mean().values
    lv = pd.Series(ret ** 2).rolling(500, min_periods=50).mean().values
    garch = ew / np.where(np.nan_to_num(lv) > 0, lv, np.nan)
    # dictionnaire de marche : mot de 4 lettres (32 clotures, z-normalisees, 4 segments)
    logc = np.log(c)
    mu32 = pd.Series(logc).rolling(32).mean().values
    sd32 = pd.Series(logc).rolling(32).std(ddof=0).values
    z = (logc - mu32) / np.where(np.nan_to_num(sd32) > 0, sd32, np.nan)
    seg = pd.Series(z).rolling(8).mean().values
    letras = []
    for s in range(4):
        dec = 32 - 8 * (s + 1)
        vv = np.full(len(c), np.nan)
        if dec:
            vv[dec:] = seg[:len(c) - dec]
        else:
            vv = seg.copy()
        letras.append(vv)
    L = [np.where(np.isfinite(x), (x >= -0.6745).astype(float) + (x >= 0.0) + (x >= 0.6745), np.nan)
         for x in letras]
    mot_ok = np.all([np.isfinite(x) for x in L], axis=0)
    mot_bas = mot_ok & np.all([(x <= 1) for x in L], axis=0)          # tout en zone basse
    mot_haut = mot_ok & np.all([(x >= 2) for x in L], axis=0)         # tout en zone haute
    mot_monte = mot_ok & (L[0] <= 1) & (L[3] >= 2)                    # debut bas, fin haute
    mot_descend = mot_ok & (L[0] >= 2) & (L[3] <= 1)                  # debut haut, fin basse

    # --- FRACTALES (indicateur Musashi / fractales de Williams) ---
    # Un fractal haut est une barre dont le plus haut domine les 2 barres de chaque cote ; il n'est
    # donc CONFIRME que 2 barres plus tard, et on le decale de 3 barres pour rester causal. La
    # cassure de ce niveau est un declencheur classique de continuation ; le rejet juste en
    # dessous est un declencheur de retournement.
    cent_h = pd.Series(h).rolling(5, center=True).max().values
    cent_l = pd.Series(l).rolling(5, center=True).min().values
    fr_h = np.where(h >= cent_h - 1e-12, h, np.nan)
    fr_l = np.where(l <= cent_l + 1e-12, l, np.nan)
    fr_haut = pd.Series(fr_h).ffill().shift(3).values
    fr_bas = pd.Series(fr_l).ffill().shift(3).values
    fr_ok = np.isfinite(fr_haut) & np.isfinite(fr_bas)

    F = {
        "meche_haute": (ok & (rng > 0) & (mh >= 0.6 * rng) & (c < o), -1),
        "meche_basse": (ok & (rng > 0) & (mb >= 0.6 * rng) & (c > o), 1),
        "choch_bas": (ok & (c < lo10), -1),
        "choch_haut": (ok & (c > hi10), 1),
        "rsi_surachat": (ok & (r >= 70), -1),
        "rsi_survente": (ok & (r <= 30), 1),
        "sous_vwap30": (ok & (c < v), -1),
        "sur_vwap30": (ok & (c > v), 1),
        "cross_vwap_bas": (ok & cross_bas, -1),
        "cross_vwap_haut": (ok & cross_haut, 1),
        "vol_haute": (ok & (atr > 1.3 * np.nan_to_num(amed, nan=1e18)), 0),
        "vol_basse": (ok & (atr < 0.7 * np.nan_to_num(amed, nan=0.0)), 0),
        "sous_poc": (ok & np.isfinite(poc) & (c < poc), -1),
        "sur_poc": (ok & np.isfinite(poc) & (c > poc), 1),
        "sous_range_veille": (ok & np.isfinite(bas) & (c < bas), -1),
        "sur_range_veille": (ok & np.isfinite(haut) & (c > haut), 1),
        "dans_value_area": (ok & np.isfinite(vah) & (c >= val) & (c <= vah), 0),
        "hors_7_16": (ok & ~((heure >= 7) & (heure <= 16)), 0),
        # --- oscillateurs ---
        "stoch_surachat": (ok & (stoch >= 80), -1),
        "stoch_survente": (ok & (stoch <= 20), 1),
        "macd_hist_pos": (ok & (hist > 0), 1),
        "macd_hist_neg": (ok & (hist < 0), -1),
        "cci_surachat": (ok & (cci >= 100), -1),
        "cci_survente": (ok & (cci <= -100), 1),
        "wr_surachat": (ok & (wr >= -20), -1),
        "wr_survente": (ok & (wr <= -80), 1),
        "obv_monte": (ok & (obv_pente > 0), 1),
        "obv_descend": (ok & (obv_pente < 0), -1),
        # --- ecarts au VWAP en sigmas ---
        "dev5_plus2": (ok & (dev5 >= 2.0), -1),
        "dev5_moins2": (ok & (dev5 <= -2.0), 1),
        "dev30_plus2": (ok & (dev30 >= 2.0), -1),
        "dev30_moins2": (ok & (dev30 <= -2.0), 1),
        "dev30_plus3": (ok & (dev30 >= 3.0), -1),
        "dev30_moins3": (ok & (dev30 <= -3.0), 1),
        # --- volatilite Yang-Zhang et GARCH-proxy ---
        "yz_haute": (ok & (np.nan_to_num(yzr, nan=0.0) > 1.3), 0),
        "yz_basse": (ok & (np.nan_to_num(yzr, nan=1e18) < 0.7), 0),
        "garch_haute": (ok & (np.nan_to_num(garch, nan=0.0) > 1.3), 0),
        "garch_basse": (ok & (np.nan_to_num(garch, nan=1e18) < 0.7), 0),
        # --- dictionnaire de marche (mots de 4 lettres) ---
        "mot_bas": (ok & mot_bas, 1),
        "mot_haut": (ok & mot_haut, -1),
        "mot_monte": (ok & mot_monte, 1),
        "mot_descend": (ok & mot_descend, -1),
        # --- fractales (Musashi) ---
        "fractal_haut_casse": (ok & fr_ok & (c > fr_haut), 1),
        "fractal_bas_casse": (ok & fr_ok & (c < fr_bas), -1),
        "sous_fractal_haut": (ok & fr_ok & (c < fr_haut), -1),
        "sur_fractal_bas": (ok & fr_ok & (c > fr_bas), 1),
    }
    return F


def premiere_touche(m5, atr, masque, sens, horizon, cible_r, stop_mult=1.0):
    """CE QUI EST TOUCHE EN PREMIER : renvoie les frequences et les excursions."""
    c, h, l = m5.close.values, m5.high.values, m5.low.values
    n = len(c)
    idx = np.flatnonzero(masque)
    idx = idx[(idx < n - horizon - 1)]
    if len(idx) < 80:
        return None
    off = np.arange(1, horizon + 1)
    Hh, Ll = h[idx[:, None] + off], l[idx[:, None] + off]
    e, a = c[idx], atr[idx] * stop_mult
    if sens < 0:
        tp, sl = e - cible_r * a, e + a
        hit_tp, hit_sl = (Ll <= tp[:, None]), (Hh >= sl[:, None])
        mfe = (e[:, None] - Ll) / a[:, None]
        mae = (Hh - e[:, None]) / a[:, None]
    else:
        tp, sl = e + cible_r * a, e - a
        hit_tp, hit_sl = (Hh >= tp[:, None]), (Ll <= sl[:, None])
        mfe = (Hh - e[:, None]) / a[:, None]
        mae = (e[:, None] - Ll) / a[:, None]
    it = np.where(hit_tp.any(1), hit_tp.argmax(1), 10 ** 6)
    isl = np.where(hit_sl.any(1), hit_sl.argmax(1), 10 ** 6)
    tp_premier = np.mean(it < isl)
    sl_premier = np.mean(isl <= it)
    return dict(n=len(idx), p_tp=100 * float(tp_premier), p_sl=100 * float(sl_premier),
                mfe=float(np.mean(mfe.max(axis=1))), mae=float(np.mean(mae.max(axis=1))),
                mfe50=float(np.median(mfe.max(axis=1))), mae50=float(np.median(mae.max(axis=1))))


def main():
    corpus = os.environ.get("CORPUS", "m1_pos")
    paires = [p.stem.replace("_M1", "") for p in sorted((B / corpus).glob("*_M1.csv"))]
    sortie = B / ("COMBOS_%s.csv" % corpus)
    if not sortie.exists():
        with sortie.open("w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow(["corpus", "paire", "sens", "combo", "geometrie", "horizon",
                                    "n", "p_tp_premier", "p_sl_premier", "mfe", "mae", "mfe_med", "mae_med",
                                    "annee_min_p_tp"])
    vus = set()
    if sortie.exists():
        with sortie.open(encoding="utf-8") as f:
            for r in csv.DictReader(f):
                vus.add((r["paire"], r["combo"], r["geometrie"], r["horizon"]))
    for paire in paires:
        ch = charge(corpus, paire)
        if ch is None:
            continue
        m5, atr = ch
        F = facteurs(m5, atr)
        noms = list(F.keys())
        lignes = []
        ans = m5.index.year.values
        for taille in (1, 2, 3):
            for groupe in combinations(noms, taille):
                sens = [F[g][1] for g in groupe if F[g][1] != 0]
                if not sens:
                    continue
                if len(set(sens)) != 1:
                    continue                      # melanger vendeur et acheteur n'a pas de sens
                s = sens[0]
                masque = np.ones(len(m5), dtype=bool)
                for g in groupe:
                    masque &= F[g][0]
                if masque.sum() < 300:
                    continue
                cle = (paire, "+".join(groupe), "generale", "")
                if any((paire, "+".join(groupe), f"{h}/{c}", "") in vus
                       for h in HORIZONS for c in CIBLES):
                    continue
                for horizon in HORIZONS:
                    for cible in CIBLES:
                        r = premiere_touche(m5, atr, masque, s, horizon, cible)
                        if not r or r["n"] < 150:
                            continue
                        # stabilite : p_tp de la pire annee
                        par_an = []
                        for an in np.unique(ans[np.flatnonzero(masque)]):
                            ma = masque & (ans == an)
                            if ma.sum() < 60:
                                continue
                            rr = premiere_touche(m5, atr, ma, s, horizon, cible)
                            if rr:
                                par_an.append(rr["p_tp"])
                        lignes.append([corpus, paire, "COURT" if s < 0 else "LONG", "+".join(groupe),
                                       "%dh/%gR" % (horizon, cible), horizon, r["n"], round(r["p_tp"], 2),
                                       round(r["p_sl"], 2), round(r["mfe"], 3), round(r["mae"], 3),
                                       round(r["mfe50"], 3), round(r["mae50"], 3),
                                       round(min(par_an), 2) if par_an else ""])
        with sortie.open("a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerows(lignes)
        print("  %-9s %d combinaisons evaluees" % (paire, len(lignes)), flush=True)
    print("ecrit %s" % sortie, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
