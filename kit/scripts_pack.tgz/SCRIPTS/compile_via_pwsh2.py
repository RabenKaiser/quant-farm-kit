# -*- coding: utf-8 -*-
"""compile_via_pwsh2.py — compile via PowerShell avec /log (le seul qui marche).
Le manuel '& MetaEditor /compile:... /log:...' produit l'ex5 à 100%.
"""
import subprocess, time, sys
from pathlib import Path
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

mq5 = Path(sys.argv[1]).resolve()
ex5 = mq5.with_suffix(".ex5")
clog = mq5.with_suffix(".clog")
if ex5.exists():
    ex5.unlink()
if clog.exists():
    clog.unlink()

# PowerShell -Command avec & (équivalent exact du manuel)
ps = ('& "C:\\MT5\\MetaEditor64.exe" /compile:"{mq5}" /log:"{clog}" /s'
      .format(mq5=mq5, clog=clog))
r = subprocess.run([r"C:\windows\System32\WindowsPowerShell\v1.0\powershell.exe",
                    "-NoProfile", "-Command", ps],
                   capture_output=True, timeout=120)
# attendre l'écriture (MetaEditor sort ~3s après le compile)
for _ in range(20):
    time.sleep(1)
    if ex5.exists() and ex5.stat().st_size > 5000:
        print(f"OK {mq5.name} ({ex5.stat().st_size}b)", flush=True)
        sys.exit(0)
print(f"FAIL {mq5.name} rc={r.returncode}", flush=True)
sys.exit(1)
