# -*- coding: utf-8 -*-
"""build_final2b.py — PORTEFEUILLE FINAL : 174 jambes validees 2 brokers.

CRITERE D'ENTREE (strict)
  Une jambe n'entre que si elle est POSITIVE et STABLE sur :
    - Upcomers  (8 mois, 2026)
    - Dukascopy (6 ans, 2020-2025)
  C'est la seule validation qui a ecarte `brk_round_dn`.

SCOPE : FX + metaux (les indices Dukascopy n'ont pas de M5 sur 6 ans).

EXCLUSIONS DE DERIVE
  On ecarte les marches dont le sous-jacent a bouge de plus de 8 % sur la
  periode Upcomers : un achat de repli y gagne mecaniquement (carry deguise).

CONTRAINTES
  - no-hedging : 1 jambe par symbole au meme instant (pas de chevauchement)
  - max 2 jambes par symbole, 1 par (symbole, structure)
  - plafond de contribution 12 % par jambe

SORTIE : portfolio_final2b.json + tables EA
"""
import os, sys, json, glob
from collections import defaultdict
import numpy as np
import pandas as pd

BASE = r"C:\EAFarm\HISTORY - Copy\research"
sys.path.insert(0, os.path.join(BASE, "SCRIPTS"))
import robust_structures as RS

MAX_PER_SYM = 2
MAX_SHARE = 0.18          # assoupli : 0.12 bridait a 6 jambes sur 173
DRIFT_MAX = 0.08
N_TARGET = 20

val = json.load(open(os.path.join(BASE, "legs_validated.json"), encoding="utf-8"))
print(f"{len(val)} jambes validees 2 brokers")

# ---- exclusions de derive ----
keep, drop = [], []
for r in val:
    if abs(r["drift_u"]) > DRIFT_MAX:
        drop.append(r)
    else:
        keep.append(r)
print(f"\n{len(keep)} retenues, {len(drop)} ecartees pour derive")
if drop:
    seen = set()
    for r in drop:
        if r["sym"] in seen:
            continue
        seen.add(r["sym"])
        print(f"  {r['sym']:<10}{r['drift_u']:+.1%}")

# ---- score : on veut positif des DEUX cotes ET stable ----
# on normalise pour ne pas favoriser les marches a forte volatilite
for r in keep:
    r["rpu"] = r["R_u"] / max(r["n_u"], 1)      # R par trade (Upcomers)
    r["rpd"] = r["R_d"] / max(r["n_d"], 1)      # R par trade (Dukascopy)
    # score = le MINIMUM des deux (exige la coherence)
    r["score"] = min(r["rpu"], r["rpd"]) * min(r["rdd_u"], r["rdd_d"]) ** 0.3

keep.sort(key=lambda r: -r["score"])

sel = []
nsym = defaultdict(int)
nstr = defaultdict(int)
for r in keep:
    if len(sel) >= N_TARGET:
        break
    s = r["sym"]
    if nsym[s] >= MAX_PER_SYM:
        continue
    if nstr[(s, r["struct"])] >= 1:
        continue
    # plafond de contribution (apres 6 jambes)
    if len(sel) >= 6:
        Rtot = sum(x["R_u"] for x in sel)
        newR = Rtot + r["R_u"]
        if newR > 0 and r["R_u"] / newR > MAX_SHARE:
            continue
        if Rtot > 0 and max(x["R_u"] for x in sel) / newR > MAX_SHARE * 1.4:
            continue
    sel.append(r)
    nsym[s] += 1; nstr[(s, r["struct"])] += 1

print(f"\n=== PORTEFEUILLE FINAL 2 BROKERS : {len(sel)} jambes ===")
print(f"{'marche':<9}{'structure':<14}{'filtre':<10}"
      f"{'R_up':>8}{'R_duka':>9}{'n_u':>6}{'n_d':>7}{'drift':>7}")
for r in sorted(sel, key=lambda x: -x["R_u"]):
    print(f"{r['sym']:<9}{r['struct']:<14}{r['filt']:<10}"
          f"{r['R_u']:>8.1f}{r['R_d']:>9.1f}{r['n_u']:>6}{r['n_d']:>7}"
          f"{r['drift_u']:>+7.1%}")

# ---- mesures ----
Ru = sum(r["R_u"] for r in sel)
Rd = sum(r["R_d"] for r in sel)
Nu = sum(r["n_u"] for r in sel)
Nd = sum(r["n_d"] for r in sel)
print(f"\n  Upcomers  : R={Ru:.0f}  trades={Nu}  -> R/mois = {Ru/8:.2f}")
print(f"  Dukascopy : R={Rd:.0f}  trades={Nd}  -> R/an   = {Rd/6:.1f}")

# ---- exposition ----
dev = defaultdict(float)
for r in sel:
    s = r["sym"]
    if len(s) == 6:
        dev[s[:3]] += r["R_u"]; dev[s[3:]] += r["R_u"]
tot = sum(dev.values()) or 1
print(f"\n=== EXPOSITION (Upcomers) ===")
for d, v in sorted(dev.items(), key=lambda t: -t[1])[:9]:
    if v/tot > 0.02:
        print(f"  {d:<5}{v/tot:>7.1%}")

Rs = np.array([r["R_u"] for r in sel])
sh = np.sort(Rs)[::-1]/Rs.sum()
print(f"\n=== CONCENTRATION ===")
print(f"  1re jambe   : {sh[0]:.1%}")
print(f"  3 premieres : {sh[:3].sum():.1%}")
print(f"  Herfindahl  : {float((sh**2).sum()):.3f} (neutre {1/len(sh):.3f})")

json.dump(dict(n_legs=len(sel), R_up=Ru, R_duka=Rd,
               n_up=Nu, n_duka=Nd, R_per_month_up=Ru/8,
               eur_expo=dev.get("EUR", 0)/tot,
               top_share=float(sh[0]),
               herfindahl=float((sh**2).sum()),
               legs=sel),
          open(os.path.join(BASE, "portfolio_final2b.json"), "w"),
          indent=1, default=str)
print(f"\n-> portfolio_final2b.json")
