"""ecart_corpus_reel : l'ecart entre le corpus et les ordres reels est-il un OFFSET CONSTANT ?

Round 391. Quatre couples sont desormais mesures des deux cotes, corpus et ordres reels, avec le meme
moteur (horizon en barres, sortie a l'ask, spread de la minute) et la meme geometrie (stop 3 ATR /
cible 6 ATR) :

    AUDCAD S r=50   corpus +0,1798   reel +0,1240   ecart -0,056
    AUDCAD S r=100  corpus +0,1356   reel +0,0869   ecart -0,049
    AUDUSD S r=100  corpus +0,0653   reel +0,0409   ecart -0,024
    EURCHF S r=50   corpus +0,0076   reel -0,0558   ecart -0,063

L'ecart vaut -0,024 a -0,063, soit environ -0,05 +- 0,02 : il ressemble a un OFFSET, pas a un facteur
multiplicatif. C'est une information exploitable, et c'est l'objet de ce script : si l'ecart est un
offset, alors on peut predire ce qu'un couple NON ENCORE mesure devrait donner en ordres reels, avec
son incertitude -- et donc decider quels couples valent la peine d'etre testes plutot que de tester
les neuf.

Ce que ce script ne fait PAS : il ne remplace pas une mesure. La colonne « attendu en reel » est une
EXTRAPOLATION calibree sur quatre couples, pas un resultat. Elle sert a ordonner les validations.

Env : SLR (3), EXEC_MIN, ATR_EA, SORTIE.
"""
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import barrieres_m1 as BM  # noqa: E402
import reel_empile as RE  # noqa: E402
import table_honnete as TH  # noqa: E402

B = Path(r"C:\EAFarm\HISTORY - Copy\research")


def main():
    TH.SLR, TH.TPR = RE.SLR, RE.SLR * 2.0
    print("ECART CORPUS / ORDRES REELS | stop %.1f ATR | journal %s\n" % (RE.SLR, RE.JOUR), flush=True)
    lignes = []
    cache = {}
    for paire, ligne, range_, sens in RE.COMPOS:
        reel = RE.mesure(paire, ligne, range_, sens)
        if paire not in cache:
            cache[paire] = BM.charge_m30(paire, "m1_pos")
        corp = TH.mesure(paire, "m1_pos", range_, sens=sens, M=cache[paire])
        if corp is None:
            continue
        if reel is None:
            print("  %-8s %-10s r=%-3d %s : corpus %+.4f | reel NON MESURE"
                  % (paire, ligne, range_, sens, corp["R"]), flush=True)
            lignes.append((paire, ligne, range_, sens, corp["R"], None, None))
            continue
        ecart = reel["R"] - corp["R"]
        print("  %-8s %-10s r=%-3d %s : corpus %+.4f (%3d tx) | reel %+.4f (%3d tx) | ecart %+.4f"
              % (paire, ligne, range_, sens, corp["R"], corp["n"], reel["R"], reel["n"], ecart),
              flush=True)
        lignes.append((paire, ligne, range_, sens, corp["R"], reel["R"], ecart))
    ec = np.array([x[6] for x in lignes if x[6] is not None])
    if len(ec) < 2:
        print("\n  trop peu de couples mesures des deux cotes pour calibrer un offset")
        return 1
    off, sd = float(ec.mean()), float(ec.std(ddof=1))
    et = sd / np.sqrt(len(ec))
    print("\n  ECART moyen %+.4f | ecart-type %.4f | erreur-type %.4f | sur %d couples"
          % (off, sd, et, len(ec)), flush=True)
    print("  -> l'ecart est un OFFSET (il ne depend pas du niveau du corpus : %s)"
          % ("OUI" if abs(np.corrcoef([x[4] for x in lignes if x[6] is not None], ec)[0, 1]) < 0.6
             else "a verifier, correlation elevee"), flush=True)
    print("\n  ATTENDU EN ORDRES REELS pour les couples non mesures (extrapolation, PAS une mesure) :",
          flush=True)
    att = []
    for paire, ligne, range_, sens, cv, rv, ev in lignes:
        if rv is None:
            att.append((paire, ligne, range_, sens, cv, cv + off))
    for paire, ligne, range_, sens, cv, a in sorted(att, key=lambda x: -x[5]):
        print("    %-8s %-10s r=%-3d %s : corpus %+.4f -> attendu reel %+.4f +- %.3f %s"
              % (paire, ligne, range_, sens, cv, a, sd,
                 "POSITIF" if a - sd > 0 else ("positif ?" if a > 0 else "probablement NUL")),
              flush=True)
    dest = Path(os.environ.get("SORTIE", str(B / "ECART_CORPUS_REEL.md")))
    out = ["# Ecart corpus / ordres reels : un offset calibre", "",
           "Moteur honnete (horizon en barres, sortie a l'ask, spread de la minute), stop %.1f ATR, "
           "cible 6 ATR, meme geometrie des deux cotes." % RE.SLR, "",
           "| couple | range | sens | corpus R/tx | reel R/tx | ecart |", "|---|---|---|---|---|---|"]
    for paire, ligne, range_, sens, cv, rv, ev in lignes:
        out.append("| %s (%s) | %d | %s | %+.4f | %s | %s |"
                   % (paire, ligne, range_, sens, cv,
                      "%+.4f" % rv if rv is not None else "non mesure",
                      "%+.4f" % ev if ev is not None else "--"))
    out += ["", "**Ecart moyen %+.4f, ecart-type %.4f sur %d couples mesures des deux cotes.**"
            % (off, sd, len(ec)), "",
            "Extrapolation (PAS une mesure) pour les couples non mesures :", "",
            "| couple | corpus | attendu en reel |", "|---|---|---|"]
    for paire, ligne, range_, sens, cv, a in sorted(att, key=lambda x: -x[5]):
        out.append("| %s (%s) r=%d %s | %+.4f | %+.4f |" % (paire, ligne, range_, sens, cv, a))
    dest.write_text("\n".join(out), encoding="utf-8")
    print("\n  -> %s" % dest.name, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
