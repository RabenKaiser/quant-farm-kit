# -*- coding: utf-8 -*-
"""c13v2_py_fast2.py — version corrigee: pre-calcul OB valides (impulsion
dans jj+1..jj+imp_look), puis propagation du dernier OB dont la confirmation
est PASSEE (dispo a partir de jj+imp_look). Lookahead reel = 0."""
import sys
import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
BARS = r"C:\EAFarm\HISTORY - Copy\research\bars"


def load_m1(sym):
    df = pd.read_parquet(f"{BARS}\\{sym}_M1_db.parquet")
    df = df.set_index("ts_event").sort_index()
    df = df[~df.index.duplicated(keep="last")]
    return df[["open", "high", "low", "close", "volume"]].astype(float)


def resample(df, rule):
    return df.resample(rule).agg(
        {"open": "first", "high": "max", "low": "min", "close": "last",
         "volume": "sum"}).dropna()


def atr_s(s, period=14):
    h, l, c = s["high"], s["low"], s["close"]
    pc = c.shift(1)
    tr = pd.concat([(h - l), (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    return tr.rolling(period).mean()


def backtest(sym, year, cfg):
    m1 = load_m1(sym)
    start = pd.Timestamp(f"{year}-01-01", tz="UTC")
    end = pd.Timestamp(f"{year + 1}-01-01", tz="UTC")
    wu = start - pd.Timedelta(days=260)
    m5 = resample(m1.loc[wu:end], "5min").loc[start:end]
    m15 = resample(m1.loc[wu:end], "15min")
    h4 = resample(m1.loc[wu:end], "4h")

    # --- bias H4 ---
    if cfg.get("bias", "ema") == "vwap":
        tv = (h4["high"] + h4["low"] + h4["close"]) / 3
        vwap = (tv * h4["volume"]).rolling(cfg.get("vwap_len", 96)).sum() / \
               h4["volume"].rolling(cfg.get("vwap_len", 96)).sum()
    else:
        vwap = h4["close"].ewm(span=cfg.get("ema", 200), adjust=False).mean()

    # --- detecter TOUS les OB bruts (candidat j + impulsion jj in j+1..j+L) ---
    o = m15["open"].to_numpy(); h = m15["high"].to_numpy()
    l = m15["low"].to_numpy(); c = m15["close"].to_numpy()
    v = m15["volume"].to_numpy()
    a15 = atr_s(m15, 14).to_numpy()
    av = pd.Series(v).rolling(cfg.get("vol_look", 50)).mean().to_numpy()
    n = len(m15)
    body = np.abs(c - o)
    is_bull = c > o
    is_bear = c < o
    L = cfg.get("imp_look", 5)
    imp_mult = cfg.get("imp_atr", 1.2)
    vol_mult = cfg.get("imp_vol", 1.5)

    # ob_valid[j] = liste des jj candidats dont l'impulsion est dans jj+1..jj+L
    # (detection pure, avant propagation temporelle)
    ob_bull_j = []  # (jj, dispo_a_partir_de)
    ob_bear_j = []
    for jj in range(n):
        if not np.isfinite(a15[jj]) or a15[jj] <= 0:
            continue
        thr = a15[jj] * imp_mult
        if is_bear[jj]:
            for k in range(1, L + 1):
                kk = jj + k
                if kk >= n:
                    break
                vok = (not np.isfinite(av[kk])) or v[kk] >= av[kk] * vol_mult
                if is_bull[kk] and body[kk] >= thr and c[kk] > h[jj] and vok:
                    ob_bull_j.append((jj, jj + k))  # dispo apres l'impulsion k
                    break
        if is_bull[jj]:
            for k in range(1, L + 1):
                kk = jj + k
                if kk >= n:
                    break
                vok = (not np.isfinite(av[kk])) or v[kk] >= av[kk] * vol_mult
                if is_bear[kk] and body[kk] >= thr and c[kk] < l[jj] and vok:
                    ob_bear_j.append((jj, jj + k))
                    break

    # zones par jj
    zb = {}  # jj -> (zl, zh, dispo)
    zs = {}
    for jj, dispo in ob_bull_j:
        zb[jj] = (l[jj], o[jj], dispo)
    for jj, dispo in ob_bear_j:
        zs[jj] = (o[jj], h[jj], dispo)

    # --- pour chaque barre M5, le dernier OB (bull/bear) dont dispo <= idx15 ---
    m15_t = m15.index.values.astype("datetime64[ns]")
    m5_t = m5.index.values.astype("datetime64[ns]")
    idx15 = np.searchsorted(m15_t, m5_t, side="right") - 1
    idx15 = np.clip(idx15, 0, n - 1)
    max_age = cfg.get("ob_age", 10000)

    pip = 0.0001
    want_buy = np.zeros(len(m5), dtype=bool)
    want_sell = np.zeros(len(m5), dtype=bool)
    buy_zl = np.full(len(m5), np.nan); buy_zh = np.full(len(m5), np.nan)
    sell_zl = np.full(len(m5), np.nan); sell_zh = np.full(len(m5), np.nan)

    o5 = m5["open"].to_numpy(); h5 = m5["high"].to_numpy()
    l5 = m5["low"].to_numpy(); c5 = m5["close"].to_numpy()
    v5 = m5["volume"].to_numpy()
    av5 = pd.Series(v5).rolling(cfg.get("vol_look", 50)).mean().to_numpy()
    body5 = np.abs(c5 - o5)
    rej_mult = cfg.get("rej_wick", 1.5)
    rej_vol = cfg.get("rej_vol", 1.2)
    close_in = cfg.get("close_zone", 0.20)

    # dernier OB dispo par index m15
    last_bull_by15 = -1
    last_bear_by15 = -1
    lastB_zl = np.nan; lastB_zh = np.nan; lastB_idx = -1
    lastS_zl = np.nan; lastS_zh = np.nan; lastS_idx = -1
    zb_sorted = sorted(zb.items())
    zs_sorted = sorted(zs.items())
    ib = 0
    is2 = 0
    # on avance sur les barres M15 en ajoutant les OB dont dispo <= i15
    for i in range(len(m5)):
        i15 = idx15[i]
        # ajouter les OB bull dispo
        while ib < len(zb_sorted) and zb_sorted[ib][0] <= i15:
            jj, (zl0, zh0, dispo) = zb_sorted[ib]
            if dispo <= i15:
                lastB_zl, lastB_zh, lastB_idx = zl0, zh0, jj
            ib += 1
        while is2 < len(zs_sorted) and zs_sorted[is2][0] <= i15:
            jj, (zl0, zh0, dispo) = zs_sorted[is2]
            if dispo <= i15:
                lastS_zl, lastS_zh, lastS_idx = zl0, zh0, jj
            is2 += 1
        if lastB_idx >= 0 and i15 - lastB_idx <= max_age and not np.isnan(lastB_zl):
            zl, zh = min(lastB_zl, lastB_zh), max(lastB_zl, lastB_zh)
            zoneH = max(zh - zl, pip * 0.5)
            lowerW = min(o5[i], c5[i]) - l5[i]
            vok = (not np.isfinite(av5[i])) or v5[i] >= av5[i] * rej_vol
            if (body5[i] >= pip * 0.5 and l5[i] <= zh and
                c5[i] >= zl + zoneH * close_in and c5[i] <= zh and
                c5[i] > o5[i] and body5[i] > 0 and
                (lowerW / body5[i]) >= rej_mult and vok):
                want_buy[i] = True
                buy_zl[i], buy_zh[i] = zl, zh
        if lastS_idx >= 0 and i15 - lastS_idx <= max_age and not np.isnan(lastS_zl):
            zl, zh = min(lastS_zl, lastS_zh), max(lastS_zl, lastS_zh)
            zoneH = max(zh - zl, pip * 0.5)
            upperW = h5[i] - max(o5[i], c5[i])
            vok = (not np.isfinite(av5[i])) or v5[i] >= av5[i] * rej_vol
            if (body5[i] >= pip * 0.5 and h5[i] >= zl and
                c5[i] <= zh - zoneH * close_in and c5[i] >= zl and
                c5[i] < o5[i] and body5[i] > 0 and
                (upperW / body5[i]) >= rej_mult and vok):
                want_sell[i] = True
                sell_zl[i], sell_zh[i] = zl, zh

    # --- simulation ---
    hour = m5.index.hour.to_numpy()
    excl = set(cfg.get("excl_hours", []))
    hok = np.array([h not in excl for h in hour])
    min_stop = cfg.get("min_stop", 0.00025)
    tp_r = cfg.get("tp_r", 2.5)
    buf = cfg.get("buf_atr", 0.25)
    a15a = a15

    pos = None
    eq_r = 0.0
    trades = []
    day = None
    day_count = 0
    for i in range(1, len(m5)):
        t = m5.index[i]
        d = t.date()
        if day != d:
            day = d; day_count = 0
        if pos is not None:
            dirn = pos["dir"]
            sl = pos["sl"]; tp0 = pos["tp"]; entry = pos["entry"]
            eff_l = l5[i] if dirn == 1 else l5[i]
            eff_h = h5[i] if dirn == 1 else h5[i]
            hit_sl = (eff_l <= sl) if dirn == 1 else (eff_h >= sl)
            hit_tp = (eff_h >= tp0) if dirn == 1 else (eff_l <= tp0)
            if hit_sl or hit_tp:
                exit_px = tp0 if (hit_tp and not hit_sl) else sl
                r = (exit_px - entry) / pos["risk"] if dirn == 1 \
                    else (entry - exit_px) / pos["risk"]
                eq_r += r
                trades.append(r)
                pos = None
        if pos is None and hok[i] and (want_buy[i] or want_sell[i]):
            bv = vwap.asof(m5.index[i - 1]) if len(vwap.dropna()) else np.nan
            if np.isnan(bv):
                continue
            bias = 1 if c5[i - 1] > bv else -1
            dirn = 1 if want_buy[i] else -1
            if (dirn == 1 and bias != 1) or (dirn == -1 and bias != -1):
                continue
            entry = c5[i]
            if dirn == 1:
                zl = buy_zl[i]
                atrv = a15a[idx15[i]]
                sl = zl - (buf * atrv if np.isfinite(atrv) else pip * 5)
                if (entry - sl) < min_stop:
                    sl = entry - min_stop
                risk = entry - sl
                tp = entry + risk * tp_r
            else:
                zh = sell_zh[i]
                atrv = a15a[idx15[i]]
                sl = zh + (buf * atrv if np.isfinite(atrv) else pip * 5)
                if (sl - entry) < min_stop:
                    sl = entry + min_stop
                risk = sl - entry
                tp = entry - risk * tp_r
            if risk > 0:
                pos = {"dir": dirn, "entry": float(entry), "sl": float(sl),
                       "tp": float(tp), "risk": float(risk)}
                day_count += 1
    ntr = len(trades)
    if ntr == 0:
        return {"n": 0, "R": 0.0, "wr": 0, "pf": 0, "dd": 0}
    arr = np.array(trades)
    wins = arr[arr > 0]; losses = arr[arr < 0]
    gw = wins.sum() if len(wins) else 0
    gl = -losses.sum() if len(losses) else 0
    eq = np.cumsum(arr)
    dd = float((np.maximum.accumulate(eq) - eq).max())
    return {"n": ntr, "R": float(arr.sum()), "wr": float(len(wins) / ntr * 100),
            "pf": float(gw / gl) if gl > 0 else 99.0, "dd": dd}


if __name__ == "__main__":
    sym = sys.argv[1] if len(sys.argv) > 1 else "EURUSD"
    year = int(sys.argv[2]) if len(sys.argv) > 2 else 2024
    cfg = {"imp_atr": 1.2, "imp_vol": 1.5, "imp_look": 5, "ob_age": 10000,
           "rej_wick": 1.5, "rej_vol": 1.2, "close_zone": 0.20, "tp_r": 2.5,
           "bias": "ema", "excl_hours": [6, 7, 12, 15, 19, 23],
           "min_stop": 0.00025, "buf_atr": 0.25}
    import time
    t0 = time.time()
    res = backtest(sym, year, cfg)
    print(sym, year, res, f"{time.time()-t0:.1f}s")
