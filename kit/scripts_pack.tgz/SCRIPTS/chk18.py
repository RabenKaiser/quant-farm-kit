﻿import pandas as pd, glob, os
from datetime import datetime, timezone
OUT = r"C:\EAFarm\HISTORY - Copy\research\m1_pos"
MIN = 1_500_000
rows=[]
for f in sorted(glob.glob(os.path.join(OUT,"*_M1.csv"))):
    sym = os.path.basename(f).replace("_M1.csv","")
    try:
        df = pd.read_csv(f, usecols=["time"])
        if len(df)==0: continue
        t0=int(df['time'].iloc[0]); t1=int(df['time'].iloc[-1])
        d0=datetime.fromtimestamp(t0,tz=timezone.utc); d1=datetime.fromtimestamp(t1,tz=timezone.utc)
        rows.append((sym,len(df),d0,d1))
    except Exception as e:
        rows.append((sym,-1,None,None))
ok=[r for r in rows if r[1]>=MIN]
print(f"VALIDABLES : {len(ok)}")
for s,n,d0,d1 in sorted(ok,key=lambda x:-x[1]):
    print(f"  {s:<8} {n:>10,}  {d0.date()} -> {d1.date()}")
bad=[r for r in rows if 0<=r[1]<MIN]
print(f"\nECARTES : {len(bad)}")
for s,n,d0,d1 in sorted(bad,key=lambda x:-x[1]):
    print(f"  {s:<8} {n:>10,}")
