# -*- coding: utf-8 -*-
"""debug_encoding.py — vérifie l'encodage du segment log."""
import re

SEG = r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS\_ref_seg.log"
raw = open(SEG, "rb").read()
print("bytes:", len(raw))

for enc in ["utf-16-le", "utf-8", "utf-16"]:
    try:
        txt = raw.decode(enc)
        sl = [l for l in txt.split("\n") if "stop loss triggered" in l]
        ex = sl[0][:130] if sl else "none"
        print(f"{enc}: {len(sl)} lignes SL | ex: {ex}")
        if sl:
            pat = re.compile(r"stop loss triggered #(\d+) (buy|sell) [\d.]+ (\S+) sl: ([\d.]+) tp: ([\d.]+) \[#\d+ \w+ [\d.]+ \S+ at ([\d.]+)\]")
            m = pat.search(sl[0])
            print(f"  regex match: {m.groups() if m else 'NO'}")
            break
    except Exception as e:
        print(f"{enc}: {e}")
