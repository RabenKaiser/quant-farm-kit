# -*- coding: utf-8 -*-
"""boucle_goal.py â€” LA BOUCLE COMPLETE POUR ATTEINDRE L'OBJECTIF.

OBJECTIF : un panier equipe des deux sens, sur plusieurs paires, avec un bon
nombre de transactions, dont le R par transaction reste POSITIF en ordres reels
sur un melange de periodes hostiles et bonnes.

CE QUE FAIT LA BOUCLE, TOUTE SEULE, EN CONTINU
----------------------------------------------
  ITERATION 1  SELECTION   : on part de la grille complete du labo (combinaison =
                             declencheur|filtre1|filtre2|sens x 48 sorties) et on
                             garde les lignes robustes : positives dans au moins
                             6 periodes sur 8, pire periode >= -0.02 R, au moins
                             150 transactions.
               GROUPEMENT  : les lignes sont groupees par sortie (stop/objectif),
                             parce que l'EA n'applique qu'une geometrie a la fois.
               TEST REEL   : chaque groupe est teste en ORDRES REELS sur MT5, sur
                             les 8 periodes melangeant hostiles et bonnes.
               EVALUATION  : on garde le R par transaction REEL de chaque groupe.
               MUTATION    : les combinaisons des groupes dont le R reel est
                             positif sont reprises, et on leur ajoute leurs
                             SORTIES VOISINES (stop x1.5, stop /1.5, objectif
                             voisin dans la grille). C'est ainsi que la boucle
                             explore autour de ce qui survit au reel.
  ITERATION 2..N  on refait TEST -> EVALUATION -> MUTATION sur les candidats
                  produits par l'iteration precedente, en alternant les deux
                  terminaux pour aller deux fois plus vite.
  ARRET       a l'heure demandee (3 h par defaut), avec un rapport ecrit a
              chaque etape dans GOAL.md et un etat sauvegarde dans goal_state.json
              (la boucle reprend exactement ou elle s'etait arretee).

CE QUI EST INTERDIT DANS CETTE BOUCLE, ET POURQUOI
  - aucun critere pris sur une seule periode : le classement se fait par la PIRE
    periode ;
  - aucune configuration jugee sur le labo seul : le seul juge est le R REEL ;
  - rien n'est supprime : tout est ecrit dans goal_essais.jsonl, y compris les
    echecs (c'est ce qui a permis d'attraper les quatre artefacts de la nuit).

USAGE : python boucle_goal.py [--arret 03:00] [--paires EURUSD,EURJPY]
"""
import argparse
import collections
import datetime
import json
import subprocess
import sys
import time
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
COMMON = Path.home() / "AppData/Roaming/MetaQuotes/Terminal/Common/Files"
LIVE = BASE / "lab_results.jsonl"
PY = sys.executable
RUNNER = BASE / "SCRIPTS" / "lab_parallel.py"
ETAT = BASE / "goal_state.json"
ESSAIS = BASE / "goal_essais.jsonl"
RAP = BASE / "GOAL.md"

TOUTES = ["2024Q1", "2024Q2", "2024Q3", "2024Q4", "2025Q1",
          "2025Q2", "2025Q3", "2025Q4"]
HOSTILES = ["2024Q1", "2024Q2", "2025Q2", "2025Q3", "2025Q4"]
SL = [2, 3, 4, 6, 8, 12]
TP = [1, 2, 3, 4, 6, 8, 12, 24]
# ---------------------------------------------------------------------------
# ROUND 109 (18/09, 22 h 30) -- RAPPORT MINIMUM 1:1, DEMANDE DE L'UTILISATEUR.
# ---------------------------------------------------------------------------
# "maybe always try to have at minimum 1:1 on the trade" : l'objectif doit
# valoir AU MOINS la distance du stop (TP >= SL). Consequence directe sur la
# grille de sortie : sur les 48 cellules (6 stops x 8 objectifs), 27 seulement
# respectent la regle. Les 21 cellules ecartees sont exactement celles qui ont
# le plus de mal a payer le cout : un objectif plus court que le stop demande
# un taux de reussite eleve pour survivre au spread.
#
# CE QUE LA MESURE DISAIT DEJA, et qui va dans ce sens :
#   stop 6 / obj 12 (2:1) : R/tx reel +0.0348, hostile +0.0474, 6/9 periodes +
#   stop 12 / obj 1 (0.08:1) : R/tx reel +0.0047, hostile +0.0024, 7/9 periodes +
# Le meilleur R par transaction du reel est bien du cote 2:1. Le 12/1 gagne sur
# la regularite mais ne paie presque rien.
RR_MIN = 1.0


def rapport_ok(sl, tp):
    """Le couple (stop, objectif) respecte-t-il le minimum 1:1 ?"""
    return tp >= sl * RR_MIN
MIN_TX, MIN_PER, PIRE_MIN = 150, 6, -0.02
ATR_PIPS = {"EURUSD": 3.1, "EURJPY": 7.6, "USDJPY": 7.3, "GBPJPY": 9.4,
            "AUDJPY": 5.4, "USDCAD": 3.5, "NZDUSD": 2.6, "CADJPY": 5.3}
PIP_USD = {"EURUSD": 1.0, "EURJPY": 0.68, "USDJPY": 0.68, "GBPJPY": 0.68,
           "AUDJPY": 0.68, "USDCAD": 0.73, "NZDUSD": 0.60, "CADJPY": 0.73}
AUT = ("autorisation utilisateur 18/09/2026 21h - boucle de developpement, "
       "tests en ordres reels sur MT5, melange de periodes hostiles et bonnes")


def charge_labo(sym):
    """(id, stop, objectif) -> periode -> (R, n) pour une paire."""
    g = collections.defaultdict(lambda: collections.defaultdict(dict))
    with open(LIVE, encoding="utf-8") as fh:
        for line in fh:
            if '"r_x7"' not in line:
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            p = str(r.get("period", ""))
            if p not in TOUTES or r["sym"] != sym or r["n"] < 3:
                continue
            for i in range(len(SL)):
                for j in range(len(TP)):
                    v = r.get("r_x%d" % (7 + i * len(TP) + j))
                    if v is not None:
                        g[(r["id"], SL[i], TP[j])][p] = (float(v), int(r["n"]))
    return g


def robustes(g):
    """Lignes robustes au labo (pour amorcer la boucle)."""
    out = []
    for (cid, sl, tp), d in g.items():
        if not rapport_ok(sl, tp):
            continue
        if len(d) < len(TOUTES):
            continue
        tx = sum(d[p][1] for p in TOUTES)
        if tx < MIN_TX:
            continue
        vals = [d[p][0] for p in TOUTES]
        if sum(1 for v in vals if v > 0) < MIN_PER or min(vals) < PIRE_MIN:
            continue
        out.append(dict(id=cid, sl=sl, tp=tp, tx=tx, pire=min(vals)))
    return out


def voisines(ligne):
    """Les sorties voisines d'une ligne : c'est la MUTATION de la boucle."""
    out = []
    for sl in (ligne["sl"], int(ligne["sl"] * 1.5), max(2, ligne["sl"] // 2)):
        if sl not in SL:
            continue
        for tp in (ligne["tp"], ligne["tp"] * 2, max(1, ligne["tp"] // 2)):
            if tp not in TP:
                continue
            if sl == ligne["sl"] and tp == ligne["tp"]:
                continue
            # ROUND 109 : la mutation obeit au minimum 1:1 elle aussi.
            if not rapport_ok(sl, tp):
                continue
            out.append(dict(id=ligne.get("id"), sl=sl, tp=tp))
    return out


def signature(sym, sl, tp, ids):
    """Empreinte d'un test : sert a ne JAMAIS payer deux fois le meme groupe.

    POURQUOI (panne du 19/09 a 21h54). La boucle s'est arretee sur un
    KeyError 'id' parce que la mutation passait un dict sans identifiant.
    En corrigeant, on ajoute aussi cette empreinte : sans elle, deux
    iterations successives peuvent retester exactement le meme groupe
    (meme paire, meme sortie, memes lignes) sous un tag different, et un
    run en ordres reels coute 8 minutes.
    """
    return "%s|%d|%d|%s" % (sym, sl, tp, ",".join(sorted(ids)))


def groupes_de(lignes):
    """Groupe les lignes par sortie : un run reel par groupe."""
    gr = collections.defaultdict(list)
    for x in lignes:
        gr[(x["sl"], x["tp"])].append(x["id"])
    return gr


def teste_groupe(sym, sl, tp, ids, terminal, tag):
    """UN test en ordres reels. Rend le R par transaction reel."""
    setfile = "g_%s.txt" % tag
    (COMMON / setfile).write_text("\n".join(sorted(set(ids))) + "\n",
                                  encoding="ascii")
    cmd = [PY, str(RUNNER), "--only", terminal, "--syms", sym,
           "--setfile", setfile, "--tag", tag, "--sl-atr", str(sl),
           "--tp-r", str(round(tp / float(sl), 4)), "--hold-bars", "192",
           "--resume", "--holdout", AUT]
    t0 = time.time()
    with open(BASE / ("goal_%s.log" % tag), "w", encoding="utf-8") as fh:
        p = subprocess.Popen(cmd, stdout=fh, stderr=subprocess.STDOUT,
                             cwd=str(BASE))
        p.wait()
    res = BASE / ("par_%s_%s.jsonl" % (terminal, tag))
    lignes = []
    if res.exists():
        for line in res.read_text(encoding="utf-8",
                                  errors="replace").splitlines():
            if line.strip().startswith("{"):
                try:
                    lignes.append(json.loads(line))
                except ValueError:
                    pass
    tx = sum(x.get("trades", 0) for x in lignes)
    pnl = sum(x.get("total", 0.0) for x in lignes)
    un_r = sl * ATR_PIPS[sym] * PIP_USD[sym]
    par_per = {str(x.get("quarter")): x.get("total", 0) / x["trades"] / un_r
               for x in lignes if x.get("trades")}
    h_n = sum(x["trades"] for x in lignes if str(x.get("quarter")) in HOSTILES)
    h_num = sum(x.get("total", 0) for x in lignes
                if str(x.get("quarter")) in HOSTILES)
    return dict(tag=tag, sym=sym, sl=sl, tp=tp, n_lignes=len(set(ids)),
                transactions=tx, pnl=round(pnl, 2),
                r_tx=(pnl / tx / un_r if tx else None),
                r_hostile=(h_num / h_n / un_r if h_n else None),
                pire=(min(par_per.values()) if par_per else None),
                n_positifs=sum(1 for v in par_per.values() if v > 0),
                n_periodes=len(par_per), par_periode=par_per,
                secondes=int(time.time() - t0))


def ecrit_rapport(etat, essais):
    with open(RAP, "w", encoding="utf-8") as fh:
        fh.write("# OBJECTIF â€” LA BOUCLE DE DEVELOPPEMENT\n\n")
        fh.write("Mise a jour : %s | iteration %d\n\n"
                 % (datetime.datetime.now().strftime("%d/%m %H:%M"),
                    etat.get("iteration", 1)))
        fh.write("Objectif : un panier, deux sens, plusieurs paires, bon volume,")
        fh.write(" dont le R REEL reste positif sur un melange de periodes")
        fh.write(" hostiles et bonnes.\n\n")
        fh.write("REGLE DE SORTIE (round 109, demande de l'utilisateur) : ")
        fh.write("**rapport minimum 1:1** -- l'objectif vaut au moins la ")
        fh.write("distance du stop (TP >= SL). Sur les 48 cellules de la grille ")
        fh.write("de sortie, 27 seulement respectent la regle. Les six premiers ")
        fh.write("groupes testes en reel (stop 12/obj 1, 12/obj 2, 8/obj 1, ")
        fh.write("6/obj 4) avaient un objectif PLUS PETIT que le stop : ils ")
        fh.write("demandent un taux de reussite eleve pour payer le spread. ")
        fh.write("La boucle ne teste donc plus que les cellules conformes.\n\n")
        if etat.get("meilleur"):
            m = etat["meilleur"]
            fh.write("## Meilleur resultat REEL a cette heure\n\n")
            fh.write("| | |\n|---|---|\n")
            fh.write("| paire | %s |\n" % m["sym"])
            fh.write("| sortie | stop %d / objectif %d |\n" % (m["sl"], m["tp"]))
            fh.write("| lignes | %d |\n" % m["n_lignes"])
            fh.write("| transactions | %d |\n" % m["transactions"])
            fh.write("| **R par transaction (reel)** | **%+.4f** |\n" % (m["r_tx"] or 0))
            fh.write("| R en periodes hostiles | %s |\n"
                     % (("%+.4f" % m["r_hostile"]) if m["r_hostile"] else "-"))
            fh.write("| periodes positives | %d/%d |\n\n"
                     % (m["n_positifs"], m["n_periodes"]))
        fh.write("## Tous les essais reels\n\n")
        fh.write("| iter | paire | stop | obj | lignes | tx | R/tx reel | "
                 "R hostile | periodes + |\n")
        fh.write("|---|---|---|---|---|---|---|---|---|\n")
        for x in essais[-80:]:
            fh.write("| %s | %s | %d | %d | %d | %d | %s | %s | %d/%d |\n"
                     % (x.get("iteration", 1), x["sym"], x["sl"], x["tp"],
                        x["n_lignes"], x["transactions"],
                        ("%+.4f" % x["r_tx"]) if x["r_tx"] is not None else "-",
                        ("%+.4f" % x["r_hostile"]) if x["r_hostile"] is not None else "-",
                        x["n_positifs"], x["n_periodes"]))
        fh.write("\n## Rappel des artefacts attrapes cette nuit (a ne jamais refaire)\n\n")
        fh.write("- selection sur un maximum borne (r_x47 plafonne a 0.08) ;\n")
        fh.write("- inversion de l'excursion favorable/adverse sur les ventes ;\n")
        fh.write("- lecture d'une seule moitie d'un run reparti sur deux terminaux ;\n")
        fh.write("- selection sur la meme periode que la mesure.\n")
        fh.write("\nC'est pourquoi la boucle ne classe que sur le R REEL et sur la "
                 "PIRE periode.\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arret", default="03:00")
    ap.add_argument("--paires", default="EURUSD")
    a = ap.parse_args()
    h, m = [int(x) for x in a.arret.split(":")]
    fin = datetime.datetime.now().replace(hour=h, minute=m, second=0,
                                          microsecond=0)
    if fin < datetime.datetime.now():
        fin += datetime.timedelta(days=1)
    paires = [p for p in a.paires.split(",") if p in ATR_PIPS]
    etat = {"iteration": 1, "meilleur": None, "candidats": None}
    if ETAT.exists():
        try:
            etat = json.loads(ETAT.read_text(encoding="utf-8"))
        except ValueError:
            pass
    essais = []
    if ESSAIS.exists():
        for line in ESSAIS.read_text(encoding="utf-8",
                                     errors="replace").splitlines():
            if line.strip().startswith("{"):
                try:
                    essais.append(json.loads(line))
                except ValueError:
                    pass
    print("=" * 96)
    print("BOUCLE DE DEVELOPPEMENT â€” arret a %s | paires %s"
          % (fin.strftime("%d/%m %H:%M"), ", ".join(paires)))
    print("=" * 96, flush=True)
    n = 0
    while datetime.datetime.now() < fin:
        it = etat.get("iteration", 1)
        print("[%s] ITERATION %d" % (datetime.datetime.now().strftime("%H:%M"), it),
              flush=True)
        # --- candidats : de l'etat, sinon selection initiale --------------
        cand = etat.get("candidats")
        if not cand:
            cand = []
            for sym in paires:
                g = charge_labo(sym)
                rob = robustes(g)
                cand += [dict(id=x["id"], sym=sym, sl=x["sl"], tp=x["tp"])
                         for x in rob]
            print("   selection initiale : %d lignes robustes au labo"
                  % len(cand), flush=True)
        if not cand:
            print("   plus de candidats : la boucle s'arrete", flush=True)
            break
        # --- test reel, groupe par sortie --------------------------------
        par_paire = collections.defaultdict(list)
        for x in cand:
            par_paire[x["sym"]].append(x)
        survivants = []
        # ROUND 109 : les groupes DEJA payes sont ecartes AVANT de choisir les
        # six plus gros. Sinon la boucle rechoisissait les memes six groupes a
        # chaque iteration, les sautait un par un, et tournait a vide jusqu'a
        # l'heure d'arret sans jamais tester le reste de la grille.
        deja = set(etat.get("faits", []))
        a_faire = []
        for sym, lst in par_paire.items():
            for (sl, tp), ids in groupes_de(lst).items():
                if not rapport_ok(sl, tp):
                    continue
                if signature(sym, sl, tp, ids) in deja:
                    continue
                a_faire.append((sym, sl, tp, ids))
        a_faire.sort(key=lambda z: -len(z[3]))
        print("   groupes a tester (objectif >= stop) : %d, dont %d non testes"
              % (len(groupes_de([x for l in par_paire.values() for x in l])),
                 len(a_faire)), flush=True)
        for sym, sl, tp, ids in a_faire[:6]:
            if True:
                if datetime.datetime.now() >= fin:
                    break
                tag = "g%d_%s_s%d_t%d" % (it, sym.lower(), sl, tp)
                terminal = "farm"   # UN SEUL terminal pour les ORDRES REELS ; le second est reserve au labo de mesure (demande utilisateur)
                sig = signature(sym, sl, tp, ids)
                if sig in etat.get("faits", []):
                    print("   deja teste (meme groupe) : %s stop %d / obj %d"
                          " -> saute" % (sym, sl, tp), flush=True)
                    continue
                etat.setdefault("faits", []).append(sig)
                print("   test reel %s stop %d / obj %d (%d lignes) sur %s"
                      % (sym, sl, tp, len(ids), terminal), flush=True)
                try:
                    r = teste_groupe(sym, sl, tp, ids, terminal, tag)
                except Exception as e:
                    print("      ECHEC : %s" % e, flush=True)
                    continue
                r["iteration"] = it
                essais.append(r)
                with open(ESSAIS, "a", encoding="utf-8") as fh:
                    fh.write(json.dumps(r) + "\n")
                if r["r_tx"] is not None:
                    print("      -> %d tx, R/tx reel %+.4f, hostile %s, %d/%d +"
                          % (r["transactions"], r["r_tx"],
                             ("%+.4f" % r["r_hostile"]) if r["r_hostile"] else "-",
                             r["n_positifs"], r["n_periodes"]), flush=True)
                    if r["r_tx"] > 0:
                        survivants.append(r)
                if etat.get("meilleur") is None or (
                        r["r_tx"] is not None
                        and r["r_tx"] > (etat["meilleur"]["r_tx"] or -9)):
                    if r["r_tx"] is not None:
                        etat["meilleur"] = r
                n += 1
                ecrit_rapport(etat, essais)
        # --- mutation ----------------------------------------------------
        if survivants:
            prochains = []
            vus = set(etat.get("faits", []))
            for s in survivants:
                ids = [x["id"] for x in cand
                       if x["sym"] == s["sym"] and x["sl"] == s["sl"]
                       and x["tp"] == s["tp"]]
                for i in ids:
                    for v in voisines(dict(sl=s["sl"], tp=s["tp"], id=i)):
                        sig = signature(s["sym"], v["sl"], v["tp"], [i])
                        if sig in vus:
                            continue
                        vus.add(sig)
                        prochains.append(dict(id=i, sym=s["sym"],
                                              sl=v["sl"], tp=v["tp"]))
            etat["candidats"] = prochains
            print("   mutation : %d nouveaux candidats (%d groupes survivants)"
                  % (len(prochains), len(survivants)), flush=True)
        else:
            # rien n'a survecu au reel : on elargit la selection au labo
            cand = []
            vus = set(etat.get("faits", []))
            for sym in paires:
                g = charge_labo(sym)
                rob = sorted(robustes(g), key=lambda x: -x["pire"])
                cand += [dict(id=x["id"], sym=sym, sl=x["sl"], tp=x["tp"])
                         for x in rob[:400]]
            etat["candidats"] = cand
            print("   aucun survivant au reel : on relargit la selection "
                  "(%d lignes, critere assoupli par le bas)" % len(cand),
                  flush=True)
        etat["iteration"] = it + 1
        ETAT.write_text(json.dumps(etat, indent=1, ensure_ascii=False),
                        encoding="utf-8")
        # garde-fou anti-boucle infinie sans progres
        if it > 12:
            print("   12 iterations atteintes", flush=True)
            break
    ETAT.write_text(json.dumps(etat, indent=1, ensure_ascii=False),
                    encoding="utf-8")
    ecrit_rapport(etat, essais)
    print("boucle terminee : %d essais reels" % n, flush=True)


if __name__ == "__main__":
    main()
