# -*- coding: utf-8 -*-
"""eurgbp_trades_r43.py — pips et pnl reels des 15 trades EURGBP + risque SL."""
import sys, glob, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
best = None
for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-100:]:
    try:
        runs = F.parse_stream(lp, "V3INT")
    except Exception:
        continue
    for key, data in runs.items():
        if "20260101" not in key.replace(".", "") or "EURGBP" not in key:
            continue
        closed = [t for t in data["trades"].values() if t["close"] is not None]
        if len(closed) != 15:
            continue
        b = data.get("balance") or 0.0
        if abs(b - 10024) < 3:
            best = {"trades": closed, "bal": b, "key": key, "lp": lp}
            break
    if best:
        break
if not best:
    print("pas trouve"); sys.exit(1)
print(f"run: {os.path.basename(best['lp'])} | {best['key']} | bal={best['bal']:.0f}")
print(f"{'date':12s} {'side':4s} {'entry':>9s} {'close':>9s} {'dist pips':>9s} "
      f"{'ctype':4s}")
for t in best["trades"]:
    e = t.get("entry"); c = t.get("close")
    pips = abs(c - e) / 0.0001 if e and c else float("nan")
    print(f"{str(t['ts_entry'])[:10]:12s} {str(t.get('side')):4s} "
          f"{e:9.5f} {c:9.5f} {pips:9.1f} {str(t.get('ctype')):4s} "
          f"pnl_parse={F.pnl_usd(t):+.1f}")
# ATR approx: distance SL moyenne
sls = [abs(t.get('close') - t.get('entry')) / 0.0001 for t in best["trades"]
       if t.get('ctype') == 'SL']
tps = [abs(t.get('close') - t.get('entry')) / 0.0001 for t in best["trades"]
       if t.get('ctype') == 'TP']
print(f"\nSL count={len(sls)} dist moy {sum(sls)/max(1,len(sls)):.1f} pips")
print(f"TP count={len(tps)} dist moy {sum(tps)/max(1,len(tps)):.1f} pips")
# risque $ par 0.1 lot pour une perte SL typique: EURGBP 0.1 lot = 10000 EUR
# pip 0.0001 x 10000 = 1 GBP ~ x1.27 USD (en supposant 1.27) mais parse dit quoi?
print("pnl $/pip par lot (parse, calibre reel k=0.472): "
      f"~{0.472*1.0:.3f}$ par 0.1 lot-pip approx")
print("FIN")
