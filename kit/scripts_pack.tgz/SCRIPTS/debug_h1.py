﻿"""Debug: does VM.copy_rates_range return H1 bars; does main() find closed bars?"""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from datetime import datetime
import MetaTrader5 as mt5
from strategytester5.MetaTrader5.api import VirtualMetaTrader5

TERM = r"C:\EAFarm\MT5\Farm\terminal64.exe"
ST5DATA = r"C:\EAFarm\HISTORY - Copy\research\st5data"

if not mt5.initialize(path=TERM):
    raise RuntimeError(f"init failed: {mt5.last_error()}")
VM = VirtualMetaTrader5(parent_mt5=mt5, custom_broker_data_path=ST5DATA)
VM.history_manager.synchronize_all_timeframes = lambda *a, **k: None

for sym in ["USDJPY", "EURUSD"]:
    rates = VM.copy_rates_range(sym, VM.TIMEFRAME_H1, datetime(2022, 1, 1), datetime(2024, 1, 1))
    print(f"{sym} H1 rates from VM: {None if rates is None else len(rates)}")
    if rates is not None and len(rates):
        print("  first:", rates[0]["time"], rates[0]["open"], "last:", rates[-1]["time"], rates[-1]["close"])
        # sample timestamps
        for t in [rates[1000]["time"], rates[5000]["time"]]:
            cur_idx = t // 3600
            closed = (cur_idx - 1) * 3600
            print(f"  t={t} closed={closed} found={any(r['time']==closed for r in rates)}")
mt5.shutdown()
