# -*- coding: utf-8 -*-
"""c13v2_py_orig.py — repro avec les params ORIGINAUX du python boss
(pin_wick=1.0, close_zone=0.15, PAS de vol rejet, PAS d age max, lookahead
du python = l'OB n'est dispo qu'apres confirmation MAIS le boss l'utilise
des qu'il existe -> c'est le lookahead). On teste: A=lookahead pur (futur),
B=honnete (dispo apres confirmation)."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import c13v2_py_fast2 as F
import numpy as np
import pandas as pd
import time


def run(sym, year, cfg, label):
    t0 = time.time()
    res = F.backtest(sym, year, cfg)
    print(f"{label}: {res} {time.time()-t0:.1f}s")
    return res


# params originaux boss: wick=1.0, close=0.15, pas de vol sur rejet,
# pas de filtre volume sur impulsion, age illimite
orig = {"imp_atr": 0.9, "imp_vol": 1.0, "imp_look": 6, "ob_age": 100000,
        "rej_wick": 1.0, "rej_vol": 1.0, "close_zone": 0.15, "tp_r": 2.5,
        "bias": "ema", "excl_hours": [6, 7, 12, 15, 19, 23],
        "min_stop": 0.00025, "buf_atr": 0.25}
run("EURUSD", 2024, orig, "ORIG (honnete, params boss)")
run("EURUSD", 2025, orig, "ORIG-2025")
