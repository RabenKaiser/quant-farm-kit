﻿import sys, numpy as np, gc
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT
G._cache.clear(); gc.collect()
F = G.get_frames("EURAUD"); m5,m1=F["m5"],F["m1"]
h1z,hh,ll,a1,gb,gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd,zlo,zhi = MT.project(m5.index,h1z,hh,ll,gb,gr,max_age_h=48)
M = NL.build(m5,F,zd,zlo,zhi); M.update(FE.more(m5,F,m1))
n=len(m5)
bb = np.asarray(M["big_bear"])
print(f"big_bear SEUL : {bb.sum()} barres ({100*bb.mean():.2f} %)")
print()
print("Cote MT5, le trigger BIGBEAR est evalue a chaque tick M5 ou les filtres")
print("passent. La sonde isolee peut le mesurer : ajoutons BIGBEAR/BIGBULL.")
