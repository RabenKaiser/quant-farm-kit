﻿import MetaTrader5 as mt5
from datetime import datetime, timezone
mt5.initialize(path=r"C:\EAFarm\MT5\Farm\terminal64.exe")
print("=== plafond reel : que se passe-t-il page 2 ? ===")
for s in ("GBPUSD","XAUUSD"):
    mt5.symbol_select(s, True)
    for start in (0, 59999, 99999, 100000):
        r = mt5.copy_rates_from_pos(s, mt5.TIMEFRAME_M1, start, 60000)
        n = 0 if r is None else len(r)
        if n:
            d0 = datetime.fromtimestamp(r[0][0], tz=timezone.utc).date()
            d1 = datetime.fromtimestamp(r[-1][0], tz=timezone.utc).date()
            print(f"  {s:<8} start={start:>7} -> {n:>6} barres  {d0} -> {d1}")
        else:
            print(f"  {s:<8} start={start:>7} -> 0")
mt5.shutdown()
