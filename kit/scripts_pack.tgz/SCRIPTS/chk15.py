﻿import pandas as pd, glob, os
from datetime import datetime, timezone
OUT = r"C:\EAFarm\HISTORY - Copy\research\m1_pos"
print(f"{'sym':<8}{'barres':>12}  {'debut':>11}  {'fin':>11}  {'ans':>4}")
tot=0
for f in sorted(glob.glob(os.path.join(OUT,"*_M1.csv"))):
    sym = os.path.basename(f).replace("_M1.csv","")
    try:
        df = pd.read_csv(f, usecols=["time"])
    except Exception:
        continue
    n=len(df)
    if n==0:
        print(f"{sym:<8}{0:>12}"); continue
    d0 = datetime.fromtimestamp(int(df['time'].iloc[0]), tz=timezone.utc)
    d1 = datetime.fromtimestamp(int(df['time'].iloc[-1]), tz=timezone.utc)
    yrs = pd.to_datetime(df['time'], unit='s', utc=True).dt.year.nunique()
    tot += n
    flag = "" if n > 1_500_000 else "  <- partiel"
    print(f"{sym:<8}{n:>12,}  {str(d0.date()):>11}  {str(d1.date()):>11}  {yrs:>4}{flag}")
print(f"\ntotal barres M1 exportees : {tot:,}")
