# -*- coding: utf-8 -*-
r"""audit_entrees.py -- trois questions en une passe.

1. COHERENCE DES ENTREES. Le labo mesure, pour chaque trade, `pos` (ou est le
   prix dans le range de 100 barres, 0 = bas, 1 = haut) et `dext` (distance a
   l'extreme du range, en ATR). Un achat "au plus bas du range" qui entre a
   pos = 0.7 n'est pas coherent : il achete en haut en croyant acheter en bas.

2. LES CELLULES EXTREMES SONT-ELLES POSSIBLES ? Une cellule stop 2 / obj 24 a
   un gain maximal de 12 R par trade. Un R moyen de +1.9 exige donc environ
   22 % de gagnants a +24 ATR. C'est arithmetiquement possible -- mais SEULEMENT
   si le MFE p75 de la combinaison atteint 24 ATR. On confronte donc chaque
   resultat extreme a son propre MFE mesure. C'est le seul juge.

3. LES VARIANTES DEJA MESUREES. L'EA publie r_x0..r_x66 : 48 cellules de
   grille (6 stops x 8 objectifs) plus 19 autres. Ces 19 autres sont des
   variantes de sortie (palier, trailing). On les affiche pour savoir ce qui a
   DEJA ete mesure avant de dire qu'il manque quelque chose.

Usage : python SCRIPTS\audit_entrees.py
"""
import collections
import json
import statistics
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
LIVE = r"C:\EAFarm\HISTORY - Copy\research\lab_results.jsonl"
REG = r"C:\EAFarm\HISTORY - Copy\research\REGISTRE.jsonl"
SL = [2, 3, 4, 6, 8, 12]
TP = [1, 2, 3, 4, 6, 8, 12, 24]
HOST = ["2024Q1", "2024Q2"]

# les 10 meilleurs couples HOSTILES du registre
reg = {}
for l in open(REG, encoding="utf-8", errors="replace"):
    if l.strip().startswith("{"):
        o = json.loads(l)
        if o.get("lab_hostile") is not None:
            reg[o["cle"]] = o
top = sorted(reg.values(), key=lambda o: -o["lab_hostile"])[:10]
voulu = {(o["id"], o["sl"], o["tp"]): o for o in top}

mes = collections.defaultdict(dict)
with open(LIVE, encoding="utf-8", errors="replace") as fh:
    for line in fh:
        if '"r_x7"' not in line:
            continue
        r = json.loads(line)
        cid = r.get("id", "")
        if "|NONE|" in cid:
            continue
        for (i2, sl, tp) in voulu:
            if i2 == cid and r.get("period") in HOST:
                mes[(cid, sl, tp)][r["period"]] = r

print("=" * 104)
print("AUDIT -- coherence des entrees, cellules extremes, variantes deja mesurees")
print("=" * 104)
print("   %-38s %-8s %6s %7s %7s %7s %7s %8s" %
      ("combinaison", "sortie", "R host", "MFE50", "MFE75", "MAE50", "pos", "dext"))
lignes = []
for (cid, sl, tp), o in voulu.items():
    d = mes.get((cid, sl, tp))
    if not d:
        continue
    m50 = statistics.fmean(float(x.get("mfe_p50") or 0) for x in d.values())
    m75 = statistics.fmean(float(x.get("mfe_p75") or 0) for x in d.values())
    a50 = statistics.fmean(float(x.get("mae_p50") or 0) for x in d.values())
    pos = statistics.fmean(float(x.get("pos") or 0) for x in d.values())
    dx = statistics.fmean(float(x.get("dext") or 0) for x in d.values())
    lignes.append((cid, sl, tp, o["lab_hostile"], m50, m75, a50, pos, dx))
    print("   %-38s s%-2d/t%-2d %+6.3f %7.2f %7.2f %7.2f %7.3f %8.2f"
          % (cid[:38], sl, tp, o["lab_hostile"], m50, m75, a50, pos, dx))

print()
print("   LECTURE 1 - COHERENCE DE L'ENTREE")
print("   pos = position du prix dans le range de 100 barres (0 bas, 1 haut).")
for cid, sl, tp, h, m50, m75, a50, pos, dx in lignes:
    sens = cid.rstrip()[-1]
    attendu = "BAS du range" if sens == "L" else "HAUT du range"
    verdict = "coherent" if ((sens == "L" and pos < 0.45) or
                             (sens == "S" and pos > 0.55)) else "INCOHERENT"
    print("      %-38s %s -> pos %.3f  attendu %-13s %s"
          % (cid[:38], sens, pos, attendu, verdict))

print()
print("   LECTURE 2 - LES CELLULES EXTREMES SONT-ELLES POSSIBLES ?")
for cid, sl, tp, h, m50, m75, a50, pos, dx in lignes:
    if tp < 8:
        continue
    # R moyen exige par le resultat, et part de gagnants que cela implique
    q = tp / float(sl)
    part = (h + 1.0) / (q + 1.0)
    ok = m75 >= tp
    print("      %-38s s%d/t%d : +%.2f R exige %.0f %% de gagnants a +%d ATR ;"
          " MFE p75 = %.1f ATR -> %s"
          % (cid[:38], sl, tp, h, 100 * part, tp, m75,
             "POSSIBLE" if ok else "IMPOSSIBLE (cible au-dela du MFE p75)"))

print()
print("   LECTURE 3 - VARIANTES DE SORTIE DEJA MESUREES (au-dela des 48 cellules)")
k = list(mes.values())[0]
ref = list(k.values())[0]
extra = [("r_x%d" % n) for n in range(55, 67)]
print("      champs presents : %s" % ", ".join(
    "%s=%s" % (n, ref.get(n)) for n in extra))
print("      (48 cellules = 6 stops x 8 objectifs ; au-dela = variantes de")
print("       sortie deja mesurees par l'EA : paliers, trailing, structurels)")
