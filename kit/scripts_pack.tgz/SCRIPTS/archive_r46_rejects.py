# -*- coding: utf-8 -*-
"""archive_r46_rejects.py — append REGISTRE rejets r45/r46."""
p = r"C:\EAFarm\SHARED\REGISTRE_MEILLEURES_STRATEGIES.md"
blk = """
================================================================================
ROUND 131-132 - REJETS avec preuve (Upcomers 2026, balance reel)
- Variantes VWAP XAU H1 close-20 (intraday, 0 swap), testees au balance reel:
  FADE w48 c20 +2,584 n106 pf0.92 | FADE w96 c20 +1,067 n83 pf0.80 (rejet pf<1)
  FADE w12 c20 +2,438 n82 pf1.17 (< win24 +3,793) | TREND w48 c20 -1,893 n97
  TREND w12 c20 +10,916 n89 pf1.44 vs TREND w24 c20 +9,800 n118 pf1.38:
  corr w12-w24 = 0.85, pire SL w12 -1,614 > w24 -1,231 -> risque+ pour +1.1k
  -> REJET: win24 reste le leg XAU (pas de gain risque-ajuste, pas de
  decorrelation). TREND sess 6-17-c17 +11,695 n105: corr 0.82 avec 7-20-c20,
  SLmoy -441 vs -341 -> meme edge decale, pas de diversification -> REJET.
- Crosses epaisses retest session 6-20 (jamais testees en 6-20):
  EURCHF-c050 +... 21t pf0.64 | EURCHF-c055 24t pf0.77 | EURCAD-c050 20t pf0.53
  | EURCAD-c055 23t pf0.57 | GBPCHF-c050 10t pf1.15 (n trop petit)
  -> REJET: CHF/CAD crosses negatifs meme en 6-20 (comme EURGBP seul rescapé).
- CONCLUSION round 132: le portefeuille deploy v7 reste optimal; XAU VWAP win24
  fade+trend + 10 legs V3INT = aucun nouveau leg decorrele trouve ce round.
================================================================================
"""
with open(p, "ab") as f:
    f.write(blk.encode("utf-8"))
print("REGISTRE rejets r131-132 appende", len(blk))
