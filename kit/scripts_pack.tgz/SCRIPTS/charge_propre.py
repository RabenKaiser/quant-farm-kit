# -*- coding: utf-8 -*-
r"""charge_propre.py -- CHARGEMENT PAR JAMBE, FILTRE PAR SYMBOLE (correctif majeur).

LE BUG (14/10). `simu_prop_15.transactions_jambe(tag)` lit `raw_farm_<tag>.txt`
et rend TOUTES les transactions du fichier. Or ces textes contiennent les
transactions de PLUSIEURS symboles : mesure faite a l'instant sur
raw_farm_g3_sr100_deuidx_2.txt -> 3 845 transactions dont **170 seulement sont
DEU.IDX** (le reste : HKG.IDX 679, CHFJPY 705, AUDUSD 391, EURCHF 602...).
Consequence : chaque « jambe » du pool etait un MELANGE, les memes transactions
revenaient dans plusieurs jambes, et tous les R par jambe -- ainsi que les
probabilites prop -- etaient calcules sur une population dupliquee.

LE CORRECTIF. Le symbole d'une campagne se lit dans son propre fichier de
resultat (`par_farm_<tag>.jsonl`, champ "sym"). On parse donc le texte brut AVEC
le filtre `symboles=[sym]`, ce qui rend la jambe reelle et unique.

LIMITE : certains tags de campagne portent plusieurs symboles (campagnes multi-
paires). On charge alors toutes leurs transactions, en le signalant.
"""
import json
import os
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE / "SCRIPTS"))
os.environ.setdefault("CORPUS", "m1_ext")
import reel_sans_constante as RSC

CACHE = {}

# --- GARDE-FOU HOLDOUT (correctif du 15/10, contre-audit) ---------------------
# PORTEFEUILLE_VERIFIE.md est produit par veille.py -> gate_demi.py -> ce module.
# Jusqu'ici le seul filtre etait `t_in >= d0` (02/01/2024) : les trimestres
# BLOQUES (2025Q2, 2025Q3, 2025Q4, 2026Q1) entraient donc dans la mesure du
# panier de reference. Mesure du 15/10 : 38 % du pool mesure etait du holdout,
# et la jambe USA30.IDX (g3_sr100_usa30idx_4) etait du holdout a 100 %.
# Exigence de l'utilisateur, non negociable : le holdout ne sert JAMAIS a la
# selection. On l'exclut donc ici, au seul endroit qui alimente la porte.
def trimestre(dt):
    """Le trimestre d'une date, au format du projet (ex. « 2024Q3 »)."""
    return "%dQ%d" % (dt.year, (dt.month - 1) // 3 + 1)


def charge_holdout():
    """Les periodes bloquees, lues dans HOLDOUT.json (source unique de verite)."""
    f = BASE / "HOLDOUT.json"
    try:
        with open(f, encoding="utf-8") as fh:
            return set(json.load(fh).get("bloque") or [])
    except Exception:
        return set()


def symboles_du_tag(tag):
    """Les symboles d'une campagne, lus dans son fichier de resultat."""
    f = BASE / ("par_farm_%s.jsonl" % tag)
    if not f.exists():
        return []
    syms = []
    for ligne in f.read_text(encoding="utf-8", errors="replace").splitlines():
        ligne = ligne.strip()
        if not ligne.startswith("{"):
            continue
        try:
            o = json.loads(ligne)
        except ValueError:
            continue
        s = o.get("sym")
        if s and s not in syms:
            syms.append(s)
    return syms


def tags_g3(tag):
    """Le vrai tag de fichier cache dans un identifiant de jambe (« LOTSL:g3_x|Y|L »
    -> « g3_x »), comme le fait le chargeur officiel."""
    import re
    m = re.search(r"g3_[a-z0-9_]+", tag)
    return m.group(0) if m else tag


# Les tournures utilisees dans les noms de campagne -> symbole reel.
MOTS_SYMBOLES = [
    ("deuidx", "DEU.IDX"), ("hkgidx", "HKG.IDX"), ("usa30idx", "USA30.IDX"),
    ("usa500idx", "USA500.IDX"), ("eusidx", "EUS.IDX"), ("fraidx", "FRA.IDX"),
    ("jpnidx", "JPN.IDX"), ("gbridx", "GBR.IDX"), ("ausidx", "AUS.IDX"),
    ("esp", "ESP.IDX"), ("nld", "NLD.IDX"), ("che", "CHE.IDX"),
    ("xauusd", "XAUUSD"), ("xagusd", "XAGUSD"), ("spxusd", "SPXUSD"),
    ("nsxusd", "NSXUSD"), ("udxusd", "UDXUSD"), ("eurusd", "EURUSD"),
    ("gbpusd", "GBPUSD"), ("usdcad", "USDCAD"), ("usdchf", "USDCHF"),
    ("audcad", "AUDCAD"), ("audusd", "AUDUSD"), ("nzdusd", "NZDUSD"),
    ("eurjpy", "EURJPY"), ("gbpjpy", "GBPJPY"), ("audjpy", "AUDJPY"),
    ("nzdjpy", "NZDJPY"), ("cadjpy", "CADJPY"), ("chfjpy", "CHFJPY"),
    ("eurchf", "EURCHF"), ("eurgbp", "EURGBP"), ("eurjpy", "EURJPY"),
    ("euraud", "EURAUD"), ("eurcad", "EURCAD"), ("eurnzd", "EURNZD"),
    ("gbpcad", "GBPCAD"), ("gbpchf", "GBPCHF"), ("nzdcad", "NZDCAD"),
]


def symbole_du_tag(tag):
    """Symbole deduit du NOM de campagne quand aucun fichier de resultat
    n'existe (les jambes legacy du type « g3_sr100_deuidx_2 » nomment leur
    marche)."""
    t = tags_g3(tag).lower()
    for mot, sym in MOTS_SYMBOLES:
        if mot in t:
            return [sym]
    return []


def transactions_propres(tag, corpus="m1_ext", holdout=None):
    """Transactions REELLES d'une jambe, filtrees sur ses propres symboles.

    GARDE-FOU HOLDOUT (15/10). C'est LE point de passage unique de tous les
    consommateurs : gate_demi (la porte), simu_prop_15, analyse_manques, wfo_15.
    Le filtre est donc pose ICI et pas dans pool() -- gate_demi n'appelle pas
    pool(), il appelle directement cette fonction (lignes 63 et 109), ce qui est
    exactement pourquoi la contamination passait.

    Par defaut le holdout est EXCLU (exigence utilisateur : il ne sert jamais a la
    selection). Pour la mesure finale, unique et volontaire, sur le panier fige :
        os.environ["HOLDOUT_AUTORISE"] = "1"
    """
    cle = (tag, corpus, bool(holdout))
    if cle in CACHE:
        return CACHE[cle]
    g = tags_g3(tag)
    f = BASE / ("raw_farm_%s.txt" % g)
    if not f.exists():
        CACHE[cle] = []
        return []
    syms = symboles_du_tag(g) or symbole_du_tag(g)
    txt = f.read_text(encoding="utf-8", errors="replace")
    if syms:
        tx = RSC.transactions_texte(txt, corpus, 0, symboles=syms)
    else:
        tx = RSC.transactions_texte(txt, corpus, 0)
    # --- garde-fou ---------------------------------------------------------
    if holdout is None:
        # True => on garde tout (mesure finale) ; False => on exclut les bloques
        holdout = os.environ.get("HOLDOUT_AUTORISE", "") == "1"
    if not holdout:
        bloque = charge_holdout()
        avant = len(tx)
        tx = [x for x in tx if trimestre(x["t_in"]) not in bloque]
        CACHE.setdefault("_holdout_retires", {})[tag] = avant - len(tx)
    CACHE[cle] = tx
    return tx


def pool(tags, d0=datetime(2024, 1, 2), verbose=True):
    """Pool de portefeuille : une seule jambe par symbole (regle prop).

    Le filtre HOLDOUT n'est pas ici : il est pose en amont dans
    transactions_propres(), le point de passage commun a tous les consommateurs
    (gate_demi, simu_prop_15, analyse_manques, wfo_15).
    """
    vus = {}
    for t in tags:
        syms = symboles_du_tag(t)
        cle = syms[0] if len(syms) == 1 else t
        if cle in vus:
            # regle prop : UNE direction par paire a la fois -> on garde la
            # premiere jambe declaree pour ce symbole.
            continue
        tx = [x for x in transactions_propres(t) if x["t_in"] >= d0]
        if not tx:
            continue
        R = np.array([x["R"] for x in tx], dtype=float)
        vus[cle] = (t, syms, len(R), float(R.mean()), float(R.sum()), tx)
    if verbose:
        tot = sum(v[4] for v in vus.values())
        n = sum(v[2] for v in vus.values())
        print("POOL PROPRE : %d jambes (une par symbole), %d transactions | R total %+.1f | mu %+.4f"
              % (len(vus), n, tot, tot / max(n, 1)))
        print("%-40s %-10s %6s %9s %9s" % ("tag", "symbole", "n", "mu(R)", "total R"))
        for cle, (t, syms, nn, mu, tr, _) in sorted(vus.items(), key=lambda x: x[1][3]):
            print("%-40s %-10s %6d %+9.4f %+9.1f" % (t[:40], ",".join(syms)[:10], nn, mu, tr))
    trades = []
    for v in vus.values():
        trades.extend(v[5])
    trades.sort(key=lambda x: x["t_in"])
    return trades