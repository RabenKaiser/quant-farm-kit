"""ADMISSION DES JAMBES SR A FILTRE CRESTM : FERME CONTRE JUGE, EN TROIS CATEGORIES.

POURQUOI. L'inventaire de la ferme (`INVENTAIRE_SR.md`) a sorti treize jambes SR positives et mesurables
chez Upcomers, toutes portant le filtre `CRESTM` que le juge n'avait jamais vu. Les lots `up_lot5_xauusd`,
`up_lot2_xauusd`, `up_lot5_xagusd`, `up_srfx_*`, `up_srhkg100` et `up_srusa30_100` les mesurent depuis
02 h 10. Ce script confronte les deux etages et classe chaque jambe selon `POUVOIR_JUGE.md` :

  ADMISE                    ferme positive (t >= 2, au moins deux annees positives) ET juge positif ET
                            juge avec au moins 30 transactions ;
  DONNEES INSUFFISANTES     ferme positive et solide, mais moins de 30 transactions au juge : ni admise,
                            ni rejetee -- remesuree quand l'historique du juge s'allonge ;
  REJETEE                   ferme negative, ou juge significativement negatif.

Le seuil de 30 transactions n'est pas une convention : c'est le point ou l'erreur type du juge (sigma/racine
de N, sigma ~ 1,4 R) descend sous 0,26 R, soit a peu pres le mu de nos meilleures jambes.
"""
import sys
import pathlib
from collections import defaultdict

import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import reel_sans_constante as RS  # noqa: E402

B = pathlib.Path(r"C:\EAFarm\HISTORY - Copy\research")

# (jambe, symbole ferme, ligne COMPLETE cote ferme, texte brut juge, symbole juge, ligne juge)
JAMBES = [
    ("or, SR97L", "XAUUSD", "SR97L|NONE|CRESTM|L", "raw_mt5_up_lot5_xauusd.txt", "XAUUSD", "SR97L"),
    ("or, SR97L (cible 2 R)", "XAUUSD", "SR97L|NONE|CRESTM|L", "raw_mt5_up_lot2_xauusd.txt", "XAUUSD", "SR97L"),
    ("or, six lignes", "XAUUSD", None, "raw_mt5_up_srfx_xauusd.txt", "XAUUSD", None),
    ("argent, six lignes", "XAGUSD", None, "raw_mt5_up_srfx_xagusd.txt", "XAGUSD", None),
    ("argent, SR97L (cible 5 R)", "XAGUSD", None, "raw_mt5_up_lot5_xagusd.txt", "XAGUSD", "SR97L"),
    ("NZDUSD, six lignes", "NZDUSD", None, "raw_mt5_up_srfx_nzdusd.txt", "NZDUSD", None),
    ("AUDUSD, six lignes", "AUDUSD", None, "raw_mt5_up_srfx_audusd.txt", "AUDUSD", None),
    ("EURCHF, six lignes", "EURCHF", None, "raw_mt5_up_srfx_eurchf.txt", "EURCHF", None),
    ("AUDCAD, six lignes", "AUDCAD", None, "raw_mt5_up_srfx_audcad.txt", "AUDCAD", None),
    ("Hang Seng, SR100S", "HKG.IDX", "SR100S|NONE|CRESTM|S", "raw_mt5_up_srhkg100.txt", "HKCHKD.c", "SR100"),
    ("Dow, SR100L", "USA30.IDX", "SR100L|NONE|CRESTM|L", "raw_mt5_up_srusa30_100.txt", "DJCUSD.c", "SR100"),
]


def stats(tx, seuil=3):
    """Statistiques d'un echantillon. `seuil=1` au juge : une transaction doit pouvoir etre AFFICHEE,
    meme si elle ne prouve rien -- c'est justement le diagnostic « donnees insuffisantes » qu'on veut."""
    if len(tx) < seuil:
        return None
    R = np.array([x["R"] for x in tx], dtype=float)
    n = len(R)
    mu = float(R.mean())
    sd = float(R.std(ddof=1)) if n > 1 else 0.0
    par_an = defaultdict(list)
    for x in tx:
        par_an[x["t_in"].year].append(float(x["R"]))
    return {"n": n, "mu": mu, "t": mu / (sd / np.sqrt(n)) if sd > 0 else 0.0,
            "se": sd / np.sqrt(n) if sd > 0 else 0.0, "queue": float((R < -1.5).mean()),
            "ans": {a: (len(v), float(np.mean(v))) for a, v in sorted(par_an.items())}}


def ferme(sym, ligne):
    """Mesure ferme : la ligne exacte si elle est donnee, sinon toutes les lignes CRESTM du symbole."""
    vus, uniques = [], {}
    for f in sorted(B.glob("raw_farm_*.txt")):
        try:
            txt = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        tx = RS.transactions_texte(txt, symboles=[sym])
        sel = [x for x in tx if "CRESTM" in x.get("ligne_complete", "")
               and (ligne is None or x["ligne_complete"] == ligne)]
        if len(sel) < 15:
            continue
        st = stats(sel)
        cle = (st["n"], round(st["mu"], 6))
        if cle in uniques:
            continue
        uniques[cle] = True
        vus.append(st)
    if not vus:
        return None
    # plusieurs campagnes peuvent mesurer la meme regle : on garde la plus fournie, et on note combien.
    vus.sort(key=lambda s: -s["n"])
    vus[0]["campagnes"] = len(vus)
    return vus[0]


def juge(fichier, sym, ligne):
    """Mesure au juge. Rend None si le texte brut n'existe pas (campagne pas encore faite), sinon un
    dictionnaire meme pour une ou deux transactions : c'est le diagnostic « donnees insuffisantes »."""
    f = B / fichier
    if not f.exists():
        return None
    tx = RS.transactions_texte(f.read_text(encoding="utf-8", errors="replace"), symboles=[sym])
    if ligne:
        tx = [x for x in tx if x["ligne"].startswith(ligne)]
    if not tx:
        return {"n": 0, "mu": 0.0, "t": 0.0, "se": 0.0, "queue": 0.0, "ans": {}}
    st = stats(tx, seuil=1)
    if st is None:
        return {"n": len(tx), "mu": 0.0, "t": 0.0, "se": 0.0, "queue": 0.0, "ans": {}}
    return st


def main():
    L = ["# ADMISSION DES JAMBES SR « CRESTM » : FERME CONTRE JUGE (trois catégories)", "",
         "Voir `POUVOIR_JUGE.md` pour la justification des seuils. Une jambe dont le juge a moins de",
         "30 transactions n'est ni admise ni rejetée : elle est **en réserve**, et sera remesurée quand",
         "l'historique du juge s'allongera.", "",
         "| jambe | ferme (n, R/tx, t, années) | juge (n, R/tx, erreur type) | verdict |",
         "|---|---|---|---|"]
    adm, res, rej = [], [], []
    for nom, sym, ligne, rf, sj, lj in JAMBES:
        mf, mj = ferme(sym, ligne), juge(rf, sj, lj)
        cf = ("n=%d, %+.4f, t %+.2f (%s)" % (mf["n"], mf["mu"], mf["t"],
              " ".join("%d %+.2f" % (a, v[1]) for a, v in mf["ans"].items()))) if mf else "—"
        cj = ("n=%d, %+.4f, ±%.2f" % (mj["n"], mj["mu"], mj["se"])) if mj and mj["n"] else \
             ("mesuré, 0 transaction" if mj else "—")
        if mf is None:
            verdict, cat = "ferme non mesurée", None
        elif mf["mu"] <= 0:
            verdict, cat = "REJETÉE (ferme négative)", rej
        else:
            annees_pos = sum(1 for _, v in mf["ans"].items() if v[1] > 0)
            if mf["t"] < 2 or annees_pos < 2:
                verdict, cat = "REJETÉE (ferme trop fragile)", rej
            elif mj is None:
                verdict, cat = "DONNÉES INSUFFISANTES (juge non mesuré)", res
            elif mj["n"] < 30:
                verdict, cat = "DONNÉES INSUFFISANTES (%d transaction(s) au juge)" % mj["n"], res
            elif mj["mu"] > 0:
                verdict, cat = "**ADMISE**", adm
            elif mj["se"] and mj["mu"] < -2 * mj["se"] and mj["mu"] < -0.10:
                verdict, cat = "REJETÉE (juge significativement négatif)", rej
            else:
                verdict, cat = "DONNÉES INSUFFISANTES (juge négatif mais dans le bruit)", res
        if cat is not None:
            cat.append(nom)
        L.append("| %s | %s | %s | %s |" % (nom, cf, cj, verdict))

    L.append("\n## Bilan")
    L.append("\n- **Admises (%d)** : %s" % (len(adm), ", ".join(adm) if adm else "aucune"))
    L.append("- **En réserve, données insuffisantes au juge (%d)** : %s"
             % (len(res), ", ".join(res) if res else "aucune"))
    L.append("- **Rejetées (%d)** : %s" % (len(rej), ", ".join(rej) if rej else "aucune"))
    L.append("\nRappel de lecture : la réserve n'est pas une admission déguisée. Ces jambes n'entrent pas "
             "au portefeuille ; elles attendent de la donnée, et c'est la seule façon honnête de traiter "
             "une jambe rare dont l'étage de confirmation ne peut rien dire.")
    (B / "ADMISSION_SR.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n".join(L))
    print("\n  rapport ecrit dans ADMISSION_SR.md")


if __name__ == "__main__":
    main()
