# -*- coding: utf-8 -*-
"""ANALYSE PROFONDE VWAP_MOMENTUM : où perd-il ? (visualisation différente)
Regroupe les trades par mois/semestre pour voir la structure des pertes.
Puis : combo PTRAIL + VWAP momentum avec filtre MUTUEL (les 2 d'accord)."""
import polars as pl
import numpy as np
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
from edge_correct import load_m1, to_tf
import deep_signals as DS

def vwap_trades_detailed(sym, tf_sec=3600, persist=5, sl_atr=3.0, rr=2.0):
    m1 = load_m1(sym)
    tf = to_tf(m1, tf_sec)
    f = DS._base(tf, {})
    vwap = DS._vwap_series(f, 86400)
    c = tf["bid_c"].to_numpy()
    o = tf["bid_o"].to_numpy()
    h = tf["bid_h"].to_numpy()
    l = tf["bid_l"].to_numpy()
    atr = f["atr"].to_numpy()
    t = tf["time"].to_numpy()
    n = len(c)
    above = c > vwap
    trades = []
    last_exit = -1
    i = 0
    while i < n - 1:
        if i > 0 and above[i] and not above[i-1]:
            cnt = 0; j = i
            while j < n and above[j]: cnt += 1; j += 1
            if cnt >= persist:
                entry = o[i+1]
                R = sl_atr * atr[i]
                if not np.isfinite(R) or R <= 0: i += 1; continue
                stop = entry - R; tgt = entry + rr * R
                for k in range(i+1, min(i+150, n)):
                    if l[k] <= stop: r = -1.0; last_exit = k; break
                    elif h[k] >= tgt: r = rr; last_exit = k; break
                else:
                    r = (c[min(i+149,n-1)] - entry) / R; last_exit = min(i+149,n-1)
                trades.append({"ts": int(t[i]), "r": r}); i = last_exit
        i += 1
    return trades

for sym in ["GBPUSD", "USDJPY"]:
    tr = vwap_trades_detailed(sym)
    if not tr: continue
    import datetime as dt
    by_month = {}
    for x in tr:
        ym = dt.datetime.utcfromtimestamp(x["ts"]).strftime("%Y-%m")
        by_month.setdefault(ym, []).append(x["r"])
    print(f"\n=== VWAP_MOMENTUM {sym} — PnL par mois ===")
    tot = 0
    for ym in sorted(by_month):
        s = sum(by_month[ym])
        tot += s
        flag = "" if s >= 0 else " ← perte"
        print(f"  {ym}: {s:+6.1f}R (n={len(by_month[ym])}){flag}")
    print(f"  TOTAL: {tot:+.1f}R")
