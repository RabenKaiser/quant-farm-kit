# -*- coding: utf-8 -*-
"""c13v2t_obfilter_r187.py — attaque l'ENTREE: OB plus exigeante
(impulsion >= 1.2 ATR, lookahead 4) + heures exclues etendues. But:
reduire les 320 trades GBPUSD 2025 aux ~150 meilleurs."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\c13v2t_obfilter_r187.jsonl"


def cfg(mg, imp, look, hours, wick, tpr):
    return dict(InpMagic=mg, InpLots=0.10, InpRiskPct=0.0, InpTpR=tpr,
                InpMagLookbackH4=60, InpTrailAtrMult=2.0, InpTrailAfterR=0.5,
                InpImpulseAtrMult=imp, InpImpulseLook=look, InpAtrPeriod=14,
                InpHtfEmaPeriod=200, InpPinWickRatio=wick, InpCloseInZoneMin=0.15,
                InpMinStopPips=2.5, InpBufferAtrFrac=0.25, InpMaxSpreadPts=80,
                InpUseHourFilter=True, InpExcludedHoursCSV=hours,
                InpUseDailyStop=True, InpDailyStopR=3.0, InpMaxTradesDay=0,
                InpUtcOffset=2, InpVerbose=False)


def main():
    mg = 753000
    RUNS = [
        ("IMP12-LOOK4", 1.2, 4, "6,7,12,15,19,23", 1.5, 2.0),
        ("IMP15-LOOK4", 1.5, 4, "6,7,12,15,19,23", 1.5, 2.0),
        ("IMP12-LOOK3", 1.2, 3, "6,7,12,15,19,23", 1.5, 2.0),
        ("HRS-5717", 1.2, 4, "5,6,7,11,12,13,15,17,19,22,23", 1.5, 2.0),
        ("IMP12-WICK20", 1.2, 4, "6,7,12,15,19,23", 2.0, 2.0),
        ("IMP12-CIZ30", 1.2, 4, "6,7,12,15,19,23", 1.5, 2.0),
    ]
    # CIZ fixe a 0.15 dans l'EA; pour CIZ30 il faudrait recompiler -> skip
    RUNS = RUNS[:5]
    with open(OUT, "a", encoding="utf-8") as fo:
        for tag, imp, look, hours, wick, tpr in RUNS:
            mg += 1
            c = cfg(mg, imp, look, hours, wick, tpr)
            print(f"[r187 {tag}] GBPUSD 2025 ...", flush=True)
            r = RF.run_backtest("C13V2T_EA", symbol="GBPUSD", tf="M5",
                                from_d="2025.01.01", to_d="2026.01.01",
                                deposit=10000, max_wait=3600, inputs=c)
            fo.write(json.dumps({"tag": tag, "r": r}, default=str) + "\n")
            fo.flush()
            print(f"[{tag}] " + ("null" if r is None else
                  f"p={r.get('profit')} n={r.get('trades')} "
                  f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
            time.sleep(2)
    print("FIN r187", flush=True)


if __name__ == "__main__":
    main()
