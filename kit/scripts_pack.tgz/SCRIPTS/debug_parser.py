"""Debug parseur : pourquoi le parsing est incohérent ?
Teste parse_htm (rapport .htm = fiable) vs parse_tester_log (mélangé)."""
import sys, json
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner as m

# 1) lancer un run propre avec rapport .htm
r = m.run_backtest("PTRAIL_LONG", "USDJPY", "M30", "2024.01.01", "2025.01.01", 10000)
print("résultat run:", json.dumps(r, indent=1, default=str))

# 2) le rapport .htm existe-t-il ?
from pathlib import Path
rep = Path(r"C:\EAFarm\MT5\Farm\Tester\PTRAIL_LONG.htm")
print(f"\nrapport .htm: existe={rep.exists()}, taille={rep.stat().st_size if rep.exists() else 0}")

# 3) si le .htm est là, le parser a-t-il marché ?
if rep.exists():
    h = rep.read_text("utf-8", errors="replace")
    print(f"  contient 'Total Trades': {'Total Trades' in h}")
    m2 = m.parse_htm(rep)
    print(f"  parse_htm: {json.dumps(m2, default=str) if m2 else None}")
