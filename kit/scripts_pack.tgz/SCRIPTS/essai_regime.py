"""essai_regime : le seul regime qui casse CREST est 2020 (tendance rectiligne). Peut-on le filtrer ?

Fait mesure : CREST (SR50 court + selectivite + blocage + 2 R) fait +2,85 %/mois sur 6 ans a
1 % de risque, mais il est COUPE a -5 % en juin 2020, et a 1,5 % des mars 2020. Le motif
SR50 vend le haut d'un range : il meurt quand le marche part en ligne droite (mesure du round
262 : 32 signaux etales sur 9,93 ATR le 01/03/2023, 32 stops sur 32, -35,5 R).

Deux filtres candidats, tous deux connus AU MOMENT du signal :
  - MOM : refuser si le prix a deja parcouru plus de k ATR sur les 8 dernieres barres
    (on ne vend pas dans une course deja lancee) ;
  - EXPAN : refuser si le range des 50 barres depasse m x ATR (regime d'expansion).

On mesure les trois jambes avec et sans, et on isole 2020 pour voir si le filtre repare
l'annee qui tue le compte.
"""
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM
import portefeuille_tp2 as P2

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
H = 32
LEGS = ["EURCHF:SR50:C", "EURGBP:SR100:C", "GBPCHF:SR50:C"]


def mesure(D, motif, sens, tpr, mom=None, expan=None):
    m = NM.motifs(D)
    sig = np.asarray(P2.masque_selectif(D, m[motif][0 if sens == "C" else 1]), dtype=int)
    c, h, l, a = D["c"], D["h"], D["l"], D["a"]
    if mom is not None:
        d8 = c[sig] - np.roll(c, 8)[sig]
        sig = sig[np.abs(d8) < mom * a[sig]]
    if expan is not None:
        lo = pd.Series(l).rolling(50).min().values
        hi = pd.Series(h).rolling(50).max().values
        sig = sig[(hi[sig] - lo[sig]) < expan * a[sig]]
    r = NM.evaluer(D, sig, -1 if sens == "C" else 1, H, tp_r=tpr)
    if r is None:
        return None, None
    sg, R = r
    annees = defaultdict(list)
    for i, v in zip(sg, R):
        annees[D["idx"][i].year].append(v)
    return R, annees


def main():
    tpr = 2.0
    os.environ["SOURCE"] = "m1_pos"
    variantes = [("sans filtre", None, None), ("MOM 2 ATR", 2.0, None), ("MOM 3 ATR", 3.0, None),
                 ("EXPAN 4 ATR", None, 4.0), ("MOM 2 + EXPAN 4", 2.0, 4.0)]
    print("=== corpus long, cible 2 R, selectivite CREST active, 3 jambes")
    for nom, mom, expan in variantes:
        tous, par_an = [], defaultdict(list)
        for leg in LEGS:
            paire, motif, sens = leg.split(":")
            D = NM.charge(paire, "m1_pos")
            if D is None:
                continue
            R, annees = mesure(D, motif, sens, tpr, mom, expan)
            if R is None:
                continue
            tous += list(R)
            for y, v in annees.items():
                par_an[y] += list(v)
        if not tous:
            continue
        a2020 = par_an.get(2020, [])
        hors = [v for y in par_an if y != 2020 for v in par_an[y]]
        detail = " ".join("%d %+.3f" % (y, np.mean(par_an[y])) for y in sorted(par_an))
        print("  %-16s %6d positions | R/tx %+.4f | 2020 %+.4f (%d) | hors 2020 %+.4f"
              % (nom, len(tous), np.mean(tous), np.mean(a2020) if a2020 else 0, len(a2020),
                 np.mean(hors) if hors else 0), flush=True)
        print("       par annee : %s" % detail, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
