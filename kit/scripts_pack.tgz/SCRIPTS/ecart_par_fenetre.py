# -*- coding: utf-8 -*-
"""ecart_par_fenetre.py — L'ECART LABO/REEL DEPEND-IL DU MODE DE TICKS ?

Question de l'utilisateur (18/09) : "est-ce que la ou le portefeuille perd, ca
a ete fait sur MetaTrader 5 ou pas ?"

Reponse en deux temps :
  - OUI, les -33 318 USD du set TOP8 sont de VRAIS ordres passes dans le
    testeur MT5 (InpTradeMode=true), pas une estimation MFE/MAE ;
  - MAIS 57 % de ces transactions (2020 = 3 631, 2021 = 4 278) ont tourne sur
    des ticks GENERES depuis M1, parce que les ticks reels ne commencent que
    le 17/09/2023. Le journal du testeur l'ecrit noir sur blanc :
        AUDUSD : real ticks begin from 2024.01.02, every tick generation used

D'ou cette question, la seule qui compte : l'ecart entre ce que le labo annonce
et ce que les ordres ont paye est-il le MEME sur les fenetres a ticks reels
(2024-2025) et sur les fenetres a ticks reconstitues (2020-2021) ?

  - s'il est identique -> le modele de ticks n'est pas le probleme, l'ecart
    vient de l'execution (spread, remplissage, swap) ;
  - s'il est plus grand sur les ticks reconstitues -> une partie de l'ecart
    est un artefact de donnees, et il faudra en tenir compte.

USAGE : python ecart_par_fenetre.py [tag]
"""
import collections
import json
import statistics
import sys
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
REEL = ["2020", "2021"]                     # ticks reconstitues depuis M1
M1 = ["2024Q1", "2024Q2", "2024Q3", "2024Q4", "2025Q1"]   # ticks reels


def lignes(nom):
    p = BASE / nom
    if not p.exists():
        return
    for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if line.startswith("{"):
            try:
                yield json.loads(line)
            except ValueError:
                continue


def main():
    tag = sys.argv[1] if len(sys.argv) > 1 else "top8"
    setfile = (Path.home() / "AppData/Roaming/MetaQuotes/Terminal/Common/Files"
               / ("%s_set.txt" % tag))
    ids = {l.strip() for l in setfile.read_text().splitlines() if "|" in l}

    # --- 1. echelle de 1 R par combinaison (perte mediane) ---------------
    pnl_c = collections.defaultdict(list)
    for d in lignes("par_mt5_%s_deals.jsonl" % tag):
        if d.get("id") in ids:
            pnl_c[d["id"]].append((str(d.get("quarter")), d["pnl"]))
    r1 = {}
    for cid, lst in pnl_c.items():
        p = [x[1] for x in lst if x[1] < 0]
        if len(p) >= 5:
            r1[cid] = -statistics.median(p)

    # --- 2. R du labo par (combinaison, fenetre) -------------------------
    labo = {}
    for r in lignes("lab_results.jsonl"):
        if r["id"] in ids and r.get("r_x2") is not None:
            labo[(r["id"], str(r.get("period")))] = (r["r_x2"], r["n"])

    # --- 3. R du reel par (combinaison, fenetre) -------------------------
    reel = collections.defaultdict(lambda: [0.0, 0])
    for cid, lst in pnl_c.items():
        for q, v in lst:
            reel[(cid, q)][0] += v
            reel[(cid, q)][1] += 1

    def synth(groupe, nom):
        ecarts = []
        det = collections.defaultdict(lambda: [0.0, 0, 0.0, 0])
        for (cid, q), (pnl, n) in reel.items():
            if q not in groupe or cid not in r1 or n < 10:
                continue
            cle = (cid, q)
            if cle not in labo:
                continue
            rl = labo[cle][0]
            rr = pnl / n / r1[cid]
            ecarts.append(rr - rl)
            e = det[q]
            e[0] += rr * n
            e[1] += n
            e[2] += rl
            e[3] += 1
        print("   === %s ===" % nom)
        if not ecarts:
            print("      aucune comparaison possible (le labo n'a pas encore")
            print("      mesure ces fenetres pour ces combinaisons)")
            return None
        print("      %-9s %10s %10s %10s %8s"
              % ("fenetre", "R labo", "R reel", "ecart", "couples"))
        for q in sorted(det):
            e = det[q]
            print("      %-9s %+10.3f %+10.3f %+10.3f %8d"
                  % (q, e[2] / e[3], e[0] / e[1], e[0] / e[1] - e[2] / e[3],
                     e[3]))
        print("      ---> ecart median : %+.3f R   ecart moyen : %+.3f R"
              % (statistics.median(ecarts), statistics.mean(ecarts)))
        return statistics.mean(ecarts)

    print("=" * 84)
    print("ECART LABO / REEL, PAR MODE DE TICKS — set %s" % tag)
    print("=" * 84)
    a = synth(M1, "TICKS REELS (a partir du 17/09/2023)")
    print()
    b = synth(REEL, "TICKS RECONSTITUES DEPUIS M1 (2020 et 2021)")
    print()
    print("=" * 84)
    print("LECTURE")
    print("=" * 84)
    if a is None or b is None:
        print("   Une des deux familles n'est pas encore comparable.")
        print("   Le labo mesure 2020-2021 en ce moment (plan VINTAGE) :")
        print("   relancer ce script quand les blocs seront arrives.")
    else:
        print("   ecart ticks reels        : %+.3f R" % a)
        print("   ecart ticks reconstitues : %+.3f R" % b)
        print("   difference               : %+.3f R" % (b - a))
        print()
        if abs(b - a) < 0.03:
            print("   -> L'ECART EST LE MEME. Le modele de ticks n'est pas la")
            print("      cause : c'est l'EXECUTION (spread paye, remplissage,")
            print("      swap) qui separe le labo du reel, de facon uniforme.")
        else:
            print("   -> L'ECART DIFFERE. Une partie du decrochage vient donc")
            print("      des donnees elles-memes : les mesures sur ticks")
            print("      reconstitues ne sont pas comparables telles quelles.")


if __name__ == "__main__":
    main()
