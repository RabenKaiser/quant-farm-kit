# -*- coding: utf-8 -*-
"""diag_final_r226.py — DIAGNOSTIC RIGOUREUX de l ecart python/MT5.
Objectif: trouver EXACTEMENT pourquoi MT5 n=200 vs python n=85 sur EURUSD 2024.
Methode: dumper les entrees MT5 (dates) et comparer aux signaux python.
1) compte les signaux python (dates)
2) compte les entrees MT5 (dates depuis le log)
3) compare: quelles dates en plus ?"""
import sys, os, glob
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import sweep_py_r205 as SW
import c13v2_engine as ENG
import pandas as pd

BASE = {"imp_atr": 0.9, "imp_vol": 1.0, "imp_look": 6, "ob_age": 16,
        "rej_wick": 0.8, "rej_vol": 1.0, "close_zone": 0.15, "tp_r": 2.0,
        "bias": "vwap", "excl_hours": [6, 7, 12, 15, 19, 23],
        "min_stop": 0.00025, "buf_atr": 0.25, "lookahead": False, "vwap_len": 96}
m5, m15, h4 = SW.prep_frames("EURUSD", 2024)
signals, idx15 = ENG.detect_signals(m5, m15, dict(BASE))
print(f"1) SIGNAUX python bruts (avant bias/filtres): {len(signals)}")
# appliquer le bias comme dans bt
tv = (h4["high"] + h4["low"] + h4["close"]) / 3
vwap = (tv * h4["volume"]).rolling(96).sum() / h4["volume"].rolling(96).sum()
c5 = m5["close"].to_numpy()
hour = m5.index.hour.to_numpy()
excl = set(BASE["excl_hours"])
ok = 0
for i, sig in signals.items():
    if hour[i] in excl:
        continue
    bv = vwap.asof(m5.index[i - 1]) if len(vwap.dropna()) else float("nan")
    if pd.isna(bv):
        continue
    bias = 1 if c5[i - 1] > bv else -1
    d = sig[0]
    if (d == 1 and bias != 1) or (d == -1 and bias != -1):
        continue
    ok += 1
print(f"   signaux apres bias+heures: {ok}")
r = ENG.run_exit(m5, m15, h4, dict(BASE), exit_mode="tp", tp_r=2.0)
print(f"2) TRADES python (1 position a la fois): n={r['n']}")
print(f"   => signaux {ok} vs trades {r['n']} = {ok - r['n']} signales perdus")
print("   (car 1 seule position a la fois: les signaux pendant une position")
print("    ouverte sont ignores)")
print(f"3) MT5 observe: n=200 (TP fixe), donc MT5 prend PLUS de signaux")
print("   que le python -> le MT5 n a pas la contrainte '1 position' OU")
print("   il genere plus de signaux (zones OB differentes).")
# verif: combien de M15 distinctes donnent un signal ?
ob_ids = set(s[3] for s in signals.values())
print(f"4) OB distincts generant des signaux: {len(ob_ids)}")
print(f"   (python: 1 trade max par signal; si MT5 re-utilise une OB -> +)")
