﻿import MetaTrader5 as mt5
from datetime import datetime, timezone
mt5.initialize(path=r"C:\EAFarm\MT5\Farm\terminal64.exe")
def probe(sym, n):
    mt5.symbol_select(sym, True)
    r = mt5.copy_rates_from_pos(sym, mt5.TIMEFRAME_M1, 0, n)
    return 0 if r is None else len(r), r
print("=== GBPUSD : taille de requete maximale ===")
for n in (5000, 20000, 50000, 80000, 100000, 150000, 200000, 300000):
    k, _ = probe("GBPUSD", n)
    print(f"  demande {n:>7} -> recu {k:>7}")
print()
print("=== avec la taille qui marche, quelle plage ? ===")
k, r = probe("GBPUSD", 100000)
if k:
    d0 = datetime.fromtimestamp(r[0][0], tz=timezone.utc)
    d1 = datetime.fromtimestamp(r[-1][0], tz=timezone.utc)
    print(f"  GBPUSD {k} barres M1 : {d0} -> {d1}")
    print(f"  soit environ {(d1-d0).days} jours")
mt5.shutdown()
