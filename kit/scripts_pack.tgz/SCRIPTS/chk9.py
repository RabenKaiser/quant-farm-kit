﻿import re
src = open("giga_lib.py", encoding="utf-8").read()
blk = src.split("MK = {")[1].split("\n}")[0]
# trouve les doublons de cle
keys = re.findall(r'"([A-Z_0-9]+)"\s*:', blk)
from collections import Counter
dup = {k:v for k,v in Counter(keys).items() if v>1}
print("cles dupliquees dans MK :", dup if dup else "aucune")
