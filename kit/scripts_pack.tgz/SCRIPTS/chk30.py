﻿import MetaTrader5 as mt5
mt5.initialize(path=r"C:\EAFarm\MT5\Farm\terminal64.exe")
syms = ["AUDJPY","AUDNZD","CADJPY","EURAUD","EURCAD","EURGBP","EURJPY",
        "EURNZD","EURUSD","GBPCAD","GBPJPY","GBPUSD","NZDJPY","USDCHF"]
ok, ko = [], []
for s in syms:
    i = mt5.symbol_info(s)
    (ok if i else ko).append(s)
print(f"PRESENTS ({len(ok)}) : {ok}")
print(f"ABSENTS  ({len(ko)}) : {ko}")
mt5.shutdown()
