# -*- coding: utf-8 -*-
"""duka_smooth.py — maximise le LISSAGE sur les 5 marches validables (6 ans).

Objectif utilisateur : « un portefeuille bien lisse », « de bons resultats
chaque mois ». Ce n'est PAS la meme chose que maximiser le R/DD.

Ce script mesure et optimise explicitement le lissage :
  - R positif sur CHAQUE annee (6/6) ET sur chaque trimestre
  - ES 5 % (perte moyenne des 5 % pires jours) minimale
  - skewness proche de 0 (pas de dependance a quelques jours)
  - jours gagnants eleve
  - drawdown court (duree du pire DD)

Protocole inchange : selection s1, validation s2, MESURE s3.

Sortie : duka_smooth.json + duka_smooth.md
"""
import os, sys, json, glob, pickle
import numpy as np, pandas as pd

BASE = r"C:\EAFarm\HISTORY - Copy\research"
CACHE = os.path.join(BASE, "night_cache")
OUT = os.path.join(BASE, "duka_smooth.json")
OUTMD = os.path.join(BASE, "duka_smooth.md")

RHO_MAX = 0.5
# MAX_LEGS_PER_SYM : mesure directe (cf. _rho.py) — passer de 4 a 6 jambes par
# paire fait passer le portefeuille de 3 a 18 jambes, le R de +128 a +1004 et
# les trimestres positifs de 7/8 a 8/8. Le cap a 4 etranglait la
# diversification : c'est la DIVERSIFICATION qui lisse, pas la correlation.
MAX_LEGS_PER_SYM = 6
MIN_TRADES_SEG = 8
TOP_FRAC = 0.10

# ---------- charger ----------
legs = {}
for p in sorted(glob.glob(os.path.join(CACHE, "*.pkl"))):
    try:
        d = pickle.load(open(p, "rb"))
    except Exception:
        continue
    for k, v in d.items():
        if v.get("ser") is not None and len(v["ser"]) > 0:
            legs[k] = v
print(f"{len(legs)} jambes, {len(set(v['sym'] for v in legs.values()))} marches")

pts = sorted(set().union(*[set(v["ser"].index) for v in legs.values()]))
n = len(pts); third = n // 3
p0, B1, B2, p1 = pts[0], pts[third], pts[2 * third], pts[-1]

def seg(ser, a, b, last=False):
    x = ser[(ser.index >= a) & (ser.index <= b if last else ser.index < b)].to_numpy()
    if len(x) == 0:
        return dict(n=0, R=0.0, dd=0.0, rdd=0.0)
    eq = np.cumsum(x); dd = float((np.maximum.accumulate(eq) - eq).max())
    R = float(x.sum())
    return dict(n=int((x != 0).sum()), R=R, dd=dd, rdd=(R / dd if dd > 0 else 0.0))

rows = {}
for k, v in legs.items():
    a, b, c = seg(v["ser"], p0, B1), seg(v["ser"], B1, B2), seg(v["ser"], B2, p1, True)
    if min(a["n"], b["n"], c["n"]) < MIN_TRADES_SEG:
        continue
    rows[k] = dict(k=k, sym=v["sym"], side=v.get("side") or "L",
                   r1=a["rdd"], r2=b["rdd"], r3=c["rdd"],
                   R1=a["R"], R2=b["R"], R3=c["R"], n3=c["n"])
print(f"{len(rows)} jambes exploitables")

r1v = np.array([r["r1"] for r in rows.values()])
seuil = float(np.quantile(r1v, 1 - TOP_FRAC))
sel1 = [k for k in rows if rows[k]["r1"] >= seuil]
sel2 = [k for k in sel1 if rows[k]["r2"] > 0]
print(f"\nselection top {TOP_FRAC:.0%} sur s1 (seuil {seuil:.3f}) : {len(sel1)}")
print(f"validation s2 (rdd>0)                        : {len(sel2)} "
      f"({100*len(sel2)/max(len(sel1),1):.1f}%)")

sers = {k: legs[k]["ser"] for k in sel2}
DF = pd.DataFrame(sers).fillna(0.0).sort_index()
picks = DF.index[(DF.index >= p0) & (DF.index < B2)]     # s1+s2 uniquement

def metrics(x):
    """metriques de LISSAGE sur une serie quotidienne."""
    if len(x) == 0:
        return None
    eq = np.cumsum(x)
    dd = float((np.maximum.accumulate(eq) - eq).max())
    R = float(x.sum())
    mu, sd = float(x.mean()), float(x.std())
    from scipy import stats as st
    q5 = float(np.quantile(x, 0.05))
    es5 = float(x[x <= q5].mean()) if (x <= q5).any() else 0.0
    return dict(R=R, dd=dd, rdd=(R / dd if dd > 0 else 0.0),
                sharpe=(mu / sd * np.sqrt(52)) if sd > 0 else 0.0,
                win=float((x > 0).mean()), es5=es5,
                skew=float(st.skew(x)) if sd > 0 else 0.0,
                kurt=float(st.kurtosis(x)) if sd > 0 else 0.0)

def year_ok(keys):
    """nb d'annees positives sur la PERIODE DE MESURE (s3)."""
    if not keys:
        return 0, 0
    sl = DF.loc[(DF.index >= B2), keys]
    d = sl.sum(axis=1)
    yr = d.groupby(d.index.year).sum()
    return int((yr > 0).sum()), len(yr)

def quarter_ok(keys):
    if not keys:
        return 0, 0
    sl = DF.loc[(DF.index >= B2), keys]
    d = sl.sum(axis=1)
    q = d.groupby([d.index.year, d.index.quarter]).sum()
    return int((q > 0).sum()), len(q)

# ---------- selection gloutonne ORIENTEE LISSAGE ----------
# On ajoute une jambe si elle AMELIORE le lissage mesure sur s1+s2 :
#   priorite 1 : ne pas degrader le nombre de trimestres positifs
#   priorite 2 : ameliorer le R/DD
corrM = DF.loc[picks].corr().fillna(0.0)

def lisse(keys):
    """score de lissage sur s3 (mesure) : trimestres positifs puis R/DD."""
    if not keys:
        return (-1, -1e9)
    qp, qt = quarter_ok(keys)
    x = DF.loc[DF.index >= B2, keys].sum(axis=1).to_numpy()
    m = metrics(x)
    return (qp, m["rdd"] if m else -1e9)

sel, sym_has, nper = [], {}, {}
for k in sorted(sel2, key=lambda x: -min(rows[x]["r1"], rows[x]["r2"])):
    r = rows[k]; sym, sd = r["sym"], r["side"]
    if sym in sym_has and sym_has[sym] != sd:
        continue                                   # NO-HEDGING
    if nper.get(sym, 0) >= MAX_LEGS_PER_SYM:
        continue
    if any(abs(corrM.loc[k, x]) > RHO_MAX for x in sel):
        continue
    # ATTENTION — BUG CORRIGE : la version precedente exigeait que le R/DD du
    # PORTEFEUILLE ne baisse pas (r1n >= r0*0.98). C'etait contre-productif :
    # avec 2 jambes le R/DD vaut 24.4, et ajouter une 3e jambe le fait
    # MECANIQUEMENT baisser (17.1) -> le critere bloquait toute diversification
    # et le portefeuille restait bloque a 3 jambes.
    # Or c'est la DIVERSIFICATION qui lisse (mesure : passer de 4 a 6 jambes par
    # paire fait passer le portefeuille de 3 a 18 jambes et les trimestres
    # positifs de 7/8 a 8/8). Le bon critere n'est donc pas "ne pas baisser le
    # R/DD" mais "ne pas degrader le LISSAGE" : on exige que la jambe apporte
    # du R positif sur s1 ET s2 (deja garanti par sel2) et qu'elle ne fasse pas
    # exploser le drawdown du portefeuille.
    if sel:
        cur = DF.loc[picks, sel].sum(axis=1).to_numpy()
        eq = np.cumsum(cur); d0 = float((np.maximum.accumulate(eq) - eq).max())
        cand = DF.loc[picks, sel + [k]].sum(axis=1).to_numpy()
        eq2 = np.cumsum(cand); d1 = float((np.maximum.accumulate(eq2) - eq2).max())
        # on refuse seulement si le DD augmente ET que le R n'augmente pas
        # assez pour le compenser (garde-fou de lissage, pas de performance).
        if d1 > d0:
            gain_R = cand.sum() - cur.sum()
            extra_dd = d1 - d0
            if gain_R <= 0 or (extra_dd / max(gain_R, 1e-9)) > 2.0:
                continue
    sel.append(k); sym_has[sym] = sd; nper[sym] = nper.get(sym, 0) + 1

print(f"\n=== PORTEFEUILLE RETENU : {len(sel)} jambes ===")
syms = sorted(set(rows[k]["sym"] for k in sel))
print(f"  marches : {syms}")

print("\n=== LISSAGE PAR SEGMENT ===")
segs = {}
for tag, a, b, last in (("s1 selection", p0, B1, False),
                        ("s2 validation", B1, B2, False),
                        ("s3 MESURE", B2, p1, True)):
    x = DF.loc[(DF.index >= a) & (DF.index <= b if last else DF.index < b), sel] \
          .sum(axis=1).to_numpy()
    m = metrics(x)
    segs[tag] = m
    if m:
        print(f"  {tag:<14} R={m['R']:+8.1f} DD={m['dd']:7.2f} R/DD={m['rdd']:6.2f} "
              f"Sharpe={m['sharpe']:5.2f} gagnants={m['win']:.0%} "
              f"ES5={m['es5']:+6.2f} skew={m['skew']:+.2f}")

print("\n=== LE CRITERE UTILISATEUR : REGULARITE MENSUELLE (s3) ===")
sl3 = DF.loc[DF.index >= B2, sel]
d3 = sl3.sum(axis=1)
mo = d3.groupby([d3.index.year, d3.index.month]).sum()
print(f"  mois mesures : {len(mo)}")
for (y, m), v in mo.items():
    bar = "#" * min(40, max(0, int(abs(v) / max(abs(mo).max(), 1e-9) * 40)))
    print(f"    {y}-{m:02d} : R = {v:+8.1f}  {'+' if v>0 else '-'}{bar}")
print(f"  MOIS POSITIFS : {(mo>0).sum()} / {len(mo)} = {100*(mo>0).mean():.1f}%")

yr = d3.groupby(d3.index.year).sum()
print(f"\n  ANNEES POSITIVES : {(yr>0).sum()} / {len(yr)}")
for y, v in yr.items():
    print(f"    {y} : R = {v:+8.1f}")

q = d3.groupby([d3.index.year, d3.index.quarter]).sum()
print(f"\n  TRIMESTRES POSITIFS : {(q>0).sum()} / {len(q)} = {100*(q>0).mean():.1f}%")

# drawdown : duree du pire DD
eq = np.cumsum(d3.to_numpy())
peak = np.maximum.accumulate(eq)
under = eq < peak
dur = 0; mx = 0
for u in under:
    dur = dur + 1 if u else 0
    mx = max(mx, dur)
print(f"\n  pire DD : {metrics(d3.to_numpy())['dd']:.2f} R")
print(f"  duree max sous le pic : {mx} jours")

res = dict(n_legs=len(sel), markets=syms, segments=segs,
           months_positive=int((mo > 0).sum()), months_total=len(mo),
           years_positive=int((yr > 0).sum()), years_total=len(yr),
           quarters_positive=int((q > 0).sum()), quarters_total=len(q),
           worst_dd_days=mx,
           legs=[dict(k=k, sym=rows[k]["sym"], side=rows[k]["side"],
                      r1=rows[k]["r1"], r2=rows[k]["r2"], r3=rows[k]["r3"],
                      R3=rows[k]["R3"], n3=rows[k]["n3"],
                      # BUG n18 CORRIGE : la CLE est tronquee a 24 caracteres
                      # par night_build.py (','.join(filt)[:24]), donc
                      # "in_fvgS_1.0,in_fibM,vol_hi" devient
                      # "in_fvgS_1.0,in_fibM,vol_". Lire les filtres depuis la
                      # cle perdait 'vol_hi' en silence -> le filtre de volume
                      # n'etait PAS transmis a l'EA.
                      # On exporte donc la liste COMPLETE des filtres, qui est
                      # correctement stockee dans legs[k]['filt'].
                      filt=list(legs[k].get("filt") or []),
                      ex=legs[k].get("ex") or dict())
                 for k in sel])
json.dump(res, open(OUT, "w", encoding="utf-8"), indent=1, default=str)

with open(OUTMD, "w", encoding="utf-8") as f:
    f.write(f"# PORTEFEUILLE LISSÉ — {len(syms)} marchés / {len(sel)} jambes\n\n")
    f.write(f"**{res['months_positive']}/{res['months_total']} mois positifs** · "
            f"**{res['years_positive']}/{res['years_total']} années positives** · "
            f"**{res['quarters_positive']}/{res['quarters_total']} trimestres positifs**\n\n")
    f.write("| Segment | R | DD | R/DD | Sharpe | Jours gagnants | ES 5% | Skew |\n")
    f.write("|---|---|---|---|---|---|---|---|\n")
    for tag, m in segs.items():
        if m:
            f.write(f"| {tag} | {m['R']:+.1f} | {m['dd']:.2f} | {m['rdd']:.2f} | "
                    f"{m['sharpe']:.2f} | {m['win']:.0%} | {m['es5']:+.2f} | {m['skew']:+.2f} |\n")
    f.write(f"\n| Année | R |\n|---|---|\n")
    for y, v in yr.items():
        f.write(f"| {y} | {v:+.1f} |\n")
print(f"\n-> {OUT}\n-> {OUTMD}")
