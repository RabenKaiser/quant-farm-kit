# -*- coding: utf-8 -*-
"""cross_broker.py — MEMES structures sur DEUX brokers independants.

PRINCIPE
  On ne compare PAS Python a MT5. On compare BROKER A BROKER.
  Une structure qui donne le meme comportement sur deux flux de donnees
  independants (Dukascopy et Upcomers) n'est pas un artefact de flux.

  C'est un test de ROBUSTESSE plus fort que la fidelite Python/MT5, parce que
  les deux brokers ont des cotations, des spreads et des heures differentes.

STRUCTURES TESTEES (celles du portefeuille final + variantes)
  brk_round_dn, brk_ll_100, sweep_lo_100, xup_vwapW, xup_vwapD,
  fvg_dn_20, ll_lh_100

METHODE
  Pour chaque structure et chaque broker :
    - construire le masque sur M5
    - compter les signaux
    - mesurer le R/DD sur la periode COMMUNE (2026-01-12 -> 2026-09)

  La periode commune est courte (~8 mois) mais IDENTIQUE pour les deux, donc
  comparable. C'est le seul intervalle ou l'on peut croiser.

SORTIE : cross_broker.json + rapport console
"""
import os, sys, glob
import numpy as np
import pandas as pd

SCRIPT_DIR = r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS"
sys.path.insert(0, SCRIPT_DIR)
BASE = r"C:\EAFarm\HISTORY - Copy\research"
SL, TP, HOLD = 1.0, 20.0, 192

# ---------- chargeurs ----------
def load_pos(sym):
    """charge un CSV M5 de pos_cache (Dukascopy, M1 -> M5)."""
    p = os.path.join(BASE, "m1_pos", f"{sym}_M1.csv")
    if not os.path.exists(p):
        return None, None
    df = pd.read_csv(p, usecols=["time", "open", "high", "low", "close",
                                 "tick_volume"])
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    return df, "duka"


def load_up(sym):
    p = os.path.join(BASE, "up_new", f"{sym}_M5.csv")
    if not os.path.exists(p):
        return None, None
    df = pd.read_csv(p)
    df["time"] = pd.to_datetime(df["time"], utc=True)
    return df, "up"


def to_m5(df, src):
    df = df.set_index("time").sort_index()
    if src == "duka":
        o = df["open"].resample("5min").first()
        h = df["high"].resample("5min").max()
        l = df["low"].resample("5min").min()
        c = df["close"].resample("5min").last()
        v = df["tick_volume"].resample("5min").sum()
    else:
        o, h, l, c, v = (df["open"], df["high"], df["low"],
                         df["close"], df["tick_volume"])
    out = pd.DataFrame({"open": o, "high": h, "low": l,
                        "close": c, "volume": v}).dropna()
    return out


# ---------- masques (identiques pour les deux brokers) ----------
def masks(m5):
    h = m5["high"].to_numpy(float); l = m5["low"].to_numpy(float)
    o = m5["open"].to_numpy(float); c = m5["close"].to_numpy(float)
    v = m5["volume"].to_numpy(float)
    n = len(c)
    pc = np.roll(c, 1); pc[0] = c[0]
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    atr = pd.Series(tr).ewm(alpha=1/14, adjust=False).mean().to_numpy()
    M = {}
    # chiffres ronds
    mult = 10.0 ** np.floor(np.log10(np.maximum(c, 1e-9)))
    stp = mult / 10.0
    r1 = np.round(c / stp) * stp
    M["brk_round_dn"] = (c < r1) & (np.roll(c, 1) >= np.roll(r1, 1))
    M["brk_round_up"] = (c > r1) & (np.roll(c, 1) <= np.roll(r1, 1))
    # cassures
    for W in (20, 50, 100):
        hi = pd.Series(h).rolling(W).max().shift(1).to_numpy()
        lo = pd.Series(l).rolling(W).min().shift(1).to_numpy()
        M[f"brk_ll_{W}"] = (c < lo) & (np.roll(c, 1) >= np.roll(lo, 1))
        M[f"brk_hh_{W}"] = (c > hi) & (np.roll(c, 1) <= np.roll(hi, 1))
        M[f"ll_lh_{W}"] = (h < hi) & (l < lo)
        M[f"hh_hl_{W}"] = (h > hi) & (l > lo)
        M[f"sweep_lo_{W}"] = (l < lo) & (c > o)
        M[f"sweep_hi_{W}"] = (h > hi) & (c < o)
    # FVG
    for mu, tag in ((1.0, "10"), (2.0, "20")):
        gu = l > (np.roll(h, 2) + mu * atr)
        gd = h < (np.roll(l, 2) - mu * atr)
        gu[:3] = False; gd[:3] = False
        M[f"fvg_up_{tag}"] = gu
        M[f"fvg_dn_{tag}"] = gd
    # VWAP ancre
    idx = m5.index
    tp_ = (h + l + c) / 3.0
    day = idx.normalize().to_numpy()
    week = (idx.isocalendar().year.astype(str) + "_" +
            idx.isocalendar().week.astype(str)).to_numpy()
    for key_, nm in ((day, "D"), (week, "W")):
        pv = pd.Series(tp_ * v).groupby(key_).cumsum().to_numpy()
        vv = pd.Series(v).groupby(key_).cumsum().to_numpy()
        vw = pv / np.where(vv > 0, vv, np.nan)
        M[f"xup_vwap{nm}"] = (c > vw) & (np.roll(c, 1) <= np.roll(vw, 1))
        M[f"xdn_vwap{nm}"] = (c < vw) & (np.roll(c, 1) >= np.roll(vw, 1))
    # filtres
    hr = idx.hour.to_numpy()
    M["h_quiet"] = (hr >= 22) | (hr < 6)
    vma = pd.Series(v).rolling(50).mean().shift(1).to_numpy()
    M["vol_lo"] = v < 0.6 * vma
    M["vol_hi"] = v > 1.5 * vma
    M["vol_clx"] = v > 2.5 * vma
    m50 = pd.Series(c).rolling(50).mean().shift(1).to_numpy()
    s50 = pd.Series(c).rolling(50).std().shift(1).to_numpy()
    z = (c - m50) / np.where(s50 > 0, s50, np.nan)
    M["bb_low"] = z < -2.0
    M["bb_high"] = z > 2.0
    return M


def run(df, mask, period=None):
    """R simple : entree au close suivant, sortie SL/TP/hold, en ATR."""
    h = df["high"].to_numpy(float); l = df["low"].to_numpy(float)
    c = df["close"].to_numpy(float); o = df["open"].to_numpy(float)
    pc = np.roll(c, 1); pc[0] = c[0]
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    atr = pd.Series(tr).ewm(alpha=1/14, adjust=False).mean().to_numpy()
    idx = np.where(mask)[0]
    rets = []
    last_exit = -1
    for i in idx:
        if i <= last_exit or i + 2 >= len(c):
            continue
        e = i + 1
        a = atr[i]
        if not np.isfinite(a) or a <= 0:
            continue
        entry = o[e]
        sl = entry - SL * a
        tp = entry + TP * a
        r = None
        for k in range(e, min(e + HOLD, len(c))):
            # pessimiste : SL prioritaire
            if l[k] <= sl:
                r = -SL; last_exit = k; break
            if h[k] >= tp:
                r = TP; last_exit = k; break
        if r is None:
            k = min(e + HOLD - 1, len(c) - 1)
            r = (c[k] - entry) / a
            last_exit = k
        rets.append(r)
    if not rets:
        return dict(n=0, R=0.0, dd=0.0, rdd=0.0)
    x = np.array(rets)
    eq = np.cumsum(x); R = float(x.sum())
    dd = float((np.maximum.accumulate(eq) - eq).max())
    return dict(n=len(x), R=R, dd=dd, rdd=(R/dd if dd > 0 else 0))


if __name__ == "__main__":
    # marches presents sur les DEUX brokers
    duka = set()
    for p in glob.glob(os.path.join(BASE, "m1_pos", "*_M1.csv")):
        duka.add(os.path.basename(p)[:-7].replace("_M1", ""))
    up = set()
    for p in glob.glob(os.path.join(BASE, "up_new", "*_M5.csv")):
        up.add(os.path.basename(p)[:-7].replace("_M5", ""))
    commun = sorted(duka & up)
    print(f"Dukascopy : {len(duka)} marches")
    print(f"Upcomers  : {len(up)} marches")
    print(f"COMMUNS   : {len(commun)} -> {commun}\n")

    STRUCT = ["brk_round_dn", "brk_ll_100", "brk_ll_50", "sweep_lo_100",
              "sweep_lo_50", "xup_vwapW", "xup_vwapD", "xdn_vwapD",
              "fvg_dn_20", "fvg_dn_10", "ll_lh_100", "bb_low"]
    FILT = ["", "h_quiet", "vol_lo", "vol_clx", "bb_low"]

    res = {}
    for sym in commun:
        d_df, _ = load_pos(sym)
        u_df, _ = load_up(sym)
        if d_df is None or u_df is None:
            continue
        d5 = to_m5(d_df, "duka"); u5 = to_m5(u_df, "up")
        Md = masks(d5); Mu = masks(u5)
        for st in STRUCT:
            for f in FILT:
                key = f"{st}|{f or '-'}"
                for tag, df5, MM in (("duka", d5, Md), ("up", u5, Mu)):
                    if st not in MM:
                        continue
                    m = MM[st]
                    if f:
                        if f not in MM:
                            continue
                        m = m & MM[f]
                    if m.sum() < 30:
                        continue
                    r = run(df5, m)
                    res.setdefault(key, {}).setdefault(tag, {})[sym] = r
        print(f"  {sym:<9} fait")

    print("\n" + "=" * 92)
    print("COMPARAISON INTER-BROKERS (structures, signaux, R)")
    print("=" * 92)
    print(f"{'structure|filtre':<26}{'mk_d':>5}{'sig_d':>8}{'R_d':>8}"
          f"{'mk_u':>5}{'sig_u':>8}{'R_u':>8}{'accord':>8}")
    lignes = []
    for key, d in res.items():
        rd = d.get("duka", {}); ru = d.get("up", {})
        if len(rd) < 4 or len(ru) < 4:
            continue
        sd = sum(v["n"] for v in rd.values())
        su = sum(v["n"] for v in ru.values())
        Rd = sum(v["R"] for v in rd.values())
        Ru = sum(v["R"] for v in ru.values())
        # accord : meme signe du R, et ordres de grandeur compatibles
        accord = "OUI" if (Rd > 0) == (Ru > 0) and Rd != 0 else "non"
        print(f"{key[:25]:<26}{len(rd):>5}{sd:>8}{Rd:>8.1f}"
              f"{len(ru):>5}{su:>8}{Ru:>8.1f}{accord:>8}")
        lignes.append(dict(key=key, mk_d=len(rd), sig_d=sd, R_d=Rd,
                           mk_u=len(ru), sig_u=su, R_u=Ru, accord=accord))

    import json
    json.dump(lignes, open(os.path.join(BASE, "cross_broker.json"), "w"),
              indent=1, default=str)
    print(f"\n-> cross_broker.json ({len(lignes)} structures comparees)")
