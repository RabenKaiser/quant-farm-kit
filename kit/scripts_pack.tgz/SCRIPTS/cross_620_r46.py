# -*- coding: utf-8 -*-
"""cross_620_r46.py — retest crosses epaisses Upcomers en session 6-20
(EURCHF n=19, EURCAD n=17 a 8-17; jamais testees 6-20) + GBPCHF 8t.
Verifie le balance reel + trades."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_duka as RD

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\upcomers_cross620_r46.jsonl"


def v3(comp, mg):
    return dict(InpLots=0.10, InpMagic=mg, InpMaxDailyLossPct=3.0, InpUtcOffset=2,
                InpSlippage=30, InpStartH=6, InpEndH=20, InpCloseHH=20, InpCloseMM=30,
                InpTpAtr=1.0, InpSlAtr=2.0, InpMaxHold=96, InpAtrPct=comp,
                InpDonPct=comp, InpObvMode=0, InpMfiMode=0, InpVerbose=False)


def main():
    tests = [("EURCHF", 0.50, 719701), ("EURCAD", 0.50, 719702),
             ("GBPCHF", 0.50, 719703), ("EURCHF", 0.55, 719704),
             ("EURCAD", 0.55, 719705)]
    with open(OUT, "a", encoding="utf-8") as fo:
        for sym, comp, mg in tests:
            c = v3(comp, mg)
            print(f"[r46 {sym}-c{comp} 6-20] H1 2026.01->09 ...", flush=True)
            r = RD.run_backtest("V3INT_EA", symbol=sym, tf="H1",
                                from_d="2026.01.01", to_d="2026.09.01",
                                deposit=10000, max_wait=1800, inputs=c)
            fo.write(json.dumps({"sym": sym, "comp": comp, "r": r},
                                default=str) + "\n")
            fo.flush()
            if r is None:
                print(f"[{sym}] ABSENT/erreur", flush=True)
            else:
                print(f"[{sym}-c{comp}] profit={r.get('profit')} "
                      f"n={r.get('trades')} pf={r.get('pf')} "
                      f"wr={r.get('wr')}", flush=True)
            time.sleep(3)
    print("FIN", flush=True)


if __name__ == "__main__":
    main()
