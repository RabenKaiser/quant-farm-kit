# -*- coding: utf-8 -*-
"""QUESTION : 3 trades simultanés, c'est assez ?
Analyse le nombre réel de positions simultanées de PTRAIL (par paire + portfolio)
à partir des logs réels, et simule le portfolio complet pour dimensionner le
nombre max de positions nécessaires."""
import re, json
from collections import defaultdict

LOG = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs\20260824.log"
with open(LOG, "rb") as fh:
    t = fh.read().decode("utf-16-le", errors="replace")

def position_concurrency(sym, year):
    """Compte les positions simultanées de PTRAIL sur une paire/année."""
    pat = re.compile(rf"{sym},\w+[^\r\n]*?testing of Experts\\PTRAIL_LONG\.ex5 from {year}\.01\.01 00:00 to {int(year)+1}\.01\.01 00:00")
    hits = [m.start() for m in pat.finditer(t)]
    if not hits:
        return None
    idx = hits[-1]
    nxt = t.find("testing of", idx + 100)
    seg = t[idx:(nxt if nxt > idx else min(idx + 6_000_000, len(t)))]
    # entrées (deal #N buy/sell) — ATTENTION : les fermetures apparaissent aussi
    # comme "deal #M sell ... done" (l'ordre inverse). On ne compte que les
    # OUVERTURES : un buy/sell qui n'est PAS une fermeture d'une position existante.
    # Méthode robuste : entrée = "deal #N buy VOL sym at P done" ; fermeture =
    # "stop loss triggered #K ... [#M sell ...]" -> on associe par ticket d'ouverture.
    open_tickets = {}
    for mm in re.finditer(r"(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s+deal #(\d+) (buy|sell) ([\d.]+) " + sym + r" at ([\d.]+) done", seg):
        # un deal est une OUVERTURE si le ticket n'a pas été ouvert avant
        tk = int(mm.group(2))
        if tk not in open_tickets:
            open_tickets[tk] = mm.group(1)   # premier deal du ticket = ouverture
    # fermetures : "stop loss triggered #K ... [#M sell ...]" où K = ticket d'ouverture
    close_map = {}
    for mm in re.finditer(r"(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s+(?:stop loss|take profit) triggered #(\d+)", seg):
        tk = int(mm.group(2))
        if tk in open_tickets:
            close_map[tk] = mm.group(1)
    events = []
    for tk, ts in open_tickets.items():
        events.append((ts, 1, tk))
        if tk in close_map:
            events.append((close_map[tk], -1, tk))
    events.sort()
    active = set(); max_conc = 0
    for ts, delta, tk in events:
        if delta == 1: active.add(tk)
        else: active.discard(tk)
        max_conc = max(max_conc, len(active))
    return max_conc, len(open_tickets)

print("=== POSITIONS SIMULTANÉES RÉELLES (PTRAIL, par paire/année) ===")
results = {}
for sym in ["GBPUSD", "EURUSD", "USDJPY"]:
    for y in ["2023", "2024", "2025"]:
        r = position_concurrency(sym, y)
        if r:
            maxc, n = r
            results[(sym, y)] = maxc
            print(f"  {sym} {y}: max {maxc} positions simultanées (sur {n} trades)")
        else:
            print(f"  {sym} {y}: n/a")

# max sur les paires valides
vals = [v for v in results.values()]
print(f"\nMAX positions simultanées sur une paire : {max(vals) if vals else '?'}")
print(f"Portfolio 3 paires (indépendantes) : max attendu ~{max(vals)*2 if vals else '?'} (chevauchement partiel)")
print(f"\nConclusion : 3 positions PAR PAIRE (pyramide max 3 unités) est déjà le cas.")
print(f"Le portfolio = 3 paires x 3 unités max = jusqu'à 9 positions simultanées.")
print(f"Le max réel observé par paire : {max(vals) if vals else '?'} -> la limite '3 positions'")
print(f"dans les sécurités est par PAIRE (1 position = 1 panier pyramide), pas globale.")
