# -*- coding: utf-8 -*-
"""eurnzd_anom.py — pourquoi EURNZD VWAPWXUP donne 283 au lieu de 83 ?

MEME SANS le filtre de spread, l'EA produit 283 entrees contre 83 en python
(ratio 3.41). Le spread n'explique donc PAS cette jambe.

HYPOTHESES A TESTER (dans l'ordre)
----------------------------------
H1. L'ancrage hebdomadaire ISO de l'EA ne correspond pas a celui de pandas.
    -> comparer les taux de declenchement xup_vwapD vs xup_vwapW cote python
       et voir lequel des deux colle a 283.
H2. Le filtre BBLOW differe (z < -2 cote python, bandes de Bollinger cote EA
    avant le bug n15 ; verifier la version actuelle).
H3. Le signal python est bien plus rare a cause du filtre bb_low combine.
"""
import sys
import numpy as np

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT, deep_lib as D

SL, TP, HOLD = 1.0, 20.0, 192
CACHE = {}
G._cache.clear()
F = G.get_frames("EURNZD")
m5, m1 = F["m5"], F["m1"]
h1z, hh, ll, a1, gb, gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd, zlo, zhi = MT.project(m5.index, h1z, hh, ll, gb, gr, max_age_h=48)
M = NL.build(m5, F, zd, zlo, zhi); M.update(FE.more(m5, F, m1))
T0, T3 = m5.index[0], m5.index[-1]

print("=== TAUX DES DECLENCHEURS (EURNZD) ===")
for t in ("xup_vwapD", "xup_vwapW", "vwap_xup"):
    if t in M:
        print(f"  {t:<12} {100*M[t].mean():.4f} %  ({int(M[t].sum())} barres)")

print("\n=== AVEC LE FILTRE bb_low ===")
for t in ("xup_vwapD", "xup_vwapW", "vwap_xup"):
    if t not in M:
        continue
    s = NL.sig(M, t, ["bb_low"])
    nsig = 0 if s is None else int((s != 0).sum())
    if nsig == 0:
        print(f"  {t:<12} -> 0 signal")
        continue
    st = D.run_ex("EURNZD", s, SL, TP, HOLD, trail_atr=None,
                  t0=T0, t1=T3, use_m1=False)
    print(f"  {t:<12} -> {nsig:4d} signaux, {st.get('n',0):4d} trades")
    print(f"      (MT5 avec spread = 229, sans spread = 283, python = 83)")

print("\n=== H2 : le filtre bb_low est-il le bon ? ===")
if "bb_low" in M:
    print(f"  bb_low taux = {100*M['bb_low'].mean():.4f} %")
    # python definition
    import re
    src = open(r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS\nested_lib.py",
               encoding="utf-8").read()
    for m in re.finditer(r".*bb_low.*", src):
        s = m.group(0).strip()
        if "=" in s and not s.startswith("#"):
            print(f"  definition python : {s[:130]}")
            break

print("\n=== H1 : simulation de l'ancrage semaine cote python ===")
# reproduction exacte de feat2.py lignes 113-123
idx = m5.index
h = m5["high"].to_numpy(); l = m5["low"].to_numpy(); c = m5["close"].to_numpy()
v = m5["volume"].to_numpy() if "volume" in m5 else m5["tick_volume"].to_numpy()
tp = (h + l + c) / 3.0
import pandas as pd
day = (idx.isocalendar().year.astype(str) + "_" +
       idx.isocalendar().week.astype(str)).to_numpy()
for key_, nm in ((idx.normalize(), "D"), (pd.Series(day), "W")):
    pv = pd.Series(tp * v).groupby(key_).cumsum().to_numpy()
    vv = pd.Series(v).groupby(key_).cumsum().to_numpy()
    vw = pv / np.where(vv > 0, vv, np.nan)
    xup = (c > vw) & (np.roll(c, 1) <= np.roll(vw, 1))
    print(f"  vwap{nm} : xup taux = {100*xup.mean():.4f} %  ({int(xup.sum())})")
    if "bb_low" in M:
        both = xup & M["bb_low"].to_numpy()
        print(f"      & bb_low -> {int(both.sum())} barres")
