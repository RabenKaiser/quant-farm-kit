# -*- coding: utf-8 -*-
"""corriger_anatomie.py — REMPLACE LA SECTION 10.1 DE PLANS.md.

POURQUOI (18/09, 01 h 40). La section 10.1 affirmait, a partir de l'anatomie du
portefeuille :

    "l'anatomie des trades est identique dans les deux periodes ; seul le R
     s'effondre ; le +84 % venait de l'ORDRE dans lequel les evenements
     arrivaient."

L'utilisateur a repondu : "c'est bizarre, ce n'est pas un artefact ?" Il avait
raison. Verification faite :

  - r_x47 (SL 12 x ATR / TP 1 x ATR) a un PLAFOND : quand tous les trades
    touchent l'objectif de 1 ATR avant le stop de 12 ATR, R = 1/12 = 0.0833,
    soit 0.08 arrondi. On ne peut pas faire mieux.
  - 2 103 couples sur 24 871 (8.5 %) sont EXACTEMENT a ce plafond sur tous leurs
    trimestres.
  - Le portefeuille a ete choisi en prenant les 3 meilleurs de chaque paire par
    R moyen : les 24 lignes retenues valent donc TOUTES exactement le plafond
    (24 sur 24), et par construction.

Consequence : comparer +0.080 (periode de choix) a -0.008 (autre periode) n'est
pas une observation sur le marche, c'est une REGRESSION VERS LA MOYENNE depuis
un maximum. Un maximum borne ne peut que baisser ensuite. L'effondrement etait
inscrit d'avance dans la facon de choisir.

Ce script reecrit la section avec la vraie explication, et conserve ce qui reste
valable (le niveau hors periode vaut -0.008, soit le niveau du hasard).
"""
import io
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
PLANS = BASE / "PLANS.md"

NOUVELLE = """## 10.1 L'anatomie du portefeuille — ET UN ARTEFACT QUE J'AI CORRIGE

Question de l'utilisateur : « est-ce qu'on a fait tourner le meme portefeuille
sur les donnees ou il perd, pour voir les courbes de MFE et MAE ? »
Reponse : non, jamais. C'est fait (`SCRIPTS/anatomie.py`).

Premier resultat, et il est spectaculaire :

| grandeur (moyenne sur les lignes comparables) | 2024-2025 (gagnant) | 2020-2021 (perdant) |
|---|---|---|
| R a SL 12 / TP 1 | **+0.080** | **-0.008** |
| R a SL 12 / TP 24 | +0.047 | +0.017 |
| MFE moyen | 9.34 | 8.59 |
| MAE moyen | 8.10 | 8.13 |
| % stoppes a SL 12 | 22.4 % | 22.6 % |
| position moyenne de l'entree | 0.612 | 0.618 |
| barre du MFE | 95.0 | 84.7 |
| barre du MAE | 79.7 | 79.6 |

J'en ai d'abord conclu : « les trades sont identiques, seul l'ORDRE des
evenements change ; le +84 % etait un equilibre sur une lame de couteau ».

**C'ETAIT FAUX, et l'utilisateur l'a senti tout de suite** : « ce n'est pas un
artefact ? » Verification faite, c'en est un, et il est total :

- `r_x47` (SL 12 x ATR / TP 1 x ATR) a un **plafond** : quand tous les trades
  touchent l'objectif de 1 ATR avant le stop de 12 ATR, R = 1/12 = 0.0833,
  soit **0.08**. On ne peut pas faire mieux, par construction.
- **2 103 couples sur 24 871 (8.5 %)** sont exactement a ce plafond sur tous
  leurs trimestres.
- Le portefeuille a ete choisi en prenant **les 3 meilleurs par paire** sur le R
  moyen : les **24 lignes retenues valent donc toutes exactement 0.080**
  (verifie : 24 sur 24). Il y avait assez de candidats au plafond pour en
  remplir chaque paire.

**Comparer +0.080 a -0.008 n'est donc pas une observation sur le marche : c'est
une regression vers la moyenne depuis un maximum.** Un maximum borne ne peut que
baisser ensuite. L'effondrement etait inscrit d'avance dans la facon de choisir,
et il ne dit rien sur 2020-2021.

Ce qui reste valable apres correction :

1. **Le niveau hors periode vaut -0.008 R**, c'est-a-dire exactement le niveau
   d'une entree ALEATOIRE sur la meme geometrie (-0.0069). Le portefeuille ne
   vaut donc pas mieux que le hasard des qu'on sort de la periode de choix.
   C'est la meme conclusion que partout ailleurs cette nuit, et elle ne depend
   pas de l'artefact.
2. **La lecon de methode, qui vaut pour tout le projet** : ne JAMAIS selectionner
   sur une variable bornee, et surtout pas a son maximum. Un critere borne
   (ici un rapport objectif/stop) fabrique mecaniquement un faux gagnant. C'est
   la meme famille d'erreur que la moyenne des ratios, corrigee la veille.
3. Les grandeurs MFE/MAE/taux de stop/position d'entree sont identiques dans les
   deux periodes. C'est un fait, mais il porte sur des lignes selectionnees au
   plafond : il ne faut PAS en tirer une histoire de changement de regime.
"""


def main():
    txt = PLANS.read_text(encoding="utf-8")
    deb = txt.index("## 10.1")
    fin = txt.index("## 10.2")
    nouveau = txt[:deb] + NOUVELLE + "\n" + txt[fin:]
    PLANS.write_text(nouveau, encoding="utf-8")
    print("section 10.1 remplacee (%d -> %d caracteres)"
          % (fin - deb, len(NOUVELLE)))


if __name__ == "__main__":
    main()
