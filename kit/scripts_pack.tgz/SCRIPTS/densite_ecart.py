"""densite_ecart : d'ou vient l'ecart de densite entre le modele et l'EA ?

Round 327. Sur le feed cible, a configuration identique : **58 positions reelles en un trimestre**
(soit environ 155 sur huit mois) contre **88 au modele** sur les memes huit mois et les memes 8 paires.
Facteur 1,76. Deux explications possibles, et elles appellent des corrections opposees :

  1. le modele BLOQUE plus que l'EA (sa fonction `bloque` avance de 32 h apres chaque entree) ;
  2. le modele COMPTE moins de signaux bruts (son filtre MOM2 utilise une MOYENNE SIMPLE des TR(14),
     alors que l'EA utilise un lissage de WILDER -- moyenne exponentielle -- et les deux ne donnent
     pas le meme nombre de signaux passes).

On decompose donc, pour les 8 jambes sur le feed cible : signaux bruts, signaux apres blocage 32 h,
et on refait le compte avec un ATR de Wilder pour isoler la part du filtre.
"""
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM

HOLD, RANGE, MOM, SEUIL = 64, 50, 2.0, 0.97
PAIRES = "NZDUSD EURGBP EURCHF GBPCHF AUDCAD NZDJPY AUDUSD CADJPY".split()
SOURCE = os.environ.get("SOURCE", "m1_upcomers")


def signaux(D, wilder):
    c, h, l = D["c"], D["h"], D["l"]
    df = pd.DataFrame({"h": h, "l": l})
    hi = df.h.rolling(RANGE).max().values
    lo = df.l.rolling(RANGE).min().values
    pos = (c - lo) / np.where(hi - lo > 0, hi - lo, np.nan)
    tr = pd.concat([pd.Series(h) - pd.Series(l),
                    (pd.Series(h) - pd.Series(c).shift()).abs(),
                    (pd.Series(l) - pd.Series(c).shift()).abs()], axis=1).max(axis=1)
    a = tr.ewm(alpha=1.0 / 14.0, adjust=False).mean().values if wilder \
        else tr.rolling(14).mean().values
    momok = np.abs(c - np.roll(c, 8)) <= MOM * a
    dehors = ~((D["idx"].hour >= 7) & (D["idx"].hour <= 16))
    base = np.flatnonzero(np.nan_to_num(pos, nan=-9.0) >= SEUIL)
    base = base[(base >= RANGE) & (base < len(c) - HOLD - 3)]
    base = base[np.isfinite(a[base]) & (a[base] > 0)]
    brut = base[dehors[base]]
    avec_mom = brut[momok[brut]]
    return len(brut), len(avec_mom), avec_mom


def bloque(D, sig):
    garde, finb = [], None
    for i in sig:
        t = D["idx"][i + 1]
        if finb is not None and t < finb:
            continue
        garde.append(i)
        finb = t + pd.Timedelta(minutes=30 * HOLD)
    return len(garde)


def main():
    print("densite sur %s | 8 jambes | range %d, seuil %.2f, MOM %.1f" % (SOURCE, RANGE, SEUIL, MOM))
    print("  %-9s %10s %10s %10s %10s" % ("paire", "brut(7-16h)", "+MOM2 SMA", "+MOM2 Wilder",
                                          "bloque 32h"))
    t = [0, 0, 0, 0]
    for p in PAIRES:
        D = NM.charge(p, SOURCE)
        if D is None:
            print("  %-9s corpus absent" % p)
            continue
        brut, sma, sig_sma = signaux(D, False)
        _, wild, _ = signaux(D, True)
        bl = bloque(D, sig_sma)
        t[0] += brut
        t[1] += sma
        t[2] += wild
        t[3] += bl
        print("  %-9s %10d %10d %10d %10d" % (p, brut, sma, wild, bl), flush=True)
    print("  %-9s %10d %10d %10d %10d" % ("TOTAL", t[0], t[1], t[2], t[3]))
    print("\n  lecture : si le compte BLOQUE est proche du brut, l'ecart avec les ordres reels est")
    print("  dans le COMPTAGE DES SIGNAUX (filtre MOM2 ou seuil) ; s'il est tres inferieur, il est")
    print("  dans le BLOCAGE. Rappel : le reel a donne 58 positions en un trimestre, soit environ")
    print("  155 sur huit mois, contre 88 au modele mesure ici.")
    if t[2]:
        print("  rapport +MOM2 Wilder / SMA = %.3f (ecart attribuable a la definition de l'ATR)"
              % (t[2] / t[1] if t[1] else 0))
    return 0


if __name__ == "__main__":
    sys.exit(main())
