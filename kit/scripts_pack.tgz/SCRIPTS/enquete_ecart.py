"""enquete_ecart : ouvre UNE transaction desaccordee et regarde le chemin reel.

Usage : PAIRES=NZDUSD CAS=2025-04-24T22:30 python enquete_ecart.py

Affiche, pour la transaction dont l'instant d'entree JRN est donne :
  - l'entree et la sortie REELLES (prix, heure, duree, profit) ;
  - les 70 barres M30 du corpus a partir de la barre de signal, avec l'ATR, le TP et le SL
    du modele, et pour chaque barre si elle touche l'un ou l'autre ;
  - le verdict du modele et l'ecart de prix d'entree.

C'est l'instrument qui doit nommer la cause d'un desaccord, sans theorie.
"""
import os
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM  # noqa: E402
import apparier_issue as AI  # noqa: E402


def main():
    paire = os.environ.get("PAIRE", "NZDUSD")
    cas = pd.Timestamp(os.environ["CAS"])
    D = NM.charge(paire, "m1_pos")
    idx = D["idx"]
    pos, _ = AI.lit_journal()
    cible = None
    for (sym, fin, pid), p in pos.items():
        if sym == paire and p.get("t_in") == cas:
            cible = p
            break
    if cible is None:
        print("transaction introuvable : %s %s" % (paire, cas))
        return 1
    p = cible
    i = int(idx.searchsorted(cas - pd.Timedelta(minutes=30)))
    if i >= len(idx) or (idx[i] - (cas - pd.Timedelta(minutes=30))).total_seconds() > 60:
        i -= 1
    st = float(D["a"][i])
    sp = D["cout"]
    e = D["o"][i + 1]
    tp, sl = e - (2.0 + sp) * st, e + max(1.0 - sp, 0.1) * st
    print("=== %s %s ===" % (paire, cas))
    print("REEL   entree %s a %.5f (lot %.2f) | sortie %s a %.5f"
          % (p["t_in"], p["p_in"], p.get("lot", 0), p["t_out"], p["p_out"]))
    dur = (p["t_out"] - p["t_in"]).total_seconds() / 3600.0
    print("       profit %.2f | duree %.2f h | deplacement %.5f (%.1f pips si point=0.0001)"
          % (p.get("prof", 0.0), dur, p["p_in"] - p["p_out"], (p["p_in"] - p["p_out"]) / 0.0001))
    print("MODELE barre %d (%s) atr %.6f cout %.4f R" % (i, idx[i], st, sp))
    print("       entree %.5f | TP %.5f (-%.2f atr) | SL %.5f (+%.2f atr)"
          % (e, tp, (e - tp) / st, sl, (sl - e) / st))
    print("       sortie reelle en R (atr corpus) : %+.3f" % ((p["p_in"] - p["p_out"]) / st))
    mm = AI.modele(D, i)
    print("       verdict modele : %s" % (("cible", "stop", "echeance")[mm[0]] if mm else "aucun"))
    print("\n  barres M30 (barre de signal puis 20 suivantes, chemin complet ensuite) :")
    print("   #  temps                o        h        l        c        atr      TP?  SL?")
    for k in range(i, min(i + 71, len(D["o"]))):
        mark_t = "oui" if D["l"][k] <= tp and k > i else ""
        mark_s = "oui" if D["h"][k] >= sl and k > i else ""
        star = " <<< entree" if k == i + 1 else ""
        if k <= i + 21 or mark_t or mark_s:
            print("  %3d %s %8.5f %8.5f %8.5f %8.5f %8.6f  %-4s %-4s%s"
                  % (k - i, idx[k], D["o"][k], D["h"][k], D["l"][k], D["c"][k], D["a"][k],
                     mark_t, mark_s, star))
    return 0


if __name__ == "__main__":
    sys.exit(main())
