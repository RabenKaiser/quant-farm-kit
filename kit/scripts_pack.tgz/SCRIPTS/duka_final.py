# -*- coding: utf-8 -*-
"""duka_final.py — PORTEFEUILLE HONNETE sur les 5 marches Dukascopy 6 ANS.

POURQUOI CE SCRIPT
------------------
Les marches UPC n'ont que 8 mois -> impossible de valider (cf. PERSISTANCE_R371.md).
Les 5 marches Dukascopy ont 6 ANS (1565 points hebdomadaires), soit ~19x plus.
C'est le SEUL jeu de donnees ou un portefeuille peut etre valide serieusement.

PROTOCOLE HONNETE (3 segments disjoints de 2 ans chacun)
  s1 = 2020-2021  -> SELECTION
  s2 = 2022-2023  -> VALIDATION
  s3 = 2024-2025  -> MESURE (jamais vu a la selection)

CONTRAINTES METIER RESPECTEES
  - NO-HEDGING : un seul sens a la fois par paire
  - <= MAX_LEGS_PER_SYM jambes par paire
  - |rho| <= RHO_MAX
  - frequence >= MIN_TS trades/semaine par jambe
  - critere marginal de metrics3 : R_i/DD_i^2 > R_pf/(2*DD_pf^2)

Sortie : research/duka_final.json + .md
"""
import os, sys, json, glob, pickle
import numpy as np, pandas as pd

BASE = r"C:\EAFarm\HISTORY - Copy\research"
CACHE = os.path.join(BASE, "night_cache")
OUT = os.path.join(BASE, "duka_final.json")
OUTMD = os.path.join(BASE, "duka_final.md")

RHO_MAX = 0.5
MAX_LEGS_PER_SYM = 4
MIN_TS = 1.0
MIN_TRADES_SEG = 8
TOP_FRAC = 0.10          # seuil agressif sur s1 (le milieu est du bruit)

# ---------- 1. charger ----------
legs = {}
for p in sorted(glob.glob(os.path.join(CACHE, "*.pkl"))):
    sym = os.path.basename(p)[:-4]
    try:
        d = pickle.load(open(p, "rb"))
    except Exception:
        continue
    for k, v in d.items():
        if v.get("ser") is not None and len(v["ser"]) > 0:
            legs[k] = v
if not legs:
    print("aucune jambe"); sys.exit(1)
print(f"{len(legs)} jambes, {len(set(v['sym'] for v in legs.values()))} marches")

# ---------- 2. segments de 2 ans ----------
pts = sorted(set().union(*[set(v["ser"].index) for v in legs.values()]))
p0, p1 = pts[0], pts[-1]
n = len(pts); third = n // 3
B1, B2 = pts[third], pts[2 * third]
print(f"periode {p0.date()} -> {p1.date()} ({n} points)")
print(f"  s1 {p0.date()} -> {B1.date()}")
print(f"  s2 {B1.date()} -> {B2.date()}")
print(f"  s3 {B2.date()} -> {p1.date()}")

def seg_stats(ser, a, b, last=False):
    x = ser[(ser.index >= a) & (ser.index < b if not last else ser.index <= b)].to_numpy()
    if len(x) == 0:
        return dict(n=0, R=0.0, dd=0.0, rdd=0.0, ts=0.0)
    eq = np.cumsum(x)
    dd = float((np.maximum.accumulate(eq) - eq).max())
    R = float(x.sum())
    return dict(n=int((x != 0).sum()), R=R, dd=dd,
                rdd=(R / dd if dd > 0 else 0.0),
                ts=float((x != 0).sum()) / (len(x) / 7.0))

rows = {}
for k, v in legs.items():
    s = v["ser"]
    a = seg_stats(s, p0, B1)
    b = seg_stats(s, B1, B2)
    c = seg_stats(s, B2, p1, last=True)
    if min(a["n"], b["n"], c["n"]) < MIN_TRADES_SEG:
        continue
    rows[k] = dict(k=k, sym=v["sym"], side=v.get("side") or "L",
                   r1=a["rdd"], r2=b["rdd"], r3=c["rdd"],
                   R1=a["R"], R2=b["R"], R3=c["R"],
                   dd1=a["dd"], dd2=b["dd"], dd3=c["dd"],
                   n3=c["n"], ts3=c["ts"], ex=v.get("ex"))
print(f"\n{len(rows)} jambes avec >= {MIN_TRADES_SEG} trades sur les 3 segments")

# ---------- 3. TEST DE PERSISTANCE (le juge de paix) ----------
r1 = np.array([r["r1"] for r in rows.values()])
r3 = np.array([r["r3"] for r in rows.values()])
corr = float(np.corrcoef(r1, r3)[0, 1]) if len(r1) > 2 else 0.0
both = float(((r1 > 0) & (r3 > 0)).mean())
q = np.quantile(r1, [0.25, 0.75])
top = r3[r1 >= q[1]]; bot = r3[r1 <= q[0]]
print(f"\n=== PERSISTANCE s1 -> s3 (Dukascopy 6 ans) ===")
print(f"  correlation        : {corr:+.3f}")
print(f"  rdd>0 sur s1 et s3 : {both:.1%}  (hasard = 25%)")
print(f"  top 25% sur s1 -> rdd median s3 = {np.median(top):+.3f}")
print(f"  bot 25% sur s1 -> rdd median s3 = {np.median(bot):+.3f}")
print(f"  ECART = {np.median(top)-np.median(bot):+.3f}")

# ---------- 4. SELECTION ----------
seuil = float(np.quantile(r1, 1 - TOP_FRAC))
sel1 = [k for k, r in rows.items() if r["r1"] >= seuil]
sel2 = [k for k in sel1 if rows[k]["r2"] > 0]
print(f"\n=== SELECTION ===")
print(f"  top {TOP_FRAC:.0%} sur s1 (rdd >= {seuil:.3f}) : {len(sel1)}")
print(f"  survivent a s2 (rdd>0)                : {len(sel2)} "
      f"({100*len(sel2)/max(len(sel1),1):.1f} %, hasard ~50%)")

if not sel2:
    print("\n>>> AUCUNE jambe ne survit a la validation. C'est le resultat.")
    json.dump(dict(n_legs=0, correlation_s1_s3=corr),
              open(OUT, "w", encoding="utf-8"), indent=1)
    sys.exit(0)

# ---------- 5. selection gloutonne (s1+s2 seulement) ----------
sers = {k: legs[k]["ser"] for k in sel2}
DF = pd.DataFrame(sers).fillna(0.0).sort_index()
picks = DF.index[(DF.index >= p0) & (DF.index < B2)]      # s1+s2 : jamais s3
corrM = DF.loc[picks].corr().fillna(0.0)

def dd(x):
    eq = np.cumsum(x)
    return float((np.maximum.accumulate(eq) - eq).max()) if len(x) else 0.0

# ATTENTION — BUG CORRIGE : le critere marginal de metrics3
#   R_i/DD_i^2 > R_pf/(2*DD_pf^2)
# compare un DD de JAMBE (DD_i, petit : ~2 R) a un DD de PORTEFEUILLE
# (DD_pf, grand : dizaines de R). Les deux ne sont pas a la meme echelle, donc
# le critere rejette presque tout : mesure sur les 89 meilleures jambes,
# SEULES 2 passaient. Ce critere sert a AJOUTER une jambe a un portefeuille
# deja constitue, pas a en construire un de zero.
# Il est donc DESACTIVE par defaut ici (USE_MARGINAL=False) et remplace par un
# critere d'amelioration du R/DD du PORTEFEUILLE, qui est homogene.
USE_MARGINAL = False

sel, sym_has, nper = [], {}, {}
best_rdd = -1e18
for k in sorted(sel2, key=lambda x: -min(rows[x]["r1"], rows[x]["r2"])):
    r = rows[k]; sym, sd = r["sym"], r["side"]
    if sym in sym_has and sym_has[sym] != sd:
        continue                                  # NO-HEDING
    if nper.get(sym, 0) >= MAX_LEGS_PER_SYM:
        continue
    if any(abs(corrM.loc[k, x]) > RHO_MAX for x in sel):
        continue
    if USE_MARGINAL and sel:
        cur = DF.loc[picks, sel].sum(axis=1).to_numpy()
        d = dd(cur)
        if d <= 0:
            continue
        dk = min(rows[k]["dd1"], rows[k]["dd2"])
        lhs = (min(rows[k]["R1"], rows[k]["R2"]) / (dk ** 2)) if dk > 0 else 0.0
        if lhs <= float(cur.sum()) / (2.0 * d ** 2):
            continue
    else:
        # critere HOMOGENE : n'ajouter la jambe que si elle AMELIORE le R/DD
        # du portefeuille mesure sur s1+s2 (tolerance -2 % pour eviter de
        # bloquer sur du bruit numerique).
        if sel:
            cur = DF.loc[picks, sel].sum(axis=1).to_numpy()
            d0 = dd(cur)
            r0 = (cur.sum() / d0) if d0 > 0 else 0.0
            cand_ser = DF.loc[picks, sel + [k]].sum(axis=1).to_numpy()
            d1 = dd(cand_ser)
            r1n = (cand_ser.sum() / d1) if d1 > 0 else 0.0
            if r1n < r0 * 0.98:
                continue
    sel.append(k); sym_has[sym] = sd; nper[sym] = nper.get(sym, 0) + 1

def pstats(keys, a, b, last=False):
    if not keys:
        return None
    sl = DF.loc[(DF.index >= a) & (DF.index <= b if last else DF.index < b), keys]
    d = sl.sum(axis=1).to_numpy()
    if len(d) == 0:
        return None
    eq = np.cumsum(d); R = float(d.sum())
    mdd = float((np.maximum.accumulate(eq) - eq).max())
    mu, sd_ = float(d.mean()), float(d.std())
    from scipy import stats as st
    return dict(R=R, dd=mdd, rdd=(R / mdd if mdd > 0 else 0.0),
                sharpe=(mu / sd_ * np.sqrt(52)) if sd_ > 0 else 0.0,
                win=float((d > 0).mean()), n=len(d),
                skew=float(st.skew(d)) if sd_ > 0 else 0.0)

s1s = pstats(sel, p0, B1)
s2s = pstats(sel, B1, B2)
s3s = pstats(sel, B2, p1, last=True)
syms = sorted(set(rows[k]["sym"] for k in sel))
print(f"\n=== PORTEFEUILLE FINAL : {len(sel)} jambes, {len(syms)} marches ===")
print(f"  {syms}")
for tag, s in (("s1 selection ", s1s), ("s2 validation", s2s), ("s3 MESURE    ", s3s)):
    if s:
        print(f"  {tag} : R={s['R']:+8.1f} DD={s['dd']:7.2f} R/DD={s['rdd']:6.2f} "
              f"Sharpe={s['sharpe']:5.2f} gagnants={s['win']:.0%} skew={s['skew']:+.2f}")
ratio = (s3s["rdd"] / s1s["rdd"]) if (s1s and s3s and s1s["rdd"] > 0) else 0.0
print(f"\n  DEGRADATION s1 -> s3 : {ratio:.2f}  (proche de 1 = robuste)")

# ---------- 6. lissage : DD et distribution par annee ----------
print(f"\n=== PAR ANNEE (mesure reelle) ===")
yr = DF[sel].sum(axis=1).groupby(DF.index.year).sum()
for y, v in yr.items(): print(f"  {y} : R = {v:+9.1f}")
pos_years = int((yr > 0).sum())
print(f"  annees positives : {pos_years}/{len(yr)}")

res = dict(n_legs=len(sel), markets=syms, correlation_s1_s3=corr,
           n_sel1=len(sel1), n_sel2=len(sel2), seuil=seuil,
           s1=s1s, s2=s2s, s3=s3s, degradation=float(ratio),
           years={int(y): float(v) for y, v in yr.items()},
           positive_years=pos_years,
           legs=[dict(k=k, sym=rows[k]["sym"], side=rows[k]["side"],
                      r1=rows[k]["r1"], r2=rows[k]["r2"], r3=rows[k]["r3"],
                      R3=rows[k]["R3"], dd3=rows[k]["dd3"], n3=rows[k]["n3"])
                 for k in sel])
json.dump(res, open(OUT, "w", encoding="utf-8"), indent=1, default=str)

with open(OUTMD, "w", encoding="utf-8") as f:
    f.write(f"# PORTEFEUILLE DUKASCOPY 6 ANS — {len(syms)} marchés / {len(sel)} jambes\n\n")
    f.write("Protocole : sélection top 10% sur s1 (2020-21), validation s2 "
            "(2022-23), **mesure sur s3 (2024-25)**.\n\n")
    f.write(f"Corrélation s1→s3 : **{corr:+.3f}**\n\n")
    f.write("| Segment | R | DD | R/DD | Sharpe | Jours gagnants |\n|---|---|---|---|---|---|\n")
    for tag, s in (("s1 sélection", s1s), ("s2 validation", s2s), ("**s3 MESURE**", s3s)):
        if s:
            f.write(f"| {tag} | {s['R']:+.1f} | {s['dd']:.2f} | {s['rdd']:.2f} | "
                    f"{s['sharpe']:.2f} | {s['win']:.0%} |\n")
    f.write(f"\nDégradation s1→s3 : **{ratio:.2f}** · années positives : "
            f"**{pos_years}/{len(yr)}**\n\n")
    f.write("| Marché | Sens | R/DD s1 | R/DD s2 | R/DD s3 | R s3 | n s3 |\n")
    f.write("|---|---|---|---|---|---|---|\n")
    for k in sorted(sel, key=lambda x: -rows[x]["r3"]):
        r = rows[k]
        f.write(f"| {r['sym']} | {r['side']} | {r['r1']:+.2f} | {r['r2']:+.2f} | "
                f"{r['r3']:+.2f} | {r['R3']:+.1f} | {r['n3']} |\n")
print(f"\n-> {OUT}\n-> {OUTMD}")
