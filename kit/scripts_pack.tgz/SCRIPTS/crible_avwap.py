"""crible_avwap : la famille du VWAP ANCRE (AVWAP) -- l'ancre au lieu de la session.

Round 497. Le VWAP classique se remet a zero a l'ouverture de la journee : il est aveugle aux positions
overnight, aux swing traders et aux catalyseurs. Un VWAP ANCRE, lui, mesure le cout moyen de la foule
DEPUIS un evenement precis -- un plus bas de capitulation, un plus haut de manie, une bougie d'impulsion.
C'est ce que decrivent les notes fournies, et la lecture en est simple : au-dessus de l'AVWAP d'un plus bas
de panique, les acheteurs venus la sont en profit (confort, pas d'urgence de couper) ; sous l'AVWAP d'un
plus haut de manie, les acheteurs de ce sommet sont en perte (stress, ils defendent ou capitulent).

CE QUI A ETE MESURE AVANT, ET QUI COMPTE ICI. La session a deja rejete la famille VWAP de session
(ecart a la VWAP du jour) : jugee en M15 et M30, elle est redondante avec le declencheur CREST (un sommet de
range EST au-dessus de la VWAP du jour) et perd son edge apres la decote de realite. L'AVWAP pose la meme
question avec une AUTRE ancre -- celle d'un evenement -- donc une autre information. C'est exactement ce qui
justifie de la mesurer.

LES ANCRES SONT DETECTEES AUTOMATIQUEMENT (ZigZag en multiples d'ATR), jamais placees a la main, pour que le
crible soit reproductible : un pivot n'est utilisable qu'APRES sa confirmation (aucune anticipation).

Quatre familles mesurees, sur deux sens :
  BREAK  : franchissement de l'AVWAP de l'ancre opposee (plus haut -> achat = squeeze ; plus bas -> vente) ;
  REJET  : meche au-dela de l'AVWAP et cloture en deca (rejet du niveau) ;
  ELAST  : eloignement de l'AVWAP en ATR -> retour a la moyenne ;
  TENUE  : prix du bon cote de son AVWAP d'ancre (continuation dans le sens de l'ancre).

Env : CORPUS=m1_ext TF_MIN=30 ZIG_ATR=3.0 ATR_N=14 TPRS=6,12 HOLD=64 ELAST_ATR=1.5 PAIRES=...
Sortie : CRIBLE_AVWAP.csv
"""
import csv
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
sys.path.insert(0, str(B / "SCRIPTS"))
import barrieres_m1 as BM  # noqa: E402
import crible_payoff as CP  # noqa: E402
import spread_barrieres as SB  # noqa: E402

CORPUS = os.environ.get("CORPUS", "m1_ext")
SORTIE = B / os.environ.get("SORTIE", "CRIBLE_AVWAP.csv")
TF_MIN = int(os.environ.get("TF_MIN", "30"))
ZIG_ATR = float(os.environ.get("ZIG_ATR", "3.0"))     # amplitude minimale d'un pivot, en ATR
ATR_N = int(os.environ.get("ATR_N", "14"))
TPRS = [float(x) for x in os.environ.get("TPRS", "6,12").split(",")]
HOLD = int(os.environ.get("HOLD", "64"))
ELAST_ATR = float(os.environ.get("ELAST_ATR", "1.5"))
PAIRES = [x for x in os.environ.get("PAIRES", "").split(",") if x]
CLASSE = CP.CLASSE
OFFSETS = CP.OFFSETS


def grille(paire):
    return BM.charge_m30(paire, CORPUS) if TF_MIN == 30 else BM.charge_tf(paire, CORPUS, minutes=TF_MIN)


def atr_serie(M):
    h, l, c = M["h"], M["l"], M["c"]
    tr = np.maximum(h - l, np.maximum(np.abs(h - np.roll(c, 1)), np.abs(l - np.roll(c, 1))))
    return pd.Series(tr).rolling(ATR_N, min_periods=ATR_N).mean().values


def zigzag(M, atr):
    """Pivots ZigZag : (indice, type) avec type +1 = plus haut, -1 = plus bas.

    Causal : un pivot n'est CONFIRME que lorsque le prix s'en est eloigne de ZIG_ATR x ATR, donc on ne
    l'utilise qu'apres -- aucune anticipation. C'est la regle de mesure du projet.
    """
    c = M["c"]
    piv = []
    if len(c) < 50:
        return piv
    # ROUND 497 : premier essai = ZERO pivot. Le suivi d'etat etait faux : avec un sens initial nul, les
    # deux conditions de mise a jour de l'extreme se combattaient et l'amplitude de retour ne depassait
    # jamais le seuil. Voici le ZigZag standard : on part en quete d'un plus haut, on bascule a chaque
    # pivot, et un pivot n'est retenu que lorsque le prix s'en est eloigne de ZIG_ATR x ATR.
    sens, extreme, i_ext = 1, c[0], 0
    for i in range(1, len(c)):
        a = atr[i]
        if not np.isfinite(a) or a <= 0:
            continue
        if sens == 1:
            if c[i] > extreme:
                extreme, i_ext = c[i], i
            elif extreme - c[i] > ZIG_ATR * a:
                piv.append((i_ext, 1, i))
                sens, extreme, i_ext = -1, c[i], i
        else:
            if c[i] < extreme:
                extreme, i_ext = c[i], i
            elif c[i] - extreme > ZIG_ATR * a:
                piv.append((i_ext, -1, i))
                sens, extreme, i_ext = 1, c[i], i
    return piv


def avwap(M, ancre):
    """VWAP ancre : moyenne cumulee du prix typique depuis `ancre` (le corpus n'a pas de volume)."""
    tp = (M["h"] + M["l"] + M["c"]) / 3.0
    cum = np.cumsum(tp[ancre:])
    n = np.arange(1, len(tp) - ancre + 1)
    out = np.full(len(tp), np.nan)
    out[ancre:] = cum / n
    return out


def signaux_avwap(M, atr, famille, sens):
    """Signaux d'une famille AVWAP, dans un sens donne.

    Pour chaque barre, la reference est l'AVWAP du dernier pivot CONFIRME du type voulu (plus bas pour un
    achat, plus haut pour une vente). Le calcul se fait par segments avec des sommes cumulees : O(n) et non
    O(n^2), ce qui compte sur 75 000 barres M30.
    """
    c, h, l = M["c"], M["h"], M["l"]
    piv = zigzag(M, atr)
    if not piv:
        return np.array([], dtype=int)
    tp = (h + l + c) / 3.0
    cs = np.concatenate([[0.0], np.cumsum(tp)])

    def serie_par_ancre(liste):
        """AVWAP pour chaque barre, l'ancre etant le dernier pivot confirme avant elle."""
        out = np.full(len(c), np.nan)
        liste = sorted(liste)
        k = 0
        ancre = None
        for i in range(len(c)):
            while k < len(liste) and liste[k][0] <= i:
                ancre = liste[k][1]
                k += 1
            if ancre is None:
                continue
            n = i - ancre + 1
            if n > 0:
                out[i] = (cs[i + 1] - cs[ancre]) / n
        return out

    liste_L = [(i_conf, i_ext) for (i_ext, typ, i_conf) in piv if typ == -1]
    liste_S = [(i_conf, i_ext) for (i_ext, typ, i_conf) in piv if typ == 1]
    v = serie_par_ancre(liste_L if sens == "L" else liste_S)
    ok = np.isfinite(v)
    if not ok.any():
        return np.array([], dtype=int)
    sig = np.zeros(len(c), dtype=bool)
    if famille == "BREAK":
        sig = ok & (c > v) & (np.roll(ok & (c <= v), 1) if sens == "L" else np.roll(ok & (c >= v), 1))
    elif famille == "REJET":
        sig = (ok & (l <= v) & (c > v)) if sens == "L" else (ok & (h >= v) & (c < v))
    elif famille == "ELAST":
        ecart = (c - v) / np.where(atr > 0, atr, np.nan)
        sig = ok & np.isfinite(ecart) & ((ecart <= -ELAST_ATR) if sens == "L" else (ecart >= ELAST_ATR))
    elif famille == "TENUE":
        sig = (ok & (c > v)) if sens == "L" else (ok & (c < v))
    idx = np.flatnonzero(sig)
    idx = idx[(idx >= ATR_N + 5) & (idx < len(c) - HOLD - 2)]
    garde, dernier_i = [], -10 ** 9
    for i in idx:
        if i - dernier_i >= HOLD:
            garde.append(i)
            dernier_i = i
    return np.array(garde, dtype=int)


def main():
    pairs = PAIRES or sorted(p.name[:-7] for p in (B / CORPUS).glob("*_M1.csv"))
    print("%s : %d paires | trame %d min | ZigZag %.1f ATR | elasticite %.1f ATR | detention %d barres"
          % (CORPUS, len(pairs), TF_MIN, ZIG_ATR, ELAST_ATR, HOLD))
    print("%-10s %-7s %-4s %5s %9s %8s %8s %7s %6s %s" %
          ("paire", "famille", "sens", "n", "R/tx", "sigma", "mu/s2", "gagn%", "annees", "verdict"))
    lignes = []
    for p in pairs:
        M = grille(p)
        if M is None:
            continue
        atr = atr_serie(M)
        cls = "INDICE" if p.endswith(".IDX") else CLASSE.get(p, "FX")
        for famille in ("BREAK", "REJET", "ELAST", "TENUE"):
            for sens in ("S", "L"):
                sig = signaux_avwap(M, atr, famille, sens)
                if len(sig) < 12:
                    continue
                for tpr in TPRS:
                    SB.HOLD = HOLD
                    m = CP.mesure_dir(M, sig, sens, tpr)
                    if m is None or m["sd"] <= 0:
                        continue
                    off = OFFSETS[cls][0 if sens == "S" else 1]
                    att = m["R"] - off
                    theta = max(att, 0.0) ** 2 * m["n"] / m["sd"] ** 2 / 6.0
                    ok = att > 0 and m["n_pos"] >= (2.0 / 3.0) * m["n_an"]
                    lignes.append(dict(paire=p, famille=famille, sens=sens, tpr=tpr, n=m["n"], R=m["R"],
                                       sigma=m["sd"], gagn=m["gagn"], attendu=att, theta=theta,
                                       npos=m["n_pos"], nan=m["n_an"], retenu=ok))
                    if ok:
                        print("%-10s %-7s %-4s %5d %+9.4f %8.2f %8.3f %7.1f %3d/%-2d RETENU"
                              % (p, famille, sens, m["n"], att, m["sd"], m["R"] / m["sd"] ** 2,
                                 m["gagn"], m["n_pos"], m["n_an"]), flush=True)
        del M
    if not lignes:
        print("  aucune mesure")
        return 1
    with SORTIE.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(lignes[0].keys()))
        w.writeheader()
        w.writerows(lignes)
    ret = [x for x in lignes if x["retenu"]]
    print("\n=== %d mesures | %d retenues ===" % (len(lignes), len(ret)))
    print("  %-8s %6s %8s %10s  %s" % ("famille", "couples", "theta", "R/tx moyen", "meilleur R/tx"))
    for famille in ("BREAK", "REJET", "ELAST", "TENUE"):
        g = [x for x in ret if x["famille"] == famille]
        if not g:
            print("  %-8s %6d" % (famille, 0))
            continue
        best = max(g, key=lambda z: z["R"])
        print("  %-8s %6d %8.2f %+10.4f  %s %s %dR : %+.4f (n=%d, %d/%d)"
              % (famille, len(g), sum(x["theta"] for x in g),
                 sum(x["R"] for x in g) / len(g), best["paire"], best["sens"], best["tpr"] / 3,
                 best["R"], best["n"], best["npos"], best["nan"]))
    print("\n  GROS EDGES (R/tx >= 0,30, la cible de l'utilisateur) :")
    for x in sorted([y for y in ret if y["R"] >= 0.30], key=lambda z: -z["R"])[:12]:
        print("    %-10s %-7s %-4s %4.1fR n=%4d R/tx %+.4f annees %d/%d"
              % (x["paire"], x["famille"], x["sens"], x["tpr"] / 3, x["n"], x["R"], x["npos"], x["nan"]))
    print("\n  -> %s" % SORTIE.name)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
