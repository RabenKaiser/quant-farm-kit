# -*- coding: utf-8 -*-
"""diag_mt5_r272.py — Diagnostic de l anomalie MT5:
comment un trade peut-il perdre plus de 1R alors que le SL est cense le limiter ?

Analyse le log du testeur: distribution des P&L par deal, plus grosses pertes,
et verifie la coherence avec le risque theorique (buf * ATR15 * lots).
"""
import sys, re, glob, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import numpy as np

D = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
logs = sorted(glob.glob(os.path.join(D, "*.log")), key=os.path.getmtime, reverse=True)
print("Logs recents:")
for l in logs[:6]:
    print(f"  {os.path.basename(l):42s} {os.path.getsize(l)/1024:9.0f} KB")

# le plus gros = run E (5 ans)
big = max(logs, key=os.path.getsize)
print(f"\n=== Analyse de {os.path.basename(big)} ({os.path.getsize(big)/1024:.0f} KB) ===")

txt = open(big, "r", encoding="utf-16", errors="replace").read()
if len(txt) < 1000:
    txt = open(big, "r", encoding="utf-8", errors="replace").read()
print(f"lignes: {len(txt.splitlines())}")

# lignes de deals
pat = re.compile(
    r"(?P<ts>\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2}).*?"
    r"(?P<sym>XAUUSD).*?"
    r"(?P<typ>buy|sell)\s+(?P<vol>[\d\.]+)\s+"
    r"(?P<price>[\d\.]+)\s+[\d\.]+\s+[\d\.]+\s+"
    r"(?P<profit>-?[\d\.]+)", re.I)

rows = []
for line in txt.splitlines():
    m = pat.search(line)
    if m:
        try:
            rows.append(dict(ts=m.group("ts"), typ=m.group("typ").lower(),
                             vol=float(m.group("vol")), price=float(m.group("price")),
                             profit=float(m.group("profit"))))
        except Exception:
            pass

print(f"deals trouves: {len(rows)}")
if rows:
    prof = np.array([r["profit"] for r in rows])
    nz = prof[prof != 0]
    print(f"\nP&L non nuls: {len(nz)} | total {nz.sum():+.2f}")
    print(f"  min {nz.min():+.2f} | max {nz.max():+.2f} | moyenne {nz.mean():+.2f}")
    print(f"  gains: {(nz>0).sum()} ({(nz>0).mean()*100:.1f}%) | pertes: {(nz<0).sum()}")
    if (nz > 0).any():
        print(f"  gain moyen {nz[nz>0].mean():+.2f} | perte moyenne {nz[nz<0].mean():+.2f}")
        print(f"  ratio gain/perte: {abs(nz[nz>0].mean()/nz[nz<0].mean()):.2f}")
    print(f"\n  10 plus grosses pertes: {sorted(nz)[:10]}")
    print(f"  10 plus gros gains   : {sorted(nz)[-10:]}")

    # le risque theorique etait de ~11.88$ par trade (6*ATR15 a 0.10 lot)
    print("\n  --- pertes > 3x le risque theorique (11.88$) ---")
    big_loss = sorted([p for p in nz if p < -35])
    print(f"  nombre: {len(big_loss)} | total: {sum(big_loss):+.0f}")
    print(f"  {big_loss[:15]}")

    # balance finale
    print(f"\n  balance implicite: 10000 {nz.sum():+.0f} = {10000+nz.sum():.0f}")

# cherche des messages d erreur / margin
print("\n=== Messages notables ===")
for kw in ["margin", "not enough", "invalid stops", "requote", "off quotes",
           "OrderSend", "error", "deleted", "so:"]:
    hits = [l for l in txt.splitlines() if kw.lower() in l.lower()]
    if hits:
        print(f"  '{kw}': {len(hits)} occurrences | ex: {hits[0][:150]}")
print("\nFIN", flush=True)
