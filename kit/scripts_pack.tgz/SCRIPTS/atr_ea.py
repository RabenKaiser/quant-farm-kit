"""QUEL ATR L'EA UTILISE-T-IL VRAIMENT ? (diagnostic de la chaine de mesure)

POURQUOI (26/09, 04 h 15). En comparant la meme regle hors ligne et en ordres reels (bandes de Bollinger
3 sigma sur le Dax), un ecart de taille apparait : mon moteur touche la cible dans 37 % des cas, l'EA dans
23 %. Les deux mesurent la meme regle sur les memes donnees. En regardant les lignes SIG du texte brut, on
voit pourquoi : **l'ATR annonce par l'EA n'est pas celui de la trame de trading**. Sur le Dax au
02/01/2024 10:30, l'EA annonce 21,12 points en M30 alors que l'ATR14 M30 vaut 37,99 ; en M15 il annonce
16,59 a 10:15 alors que l'ATR14 M15 vaut 30,44.

C'est capital pour tout le projet : le stop et la cible de CHAQUE mesure (ferme et juge) sont deduits de cet
ATR (`sl = SLR x atr`, `tp = cible x sl`). Si l'ATR de l'EA vaut la moitie du vrai, alors nos stops sont
deux fois plus serres que ce que nous croyons mesurer -- ce qui expliquerait a la fois les queues de perte
observees partout et l'ecart systematique entre nos cribles hors ligne et les ordres reels.

On releve donc les (heure, atr) annonces par l'EA dans les textes bruts et on les confronte a toutes les
combinaisons (trame, periode) calculees sur les memes donnees, pour trouver celle qui reproduit l'EA.
"""
import re
import sys
import pathlib
from collections import defaultdict

import numpy as np
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import crible_contre_courant as C  # noqa: E402

B = pathlib.Path(r"C:\EAFarm\HISTORY - Copy\research")
# (texte brut, symbole, corpus) : deux campagnes du meme instrument, en M30 et en M15
CAMPAGNES = [("raw_farm_g3_bb3_deu.txt", "DEU.IDX", "m1_ext"),
             ("raw_farm_g3_kelt32_deu.txt", "DEU.IDX", "m1_ext"),
             ("raw_farm_g3_kelt32_xauusd.txt", "XAUUSD", "m1_real")]
TRAMES = {"1min": 1, "5min": 5, "15min": 15, "30min": 30, "60min": 60}


def releve(fichier, sym):
    """(heure d'impression, heure du signal, atr annonce, spread en points) pour chaque ligne SIG."""
    f = B / fichier
    if not f.exists():
        return []
    out = []
    for l in f.read_text(encoding="utf-8", errors="replace").splitlines():
        if "SIG %s " % sym not in l:
            continue
        m = re.search(r"(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s+SIG \S+ \S+ spread_pts=(\d+) atr=([\d.]+)",
                      l)
        if m:
            out.append((m.group(1), float(m.group(3))))
    return out


def atr_series(D, tf, periode):
    df = pd.DataFrame({"t": pd.to_datetime(D["t"], unit="s"), "h": D["h"], "l": D["l"], "c": D["c"]}).set_index("t")
    b = pd.DataFrame({"h": df["h"].resample(tf).max(), "l": df["l"].resample(tf).min(),
                      "c": df["c"].resample(tf).last()}).dropna()
    pc = b["c"].shift(1)
    tr = pd.concat([b["h"] - b["l"], (b["h"] - pc).abs(), (b["l"] - pc).abs()], axis=1).max(axis=1)
    a = tr.ewm(alpha=1.0 / periode, adjust=False).mean()
    return a.shift(1)          # la valeur CONNUE a la cloture de la bougie t est celle de t-1


def main():
    print("=" * 118)
    print("QUEL ATR L'EA ANNONCE-T-IL ? (releve dans les textes bruts contre ATR calcules)")
    print("=" * 118)
    L = ["# QUEL ATR L'EA UTILISE-T-IL ?", "",
         "Relevé des ATR annoncés dans les lignes SIG des textes bruts, confrontés aux ATR calculés sur les",
         "mêmes données M1 (corpus de la ferme). Le rapport `EA / calculé` doit valoir 1,00 pour la bonne",
         "combinaison : toute autre valeur signifie que nos stops ne sont pas ceux que nous croyons.",
         "", "| campagne | trames testées | meilleur rapport EA/calculé | verdict |", "|---|---|---|---|"]
    for fichier, sym, corpus in CAMPAGNES:
        rel = releve(fichier, sym)
        if len(rel) < 20:
            continue
        D = C.prepare(sym, corpus)
        if D is None:
            continue
        res = {}
        for tf, minutes in TRAMES.items():
            ratios = []
            for periode in (7, 14, 28, 50, 100):
                a = atr_series(D, tf, periode)
                idx = pd.to_datetime([r[0] for r in rel], format="%Y.%m.%d %H:%M:%S")
                vals = a.reindex(idx, method="ffill").values
                ok = np.isfinite(vals) & (vals > 0)
                if ok.sum() < 20:
                    continue
                r = np.array([x[1] for x in rel])[ok] / vals[ok]
                ratios.append((float(np.median(r)), periode, int(ok.sum())))
            if ratios:
                ratios.sort(key=lambda z: abs(np.log(z[0])))
                res[tf] = ratios[0]
        # la meilleure trame : celle dont le rapport median est le plus proche de 1
        if not res:
            continue
        best = min(res.items(), key=lambda kv: abs(np.log(kv[1][0])))
        print("\n%s (%s, %d signaux)" % (fichier, sym, len(rel)))
        for tf, (ratio, periode, n) in sorted(res.items(), key=lambda kv: abs(np.log(kv[1][0]))):
            print("   %-6s ATR%d : rapport EA/calcule = %.3f  (n=%d)" % (tf, periode, ratio, n))
        print("   -> l'EA se comporte comme un ATR%d %s (rapport %.2f)"
              % (best[1][1], best[0], best[1][0]))
        L.append("| %s (%s) | %s | **%s ATR%d : ratio %.3f** | %s |"
                 % (fichier, sym,
                    ", ".join("%s %.2f" % (tf, v[0]) for tf, v in sorted(res.items())),
                    best[0], best[1][1], best[1][0],
                    "l'EA sous-estime l'ATR de la trame" if best[1][0] < 0.8 else "cohérent"))
    L.append("\n## Conséquence pour le projet")
    L.append("\nSi l'ATR de l'EA vaut environ la moitié de l'ATR réel de la trame de trading, alors **tous "
             "nos stops mesurés sont deux fois plus serrés que ce que nous croyons** : chaque famille a été "
             "jugée avec un stop sous-dimensionné, et c'est une explication mécanique -- donc réparable -- "
             "des queues de perte observées partout et de l'écart entre nos cribles et les ordres réels.")
    L.append("La correction est simple et se mesure : doubler `SLR` (et la cible avec lui) pour retrouver la "
             "géométrie voulue, puis refaire tourner les familles survivantes.")
    (B / "ATR_EA.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n  rapport ecrit dans ATR_EA.md")


if __name__ == "__main__":
    main()
