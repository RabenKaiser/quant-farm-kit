"""corr_jambes : les jambes du portefeuille sont-elles des paris distincts ?

Round 310. La simulation prop a montre que le drawdown plafonne le portefeuille a 0,20 % de risque
par transaction, et j'ai avance que la cause etait la CORRELATION des trois jambes (EURCHF, EURGBP,
GBPCHF reagissent tous au mouvement du franc et de la livre). Une affirmation de ce genre doit se
chiffrer, sinon c'est une histoire.

On agrege les R par MOIS et par paire (les trois paires ne traitent pas les memes jours, donc le
mois est la maille ou l'on a des points communs), puis on calcule la matrice de correlation et, pour
chaque paire, la part de sa variance expliquee par la moyenne des deux autres. Un portefeuille de
jambes vraiment distinctes doit avoir des correlations faibles ; une correlation proche de 1 signifie
qu'on repete le meme pari en croyant diversifier.
"""
import csv
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
CSV = B / "JAMBES_CRESTM.csv"
OUT = B / "CORRELATION_JAMBES.md"


def main():
    if not CSV.exists():
        print("JAMBES_CRESTM.csv absent")
        return 1
    par_mois = defaultdict(lambda: defaultdict(list))
    with CSV.open(encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            par_mois[r["date"][:7]][r["paire"]].append(float(r["R"]))
    paires = sorted({p for m in par_mois.values() for p in m})
    mois = sorted(par_mois)
    X = np.full((len(mois), len(paires)), np.nan)
    for i, m in enumerate(mois):
        for j, p in enumerate(paires):
            if par_mois[m].get(p):
                X[i, j] = float(np.mean(par_mois[m][p]))
    print("=== CORRELATION MENSUELLE DES JAMBES (%d mois, %d paires) ===" % (len(mois), len(paires)))
    print("  %-9s %s" % ("", "  ".join("%8s" % p for p in paires)))
    for j, p in enumerate(paires):
        ligne = []
        for k in range(len(paires)):
            v = np.ma.corrcoef(np.ma.masked_invalid(X[:, j]), np.ma.masked_invalid(X[:, k]))[0, 1]
            ligne.append("%8.2f" % float(v))
        print("  %-9s %s" % (p, "  ".join(ligne)))
    lignes = ["# CORRELATION DES JAMBES DU PORTEFEUILLE RETENU", "",
              "Correlation des R **mensuels** entre paires (%d mois). Une correlation proche de 1 "
              "signifie que les jambes repetent le meme pari, donc que le drawdown du portefeuille "
              "n'est pas divise par le nombre de jambes." % len(mois), "",
              "| paire | " + " | ".join(paires) + " |", "|---" * (len(paires) + 1) + "|"]
    for j, p in enumerate(paires):
        cells = []
        for k in range(len(paires)):
            v = float(np.ma.corrcoef(np.ma.masked_invalid(X[:, j]),
                                     np.ma.masked_invalid(X[:, k]))[0, 1])
            cells.append("%+.2f" % v)
        lignes.append("| **%s** | %s |" % (p, " | ".join(cells)))
    # correlation moyenne hors diagonale
    hors = [float(np.ma.corrcoef(np.ma.masked_invalid(X[:, j]), np.ma.masked_invalid(X[:, k]))[0, 1])
            for j in range(len(paires)) for k in range(j + 1, len(paires))]
    if hors:
        moy = float(np.mean(hors))
        print("\n  correlation moyenne hors diagonale : %+.2f" % moy)
        print("  lecture : au-dessus de +0,5, les jambes sont un meme pari -- le drawdown du")
        print("  portefeuille ne se divise donc PAS par le nombre de jambes, et c'est ce qui")
        print("  plafonne le risque a 0,20 %% par transaction.")
        lignes += ["", "**Correlation moyenne hors diagonale : %+.2f.**" % moy, "",
                   "Lecture : au-dessus de +0,5, les jambes sont un meme pari ; le drawdown du "
                   "portefeuille ne se divise pas par le nombre de jambes, ce qui plafonne le "
                   "risque par transaction. La voie vers un meilleur rendement a drawdown constant "
                   "est donc d'ajouter des jambes DECORRELEES (indices, metaux, autres complexes "
                   "de devises), pas d'augmenter le risque."]
    OUT.write_text("\n".join(lignes), encoding="utf-8")
    print("\necrit %s" % OUT.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
