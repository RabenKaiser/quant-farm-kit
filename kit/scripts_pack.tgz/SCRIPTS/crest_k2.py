"""crest_k2 : croiser la selection K=2 du tour 6 avec CREST-M (point (c) de l'objectif).

Le tour 6 (`multi_par_paire.py`) tenait son resultat d'un protocole precis : jusqu'a K lignes PAR
PAIRE, toutes de MEME SENS (contrainte anti-couverture), choisies gloutonnement sur la PREMIERE
moitie des fenetres par le critere de STABILITE (fraction de fenetres positives), puis lues sur la
SECONDE moitie sans reoptimiser, avec un controle par portefeuilles tires au hasard. Resultat du
tour 6 : K=2, test moyen +0,0303, pire fenetre -0,0559, 58 % de fenetres positives, R/DD 5,95,
percentile 99,1 face a 300 tirages.

Ce script applique le MEME protocole a un vivier de variantes CREST-M, ce qui n'avait jamais ete
fait : la configuration de reference n'est qu'UNE ligne par paire, donc la question "une deuxieme
ligne de meme sens ameliore-t-elle le portefeuille ?" n'avait pas de pool ou se poser.

Vivier, par paire (18 lignes) :
  - seuil de position dans le range de 50 barres : 0,95 / 0,97 / 0,99 ;
  - filtre de course MOM : |c - c[-8]| <= 1,5 / 2,0 / 2,5 ATR (la reference CREST-M est 2,0) ;
  - sens : vente au sommet (C) et achat au plancher (L), soit les deux camps demandes ;
  - hors 7-16 h (invariant, c'est la definition de CREST-M) ;
  - geometrie de reference : stop 1 ATR, cible 2 R, detention 64 barres M30 (32 h), entree au
    close du signal, premier toucher, egalite = stop, echeance comptee a son prix, cout = spread
    median / ATR median (deja dans D["cout"]).

Protocole identique au tour 6 : selection sur 2020Q1..2022Q4, lecture sur 2023Q1..2025Q4, poids
egal entre les lignes d'une paire puis entre les paires, controle par 300 tirages aleatoires
respectant la contrainte de sens unique par paire.

Aucune direction n'est recalculee : chaque ligne porte son sens, fige.
"""
import os
import random
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
OUT = B / "CREST_K2.md"
HOLD = 64          # barres M30 = 32 h
TPR = 2.0          # cible 2 R
SL = 1.0           # stop 1 ATR
SEUILS = (0.95, 0.97, 0.99)
MOMS = (1.5, 2.0, 2.5)
TIRAGES = 300
KMAX = 2


def quartier(t):
    return "%dQ%d" % (t.year, (t.month - 1) // 3 + 1)


def cle(q):
    return (int(q[:4]), int(q[-1]))


def ligne(D, seuil, mom, sens):
    """R par transaction de chaque signal, et la fenetre (trimestre) de chaque signal.

    DECALE=1 (round 307) : les barrieres sont DECALEES par le spread au lieu d'un cout plat. Une
    vente entre au bid et declenche son TP/SL sur l'ask : la barriere de profit s'eloigne du spread
    et celle de perte se rapproche d'autant, ce qui change la FREQUENCE des touches. Le montant
    encaisse ou perdu ne change pas (on sort exactement au niveau : -1 R si le stop est touche) ;
    seule la sortie a l'echeance paie le spread. Sans ce reglage, le +0,1645 du round 303 etait
    mesure a cout plat, donc non publiable.
    """
    decale = os.environ.get("DECALE") == "1"
    c, h, l, a, o = D["c"], D["h"], D["l"], D["a"], D["o"]
    df = pd.DataFrame({"h": h, "l": l, "c": c})
    hi = df.h.rolling(50).max().values
    lo = df.l.rolling(50).min().values
    pos = (c - lo) / np.where(hi - lo > 0, hi - lo, np.nan)
    atr = a
    momok = np.abs(c - np.roll(c, 8)) <= mom * atr
    hr = D["idx"].hour
    dehors = ~((hr >= 7) & (hr <= 16))
    if sens < 0:
        sig = np.flatnonzero(np.nan_to_num(pos, nan=-9.0) >= seuil)
    else:
        sig = np.flatnonzero(np.nan_to_num(pos, nan=9.0) <= (1.0 - seuil))
    sig = sig[momok[sig] & dehors[sig]]
    sig = sig[(sig >= 50) & (sig < len(c) - HOLD - 2)]
    sig = sig[np.isfinite(atr[sig]) & (atr[sig] > 0)]
    if len(sig) < 60:
        return None
    e, st = c[sig], atr[sig]
    k = D["cout"] if decale else 0.0          # le spread, deja exprime en ATR
    if sens < 0:
        tp, sl = e - (TPR + k) * st, e + max(SL - k, 0.1) * st
    else:
        tp, sl = e + (TPR + k) * st, e - max(SL - k, 0.1) * st
    off = np.arange(1, HOLD + 1)
    Hh, Ll = h[sig[:, None] + off], l[sig[:, None] + off]
    htp = (Ll <= tp[:, None]) if sens < 0 else (Hh >= tp[:, None])
    hsl = (Hh >= sl[:, None]) if sens < 0 else (Ll <= sl[:, None])
    it = np.where(htp.any(1), htp.argmax(1), 10 ** 6)
    isl = np.where(hsl.any(1), hsl.argmax(1), 10 ** 6)
    tph, slh = htp.any(1), hsl.any(1)
    kind = np.where(tph & (~slh | (it < isl)), 0, np.where(slh, 1, 2))
    fin = ((e - c[sig + HOLD]) if sens < 0 else (c[sig + HOLD] - e)) / st
    # -1 R exactement quand le stop est touche (on sort au niveau) ; la sortie a l'echeance paie le
    # spread une fois. A cout plat (DECALE=0), on retranche `cout` comme avant.
    if decale:
        R = np.where(kind == 0, TPR, np.where(kind == 1, -1.0, fin - k))
    else:
        R = np.where(kind == 0, TPR, np.where(kind == 1, -1.0, fin)) - D["cout"]
    R = R[np.isfinite(R)]
    if len(R) < 60:
        return None
    per = defaultdict(list)
    for k, i in enumerate(sig[:len(R)]):
        per[quartier(D["idx"][i])].append(float(R[k]))
    return {q: float(np.mean(v)) for q, v in per.items() if len(v) >= 3}, len(R)


def stat(xs):
    if not xs:
        return dict(moy=0.0, pire=-9.0, pos=0.0, dd=0.0, rdd=0.0)
    v = np.asarray(xs, dtype=float)
    eq = np.cumsum(v)
    dd = float(np.max(np.maximum.accumulate(eq) - eq)) if len(eq) else 0.0
    return dict(moy=float(v.mean()), pire=float(v.min()),
                pos=float(np.mean(v > 0)), dd=dd,
                rdd=(float(v.mean()) / dd) if dd > 1e-9 else 0.0)


def portefeuille(choix, fen):
    """choix : {paire: [lignes]}. Poids egal a chaque paire, puis a chaque ligne."""
    qs = [q for q in fen if all(q in l["per"] for l in choix.values() for l in [choix[paire][0]])]
    out = []
    for q in qs:
        vals = []
        for p, ls in choix.items():
            v = [l["per"][q] for l in ls if q in l["per"]]
            if v:
                vals.append(float(np.mean(v)))
        if vals:
            out.append(float(np.mean(vals)))
    return out


def main():
    random.seed(11)
    print("construction du vivier CREST-M (M30, stop 1 ATR, cible 2 R, 64 barres = 32 h)", flush=True)
    vivier = {}
    for f in sorted((B / "m1_pos").glob("*_M1.csv")):
        p = f.stem.replace("_M1", "")
        D = NM.charge(p, "m1_pos")
        if D is None:
            continue
        ls = []
        for seuil in SEUILS:
            for mom in MOMS:
                for sens in (-1, 1):
                    r = ligne(D, seuil, mom, sens)
                    if r is None:
                        continue
                    per, n = r
                    ls.append(dict(paire=p, sens="C" if sens < 0 else "L", seuil=seuil,
                                   mom=mom, per=per, n=n))
        if ls:
            vivier[p] = ls
        print("  %-9s %2d lignes exploitables" % (p, len(ls)), flush=True)
    if not vivier:
        print("vivier vide")
        return 1
    fen = sorted({q for ls in vivier.values() for l in ls for q in l["per"]}, key=cle)
    coupe = len(fen) // 2
    sel, test = fen[:coupe], fen[coupe:]
    print("\nfenetres %d | selection %s..%s | test %s..%s"
          % (len(fen), sel[0], sel[-1], test[0], test[-1]), flush=True)

    def note(l, fens):
        v = [l["per"][q] for q in fens if q in l["per"]]
        return float(np.mean([1.0 if x > 0 else 0.0 for x in v])) if v else -9.0

    def choix_glouton(paire, k):
        ls = vivier[paire]
        meilleure = max(ls, key=lambda l: note(l, sel))
        bloc = [meilleure]
        meme = [l for l in ls if l["sens"] == meilleure["sens"] and l is not meilleure]
        while len(bloc) < k and meme:
            best, bs = None, -9e9
            for l in meme:
                essai = bloc + [l]
                s = float(np.mean([note(x, sel) for x in essai]))
                if s > bs:
                    bs, best = s, l
            if best is None:
                break
            bloc.append(best)
            meme = [l for l in meme if l is not best]
        return bloc

    def lit(choix, fens):
        qs = [q for q in fens if all(any(q in l["per"] for l in ls) for ls in choix.values())]
        out = []
        for q in qs:
            vals = []
            for p, ls in choix.items():
                v = [l["per"][q] for l in ls if q in l["per"]]
                if v:
                    vals.append(float(np.mean(v)))
            if vals:
                out.append(float(np.mean(vals)))
        return out

    rapport = ["# CREST-M croise avec la selection K=2 du tour 6", "",
               "Protocole du tour 6 : selection gloutonne par fraction de fenetres positives sur "
               "%s..%s, lecture sur %s..%s sans reoptimiser, poids egal entre lignes d'une paire "
               "puis entre paires. Vivier : %d paires, seuils %s, MOM %s, les deux sens."
               % (sel[0], sel[-1], test[0], test[-1], len(vivier),
                  "/".join(str(x) for x in SEUILS), "/".join(str(x) for x in MOMS)), ""]
    resultats = {}
    for k in (1, 2, 3):
        choix = {p: choix_glouton(p, k) for p in vivier}
        tr = lit(choix, test)
        s = stat(tr)
        resultats[k] = s
        n_lignes = np.mean([len(v) for v in choix.values()])
        print("\nK=%d | lignes/paire %.2f | test moy %+.4f | pire %+.4f | fen+ %.0f %% | "
              "DD %.2f | R/DD %.2f"
              % (k, n_lignes, s["moy"], s["pire"], 100 * s["pos"], s["dd"], s["rdd"]), flush=True)
        rapport.append("- K=%d : lignes/paire %.2f | test moy %+.4f | pire %+.4f | fen+ %.0f %% | "
                       "DD %.2f | R/DD %.2f"
                       % (k, n_lignes, s["moy"], s["pire"], 100 * s["pos"], s["dd"], s["rdd"]))

    # controle : portefeuilles tires au hasard, meme contrainte (une seule direction par paire)
    alea = []
    for _ in range(TIRAGES):
        choix = {}
        for p, ls in vivier.items():
            base = random.choice(ls)
            meme = [l for l in ls if l["sens"] == base["sens"]]
            k = min(KMAX, len(meme))
            choix[p] = random.sample(meme, k)
        alea.append(stat(lit(choix, test))["moy"])
    alea = np.array(alea)
    pct = 100.0 * float(np.mean(alea < resultats[2]["moy"]))
    print("\ncontrole %d tirages : mediane %+.4f | pct du K=2 selectionne %.1f"
          % (TIRAGES, float(np.median(alea)), pct), flush=True)
    rapport += ["", "Controle : %d portefeuilles aleatoires (meme contrainte de sens unique), "
                "mediane %+.4f, le K=2 selectionne est au percentile %.1f."
                % (TIRAGES, float(np.median(alea)), pct), ""]

    # ce que contient reellement la selection K=2 : seuil, MOM et sens retenus
    choix = {p: choix_glouton(p, 2) for p in vivier}
    lignes = ["| paire | ligne 1 | ligne 2 |", "|---|---|---|"]
    for p in sorted(choix):
        d = []
        for l in choix[p]:
            d.append("SR%.2f MOM%.1f %s" % (l["seuil"], l["mom"], l["sens"]))
        while len(d) < 2:
            d.append("—")
        lignes.append("| %s | %s | %s |" % (p, d[0], d[1]))
    rapport += ["## Composition du K=2 retenu", ""] + lignes + [""]
    compteur = defaultdict(int)
    for ls in choix.values():
        for l in ls:
            compteur[l["sens"]] += 1
    rapport.append("Repartition des sens : %s" % ", ".join("%s %d" % (k, v)
                                                           for k, v in sorted(compteur.items())))
    OUT.write_text("\n".join(rapport), encoding="utf-8")
    print("ecrit %s" % OUT.name, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
