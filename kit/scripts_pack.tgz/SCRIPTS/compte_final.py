"""compte_final : simulation du compte prop avec directions IMPOSEES (table validee).

Directions prises dans la table verifiee du 21/09 (STRATEGIE_16_COURTES.md) : on ne
recalcule JAMAIS le sens par paire (trois inversions de signe observees).
Formule de sortie : PREMIER TOUCHER, egalite = stop d'abord (jamais la version
"objectif touche quelque part" qui donnait +0,98 R/tx).

Simulation : max 2 positions simultanees (occupation 16 h = 32 barres M30),
stop journalier, drawdown coupe, pas de trading 21h-1h (heure serveur).
"""
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
OUT = B / "compte_final.md"
COURT = ("EURCHF", "GBPCHF", "USDCHF", "EURGBP", "USDCAD", "EURAUD", "GBPUSD",
         "EURCAD", "EURUSD", "EURJPY", "AUDCAD", "NZDCAD", "AUDUSD", "CADJPY",
         "AUDJPY", "NZDUSD")
RISK = float(os.environ.get("RISK", "0.08"))          # % de l'equity par trade
STOP_JOUR = -2.5     # %
DD_COUPE = -5.0      # %
MAXPOS = int(os.environ.get("MAXPOS", "2"))
HOLD = int(os.environ.get("HOLD", "32"))


def trades_pair(p):
    src = os.environ.get("SOURCE", "m1_upcomers")
    f = B / src / ("%s_M1.csv" % p)
    if not f.exists():
        return []
    d = pd.read_csv(f)
    # 256 : le tick est DEDUIT DES DONNEES (min |dclose| > 0) et non du nombre de
    # decimales du fichier : sur le corpus Dukascopy le format donne 5 decimales a
    # toutes les paires, ce qui gonflait le cout des paires JPY d'un facteur 100.
    dcl = d["close"].diff().abs()
    nzcl = dcl[dcl > 0]
    if not len(nzcl):
        return []
    pt = float(nzcl.min())
    s = d["spread"].astype(float)
    nz = s[s > 0]
    d["t"] = pd.to_datetime(d["time"], unit="s")
    d = d.set_index("t")
    b = d.resample("30min").agg(high=("high", "max"), low=("low", "min"),
                                close=("close", "last")).dropna()
    tr = pd.concat([b.high - b.low, (b.high - b.close.shift()).abs(),
                    (b.low - b.close.shift()).abs()], axis=1).max(axis=1)
    atr = tr.rolling(14).mean()
    if len(b) < 2000 or atr.median() <= 0 or not len(nz):
        return []
    cout = (float(nz.median()) * pt) / float(atr.median())
    if cout > 0.2:
        print("  !! %s cout %.4f R > 0.2 : tick probablement mal deduit (pt=%g)" % (p, cout, pt), flush=True)
    c, h, l, a = b.close.values, b.high.values, b.low.values, atr.values
    lo, hi = b.low.rolling(50).min().values, b.high.rolling(50).max().values
    pos = (c - lo) / np.where(hi - lo > 0, hi - lo, np.nan)
    sig = np.flatnonzero(np.nan_to_num(pos) >= 0.90)     # COURT uniquement
    sig = sig[sig < len(b) - HOLD - 2]
    sig = sig[(~np.isnan(a[sig])) & (a[sig] > 0)]
    if len(sig) < 80:
        return []
    e, st = c[sig], a[sig]
    tp, sl = e - st, e + st
    off = np.arange(1, HOLD + 1)
    H = h[sig[:, None] + off]
    L = l[sig[:, None] + off]
    cl = c[sig + HOLD]
    htp = (L <= tp[:, None])
    hsl = (H >= sl[:, None])
    it = np.where(htp.any(1), htp.argmax(1), 10 ** 6)
    isl = np.where(hsl.any(1), hsl.argmax(1), 10 ** 6)
    fin = (e - cl) / st
    # 259 : BUG MAJEUR corrige. `np.where(isl <= it, -1.0, fin)` rendait la branche
    # "echeance" INATTEIGNABLE : quand ni l'objectif ni le stop n'est touche, it et isl
    # valent tous deux 10**6, donc isl <= it est vrai et la transaction etait notee -1 R
    # au lieu de son prix de sortie au marche apres 32 barres. Toutes les mesures Python
    # de la session etaient donc biaisees vers le bas, d'autant plus que la detention
    # etait courte (d'ou l'illusion que "detention longue = meilleur"). Egalite = stop.
    tp_hit, sl_hit = htp.any(1), hsl.any(1)
    kind = np.where(tp_hit & (~sl_hit | (it < isl)), 0, np.where(sl_hit, 1, 2))
    R = np.where(kind == 0, 1.0, np.where(kind == 1, -1.0, fin)) - cout
    ok = ~np.isnan(R)
    return list(zip(b.index[sig][ok], R[ok]))


def main():
    tous = []
    for p in COURT:
        tr = trades_pair(p)
        for t, r in tr:
            tous.append((t, float(r), p))
        print("  %-8s %5d trades" % (p, len(tr)), flush=True)
    tous.sort(key=lambda x: x[0])
    occ = []                       # heures de fin d'occupation
    gardes, rejetes = [], 0
    for t, r, p in tous:
        if t.hour >= 21 or t.hour < 1:            # pas de trading 21h-1h
            rejetes += 1
            continue
        fin = t + pd.Timedelta(hours=HOLD / 2.0)
        occ = [x for x in occ if x > t]
        if len(occ) >= MAXPOS:
            rejetes += 1
            continue
        occ.append(fin)
        gardes.append((t, r))
    par_jour = defaultdict(float)
    for t, r in gardes:
        par_jour[t.date()] += r
    eq = 1.0
    pic = 1.0
    dd_max = 0.0
    mois = defaultdict(lambda: [None, None])
    coupe = False
    for j in sorted(par_jour):
        if coupe:
            break
        # 212 : CORRECTION. RISK est deja en POURCENT (0,5 = 0,5 %) : le /100
        # supplementaire divisait le resultat par 100 et faisait croire a +0,05 %/mois.
        pnl = par_jour[j] * RISK                   # en % de l'equity du jour
        if pnl < STOP_JOUR:
            pnl = STOP_JOUR
        eq *= (1 + pnl / 100.0)
        pic = max(pic, eq)
        dd = (eq / pic - 1) * 100
        dd_max = min(dd_max, dd)
        mois["%04d-%02d" % (j.year, j.month)][1] = eq
        if dd <= DD_COUPE:
            coupe = True
    ret = []
    eq0 = 1.0
    for m in sorted(mois):
        eqf = mois[m][1] or eq0
        ret.append((m, (eqf / eq0 - 1) * 100))
        eq0 = eqf
    gains = [x for _, x in ret]
    lignes = ["# Simulation du compte prop — 16 jambes COURTES imposees (feed Upcomers)", "",
              "Risque %.2f %% par trade | max %d positions | stop journalier %.1f %% | "
              "drawdown coupe a %.1f %% | trading 1h-21h seulement"
              % (RISK, MAXPOS, STOP_JOUR, DD_COUPE), "",
              "| indicateur | valeur |", "|---|---|",
              "| trades generes | %d |" % len(tous),
              "| trades pris (max %d positions) | %d |" % (MAXPOS, len(gardes)),
              "| trades rejetes (occupation/horaire) | %d |" % rejetes,
              "| R/tx moyen des trades pris | %+.4f |" % (np.mean([r for _, r in gardes]) if gardes else 0),
              "| rendement mensuel moyen | %+.2f %% |" % (np.mean(gains) if gains else 0),
              "| mois positifs | %d/%d |" % (sum(1 for x in gains if x > 0), len(gains)),
              "| meilleur / pire mois | %+.2f %% / %+.2f %% |" % (max(gains) if gains else 0, min(gains) if gains else 0),
              "| drawdown max | %.2f %% |" % dd_max,
              "| compte coupe (DD %.1f %%) | %s |" % (DD_COUPE, "OUI" if coupe else "non"),
              "", "## mois par mois", ""]
    for m, x in ret:
        lignes.append("- %s : %+.2f %%" % (m, x))
    OUT.write_text("\n".join(lignes), encoding="utf-8")
    print("\n".join(lignes[:16]), flush=True)
    print("ecrit %s" % OUT, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())




