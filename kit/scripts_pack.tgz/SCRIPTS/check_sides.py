# -*- coding: utf-8 -*-
"""check_sides.py — controle de DIRECTION du meilleur portefeuille.

La cle des unites simples est : SYM|TRIG|FILTRES|SIDE|1sens
La cle des paires est        : SYM|TRIGL+TRIGS|FILTRES
On verifie donc la repartition LONG / SHORT : un portefeuille a 100 % long
n'est pas un portefeuille, c'est un pari directionnel.
"""
import json, os, sys, collections
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
BASE = r"C:\EAFarm\HISTORY - Copy\research"
d = json.load(open(os.path.join(BASE, "NIGHT2_BEST.json"), encoding="utf-8"))
print(f"tour {d['round_no']} | {d['n_units']} unites | CA/mois {d['ca_mois']:.2f} % "
      f"| P90 {d['ca_mois_p90']:.2f} % | Calmar12 {d['calmar12']:.2f}")
cnt = collections.Counter()
print(f"\n{'cle':<10} {'marche':>8} {'sens':>5}  {'R':>7}  cle complete")
for u in sorted(d["units"], key=lambda x: -abs(x["RL"])):
    k = u["key"]
    parts = k.split("|")
    if "paired" in u and u["paired"]:
        side = "PAIRE"
    else:
        side = parts[3] if len(parts) >= 4 else "?"
    cnt[side] += 1
    print(f"  {u['trigL']:<10} {u['sym']:>8} {side:>5}  {u['RL']:>+7.1f}  {k}")
print(f"\nREPARTITION : {dict(cnt)}")
n_long = cnt.get("L", 0)
n_short = cnt.get("S", 0)
tot = n_long + n_short + cnt.get("PAIRE", 0)
if tot:
    print(f"  {n_long} LONG / {n_short} SHORT / {cnt.get('PAIRE',0)} appariees "
          f"-> {100*n_long/tot:.0f} % long")
if n_short == 0 and cnt.get("PAIRE", 0) == 0:
    print("\n  *** ALERTE : portefeuille 100 % LONG = pari directionnel, PAS un ***")
    print("  *** portefeuille. Il faut contraindre l'equilibre des sens.        ***")
