"""corr_reel : les couples valides sont-ils DECORRELES ? Combien de jambes faudrait-il ?

Round 411. Le round 410 a montre que la regle prop n'est pas satisfaite avec 3 jambes : +0,19 %/mois au
mieux, pire annee -2,85 %. Le drawdown depend moins de l'edge moyen que du NOMBRE de jambes et de leur
correlation : pour N jambes independantes de meme mu/sigma2, le drawdown maximal baisse en gros comme
1/sqrt(N). Ce script mesure donc, sur les ordres REELS, la correlation mensuelle des couples valides et
en deduit combien de jambes il faudrait pour ramener le drawdown sous 5 % avec une pire annee positive.

Usage : python SCRIPTS\\corr_reel.py
"""
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import reel_empile as RE  # noqa: E402

COUPLES = [("AUDCAD", "SR97S", 50, "S"),
           ("AUDUSD", "SR97W20S", 20, "S"),
           ("NZDUSD", "SR97W20S", 20, "S")]


def main():
    mois = {}
    for paire, ligne, range_, sens in COUPLES:
        m = RE.mesure(paire, ligne, range_, sens)
        if m is None:
            continue
        d = defaultdict(list)
        for tt, rr in zip(m["times"], m["r"]):
            d[(tt.year, tt.month)].append(rr)
        mois[paire] = {k: float(np.mean(v)) for k, v in d.items()}
        print("  %-8s %3d mois mesures | R/tx %+.4f | mu/sigma2 %.4f"
              % (paire, len(mois[paire]), m["R"], m["R"] / m["sd"] ** 2), flush=True)
    noms = list(mois)
    if len(noms) < 2:
        print("  trop peu de couples")
        return 1
    print("\n  CORRELATION des rendements MENSUELS (ordres reels) :")
    for i in range(len(noms)):
        for j in range(i + 1, len(noms)):
            commun = sorted(set(mois[noms[i]]) & set(mois[noms[j]]))
            if len(commun) < 12:
                print("    %-8s / %-8s : %d mois communs -- insuffisant" % (noms[i], noms[j],
                                                                             len(commun)))
                continue
            a = np.array([mois[noms[i]][k] for k in commun])
            b = np.array([mois[noms[j]][k] for k in commun])
            print("    %-8s / %-8s : rho %+.3f sur %d mois communs" % (noms[i], noms[j],
                                                                       np.corrcoef(a, b)[0, 1],
                                                                       len(commun)))
    # tous les mois, couples alignes : correlation moyenne et gain d'un portefeuille egal-pondere
    commun = sorted(set.intersection(*[set(v) for v in mois.values()]))
    if len(commun) >= 12:
        M = np.array([[mois[n][k] for k in commun] for n in noms])
        print("\n  %d mois ou les %d couples coexistent." % (len(commun), len(noms)))
        print("  correlation moyenne entre couples : %+.3f"
              % np.mean([np.corrcoef(M[i], M[j])[0, 1] for i in range(len(noms))
                         for j in range(i + 1, len(noms))]))
        port = M.mean(axis=0)
        print("  portefeuille egal-pondere : mu mensuel %+.4f R, sigma mensuel %.4f R, mu/sigma2 %.3f"
              % (port.mean(), port.std(ddof=1), port.mean() / port.std(ddof=1) ** 2))
        print("  meilleure jambe seule      : mu mensuel %+.4f R, sigma mensuel %.4f R, mu/sigma2 %.3f"
              % (M[0].mean(), M[0].std(ddof=1), M[0].mean() / M[0].std(ddof=1) ** 2))
        print("\n  lecture : si mu/sigma2 du portefeuille est SUPERIEUR a celui de la meilleure jambe,")
        print("  la decorrelation paie et il faut ajouter des jambes ; sinon, il faut un meilleur edge.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
