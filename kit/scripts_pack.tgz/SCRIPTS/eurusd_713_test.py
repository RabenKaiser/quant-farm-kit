# -*- coding: utf-8 -*-
"""eurusd_713_test.py — re-test EURUSD session 7-13 vs 7-15 (log propre).
Le premier test EURUSD etait corrompu (log 400MB melange). Log archive.
Configs Dc25/R480 M3F6 et M3F4.
"""
import sys, json, time
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from pathlib import Path
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_duka as D

OUT = Path(r"C:\EAFarm\HISTORY - Copy\research\night_results\eurusd_713.jsonl")

CONFIGS = []
for m, f, lad in [(3, 6, 10), (3, 4, 12)]:
    for end in [13, 15]:
        CONFIGS.append({
            "name": f"M{m}F{f}L{lad}_s{end}", "sym": "EURUSD",
            "inputs": {"InpDcDelta": 25, "InpMaxTradesDay": m, "InpFvgMinPts": f,
                       "InpRetestBars": 480, "InpLadderMax": lad,
                       "InpStartHour": 7, "InpEndHour": end},
        })
PERIODS = [
    ("IS-1", "2022.01.01", "2023.01.01"),
    ("IS-2", "2023.01.01", "2024.01.01"),
    ("IS-3", "2024.01.01", "2025.01.01"),
    ("OOS", "2025.01.01", "2026.01.01"),
]

def main():
    total = len(CONFIGS) * len(PERIODS)
    print(f"{len(CONFIGS)} configs × {len(PERIODS)} = {total} runs EURUSD", flush=True)
    done = set()
    if OUT.exists():
        for line in OUT.open(encoding="utf-8"):
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
                done.add((rec["name"], rec["tag"]))
            except Exception:
                continue
    t0 = time.time()
    with open(OUT, "a", encoding="utf-8") as fo:
        for c in CONFIGS:
            for tag, frm, to in PERIODS:
                if (c["name"], tag) in done:
                    continue
                r = D.run_backtest("V45G_EA", c["sym"], "M15", frm, to, 10000,
                                   max_wait=420, inputs=c["inputs"])
                rec = {"name": c["name"], "tag": tag, "inputs": c["inputs"],
                       "result": r}
                fo.write(json.dumps(rec, default=str) + "\n")
                fo.flush()
                if r and not r.get("error"):
                    print(f"  {c['name']:<14} {tag}: {r.get('profit',0):>8.0f}$ "
                          f"n={r.get('trades','?')}", flush=True)
                else:
                    print(f"  {c['name']:<14} {tag}: {r}", flush=True)
    print(f"\nTERMINÉ → {OUT} ({(time.time()-t0)/60:.0f}min)", flush=True)

if __name__ == "__main__":
    main()
