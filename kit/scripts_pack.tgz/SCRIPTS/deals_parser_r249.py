# -*- coding: utf-8 -*-
"""deals_parser_r249.py — parser COMPLET des deals MT5: reconstruit les
trades (entree->sortie) avec P&L reel, y compris les fermetures par l EA.
Utilisable comme alternative a fix_v45g_parse pour l exit extend."""
import re
import sys

DEAL = re.compile(
    r"(\d{4}\.\d{2}\.\d{2} [\d:]+)\s+deal #(\d+) (buy|sell) ([\d.]+) (\S+) at ([\d.]+) done"
)


def parse_trades(path, sym=None):
    """retourne liste de dicts {ts_in, ts_out, dir, vol, px_in, px_out, dp}"""
    events = []
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            m = DEAL.search(line)
            if not m:
                continue
            ts, num, side, vol, s, px = m.groups()
            if sym and sym.upper() not in s.upper():
                continue
            events.append({"ts": ts, "n": int(num), "side": side,
                           "vol": float(vol), "sym": s, "px": float(px)})
    trades = []
    openpos = {}
    for e in events:
        s = e["sym"]
        if s not in openpos:
            openpos[s] = e
        else:
            ent = openpos.pop(s)
            dirn = 1 if ent["side"] == "buy" else -1
            dp = (e["px"] - ent["px"]) * dirn
            trades.append({"ts_in": ent["ts"], "ts_out": e["ts"], "sym": s,
                           "dir": dirn, "vol": ent["vol"],
                           "px_in": ent["px"], "px_out": e["px"], "dp": dp})
    return trades


def stats(trades, point_value=1.0):
    """point_value = $ par point de prix pour 1 lot (approx) ; pour un pf
    directionnel on utilise dp (mouvement en prix) qui est comparable."""
    if not trades:
        return {"n": 0, "w": 0, "l": 0, "pf": 0, "sum": 0.0, "wr": 0}
    wins = [t for t in trades if t["dp"] > 0]
    losses = [t for t in trades if t["dp"] < 0]
    gw = sum(t["dp"] for t in wins)
    gl = -sum(t["dp"] for t in losses)
    return {"n": len(trades), "w": len(wins), "l": len(losses),
            "pf": (gw / gl) if gl > 0 else 99.0,
            "sum": sum(t["dp"] for t in trades),
            "wr": len(wins) / len(trades) * 100}


if __name__ == "__main__":
    import glob, os
    LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
    for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime, reverse=True)[:6]:
        if os.path.getsize(lp) > 5 * 1024 * 1024:
            continue
        for sym in ["XAUUSD", "US500", "USATECH"]:
            tr = parse_trades(lp, sym)
            if len(tr) < 20:
                continue
            st = stats(tr)
            print(f"{os.path.basename(lp)} {sym}: n={st['n']} W={st['w']} "
                  f"L={st['l']} pf_prix={st['pf']:.2f} wr={st['wr']:.1f}%")
