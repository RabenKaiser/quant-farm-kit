# -*- coding: utf-8 -*-
"""chk_vols_all_r43.py — verifier vols reels des runs qui ont genere chaque equity CSV
(EURGBP 15t, GBPUSD-620 24t, EURUSD 15t, SPX/DOW, FRCEUR)."""
import sys, glob, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
TARGETS = [("V3INT", "EURGBP", 15, None),
           ("V3INT", "GBPUSD", 24, None),
           ("V3INT", "EURUSD", 15, None),
           ("V3INT", "DJCUSD", None, None),
           ("V3INT", "SPCUSD", None, None),
           ("V3INT", "FRCEUR", None, None),
           ("V3INT", "GBPJPY", None, None)]

for EA, sym, nt, _ in TARGETS:
    seen = {}
    for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-80:]:
        try:
            runs = F.parse_stream(lp, EA)
        except Exception:
            continue
        for key, data in runs.items():
            if sym not in key:
                continue
            closed = [t for t in data["trades"].values() if t["close"] is not None]
            if nt and len(closed) != nt:
                continue
            if nt is None and len(closed) < 5:
                continue
            vols = sorted({round(t.get("vol", 0), 2) for t in closed})
            k = key.split(" ")[0]
            tag = (sym, len(closed), tuple(vols))
            if tag not in seen:
                seen[tag] = (data.get("balance") or 0, os.path.basename(lp)[:18])
    for (s, n, v), (b, lp) in sorted(seen.items())[:6]:
        print(f"{s:8s} n={n:3d} vols={v} bal={b:8.0f} [{lp}]", flush=True)
print("FIN")
