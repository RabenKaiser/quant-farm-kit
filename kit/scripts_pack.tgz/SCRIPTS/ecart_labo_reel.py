# -*- coding: utf-8 -*-
"""ecart_labo_reel.py — POURQUOI LE LABO DIT +2.5 ET LE REEL DIT -0.10.

LE CONSTAT (16/09, 14 h)
------------------------
Le set TOP8 est le premier set du projet choisi honnetement : critere complet
(L+S >= 2.0 ET chaque sens >= 1.0), tenue sur 5 fenetres sur 7, tenue sur 2020
et 2021. Sa mesure est excellente : L+S de 2.34 a 2.86.

Teste en VRAIS ordres, sur 7 fenetres et 15 paires :
    100 tests | 27 894 trades | -33 318.62 USD | R moyen -0.104
    negatif dans les 7 fenetres, 2 paires positives sur 15.

Donc : l'asymetrie des excursions, mesuree et stable, NE SE TRANSFORME PAS en
argent. Ce n'est pas une question de selection (elle est honnete) ni de
fenetres (elles tiennent). Il y a un ECART entre ce que le labo mesure et ce
que la realite paie.

CE QUE CE SCRIPT MESURE
-----------------------
Le labo enregistre, pour chaque combinaison et chaque fenetre, le R realise
sous 7 reglages de sortie (r_x0 ... r_x6), mesures sur les MEMES signaux. Le
test reel a utilise le reglage x2 (SL = 12 x ATR, TP = 2 x SL). On peut donc
comparer, pour les 48 combinaisons reellement tradees :

    R du labo (r_x2)   contre   R du reel (meme reglage, vrais ordres)

C'est la seule facon de savoir OU l'argent disparait : entre le signal et
l'ordre (execution), ou entre l'ordre et la sortie (reglage).

USAGE : python ecart_labo_reel.py [tag]     (tag par defaut : top8)
"""
import collections
import json
import statistics
import sys
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")


def lignes(nom):
    p = BASE / nom
    if not p.exists():
        return []
    for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if line.startswith("{"):
            try:
                yield json.loads(line)
            except ValueError:
                continue


def main():
    tag = sys.argv[1] if len(sys.argv) > 1 else "top8"

    # --- 1. le set reellement trade -----------------------------------
    setfile = (Path.home() / "AppData/Roaming/MetaQuotes/Terminal/Common/Files"
               / ("%s_set.txt" % tag))
    if not setfile.exists():
        print("set introuvable : %s" % setfile)
        return
    ids = [l.strip() for l in setfile.read_text().splitlines() if "|" in l]
    idset = set(ids)
    print("=" * 100)
    print("ECART LABORATOIRE / REEL — set %s (%d combinaisons)" % (tag, len(ids)))
    print("=" * 100)

    # --- 2. le R du labo (r_x0..r_x6) sur ces combinaisons -------------
    # ROUND 105 (18/09) : on accepte aussi les fenetres ANNUELLES ("2020",
    # "2021"). Pourquoi c'est important : les tests en ordres reels du set TOP8
    # ont tourne sur 2020 et 2021 ENTIERS (3 631 et 4 278 transactions, sur des
    # ticks generes depuis M1 -- le journal du testeur le dit : "real ticks
    # begin from 2023.09.11, every tick generation used"). Le plan VINTAGE
    # mesure ces memes fenetres en ce moment. C'est donc la premiere fois qu'on
    # peut comparer, sur les MEMES combinaisons, les MEMES annees et les MEMES
    # paires, ce que le labo annonce et ce que les ordres reels ont paye.
    LABO_Q = {"2024Q1", "2024Q2", "2024Q3", "2024Q4", "2025Q1",
              "2020", "2021", "2020.01", "2021.01"}
    labo = collections.defaultdict(lambda: collections.defaultdict(list))
    for r in lignes("lab_results.jsonl"):
        if r["id"] not in idset or str(r.get("period", "")) not in LABO_Q:
            continue
        for k in range(7):
            v = r.get("r_x%d" % k)
            if v is not None:
                labo[r["id"]]["x%d" % k].append(v)

    if not labo:
        print("aucune mesure de sortie (r_x*) pour ces combinaisons.")
        print("-> le champ r_x* n'est pas present dans les donnees : voir la")
        print("   grille de sortie du round 80 et la mesure des blocs.")
        return

    print("\n1. LE R DU LABO, par reglage de sortie, sur les combinaisons tradees")
    print("   %-8s %10s %10s %10s" % ("reglage", "R moyen", "R median",
                                      "combinaisons"))
    for k in range(7):
        v = [x for c in labo.values() for x in c.get("x%d" % k, [])]
        if v:
            print("   x%-7d %+10.3f %+10.3f %10d"
                  % (k, statistics.mean(v), statistics.median(v), len(v)))
    print("\n   RAPPEL de la grille : x0/x1 = SL 8 x ATR, x2 = SL 12 x ATR,")
    print("   x3 = SL 12 x ATR TP 1R, x4/x5 = SL structurel (distance a")
    print("   l'extreme), x6 = trailing. Le test reel a tourne en x2.")

    # --- 3. le R du reel -------------------------------------------------
    reel = collections.defaultdict(lambda: [0.0, 0])
    for d in lignes("par_mt5_%s_deals.jsonl" % tag):
        if "pnl" in d and d["id"] in idset:
            e = reel[d["id"]]
            e[0] += d["pnl"]
            e[1] += 1
    if not reel:
        print("\n2. pas de transactions reelles")
        return

    print("\n2. LE R DU REEL, combinaison par combinaison (reglage x2)")
    print("   %-30s %8s %7s %9s %9s %8s"
          % ("combinaison", "labo x2", "trades", "reel USD", "reel R", "ecart"))
    print("   " + "-" * 78)
    ecarts = []
    for cid in sorted(reel, key=lambda c: -reel[c][0]):
        pnl, n = reel[cid]
        # 1R reel : on prend la perte mediane de CETTE combinaison, seule facon
        # de comparer des paires dont la valeur du pip differe.
        p = [x["pnl"] for x in lignes("par_mt5_%s_deals.jsonl" % tag)
             if x.get("id") == cid and x["pnl"] < 0]
        if not p:
            continue
        r1 = -statistics.median(p)
        rreel = pnl / n / r1 if r1 else 0
        v = labo.get(cid, {}).get("x2", [])
        rlabo = statistics.mean(v) if v else None
        ec = (rreel - rlabo) if rlabo is not None else None
        if ec is not None:
            ecarts.append(ec)
        print("   %-30s %8s %7d %+9.2f %+9.3f %8s"
              % (cid, "%+.2f" % rlabo if rlabo is not None else "-", n, pnl,
                 rreel, "%+.3f" % ec if ec is not None else "-"))

    print("\n3. VERDICT")
    if ecarts:
        print("   combinaisons comparees : %d" % len(ecarts))
        print("   ecart median (reel - labo) : %+.3f R" % statistics.median(ecarts))
        print("   ecart moyen                : %+.3f R" % statistics.mean(ecarts))
        neg = sum(1 for e in ecarts if e < 0)
        print("   le reel est PIRE que le labo dans %d cas sur %d (%.0f%%)"
              % (neg, len(ecarts), 100.0 * neg / len(ecarts)))
        print()
        print("   Lecture : si l'ecart est du meme ordre pour TOUTES les")
        print("   combinaisons, ce n'est pas un probleme de signal mais de")
        print("   COUT ou d'EXECUTION (spread, commission, swap, remplissage).")
        print("   S'il est concentre sur quelques-unes, c'est un probleme de")
        print("   reglage de sortie par combinaison.")


if __name__ == "__main__":
    main()
