# -*- coding: utf-8 -*-
"""chk_xau_profit_r43.py — comparer F.pnl_usd vs profit reel (deals du log)
sur le run VWAPTREND n=128 bal=19738."""
import sys, glob, os
import pandas as pd
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"

# re-trouver le run
best = None
for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-80:]:
    try:
        runs = F.parse_stream(lp, "VWAPTREND")
    except Exception:
        continue
    for key, data in runs.items():
        if "XAUUSD" not in key or "H1" not in key:
            continue
        closed = [t for t in data["trades"].values() if t["close"] is not None]
        if len(closed) != 128:
            continue
        b = data.get("balance") or 0.0
        if abs(b - 19738) < 5:
            best = {"trades": closed, "bal": b, "lp": lp, "key": key, "data": data}
            break
    if best:
        break
if not best:
    print("run introuvable")
    sys.exit(1)
print(f"run: {os.path.basename(best['lp'])} | bal={best['bal']:.0f} n={len(best['trades'])}")

# comparer pnl_usd parse vs profit reel dispo
diff = []
reel_sum = 0.0
parse_sum = 0.0
for t in best["trades"]:
    pu = F.pnl_usd(t)
    pf = t.get("profit")
    parse_sum += pu
    if pf is not None:
        reel_sum += pf
        diff.append(pu - pf)
print(f"parse sum = {parse_sum:+.1f} | profit reel sum = {reel_sum:+.1f} "
      f"| n avec profit={len(diff)}")
if diff:
    print(f"diff parse-profit: min {min(diff):+.2f} max {max(diff):+.2f} "
          f"moy {sum(diff)/len(diff):+.3f}")
    # pires divergences
    od = sorted(zip(best["trades"], diff), key=lambda x: -abs(x[1]))[:5]
    for t, d in od:
        print(f"  parse {F.pnl_usd(t):+9.2f} | profit {t.get('profit'):+9.2f} | "
              f"vol {t.get('vol')} | {t.get('side')} {t.get('entry')} -> "
              f"{t.get('close')} [{t.get('ctype')}]")
# extremes journaliers parse (comme le csv) pour confirmer le +3824
rows = []
for t in best["trades"]:
    try:
        rows.append((str(t["ts_entry"])[:10], F.pnl_usd(t)))
    except Exception:
        pass
s = pd.Series([r[1] for r in rows], index=pd.DatetimeIndex([r[0] for r in rows]))
ds = s.groupby(s.index).sum()
print(f"jours n={len(ds)} | min/j {ds.min():+.0f} | max/j {ds.max():+.0f}")
print(ds.sort_values(ascending=False).head(3))
print("FIN")
