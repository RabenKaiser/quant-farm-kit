# -*- coding: utf-8 -*-
"""debug_tiny.py — mini test propagation."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import c13v2_py_v3 as F
import pandas as pd
import numpy as np

m1 = F.load_m1("EURUSD")
start = pd.Timestamp("2024-01-01", tz="UTC")
wu = start - pd.Timedelta(days=260)
m15 = F.resample(m1.loc[wu:start], "15min")
cfg = {"imp_atr": 0.9, "imp_vol": 1.0, "imp_look": 6}
bull, bear = F.detect_ob(m15, cfg, lookahead=False)
print("bull detectes:", len(bull))
if bull:
    items = sorted(bull.items())
    jj0, (dispo, zl, zh) = items[0]
    print("premier:", jj0, "dispo:", dispo, "type dispo:", type(dispo))
    # mini propagation
    curB = None
    for i15 in range(dispo + 2):
        # ajouter les OB avec jj <= i15 et dispo <= i15
        pass
    # direct: est-ce que dispo <= dispo ?
    print("dispo <= dispo:", dispo <= dispo)
    # propagation correcte
    cur = None
    bi = 0
    for i15 in range(50):
        while bi < len(items) and items[bi][0] <= i15:
            jj, (d, z, h2) = items[bi]
            if d <= i15:
                cur = (z, h2, jj)
            bi += 1
    print("cur apres 50:", cur)
