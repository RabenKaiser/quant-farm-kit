"""diag_avwap : ou les signaux AVWAP disparaissent-ils ?

Le premier essai a rendu « aucune mesure » sur cinq instruments : soit le ZigZag ne detecte aucun pivot,
soit les references AVWAP ne sont pas finies, soit les familles ne declenchent rien. On mesure chaque
etage separement plutot que de deviner.

Usage : python SCRIPTS\\diag_avwap.py
"""
import os
import sys
from pathlib import Path

import numpy as np

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
sys.path.insert(0, str(B / "SCRIPTS"))
os.environ.setdefault("CORPUS", "m1_ext")
import crible_avwap as AV  # noqa: E402
import barrieres_m1 as BM  # noqa: E402


def main():
    for p in ("AUS.IDX", "GBR.IDX", "XAUUSD"):
        M = BM.charge_m30(p, AV.CORPUS)
        if M is None:
            print("%s : corpus absent" % p)
            continue
        atr = AV.atr_serie(M)
        piv = AV.zigzag(M, atr)
        hauts = sum(1 for x in piv if x[1] == 1)
        bas = sum(1 for x in piv if x[1] == -1)
        print("%-10s %6d barres | ATR fini %.0f%% | pivots %d (hauts %d, bas %d)"
              % (p, len(M["c"]), 100 * np.mean(np.isfinite(atr)), len(piv), hauts, bas))
        for famille in ("BREAK", "REJET", "ELAST", "TENUE"):
            compte = []
            for sens in ("S", "L"):
                s = AV.signaux_avwap(M, atr, famille, sens)
                compte.append("%s=%d" % (sens, len(s)))
            print("      %-7s %s" % (famille, " ".join(compte)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
