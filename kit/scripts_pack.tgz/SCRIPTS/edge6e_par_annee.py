# -*- coding: utf-8 -*-
"""EDGE_6E par année sur Dukascopy (vrai banc)."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_duka as d

for y0, y1 in [("2024.01.01", "2025.01.01"), ("2025.01.01", "2026.01.01")]:
    r = d.run_backtest("EDGE_6E", "EURUSD", "M30", y0, y1, 10000, max_wait=240)
    if r:
        print(f"{y0[:4]}: profit=${r.get('profit')} trades={r.get('trades')} "
              f"wins={r.get('wins')} losses={r.get('losses')} src={r.get('_source')}")
    else:
        print(f"{y0[:4]}: None")
