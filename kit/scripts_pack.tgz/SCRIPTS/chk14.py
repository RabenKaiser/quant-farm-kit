﻿import os, re
LOGD=r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
pat = re.compile(r"([A-Z]{6}),M1: history cache allocated for \d+ bars and contains (\d+) bars from ([\d.]+) to ([\d.]+)")
seen={}
for f in os.listdir(LOGD):
    if ".log" not in f: continue
    p=os.path.join(LOGD,f)
    if os.path.getsize(p)<300: continue
    raw=open(p,"rb").read(4)
    enc="utf-16" if raw[:2] in (b"\xff\xfe",b"\xfe\xff") else "utf-8"
    try: txt=open(p,encoding=enc,errors="replace").read()
    except Exception: continue
    for m in pat.finditer(txt):
        s=m.group(1)
        if s not in seen or int(m.group(2))>seen[s][0]:
            seen[s]=(int(m.group(2)), m.group(3), m.group(4))
print(f"{'sym':<8}{'bars':>10}  {'debut':>11}  {'fin':>11}")
for s in sorted(seen):
    b,d0,d1=seen[s]
    print(f"{s:<8}{b:>10,}  {d0[:10]:>11}  {d1[:10]:>11}")
