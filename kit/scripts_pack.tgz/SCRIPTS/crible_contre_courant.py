"""ETAGE 1 : CRIBLE D'UNE FAMILLE CONTRE-COURANT SUR LE CORPUS (aucun terminal).

POURQUOI (26/09, 03 h 25). `LARGEUR_JAMBES.md` vient de chiffrer ce qui manque : ajouter une jambe ne
sert que si elle est **decorrelee** et **porteuse**. Le portefeuille valide (Dax + or, correlation +0,04)
plafonne a ~58 % de P(passer) ; pour monter, il faut une famille qui ne soit pas une variante de la
cassure de Keltner. Or toutes les familles testees jusqu'ici sont des familles de **suivi de tendance**
(Keltner 32 h, divergence RSI, SR aux extremes, VWAP, biais H4) : elles se ressemblent.

On crible donc ici la famille opposee : **le retour a la moyenne apres un mouvement violent**. Signal :
le prix a parcouru plus de X ATR en K minutes contre le sens dans lequel on entre. Sortie unique du
projet : premier toucher, egalite = stop, cout pris dans les donnees (`issue()` ajoute le spread reel).

CE QUE CE CRIBLE EST, ET N'EST PAS. C'est l'etage 1 du processus : il sert a **ecarter** des hypotheses
mortes sur 23 instruments en quelques minutes, pas a admettre quoi que ce soit. Le corpus surestime
systematiquement (Hang Seng : +0,449 au corpus contre -0,03 en ordres reels ; divergence : +0,21 contre
-0,23). Ce qui survit ici devra etre mesure sur les ordres reels de la ferme, puis chez le juge.

Choix du corpus : `m1_new` (37 instruments) ne contient que deux a trois mois de 2026 -- cinq a vingt
transactions par instrument, rien de mesurable. `m1_ext` couvre 2020 -> 2026 avec 18 instruments et
`m1_real` en ajoute cinq : c'est ce qu'il faut pour un etage 1.
"""
import sys
import pathlib

import numpy as np
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import barrieres_m1 as BM  # noqa: E402

B = pathlib.Path(r"C:\EAFarm\HISTORY - Copy\research")
SOURCES = ("m1_ext", "m1_real")
# (duree du mouvement en minutes, seuil en ATR). Peu de couples volontairement : chaque couple supplementaire
# multiplie les occasions de trouver du bruit, et ce projet a deja paye pour l'apprendre.
COUPLES = [(60, 2.0), (180, 2.0), (180, 3.0)]
SLR, TPR = 1.5, 3.0        # stop 1,5 ATR, cible 2 R (la geometrie du projet)
HOLD = 1920                # 64 barres M30, comptees en donnee comme l'EA


def charge(sym, source):
    """Chargeur local : les corpus n'ont pas tous le meme format (epoch, ISO, colonne volume absente)."""
    f = B / source / ("%s_M1.csv" % sym)
    if not f.exists():
        return None
    try:
        d = pd.read_csv(f)
    except (OSError, ValueError):
        return None
    col = "time" if "time" in d.columns else d.columns[0]
    t = d[col]
    if t.dtype == object:
        t = pd.to_datetime(t, utc=True, errors="coerce").astype("int64") // 10 ** 9
    t = t.astype("int64").values
    if not {"open", "high", "low", "close", "spread"} <= set(d.columns):
        return None
    dcl = np.abs(np.diff(d["close"].values.astype(float)))
    nz = dcl[dcl > 0]
    if not len(nz):
        return None
    pt = float(np.min(nz))
    return {"paire": sym, "source": source, "pt": pt, "t": t,
            "o": d["open"].values.astype(float), "h": d["high"].values.astype(float),
            "l": d["low"].values.astype(float), "c": d["close"].values.astype(float),
            "spr": d["spread"].values.astype(float) * pt}


def prepare(sym, source):
    """M1 + ATR M30 par minute + close M30 par minute. L'ATR n'est lu que sur des bougies CLOTUREES."""
    D = charge(sym, source)
    if D is None or len(D["t"]) < 5000:
        return None
    df = pd.DataFrame({"t": pd.to_datetime(D["t"], unit="s"), "h": D["h"], "l": D["l"], "c": D["c"]})
    df = df.set_index("t")
    m30 = pd.DataFrame({"h": df["h"].resample("30min").max(),
                        "l": df["l"].resample("30min").min(),
                        "c": df["c"].resample("30min").last()}).dropna()
    pc = m30["c"].shift(1)
    tr = pd.concat([m30["h"] - m30["l"], (m30["h"] - pc).abs(), (m30["l"] - pc).abs()], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1 / 14.0, adjust=False).mean()
    D["atr"] = atr.reindex(df.index, method="ffill").values
    D["c30"] = m30["c"].reindex(df.index, method="ffill").values
    return D


def crible(D, minutes, seuil):
    """Transactions d'une variante, une position a la fois (comme le robot)."""
    t, c, atr = D["t"], D["c30"], D["atr"]
    n = len(t)
    pas = max(1, int(minutes / 30))
    # minutes qui CLOTURENT une bougie M30 : c'est seulement la que le signal est connu
    idx30 = [i for i in range(n) if i % 30 == 29 or (i + 1 < n and t[i + 1] - t[i] > 60)]
    out = []
    bloque = -1
    for k in range(pas, len(idx30)):
        i, j = idx30[k], idx30[k - pas]
        if i <= bloque or not np.isfinite(atr[i]) or atr[i] <= 0 or not np.isfinite(c[j]):
            continue
        move = c[i] - c[j]
        if move <= -seuil * atr[i]:
            sens = "L"
        elif move >= seuil * atr[i]:
            sens = "S"
        else:
            continue
        r = BM.issue(D, int(t[i]), float(c[i]), float(atr[i]), tpr=TPR, slr=SLR,
                     hold_min=HOLD, sens=sens, r_en_risque=True, par_barres=True)
        if r is None:
            continue
        _kind, R, _p, t_sortie = r
        out.append((int(t[i]), R))
        bloque = int(np.searchsorted(t, t_sortie))
    return out


def stats(tx):
    if len(tx) < 30:
        return None
    R = np.array([x[1] for x in tx], dtype=float)
    n = len(R)
    mu = float(R.mean())
    sd = float(R.std(ddof=1)) if n > 1 else 0.0
    return {"n": n, "mu": mu, "t": mu / (sd / np.sqrt(n)) if sd > 0 else 0.0,
            "queue": float((R < -1.5).mean())}


def main():
    couples = sorted({(src, f.stem.replace("_M1", "")) for src in SOURCES for f in (B / src).glob("*_M1.csv")})
    print("=" * 118)
    print("CRIBLE CONTRE-COURANT — corpus %s, %d couples instrument/corpus"
          % (", ".join(SOURCES), len(couples)))
    print("=" * 118)
    L = ["# CRIBLE ETAGE 1 — FAMILLE CONTRE-COURANT (corpus %s)" % ", ".join(SOURCES), "",
         "Signal : mouvement de plus de X ATR en K minutes, on entre CONTRE lui. Sortie unique du projet",
         "(premier toucher, egalite = stop), cout pris dans les donnees. Stop 1,5 ATR, cible 2 R,",
         "detention 64 barres M30, une position a la fois.", "",
         "**Ce crible ecarte, il n'admet pas** : le corpus surestime (cf. Hang Seng et divergence).", ""]
    resultats = {}
    for (minutes, seuil) in COUPLES:
        par_sym = {}
        for src, sym in couples:
            D = prepare(sym, src)
            if D is None:
                continue
            st = stats(crible(D, minutes, seuil))
            if st:
                par_sym["%s (%s)" % (sym, src)] = st
        resultats[(minutes, seuil)] = par_sym
        pos = [s for s, st in par_sym.items() if st["mu"] > 0]
        mus = [par_sym[s]["mu"] for s in pos]
        print("\n%d ATR en %d min : %d instruments mesurables, %d positifs (%.0f %%), mu moyen des "
              "positifs %+.4f" % (seuil, minutes, len(par_sym), len(pos),
                                  100 * len(pos) / max(1, len(par_sym)), float(np.mean(mus)) if mus else 0.0))
        for s in sorted(par_sym, key=lambda k: -par_sym[k]["mu"])[:8]:
            st = par_sym[s]
            print("    %-24s n=%4d  mu %+.4f  t %+.2f  queue %.0f%%"
                  % (s, st["n"], st["mu"], st["t"], 100 * st["queue"]))
        L.append("\n## %d ATR en %d minutes" % (seuil, minutes))
        L.append("\n%d instruments mesurables, **%d positifs (%.0f %%)**, mu moyen des positifs **%+.4f**."
                 % (len(par_sym), len(pos), 100 * len(pos) / max(1, len(par_sym)),
                    float(np.mean(mus)) if mus else 0.0))
        L.append("\n| instrument | n | R/tx | t | queue < -1,5 R |")
        L.append("|---|---|---|---|---|")
        for s in sorted(par_sym, key=lambda k: -par_sym[k]["mu"]):
            st = par_sym[s]
            L.append("| %s | %d | %+.4f | %+.2f | %.0f %% |"
                     % (s, st["n"], st["mu"], st["t"], 100 * st["queue"]))

    L.append("\n## Verdict")
    for (minutes, seuil), par_sym in resultats.items():
        pos = [s for s, st in par_sym.items() if st["mu"] > 0]
        part = len(pos) / max(1, len(par_sym))
        L.append("\n- **%d ATR en %d min** : %.0f %% des instruments positifs%s"
                 % (seuil, minutes, 100 * part,
                    " — assez large pour meriter l'etage 2" if part >= 0.6 else
                    " — trop disperse : la famille n'existe pas, c'est du bruit par instrument"))
    (B / "CRIBLE_CONTRE_COURANT.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n  rapport ecrit dans CRIBLE_CONTRE_COURANT.md")


if __name__ == "__main__":
    main()
