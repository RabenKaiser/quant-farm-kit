# -*- coding: utf-8 -*-
"""barcheck.py — l'EA et le CSV voient-ils les MEMES barres M5 ?

CONTEXTE
  La sonde probe_fvg a mesure, sur 1197 barres communes EURCAD :
    |high_EA - high_PY| max = 0.000000   <-- IDENTIQUES
    |low_EA  - low_PY | max = 0.002890   <-- DIFFERENTS
    ATR : ratio 0.997 (ok)

  Comment high peut etre identique et low different sur les MEMES barres ?
  Reponse possible : le decalage n'est pas le meme pour les deux, OU la sonde
  comparait des barres differentes (mon probe lisait r[i] et r[i+2] alors que
  python donne low a l'indice j-2).

  On refait la comparaison proprement : pour chaque horodatage, on compare
  high ET low, et on regarde si les deux viennent de la meme barre.
"""
import sys
import numpy as np
import pandas as pd

BASE = r"C:\EAFarm\HISTORY - Copy\research"
OUT = (r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal"
       r"\Common\Files\PROBE_FVG.csv")
df = pd.read_csv(OUT)
df.columns = [c.strip() for c in df.columns]
print(f"sonde : {len(df)} lignes")

sys.path.insert(0, BASE + r"\SCRIPTS")
import giga_lib as G
G._cache.clear()
m5 = G.get_frames("EURCAD")["m5"]
h = m5["high"].to_numpy(float); l = m5["low"].to_numpy(float)
ref = pd.DataFrame({"time": m5.index.strftime("%Y.%m.%d %H:%M"), "h": h, "l": l})
mg = df.merge(ref, on="time", how="inner")
print(f"communes : {len(mg)}")

print("\n=== comparaison high1 (doit etre h au meme horodatage) ===")
d = mg["high1"] - mg["h"]
print(f"  ecart max : {np.abs(d).max():.6f}   non nuls : {int((np.abs(d)>1e-9).sum())}")

print("\n=== comparaison low3 : a quel horodatage correspond-il ? ===")
# on teste plusieurs decalages
for sh in (0, 1, 2, 3, -1, -2):
    lref = np.roll(l, sh)
    if sh > 0: lref[:sh] = np.nan
    elif sh < 0: lref[sh:] = np.nan
    ref2 = pd.DataFrame({"time": m5.index.strftime("%Y.%m.%d %H:%M"), "lx": lref})
    m2 = df.merge(ref2, on="time", how="inner")
    e = np.abs(m2["low3"] - m2["lx"])
    print(f"  low3 vs low(j{sh:+d}) : ecart max {np.nanmax(e):.6f}  "
          f"non nuls {int((e>1e-9).sum())}")

print("\n=== conclusion ===")
print("  Si low3 correspond a low(j+2), alors r[i+2] est 2 barres APRES r[i]")
print("  dans un tableau ascendant -> coherent avec r[k] = k barres en arriere.")
print("  L'ecart vient alors de la sonde, pas de l'EA.")
