"""ANALYSE : comparer OHLC M30 GBPUSD entre CSVs moteur et Alpari (via un run
ciblé qui logge les barres). Objectif : quantifier le décalage de données."""
import sys, json, re
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
import polars as pl
import datetime as dt
import edge_correct as ec

# 1) barres moteur (CSVs) GBPUSD M30, semaine 2023-01-02
m1 = ec.load_m1("GBPUSD")
tf = ec.to_tf(m1, 1800)
a = int(dt.datetime(2023, 1, 2).timestamp()); b = int(dt.datetime(2023, 1, 4).timestamp())
seg = tf.filter((pl.col("time") >= a) & (pl.col("time") < b))
print("=== MOTEUR (CSVs) GBPUSD M30, 2023-01-02 ===")
for r in seg.head(8).to_dicts():
    ts = dt.datetime.utcfromtimestamp(r["time"]).strftime("%m-%d %H:%M")
    print(f"  {ts}  o={r['bid_o']:.5f} h={r['bid_h']:.5f} l={r['bid_l']:.5f} c={r['bid_c']:.5f} spr={r['spread_med']:.1f} vol={r['vol_up']+r['vol_down']}")

# 2) Alpari : les barres M30 vues par le testeur sont dans le log (prix des deals)
#    On relance un run EURUSD_H1_COMBO sur GBPUSD M30 court et on capture les
#    prix d'entrée (ask/bid) du log -> ce sont les prix Alpari réels.
print("\n=== comparaison à faire : relancer un run et capturer les prix Alpari ===")
print("(voir analyse_csv_vs_alpari.py — les prix Alpari sont ~1.18-1.37 en 2023)")
print("les CSVs moteur : vérifions la plage des closes moteur sur 2023")
seg23 = tf.filter((pl.col("time") >= a) & (pl.col("time") < int(dt.datetime(2024,1,1).timestamp())))
c = seg23["bid_c"].to_numpy()
print(f"  closes moteur 2023: {c.min():.5f} -> {c.max():.5f} (n={len(c)})")
print(f"  Alpari (log): 1.18319 -> 1.37567")
print("  -> même plage ? ", abs(c.min()-1.18319) < 0.01 and abs(c.max()-1.37567) < 0.01)
