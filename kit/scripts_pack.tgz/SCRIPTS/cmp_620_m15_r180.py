# -*- coding: utf-8 -*-
"""cmp_620_vs_m15c055_r180.py — comparison GBPUSD Upcomers 2026:
H1 c055 sess 6-20 (leg deploy actuel 620) vs M15 c055 sess 6-20.
Objectif: le M15 donne-t-il PLUS de trades / meilleur profil ?"""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_duka as RD

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\cmp_620_m15_r180.jsonl"


def v3(comp, mg):
    return dict(InpLots=0.10, InpRiskPct=0.0, InpMagic=mg, InpMaxDailyLossPct=3.0,
                InpUtcOffset=2, InpSlippage=30, InpStartH=6, InpEndH=20,
                InpCloseHH=20, InpCloseMM=30, InpTpAtr=1.0, InpSlAtr=2.0,
                InpMaxHold=96, InpAtrPct=comp, InpDonPct=comp,
                InpObvMode=0, InpMfiMode=0, InpVerbose=False)


def main():
    mg = 748000
    RUNS = [("GBPUSD-H1-c055-620", "H1", 96),
            ("GBPUSD-M15-c055", "M15", 192)]
    with open(OUT, "a", encoding="utf-8") as fo:
        for tag, tf, maxhold in RUNS:
            mg += 1
            c = v3(0.55, mg)
            c["InpMaxHold"] = maxhold
            print(f"[r180 {tag}] GBPUSD {tf} 2026.01->09 ...", flush=True)
            r = RD.run_backtest("V3INT_EA", symbol="GBPUSD", tf=tf,
                                from_d="2026.01.01", to_d="2026.09.01",
                                deposit=10000, max_wait=2400, inputs=c)
            fo.write(json.dumps({"tag": tag, "tf": tf, "r": r},
                                default=str) + "\n")
            fo.flush()
            print(f"[{tag}] " + ("null" if r is None else
                  f"p={r.get('profit')} n={r.get('trades')} "
                  f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
            time.sleep(2)
    print("FIN r180", flush=True)


if __name__ == "__main__":
    main()
