# -*- coding: utf-8 -*-
"""diag_atr_scale.py — QUANTIFIER bug n56 : l'EA utilise un ATR M15, python un ATR M5.

MESURE (diag_sl.py)
-------------------
  atr_log / atr_M5  = 1.954   <-- l'ATR de l'EA vaut ~2x l'ATR M5
  atr_log / atr_M15 = 0.906   <-- il correspond a un ATR M15
  risk / atr_log    = 2.000   <-- le parametre sl_atr=2 est bien applique

CONSEQUENCE
-----------
Le SL reel de l'EA vaut   2 x atr_M15 ~= 2 x 1.95 x atr_M5 = 3.9 x atr_M5
alors que le backtest python simule  2 x atr_M5.

Le SL de l'EA est donc ~2x PLUS LARGE que simule. Mais le TP l'est aussi
(TP = 3R), donc le RATIO reste 1:3... alors pourquoi seulement 2 TP sur 144 ?

Parce que la duree de detention, elle, ne change pas : hold=48 barres M5 = 4 h.
Un TP place a 3 x 3.9 = 11.7 ATR_M5 est inatteignable en 4 heures.
En python, le TP est a 3 x 2 = 6 ATR_M5, atteignable.

C'EST LA CAUSE DE L'ECART 13 % -> 31 % vs 51 % attendu.

CE SCRIPT MESURE, sur les vraies bougies, la probabilite d'atteindre
  - TP a 6 ATR_M5   (ce que python simule)
  - TP a 11.7 ATR_M5 (ce que l'EA fait vraiment)
  - SL a 4 ATR_M5   (python)  /  SL a 7.8 ATR_M5 (EA)
sur un horizon de 48 barres M5, apres un signal fvg_dn.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
PORT = json.load(open(BASE / "portfolio_v2.json", encoding="utf-8"))


def m5(sym):
    p = BASE / "m1_pos" / f"{sym}_M1.csv"
    if not p.exists():
        return None
    df = pd.read_csv(p, usecols=["time", "open", "high", "low", "close"])
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time").sort_index()
    return pd.DataFrame({
        "open": df["open"].resample("5min").first(),
        "high": df["high"].resample("5min").max(),
        "low": df["low"].resample("5min").min(),
        "close": df["close"].resample("5min").last()}).dropna()


def atr_ewm(h, l, c, n=14):
    pc = np.roll(c, 1); pc[0] = c[0]
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    return pd.Series(tr).ewm(alpha=1/n, adjust=False).mean().to_numpy()


def sim(d, sig, sl_mult, tp_mult, hold):
    """Simule : entree a l'open suivant, SL a sl_mult ATR M5, TP a tp_mult ATR M5."""
    h = d["high"].to_numpy(float); l = d["low"].to_numpy(float)
    o = d["open"].to_numpy(float); c = d["close"].to_numpy(float)
    a = atr_ewm(h, l, c)
    N = len(c)
    idx = np.where(sig)[0]
    out = []; last = -1
    for i in idx:
        if i <= last or i + 2 >= N:
            continue
        e = i + 1
        if not np.isfinite(a[i]) or a[i] <= 0:
            continue
        entry = o[e]
        sl = entry - sl_mult * a[i]
        tp = entry + tp_mult * a[i]
        r = None
        for k in range(e, min(e + hold, N)):
            if l[k] <= sl:
                # BUG CORRIGE (round 59) : un SL coute TOUJOURS -1 R, quelle que
                # soit la largeur du stop. Ecrire `r = -sl_mult` faisait compter
                # -3.9 R pour le stop large de l'EA (au lieu de -1.0), ce qui
                # gonflait artificiellement la colonne "EA" et faisait croire
                # que le stop large etait MEILLEUR. C'etait faux.
                r = -1.0; last = k; break
            if h[k] >= tp:
                r = tp_mult; last = k; break
            if h[k] >= tp:
                r = tp_mult; last = k; break
        if r is None:
            k = min(e + hold - 1, N - 1)
            # residuel exprime en R : (prix - entree) / risque, avec risque =
            # sl_mult * atr (et non l'ATR seul).
            r = (c[k] - entry) / (sl_mult * a[i]); last = k
        out.append(r)
    return np.array(out) if out else np.array([])


print("=" * 92)
print("bug n56 — L'EA UTILISE UN ATR M15, PYTHON UN ATR M5")
print("=" * 92)
print()
print("Sur les vraies bougies M5, apres un signal fvg_dn, quelle est la")
print("probabilite d'atteindre le TP dans les 48 barres ?")
print()
print(f"{'marche':<9}{'n sig':>7}{'PY 6ATR':>10}{'EA 11.7ATR':>12}"
      f"{'PY R':>8}{'EA R':>8}")
print("-" * 92)

tot = {"n": 0, "pyR": 0.0, "eaR": 0.0, "pyw": 0.0, "eaw": 0.0}
for sym in sorted(PORT):
    d = m5(sym)
    if d is None or len(d) < 5000:
        continue
    h = d["high"].to_numpy(float); l = d["low"].to_numpy(float)
    c = d["close"].to_numpy(float)
    a = atr_ewm(h, l, c)
    # signal fvg_dn_10 (le plus frequent du portefeuille)
    sig = h < (np.roll(l, 2) - 1.0 * a)
    sig[:5] = False
    if sig.sum() < 50:
        continue
    # python : SL 2 ATR, TP 3R = 6 ATR
    py = sim(d, sig, 2.0, 6.0, 48)
    # EA : SL 2 x ATR_M15 ~= 3.9 ATR_M5, TP 3R = 11.7 ATR_M5
    ea = sim(d, sig, 3.9, 11.7, 48)
    if len(py) == 0:
        continue
    tw = 100 * (py > 0).mean()
    ew = 100 * (ea > 0).mean() if len(ea) else 0
    print(f"{sym:<9}{int(sig.sum()):>7}{tw:>9.1f}%{ew:>11.1f}%"
          f"{py.sum():>8.0f}{ea.sum() if len(ea) else 0:>8.0f}")
    tot["n"] += 1
    tot["pyR"] += py.sum(); tot["eaR"] += ea.sum() if len(ea) else 0
    tot["pyw"] += tw; tot["eaw"] += ew

print("-" * 92)
if tot["n"]:
    print(f"{'MOYENNE':<9}{'':>7}{tot['pyw']/tot['n']:>9.1f}%"
          f"{tot['eaw']/tot['n']:>11.1f}%{tot['pyR']:>8.0f}{tot['eaR']:>8.0f}")
print()
print("=" * 92)
print("INTERPRETATION")
print("=" * 92)
print("  Colonne 'PY 6ATR'  : ce que le backtest python simule et mesure.")
print("  Colonne 'EA 11.7ATR': ce que l'EA fait REELLEMENT (ATR M15).")
print()
print("  Si la 2e colonne est tres inferieure a la 1re, l'ecart MT5/python")
print("  n'est PAS un probleme de donnees ni de modele : c'est un DECALAGE")
print("  D'UNITE entre le backtest et l'EA. Le corriger alignera les deux.")
