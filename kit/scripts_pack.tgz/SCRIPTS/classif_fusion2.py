# -*- coding: utf-8 -*-
r"""classif_fusion2.py -- CROSS-TAB forecast x VRAIS declencheurs du
reservoir (leçon classif_fusion : le fade synthetique 'grosse bougie' est
un mauvais declencheur, mu -0.65 des deux cotes, separation +0.03 = rien).
On rejoue avec les VRAIS signaux corpus :
  - SR97 vente (vpc_sr97.signaux, le reservoir documente)
  - MONDAYFADE L (Stacey Burke, crible_lundi)
  - KELT fade (retour mediane du canal kelt)
Chacun split forecast HAUT/BAS -> mu par cote -> l'ecart EST le pouvoir du
filtre regime sur un vrai declencheur.
"""
import os
import sys
from collections import defaultdict

import numpy as np
import pandas as pd

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parent))
import nuit_motifs as NM
from classif_m5 import er, adx_like, z_prix, pentes
import classif_m5_v2 as V2
from classif_cause import variables, transitions
from classif_cause2 import score_compose, quantile_table, FEN
from classif_patterns import etat_h4, lettre, H4, MOTIF_LEN, HORIZONS
from classif_fusion import build_forecast, mesure_trigger, zscore, MIN_N

JAMBES = [x.strip() for x in os.environ.get(
    "PAIRES", "EURUSD,GBPUSD,USDCHF,AUDUSD,NZDUSD,EURJPY,XAUUSD").split(",")
    if x.strip()]
HOLD = 64


def sig_sr97(D):
    """Le vrai SR97 : retour sous le bandeau haut VPC (portage corpus)."""
    h, l, c, a = D["h"], D["l"], D["c"], D["a"]
    n = len(c)
    # VWAP-moyenne mobile 20 barres + bandeau (replication vpc_sr97)
    tp = (h + l + c) / 3.0
    vwap = pd.Series(tp).rolling(20).mean().values
    hv = pd.Series(h).rolling(20).max().values
    up = np.maximum(vwap, hv)
    s9 = pd.Series(c).rolling(50).rank(pct=True).values
    # condition SR97 : percentile haut + pierce-return
    cond = (s9 >= 0.97) & (np.roll(c, 2) > np.roll(up, 2)) & (c < up)
    sig = np.flatnonzero(cond & (np.arange(n) > 100) & (np.arange(n) < n - HOLD - 2))
    # une position par paire : espacement hold
    garde, fin = [], -10 ** 9
    for i in sig:
        if i > fin:
            garde.append(i)
            fin = i + HOLD
    return np.array(garde, dtype=int)


def sig_mondayfade(D):
    """Le vrai MONDAYFADE L : range du lundi, fade des sorties hautes les
    autres jours (crible_lundi, 11/12 paires WF-OK)."""
    h, l, c, a = D["h"], D["l"], D["c"], D["a"]
    n = len(c)
    dts = D["idx"]
    jours = pd.Series(dts).dt.dayofweek.values
    dates = pd.Series(dts).dt.date.values
    # range du lundi = max/min des bougies du lundi de la SEMAINE en cours
    hi = np.full(n, np.nan)
    lo = np.full(n, np.nan)
    cur_week = None
    lundi_max, lundi_min = np.nan, np.nan
    for i in range(n):
        j = jours[i]
        w = dates[i] - pd.Timedelta(days=int(j))
        if w != cur_week:
            cur_week = w
            lundi_max, lundi_min = np.nan, np.nan
        if j == 0:
            lundi_max = np.nanmax([lundi_max, h[i]])
            lundi_min = np.nanmin([lundi_min, l[i]])
            hi[i], lo[i] = lundi_max, lundi_min
        else:
            hi[i], lo[i] = lundi_max, lundi_min
    sig = []
    fin = -10 ** 9
    for i in range(100, n - HOLD - 2):
        if jours[i] == 0 or not np.isfinite(hi[i]) or not np.isfinite(lo[i]):
            continue
        if h[i] > hi[i] and c[i] < h[i]:   # sortie haute du range lundi
            if i > fin:
                sig.append(i)
                fin = i + HOLD
    return np.array(sig, dtype=int)


def sig_kelt(D):
    """KELT fade : retour mediane du canal kelt 20/2ATR."""
    h, l, c, a = D["h"], D["l"], D["c"], D["a"]
    n = len(c)
    ema = pd.Series(c).ewm(span=20).mean().values
    up = ema + 2.0 * a
    dn = ema - 2.0 * a
    cond = (np.roll(c, 1) > np.roll(up, 1)) & (c < up)  # retour depuis le haut
    sig = np.flatnonzero(cond & (np.arange(n) > 100) & (np.arange(n) < n - HOLD - 2))
    garde, fin = [], -10 ** 9
    for i in sig:
        if i > fin:
            garde.append(i)
            fin = i + HOLD
    return np.array(garde, dtype=int)


def main():
    print("CROSS-TAB forecast x VRAIS declencheurs (SR97, MONDAYFADE, KELT)")
    # tables train (comme fusion)
    table_motif = {}
    sys_path = str(_Path(__file__).resolve().parent)
    os.chdir(sys_path + "/..")
    table_motif, bases = load_motifs(JAMBES)
    ref = load_refs(JAMBES)
    res = defaultdict(lambda: [[], []])
    for p in JAMBES:
        if p not in ref:
            continue
        got = build_forecast(p, ref[p], table_motif, bases)
        if got is None:
            continue
        D, lab, vv, zf, pR, pE = got
        # le filtre : forecast haut = le regime reste range (fade OK)
        med = np.nanmedian(zf[np.isfinite(zf)])
        haut = np.nan_to_num(zf) >= med
        for nom, fn in (("SR97", sig_sr97), ("MONDAYFADE", sig_mondayfade),
                        ("KELT", sig_kelt)):
            s = fn(D)
            if len(s) < 40:
                continue
            _, R = mesure_trigger(D, s)
            h = haut[s]
            if 20 < h.sum() < len(R):
                res[nom][0].extend(R[h])
                res[nom][1].extend(R[~h])
                print("  %-8s %-10s n=%4d haut mu=%+.3f (n=%3d) bas mu=%+.3f "
                      "(n=%3d) ecart %+.3f"
                      % (p, nom, len(R), np.mean(R[h]), int(h.sum()),
                         np.mean(R[~h]), int((~h).sum()),
                         np.mean(R[h]) - np.mean(R[~h])))
    print("\n=== VERDICT GLOBAL (train+valid corpus, forecast filtre) ===")
    for nom, (a, b) in res.items():
        if len(a) >= 60 and len(b) >= 60:
            print("  %-10s HAUT %+.3f (n=%d) vs BAS %+.3f (n=%d) ecart %+.3f"
                  % (nom, np.mean(a), len(a), np.mean(b), len(b),
                     np.mean(a) - np.mean(b)))


def load_motifs(jambes):
    from collections import defaultdict, Counter
    table = defaultdict(Counter)
    glob = Counter()
    for p in jambes:
        D = NM.charge(p, "m1_pos")
        if D is None:
            continue
        lab, _ = V2.etats(D)
        n = (len(lab) // H4) * H4
        seq = etat_h4(lab)
        dts = np.asarray(D["idx"])[:n].reshape(-1, H4)[:, -1]
        for i in range(MOTIF_LEN, len(seq) - max(HORIZONS) // H4):
            if pd.Timestamp(dts[i]).year > 2023:
                continue
            motif = "".join(lettre(x) for x in seq[i - MOTIF_LEN:i])
            table[motif + "|16"][seq[i + HORIZONS[1] // H4]] += 1
            glob[lettre(seq[i + HORIZONS[1] // H4])] += 1
    tg = sum(glob.values())
    bases = {k: v / tg for k, v in glob.items()} if tg else \
        {"R": 0.73, "E": 0.15, "C": 0.07, "T": 0.04}
    return table, bases


def load_refs(jambes):
    ref = {}
    for p in jambes:
        D = NM.charge(p, "m1_pos")
        if D is None:
            continue
        lab, _ = V2.etats(D)
        vv = variables(D)
        trans = transitions(lab)
        pos_all = np.zeros(len(lab), dtype=bool)
        for (i, A, B) in trans:
            pos_all[max(0, i - FEN):i] = True
        tables = {}
        for nom, x in vv.items():
            t = quantile_table(x, pos_all)
            if t is None:
                continue
            edges = np.quantile(x[~np.isnan(x)], np.linspace(0, 1, 6))
            tables[nom] = (edges, np.array([z[2] for z in t]))
        ref[p] = tables
    return ref


if __name__ == "__main__":
    main()