import collections, json, os, sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
B = r"C:\EAFarm\HISTORY - Copy\research"
ATR = 2.77
TESTS = [("prop_clean_s2_t12", 2), ("brkasia_s4_t12", 4)]


def mensuel(tag, sl):
    f = os.path.join(B, "par_farm_%s_deals.jsonl" % tag)
    if not os.path.exists(f):
        return None
    un_r = sl * ATR
    m = collections.defaultdict(float)
    for line in open(f, encoding="utf-8", errors="replace"):
        if not line.strip().startswith("{"):
            continue
        d = json.loads(line)
        j = str(d.get("day") or "")
        p = d.get("pnl")
        if len(j) >= 7 and isinstance(p, (int, float)):
            m[j[:7]] += float(p) / un_r
    return dict(m) if m else None


def rdd(s):
    cum = dd = sommet = 0.0
    for k in sorted(s):
        cum += s[k]
        sommet = max(sommet, cum)
        dd = min(dd, cum - sommet)
    return cum, dd, (cum / abs(dd) if dd else 99.0)


series = {}
for tag, sl in TESTS:
    s = mensuel(tag, sl)
    if s:
        series[tag] = s
        print("%-22s %2d mois | %d fenetres" % (tag, len(s), len(s)))
if len(series) < 2:
    print("pas assez de series")
    sys.exit(0)

a, b = [series[t] for t, _ in TESTS]
communs = sorted(set(a) & set(b))
print("\nmois communs : %d (%s .. %s)" % (len(communs), communs[0], communs[-1]))
for tag, s in series.items():
    sub = {k: s[k] for k in communs}
    c, d, r = rdd(sub)
    print("   %-22s R cumule %+8.1f | DD %8.1f | R/DD %6.2f" % (tag, c, d, r))
comb = {k: a[k] + b[k] for k in communs}
c, d, r = rdd(comb)
print("   %-22s R cumule %+8.1f | DD %8.1f | R/DD %6.2f" % ("COMBINAISON", c, d, r))
# correlation mensuelle
va = [a[k] for k in communs]
vb = [b[k] for k in communs]
ma = sum(va) / len(va); mb = sum(vb) / len(vb)
num = sum((x - ma) * (y - mb) for x, y in zip(va, vb))
da = sum((x - ma) ** 2 for x in va) ** 0.5
db = sum((y - mb) ** 2 for y in vb) ** 0.5
cor = num / (da * db) if da and db else 0.0
print("\nCORRELATION MENSUELLE : %+.3f" % cor)
pos = sum(1 for k in communs if comb[k] > 0)
print("mois positifs de la combinaison : %d / %d" % (pos, len(communs)))
print()
print("   lecture : correlation basse ou negative + R/DD de la combinaison")
print("   superieur au meilleur des deux = la diversification fait le travail.")
print("   detail mensuel de la combinaison :")
for k in communs:
    print("      %s  A %+7.1f  B %+7.1f  somme %+7.1f" % (k, a[k], b[k], comb[k]))
