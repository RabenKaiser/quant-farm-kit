﻿import MetaTrader5 as mt5
mt5.initialize(path=r"C:\EAFarm\MT5\Farm\terminal64.exe")
ti = mt5.terminal_info()
print("connecte  :", ti.connected if ti else "?")
print("trade allowed :", ti.trade_allowed if ti else "?")
ai = mt5.account_info()
if ai: print(f"compte {ai.login} | serveur {ai.server} | balance {ai.balance}")
# les barres M1 disponibles, par annee, pour quelques symboles
from datetime import datetime
import numpy as np
print()
print("=== M1 disponible par ANNEE (via copy_rates_range) ===")
for s in ("GBPUSD","EURUSD","AUDNZD","XAGUSD","EURJPY"):
    tot = 0; years = []
    for y in (2019,2020,2021,2022,2023,2024,2025,2026):
        r = mt5.copy_rates_range(s, mt5.TIMEFRAME_M1,
                                 datetime(y,1,1), datetime(y,12,31))
        n = 0 if r is None else len(r)
        tot += n
        if n: years.append(f"{y}:{n}")
    print(f"  {s:<8} total={tot:<9} {years if years else 'AUCUNE'}")
mt5.shutdown()
