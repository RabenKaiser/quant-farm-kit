# -*- coding: utf-8 -*-
"""ab_mgmt_r149.py — A/B gestion position: V3INT_EA (mode 0 fixe SL2/TP1)
vs V3INTT_EA modes 1 (breakeven) / 2 (trailing SL) / 3 (BE+trail).
EURUSD + GBPJPY, Dukascopy 2017-2024, configs comp055 sess 8-17 (durables)."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\ab_mgmt_r149.jsonl"


def base(comp, mg):
    return dict(InpLots=0.10, InpMagic=mg, InpMaxDailyLossPct=3.0, InpUtcOffset=2,
                InpSlippage=30, InpStartH=8, InpEndH=17, InpCloseHH=20, InpCloseMM=30,
                InpTpAtr=1.0, InpSlAtr=2.0, InpMaxHold=96, InpAtrPct=comp,
                InpDonPct=comp, InpObvMode=0, InpMfiMode=0, InpVerbose=False)


def main():
    mg = 729000
    RUNS = []
    for sym, comp in [("EURUSD", 0.55), ("GBPJPY", 0.55)]:
        RUNS.append((f"{sym}-MODE0-FIXE", "V3INT_EA", sym,
                     dict(base(comp, mg := mg + 1))))
        for mode, tag in [(1, "BE"), (2, "TRAIL"), (3, "BE+TRAIL")]:
            c = base(comp, mg := mg + 1)
            c.update(InpMgmtMode=mode, InpBeAtr=1.0, InpTrailAtr=1.0)
            RUNS.append((f"{sym}-MODE{mode}-{tag}", "V3INTT_EA", sym, c))
    with open(OUT, "a", encoding="utf-8") as fo:
        for tag, ea, sym, c in RUNS:
            print(f"[r149 {tag}] {ea} {sym} 2017->2024 ...", flush=True)
            r = RF.run_backtest(ea, symbol=sym, tf="H1",
                                from_d="2017.01.01", to_d="2024.01.01",
                                deposit=10000, max_wait=3600, inputs=c)
            fo.write(json.dumps({"tag": tag, "ea": ea, "sym": sym,
                                 "mode": c.get("InpMgmtMode", 0), "r": r},
                                default=str) + "\n")
            fo.flush()
            print(f"[{tag}] " + ("null" if r is None else
                  f"p={r.get('profit')} n={r.get('trades')} "
                  f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
            time.sleep(2)
    print("FIN r149", flush=True)


if __name__ == "__main__":
    main()
