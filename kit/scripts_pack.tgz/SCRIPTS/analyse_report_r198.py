# -*- coding: utf-8 -*-
"""analyse_report_r198.py — lire ReportHistory-1416865.xlsx (historique du
compte challenge) et identifier le probleme."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import openpyxl

P = r"C:\EAFarm\SHARED\ReportHistory-1416865.xlsx"
wb = openpyxl.load_workbook(P, data_only=True)
print("feuilles:", wb.sheetnames)
for sn in wb.sheetnames:
    ws = wb[sn]
    print(f"\n=== {sn} ({ws.max_row} rows x {ws.max_column} cols) ===")
    # header
    hdr = [c.value for c in ws[1]]
    print("header:", hdr)
    for row in ws.iter_rows(min_row=2, max_row=min(6, ws.max_row)):
        vals = [c.value for c in row]
        print("  ", vals)
