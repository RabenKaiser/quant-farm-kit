"""compte_prop : composition finale + simulation du compte jour par jour (feed Upcomers).

14 paires retenues sur les mesures du round 197. Pour chaque paire on mesure les
DEUX sens (SR n=50 haut -> court, bas -> long), on garde le meilleur en imposant
au moins 4 jambes LONGUES et 4 COURTES. Puis on simule le compte :
  - risque R% par trade, stop journalier -2,5 %, drawdown total coupe a -5 %
  - pas de trading 21h-1h UTC
Sortie : rendement mensuel, moyenne, drawdown max, mois positifs, et la cible
5-8 %/mois est-elle atteinte.
"""
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
OUT = B / "compte_prop.md"
PAIRES = ("EURUSD", "GBPUSD", "AUDUSD", "NZDUSD", "USDCAD", "USDCHF", "EURGBP",
          "EURJPY", "CADJPY", "AUDJPY", "EURCHF", "EURAUD", "EURCAD", "AUDCAD",
          "NZDCAD", "GBPCHF")
RISK = 1.5          # % par trade
STOP_JOUR = -2.5    # % stop journalier
DD_MAX = -5.0       # % drawdown total coupe
HOLD = 32


def mesure(p):
    f = B / "m1_upcomers" / ("%s_M1.csv" % p)
    if not f.exists():
        return None
    d = pd.read_csv(f)
    dec = d["close"].astype(str).str.split(".").str[-1].str.len().max()
    pt = 10.0 ** (-dec)
    s = d["spread"].astype(float)
    nz = s[s > 0]
    d["t"] = pd.to_datetime(d["time"], unit="s")
    d = d.set_index("t")
    b = d.resample("30min").agg(high=("high", "max"), low=("low", "min"),
                                close=("close", "last")).dropna()
    tr = pd.concat([b.high - b.low, (b.high - b.close.shift()).abs(),
                    (b.low - b.close.shift()).abs()], axis=1).max(axis=1)
    atr = tr.rolling(14).mean()
    if len(b) < 2000 or atr.median() <= 0 or not len(nz):
        return None
    cout = (float(nz.median()) * pt) / float(atr.median())
    c, h, l, a = b.close.values, b.high.values, b.low.values, atr.values
    lo, hi = b.low.rolling(50).min(), b.high.rolling(50).max()
    pos = ((b.close - lo) / (hi - lo)).values
    out = {}
    for sens in (-1, 1):
        sig = np.flatnonzero(np.nan_to_num(pos) >= 0.90) if sens < 0 else \
            np.flatnonzero(np.nan_to_num(pos) <= 0.10)
        sig = sig[sig < len(b) - HOLD - 2]
        sig = sig[(~np.isnan(a[sig])) & (a[sig] > 0)]   # ATR non defini au debut de serie
        if len(sig) < 80:
            continue
        e, st = c[sig], a[sig]
        tp, sl = (e - st, e + st) if sens < 0 else (e + st, e - st)
        off = np.arange(1, HOLD + 1)
        H = h[sig[:, None] + off].max(axis=1)
        L = l[sig[:, None] + off].min(axis=1)
        # 204 : PREMIER TOUCHER (la version abregee "objectif touche quelque part"
        # etait optimiste et faussait tout : meme correction que portefeuille_large).
        htp = (L <= tp[:, None]) if sens < 0 else (H >= tp[:, None])
        hsl = (H >= sl[:, None]) if sens < 0 else (L <= sl[:, None])
        it = np.where(htp.any(1), htp.argmax(1), 10 ** 6)
        isl = np.where(hsl.any(1), hsl.argmax(1), 10 ** 6)
        cl = c[sig + HOLD]
        fin = (e - cl) / st if sens < 0 else (cl - e) / st
        R = np.where(it < isl, 1.0, np.where(isl <= it, -1.0, fin)) - cout
        ok = ~np.isnan(R)
        R, T2 = R[ok], b.index[sig][ok]
        out[sens] = (R, T2)
        continue
        out[sens] = (R, b.index[sig])
    return out


def simule(legs):
    """legs = liste de (R, timestamps). Simule le compte jour par jour."""
    trades = []
    for R, T in legs:
        for x, t in zip(R, T):
            if 21 <= t.hour or t.hour < 1:
                continue                     # pas de trading 21h-1h UTC
            trades.append((t.date(), float(x)))
    trades.sort()
    eq, pic, dd, dd_max = 1.0, 1.0, 0.0, 0.0
    par_jour = defaultdict(float)
    for j, x in trades:
        par_jour[j] += x
    jours = sorted(par_jour)
    serie = []
    for j in jours:
        pnl = par_jour[j] * RISK / 100.0 * eq          # % de l'equity courante
        if pnl < STOP_JOUR:
            pnl = STOP_JOUR                            # stop journalier
        eq *= (1 + pnl / 100.0)
        pic = max(pic, eq)
        dd = (eq / pic - 1) * 100
        dd_max = min(dd_max, dd)
        serie.append((j, eq, pnl, dd))
    return serie, dd_max


def main():
    data = {p: mesure(p) for p in PAIRES}
    data = {p: v for p, v in data.items() if v}
    # choix de direction : meilleur R/tx, avec >= 4 LONG imposes
    # 205 : DIRECTION IMPOSEE depuis la table validee (round 202, formule du
    # premier toucher, chiffres identiques au round 197). On ne recalcule plus le
    # sens par paire : c'est ce recalcul qui a inverse le resultat trois fois.
    COURT = ("AUDCAD", "AUDJPY", "AUDUSD", "CADJPY", "EURAUD", "EURCAD",
             "EURCHF", "EURGBP", "EURJPY", "GBPCHF", "GBPUSD", "NZDCAD",
             "NZDUSD", "USDCAD")
    LONG = ("EURUSD", "USDCHF")     # les 2 seules paires positives en long
    choix = {}
    for p in COURT:
        if p in data and -1 in data[p]:
            choix[p] = -1
    for p in LONG:
        if p in data and 1 in data[p]:
            choix[p] = 1
    nlong = sum(1 for s in choix.values() if s > 0)
    cands = sorted([p for p in data if choix[p] < 0],
                   key=lambda p: float(np.mean(data[p][1][0]))
                   - float(np.mean(data[p][-1][0])))
    for p in cands[:0]:   # 203 : on ne force PLUS 4 jambes longues -- mesure du round 202 : seules EURUSD et USDCHF sont positives en long, les forcer coute -0,12 R/tx en moyenne
        choix[p] = 1
    nlong = sum(1 for s in choix.values() if s > 0)
    legs = [data[p][s] for p, s in choix.items()]
    serie, dd_max = simule(legs)
    if not serie:
        print("aucun trade exploitable")
        return 1
    par_mois = defaultdict(lambda: [None, None])
    for j, eq, pnl, dd in serie:
        par_mois["%04d-%02d" % (j.year, j.month)][1] = eq
    mois = []
    eq0 = 1.0
    for m in sorted(par_mois):
        eqf = par_mois[m][1]
        mois.append((m, (eqf / eq0 - 1) * 100))
        eq0 = eqf
    gains = [x for _, x in mois]
    lignes = ["# Simulation du compte prop (feed Upcomers, 14-16 jambes)", "",
              "Risque %.1f %% par trade | stop journalier %.1f %% | drawdown coupe a %.1f %% | "
              "max 2 positions | pas de trading 21h-1h UTC" % (RISK, STOP_JOUR, DD_MAX), "",
              "| indicateur | valeur |", "|---|---|",
              "| jambes | %d (%d LONG / %d COURT) |" % (len(choix), nlong, len(choix) - nlong),
              "| trades | %d |" % sum(len(R) for R, _ in legs),
              "| R/tx moyen | %+.4f |" % np.mean([np.mean(R) for R, _ in legs]),
              "| rendement mensuel moyen | %+.2f %% |" % np.mean(gains),
              "| mois positifs | %d/%d |" % (sum(1 for x in gains if x > 0), len(gains)),
              "| meilleur mois | %+.2f %% |" % max(gains),
              "| pire mois | %+.2f %% |" % min(gains),
              "| drawdown max | %.2f %% |" % dd_max,
              "", "## mois par mois", ""]
    for m, x in mois:
        lignes.append("- %s : %+.2f %%" % (m, x))
    lignes += ["", "## composition"]
    for p, s in sorted(choix.items()):
        lignes.append("- **%s** : %s (R/tx %+.4f)" % (p, "LONG" if s > 0 else "COURT",
                                                     float(np.mean(data[p][s][0]))))
    OUT.write_text("\n".join(lignes), encoding="utf-8")
    print("\n".join(lignes[:16]), flush=True)
    print("ecrit %s" % OUT, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())




