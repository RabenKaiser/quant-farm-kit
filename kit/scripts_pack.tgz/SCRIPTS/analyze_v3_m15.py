# -*- coding: utf-8 -*-
"""Analyseur des resultats V3_EA_M15 (v3_m15.jsonl): trades/an, PF, WR,
TP/SL, jours qualifiants (>0.5%) approx. Repond a la question mitraillette:
frequence x4 avec PF>1.2?"""
import json
from pathlib import Path

P = Path(r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\v3_m15.jsonl")
if not P.exists():
    print("pas de fichier"); raise SystemExit
for line in P.read_text(encoding="utf-8").splitlines():
    rec = json.loads(line)
    tag = rec["tag"]; r = rec["r"]
    if isinstance(r, dict) and r.get("error"):
        print(f"[{tag}] ERREUR: {r['error']}")
        continue
    print(f"\n=== {tag} ===")
    for k in ["ea", "symbol", "tf", "from", "to", "trades", "profit", "pf",
              "wr", "wins", "losses", "tp", "gain_trail", "be", "net_usd",
              "dd", "_source"]:
        if k in r:
            print(f"  {k}: {r[k]}")
    tr = r.get("trades") or 0
    yrs = 6.0  # 2020-2026
    if tr:
        print(f"  -> {tr/yrs:.0f} trades/an | profit/trade: "
              f"{(r.get('profit') or 0)/tr:.2f}$")
