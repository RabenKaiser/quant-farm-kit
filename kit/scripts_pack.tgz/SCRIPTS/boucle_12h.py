"""boucle_12h : la boucle de nuit demandee - toutes les trames, les deux feeds, 12 heures.

Ce que fait la boucle, dans l'ordre et en continu jusqu'a l'heure limite :
  1. `combos_facteurs.py` (50 facteurs, combinaisons de 1 a 3, mesure « qui est touche en
     premier ») sur M5, M15, M30, H1 - parce qu'un facteur peut n'exister qu'a une echelle ;
  2. `precurseurs.py` (la methode INVERSE : partir du mouvement et regarder ce qui le precedait)
     sur les memes trames ;
  3. les memes moteurs sur le FEED CIBLE (Upcomers 2026), puis comparaison ;
  4. `heatmap_etats.py` (carte de chaleur des etats) ;
  5. `dico_tpo.py` (mot du dictionnaire x etat TPO) ;
  6. les analyses de synthese (`organise.py` pour regenerer l'inventaire et la table).

Chaque moteur ecrit son propre CSV ou MD : rien n'est ecrase, et chaque resultat est rejouable.
La boucle est DETACHEE du processus appelant, donc elle survit a la conversation.
"""
import datetime
import os
import subprocess
import sys
from pathlib import Path

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
LOG = B / "boucle_12h.log"
DUREE_H = float(os.environ.get("DUREE_H", "12"))
TRAMES = ["5min", "15min", "30min", "60min"]
FEEDS = ["m1_pos", "m1_upcomers"]


def note(m):
    with LOG.open("a", encoding="utf-8") as f:
        f.write("%s %s\n" % (datetime.datetime.now().strftime("%d/%m %H:%M:%S"), m))


def tour(script, env_sup):
    env = dict(os.environ)
    env.update(env_sup)
    nom = "%s_%s_%s" % (Path(script).stem, env_sup.get("CORPUS", "?"), env_sup.get("TF", "?"))
    note("lancement %s" % nom)
    with (B / ("nuit_%s.log" % nom)).open("a", encoding="utf-8") as f:
        subprocess.run([sys.executable, str(B / "SCRIPTS" / script)], cwd=str(B), env=env,
                       stdout=f, stderr=f)
    note("termine %s" % nom)


def main():
    fin = datetime.datetime.now() + datetime.timedelta(hours=DUREE_H)
    note("BOUCLE 12H DEMARREE, fin prevue a %s" % fin.strftime("%d/%m %H:%M"))
    while datetime.datetime.now() < fin:
        for corpus in FEEDS:
            for tf in TRAMES:
                for script in ("combos_facteurs.py", "precurseurs.py"):
                    if datetime.datetime.now() >= fin:
                        break
                    tour(script, {"CORPUS": corpus, "TF": tf})
            if datetime.datetime.now() >= fin:
                break
            tour("heatmap_etats.py", {"CORPUS": corpus})
            tour("dico_tpo.py", {"CORPUS": corpus})
        if datetime.datetime.now() < fin:
            tour("organise.py", {})
        note("un cycle complet termine, on recommence")
    note("BOUCLE 12H TERMINEE")
    return 0


if __name__ == "__main__":
    sys.exit(main())
