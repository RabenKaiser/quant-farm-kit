# -*- coding: utf-8 -*-
"""closeopt_r281.py — RE-OPTIMISATION COMPLETE EN MODELE DE REMPLISSAGE REEL.

R279: `ext_fill="close"` reduit l ecart python/MT5 de 0.809 a 0.315.
Il faut donc REFAIRE toute l optimisation avec ce modele, car il inverse
plusieurs conclusions:
  - le biais VWAP AIDE en mode close (+101R vs +78R sans) -> contre R277
  - buf serre (2-3) bat buf large en mode close -> contre R267/R276

Ce script:
 1. balaye buf x ext en mode close, avec et sans biais
 2. walk-forward SEQ 2021-2023 / VAL 2024-2025
 3. stress spread/slippage
 4. simulation prop (contrainte MaxDD<10%)
 5. test croise sur les autres marches (en gardant en tete que leurs donnees
    sont de mauvaise qualite: 1 prix/minute)
"""
import sys, json
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import c13v2_py_v3 as F
import c13v2_engine as ENG
import pandas as pd, numpy as np

BASE = {"imp_atr": 0.7, "imp_vol": 1.0, "imp_look": 6, "ob_age": 32,
        "rej_wick": 0.4, "rej_vol": 1.0, "close_zone": 0.15,
        "bias": "vwap", "excl_hours": [], "lookahead": False, "vwap_len": 96,
        "tp_r": 99, "min_stop": 0.00025, "buf_atr": 6.0, "bias_src": "m5_asof"}

print("Chargement XAUUSD...", flush=True)
M1 = F.load_m1("XAUUSD")
FR = {}
def bt(y0, y1, buf=6.0, ext=8.0, bs="m5_asof", sp=20.0, slip=1.0, hours=None):
    k = (y0, y1)
    if k not in FR:
        s = pd.Timestamp(f"{y0}-01-01", tz="UTC"); e = pd.Timestamp(f"{y1+1}-01-01", tz="UTC")
        wu = s - pd.Timedelta(days=260)
        w = M1.loc[wu:e]
        m5 = F.resample(w, "5min").loc[s:e]
        m15 = F.resample(w, "15min")
        h4 = F.resample(w, "4h")
        a15 = ENG.SW.F.atr_s(m15, 14)
        a15i = a15.reindex(a15.index.union(m5.index)).ffill().reindex(m5.index)
        FR[k] = (m5, m15, h4, a15i.to_numpy())
    m5, m15, h4, a15 = FR[k]
    cf = dict(BASE); cf["buf_atr"] = buf; cf["bias_src"] = bs
    cf["excl_hours"] = hours if hours is not None else []
    return ENG.run_exit(m5, m15, h4, cf, exit_mode="extend", ext_atr=ext, tp_r=99,
                        spread_pips=sp, point_size=0.01, atr_ref=a15,
                        ext_fill="close", slip_points=slip)

def propeq(r, risk=1.0):
    Rs = np.array([t[0] for t in r["trades"]])
    e = 100.0; pk = 100.0; dd = 0.0
    for x in Rs:
        e *= (1 + risk / 100 * x); pk = max(pk, e); dd = max(dd, (pk - e) / pk * 100)
    return e, dd

print("=" * 104)
print("R281 — OPTIMISATION EN MODELE DE REMPLISSAGE REEL (ext_fill='close')")
print("=" * 104)

print("\n--- 1. BIAIS: avec vs sans (mode close, buf varie, full 21-25) ---")
print(f"{'buf':>5s} | {'VWAP':>20s} | {'SANS BIAIS':>20s}")
for buf in (2.0, 3.0, 4.0, 6.0, 8.0, 12.0, 16.0):
    a = bt(2021, 2025, buf=buf, bs="m5_asof")
    b = bt(2021, 2025, buf=buf, bs="none")
    print(f"{buf:5.1f} | R={a['R']:+7.1f} pf={a['pf']:5.2f} | "
          f"R={b['R']:+7.1f} pf={b['pf']:5.2f}")

print("\n--- 2. ANNEE PAR ANNEE du meilleur buf (VWAP, heures non filtrees) ---")
for buf in (2.0, 3.0, 4.0):
    row = []
    tot = 0
    for y in range(2021, 2026):
        r = bt(y, y, buf=buf); row.append(r["R"]); tot += r["R"]
    pos = sum(1 for v in row if v > 0)
    print(f"  buf{buf:4.1f}: " + " ".join(f"{v:+7.1f}" for v in row) +
          f" | total {tot:+7.1f} | {pos}/5 annees positives")

print("\n--- 3. GRILLE buf x ext en mode close (full 21-25, VWAP) ---")
print(f"{'buf':>5s} | " + " ".join(f"ext{e:<4}" for e in (4, 6, 8, 10, 12, 16)))
best = None
for buf in (1.5, 2.0, 2.5, 3.0, 4.0, 6.0):
    cells = []
    for ext in (4, 6, 8, 10, 12, 16):
        r = bt(2021, 2025, buf=buf, ext=ext)
        cells.append(f"{r['R']:+6.0f}")
        rdd = r["R"] / r["dd"] if r["dd"] > 0 else 0
        if best is None or rdd > best[1]:
            best = (f"buf{buf}/ext{ext}", rdd, r)
    print(f"{buf:5.1f} | " + " ".join(cells))
print(f"\n  meilleur R/DD: {best[0]} -> R={best[2]['R']:+.1f} pf={best[2]['pf']:.2f} "
      f"dd={best[2]['dd']:.1f} R/DD={best[1]:.1f} n={best[2]['n']} wr={best[2]['wr']:.1f}%")

print("\n--- 4. WALK-FORWARD du meilleur (SEQ 21-23 / VAL 24-25) ---")
parts = best[0].replace("buf", "").split("/ext")
bb, ee = float(parts[0]), float(parts[1])
a = bt(2021, 2023, buf=bb, ext=ee); b = bt(2024, 2025, buf=bb, ext=ee)
print(f"  {best[0]}: SEQ R={a['R']:+7.1f} pf={a['pf']:.2f} | "
      f"VAL R={b['R']:+7.1f} pf={b['pf']:.2f}")

print("\n--- 5. STRESS du meilleur ---")
f = bt(2021, 2025, buf=bb, ext=ee)
for lab, kw in [("base", {}), ("spread 30", dict(sp=30.0)), ("spread 40 (x2)", dict(sp=40.0)),
                ("spread 60 (x3)", dict(sp=60.0)), ("slip 2", dict(slip=2.0)),
                ("PIRE sp40+slip2", dict(sp=40.0, slip=2.0))]:
    r = bt(2021, 2025, buf=bb, ext=ee, **kw)
    print(f"  {lab:18s}: R={r['R']:+7.1f} pf={r['pf']:.2f} dd={r['dd']:.1f}")

print("\n--- 6. PROP: risque optimal sous MaxDD<10% ---")
tbl = []
for risk in (0.2, 0.3, 0.4, 0.5, 0.75, 1.0):
    e, dd = propeq(f, risk)
    cagr = ((e / 100) ** (1 / 5) - 1) * 100
    ok = "OK" if dd < 10 else "--"
    tbl.append((risk, e, cagr, dd, ok))
    print(f"  risk {risk:4.2f}%/trade : eq {e:9,.1f} CAGR {cagr:+6.1f}% MaxDD {dd:5.2f}% {ok}")

print("\n--- 7. TEST CROISE (attention: donnees 1 prix/minute sur ces marches) ---")
MKT2 = {"AUDUSD": (0.0001, 1.5), "NZDUSD": (0.0001, 2.0),
        "USDCAD": (0.0001, 1.8), "AUDCAD": (0.0001, 2.0)}
CR = {}
for sym, (ps, sp) in MKT2.items():
    try:
        m1 = F.load_m1(sym)
    except Exception as ex:
        print(f"  {sym}: ERR {ex}"); continue
    s = pd.Timestamp("2021-01-01", tz="UTC"); e_ = pd.Timestamp("2026-01-01", tz="UTC")
    w = m1.loc[s - pd.Timedelta(days=260):e_]
    m5 = F.resample(w, "5min").loc[s:e_]
    m15 = F.resample(w, "15min"); h4 = F.resample(w, "4h")
    a15 = ENG.SW.F.atr_s(m15, 14)
    a15i = a15.reindex(a15.index.union(m5.index)).ffill().reindex(m5.index)
    cf = dict(BASE); cf["buf_atr"] = bb
    r = ENG.run_exit(m5, m15, h4, cf, exit_mode="extend", ext_atr=ee, tp_r=99,
                     spread_pips=sp, point_size=ps, atr_ref=a15i.to_numpy(),
                     ext_fill="close", slip_points=1.0)
    print(f"  {sym:8s}: n={r['n']:4d} R={r['R']:+7.1f} pf={r['pf']:.2f} wr={r['wr']:.1f}%")

json.dump({"best": best[0], "R": best[2]["R"], "pf": best[2]["pf"],
           "dd": best[2]["dd"], "n": best[2]["n"]},
          open(r"C:\EAFarm\HISTORY - Copy\research\RESULTS_C13V2\r281_closeopt.json", "w"),
          indent=1, default=str)
print("\nFIN", flush=True)
