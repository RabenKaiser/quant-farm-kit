"""compare_spreads : spread Upcomers contre spread Dukascopy (farm).

Pour chaque paire exportee du feed Upcomers, on calcule le spread median et le
90e centile en pips, l'ATR median (M5) et le cout en R a stop 1 ATR, puis on
compare au meme calcul sur le corpus Dukascopy (m1_pos). Le rapport des couts
est le MULTIPLICATEUR reel a utiliser dans cout_sweep.py, au lieu des 1/1.5/2/3
hypothetiques.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
UP = B / "m1_upcomers"
FARM = B / "m1_pos"
OUT = B / "compare_spreads.md"
POINT = {"EURUSD": 1e-5, "GBPUSD": 1e-5, "AUDUSD": 1e-5, "NZDUSD": 1e-5,
         "USDCAD": 1e-5, "USDCHF": 1e-5, "EURGBP": 1e-5, "EURJPY": 1e-3,
         "GBPJPY": 1e-3, "AUDJPY": 1e-3, "CADJPY": 1e-3, "CHFJPY": 1e-3,
         "USDJPY": 1e-3}


def mesure(f):
    d = pd.read_csv(f, usecols=["time", "high", "low", "close", "spread"])
    p = None
    for k, v in POINT.items():
        if f.stem.startswith(k):
            p = v
            break
    p = p or 1e-5
    d["t"] = pd.to_datetime(d["time"], unit="s", utc=True)
    d = d.set_index("t")
    b = d.resample("5min").agg(high=("high", "max"), low=("low", "min"),
                               close=("close", "last")).dropna()
    tr = pd.concat([b.high - b.low, (b.high - b.close.shift()).abs(),
                    (b.low - b.close.shift()).abs()], axis=1).max(axis=1)
    atr = float(tr.rolling(14).mean().median())
    s = d["spread"].astype(float) * p
    pip = p * 10
    return dict(fichier=f.name, n=len(d),
                med=float(np.median(s) / pip), p90=float(np.percentile(s, 90) / pip),
                atr=atr, cout=float(np.median(s) / atr),
                deb=str(d.index[0])[:10], fin=str(d.index[-1])[:10])


def main():
    ups = sorted(UP.glob("*_M1.csv")) if UP.exists() else []
    if not ups:
        print("aucun export Upcomers dans %s" % UP)
        return 1
    lignes = ["# Spread Upcomers contre Dukascopy", "",
              "| paire | source | periode | barres | spread med (pips) | spread 90e | ATR M5 | cout (R a 1 ATR) | rapport |",
              "|---|---|---|---|---|---|---|---|---|"]
    for f in ups:
        u = mesure(f)
        g = FARM / f.name
        gm = mesure(g) if g.exists() else None
        rap = "%.2f" % (u["cout"] / gm["cout"]) if gm and gm["cout"] else "-"
        lignes.append("| %s | Upcomers | %s..%s | %d | %.2f | %.2f | %.6f | %.4f | %s |"
                      % (f.stem.replace("_M1", ""), u["deb"], u["fin"], u["n"],
                         u["med"], u["p90"], u["atr"], u["cout"], rap))
        if gm:
            lignes.append("| %s | Dukascopy | %s..%s | %d | %.2f | %.2f | %.6f | %.4f | 1.00 |"
                          % (f.stem.replace("_M1", ""), gm["deb"], gm["fin"], gm["n"],
                             gm["med"], gm["p90"], gm["atr"], gm["cout"]))
        print("%-8s Upcomers cout %.4f R (spread %.2f pips) | Dukascopy %s"
              % (f.stem, u["cout"], u["med"],
                 "%.4f R" % gm["cout"] if gm else "absent"), flush=True)
    OUT.write_text("\n".join(lignes), encoding="utf-8")
    print("ecrit %s" % OUT, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
