"""audcad_diag : ou est l'ecart entre le moteur honnete et les ordres reels a stop LARGE ?

Round 385. Au stop de 1 ATR le moteur honnete rend le taux de gagnantes reel a 0,2-0,6 point pres
(1 412 transactions, deux echantillons disjoints). Au stop de 3 ATR / cible 6 ATR sur AUDCAD, il
annonce 39,9 % quand le reel donne 25,2 %. Ce script nomme l'ecart, sans theorie :

  1. la DUREE reelle de chaque position : sortie a l'echeance (proche de 32 h) ou stop precoce ?
  2. la distribution du R reel, en distance de STOP ;
  3. la table de contingence modele x reel ;
  4. pour chaque desaccord « modele = cible / reel = perte », l'instant de sortie et le SPREAD DU
     CORPUS a cette minute, compares au prix de sortie reel : c'est ce qui dit si le corpus
     sous-estime le spread a cet instant precis, ou si c'est autre chose.

Le script separe aussi les positions par grappe d'horodatage d'EXECUTION du journal : deux campagnes
differentes portant le meme identifiant de ligne de jeu (une avec une cible a 18 ATR lancee par
erreur, une a 6 ATR) ecrivent dans les MEMES journaux, et un melange des deux fausserait la mesure.

Env : PAIRES (defaut AUDCAD), SLR (3), TPR (6), LIGNE (SR97S), PROFIL (farm), EXEC_MIN (filtre
optionnel "HH:MM:SS" : ne garder que les lignes executees apres cette heure).
"""
import os
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import barrieres_m1 as BM  # noqa: E402
import nuit_motifs as NM  # noqa: E402

PROFILS = {"mt5": "E23367DD11DBEB0EF97D08185EAB7295",
           "farm": "CF0B997454318B475CF01419AFE2BBF3"}
LIGNE = os.environ.get("LIGNE", "SR97S")
SLR = float(os.environ.get("SLR", "3"))
TPR = float(os.environ.get("TPR", "6"))
HOLD = int(os.environ.get("HOLD", "64"))
# rapport ATR de l'EA / ATR du corpus, mesure au round 359 : l'EA est 7 % plus serre.
ATR_EA = float(os.environ.get("ATR_EA", "1.0"))
# 1 = le modele recoit l'horizon reellement mesure de chaque position (voir plus bas).
HORIZON_REEL = os.environ.get("HORIZON_REEL", "") == "1"
# ROUND 388 : PAR_BARRES=1 (defaut) compte l'horizon en BARRES de donnee (64 barres M30 = 1920 barres
# M1), comme l'EA, au lieu de 1920 minutes murales -- un week-end intercale ne consomme aucune barre.
# C'est le reglage de reference depuis que la table a ete refaite avec lui.
PAR_BARRES = os.environ.get("PAR_BARRES", "1") == "1"
PAIRES = os.environ.get("PAIRES", "AUDCAD").split(",")
EXEC_MIN = os.environ.get("EXEC_MIN", "")
# ROUND 387 : un journal du testeur par jour. Un filtre sur l'heure seule laissait passer la campagne
# de la VEILLE (une autre geometrie) parce que "23:32" >= "01:27" en comparaison de chaines -- meme
# defaut que le round 384, autre porte. On restreint donc au journal du jour.
JOUR = os.environ.get("JOUR", pd.Timestamp.now().strftime("%Y%m%d"))


def lit(paire):
    """Positions reelles de `paire`, avec la grappe d'horodatage d'execution."""
    d = (Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Tester")
         / PROFILS.get(os.environ.get("PROFIL", "farm"), ""))
    re_j = re.compile(
        r"(\d{2}:\d{2}:\d{2})\.\d+\s+TRIGGER_LAB \(%s,M30\).*?(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})"
        r"\s+JRN \w+ (\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}) (%s\|[^\s]*) ([01]) (\d+) ([\d.eE+-]+)"
        % (paire, re.escape(LIGNE)))
    pos, grappes = {}, Counter()
    for lg in d.glob("Agent-*/logs/%s.log" % JOUR):
        try:
            txt = lg.read_text(encoding="utf-16", errors="replace")
        except OSError:
            continue
        if "JRN " not in txt:
            txt = lg.read_text(encoding="utf-8", errors="replace")
        for m in re_j.finditer(txt):
            ex, fin, t, _lid, typ, pid, prix = m.groups()
            if EXEC_MIN and ex < EXEC_MIN:
                continue
            grappes[ex[:5]] += 1
            p = pos.setdefault((fin, int(pid)), {})
            ts = pd.Timestamp(t.replace(".", "-", 2).replace(".", " "))
            if typ == "0":
                p.setdefault("t_in", ts)
                p.setdefault("p_in", float(prix))
                p["ex"] = ex
            elif "t_in" in p:
                p["t_out"] = ts
                p["p_out"] = float(prix)
    return [p for p in pos.values() if "p_out" in p and "t_in" in p], grappes


def main():
    print("MOTEUR HONNETE, stop %.1f ATR / cible %.1f ATR | ligne %s | exec >= %s\n"
          % (SLR, TPR, LIGNE, EXEC_MIN or "(tout)"), flush=True)
    for paire in PAIRES:
        pos, grappes = lit(paire)
        print("=== %s : %d positions recollees ===" % (paire, len(pos)))
        print("    grappes d'execution du journal : %s"
              % ", ".join("%s (%d lignes)" % (k, v) for k, v in sorted(grappes.items())))
        M = BM.charge_m30(paire, "m1_pos")
        D = NM.charge(paire, "m1_pos")
        if M is None or D is None:
            print("    corpus absent")
            continue
        idx = M["idx"]
        reels, kinds, durs, det, rmodele = [], [], [], [], []
        for p in sorted(pos, key=lambda x: x["t_in"]):
            if p["t_in"] < idx[0] or p["t_in"] > idx[-1]:
                continue
            i = int(idx.searchsorted(p["t_in"] - pd.Timedelta(minutes=30)))
            if i >= len(idx) or (idx[i] - (p["t_in"] - pd.Timedelta(minutes=30))).total_seconds() > 60:
                i -= 1
            if i < 51 or i + 1 + HOLD >= len(idx):
                continue
            st = float(M["a"][i])
            if not np.isfinite(st) or st <= 0:
                continue
            # ROUND 385 : l'ATR de l'EA est plus SERRE que celui du corpus (rapport mesure 0,9318
            # depuis le round 359). Le modele place donc son stop a 3,00 ATR du corpus quand l'EA le
            # place a 2,79 : il manque des stops que le reel prend. ATR_EA permet de mesurer
            # exactement cet effet, au lieu de le supposer.
            # ROUND 388 : HORIZON_REEL=1 donne au modele l'HORIZON REELLEMENT MESURE de la position
            # (t_out - t_in, lu dans le JRN) au lieu de 64 barres M30. Si l'EA tient plus longtemps
            # que 32 h, le modele declare « echeance » des positions que le reel a finies en stop ou en
            # cible -- c'est l'hypothese testee ici pour expliquer la poche « echeance ».
            hz = HOLD * 30
            if HORIZON_REEL:
                hz = max(30.0, (p["t_out"] - p["t_in"]).total_seconds() / 60.0)
            r = BM.issue(M["m1"], int(idx[i + 1].timestamp()), float(M["o"][i + 1]), st * ATR_EA,
                         TPR, SLR, int(round(hz)), "S", par_barres=PAR_BARRES)
            if r is None:
                continue
            # ROUND 387 : meme reference que reel_empile.py -- le R reel est divise par le stop de
            # l'EA (SLR x ATR de l'EA), pour que les deux scripts donnent le MEME chiffre sur le
            # meme echantillon. Deux conventions differentes de 7 % avaient produit deux tableaux
            # incoherents au round 386.
            Rr = (p["p_in"] - p["p_out"]) / (SLR * st * ATR_EA)
            reels.append(Rr)
            rmodele.append(r[1])
            kinds.append(r[0])
            durs.append((p["t_out"] - p["t_in"]).total_seconds() / 3600.0)
            det.append((p, i, st, r, Rr))
        if len(reels) < 10:
            print("    %d transactions exploitables -- trop peu" % len(reels))
            continue
        reels, kinds, durs = np.array(reels), np.array(kinds), np.array(durs)
        rmodele = np.array(rmodele)
        # issue reelle : cible si R > 1 (2 R), stop si R < -0,5 (1 R), sinon echeance
        # ROUND 387 : les seuils sont exprimes dans l'unite du R mesure, c'est-a-dire en multiples du
        # stop de l'EA : une cible vaut +2 (un peu moins avec le cout), un stop vaut -1. Le seuil de
        # 1,0 etait un point milieu convenable au stop de 1 ATR ; au stop de 3 ATR et avec l'ATR de
        # l'EA il faut 1,5, sinon des sorties a l'echeance (+1,1 R) sont comptees comme des cibles.
        kr = np.where(reels > 1.5, 0, np.where(reels < -0.5, 1, 2))
        km = kinds
        n = len(reels)
        print("    %d transactions jugees | gagnantes REELLES %.1f %% | modele %.1f %% | accord %.1f %%"
              % (n, 100.0 * np.mean(kr == 0), 100.0 * np.mean(km == 0), 100.0 * np.mean(km == kr)))
        print("    R/tx reel %+.4f | R/tx modele %+.4f | ecart-type reel %.2f"
              % (reels.mean(), rmodele.mean(), reels.std()))
        print("    contingence (lignes = modele, colonnes = reel) cible/stop/echeance :")
        for k_, lab in ((0, "modele cible  "), (1, "modele stop   "), (2, "modele echeance")):
            print("      %s : %s" % (lab, [int(np.sum((km == k_) & (kr == b))) for b in (0, 1, 2)]))
        print("    duree reelle : mediane %.1f h | > 30 h : %d/%d | 3-12 h : %d | < 3 h : %d"
              % (np.median(durs), int(np.sum(durs > 30)), n, int(np.sum((durs >= 3) & (durs <= 12))),
                 int(np.sum(durs < 3))))
        # ROUND 388 : la POCHE « ECHEANCE » -- le moteur conclut a l'echeance alors que le reel a fini
        # en stop ou en cible. C'est le seul residu systematique du moteur ; on regarde si l'horizon
        # reel l'explique (duree > 32 h) avant de chercher ailleurs.
        poc = [k for k in range(n) if km[k] == 2 and (kr[k] == 0 or kr[k] == 1)]
        if poc:
            dp = durs[poc]
            print("    POCHE echeance : %d/%d transactions (%.0f %%) | duree mediane %.1f h |"
                  " > 30 h : %d (%.0f %%) | R moyen reel %+.2f"
                  % (len(poc), int(np.sum(km == 2)), 100.0 * len(poc) / max(1, int(np.sum(km == 2))),
                     np.median(dp), int(np.sum(dp > 30)), 100.0 * np.mean(dp > 30),
                     float(reels[poc].mean())))
        # desaccords modele=cible / reel=perte : le corpus explique-t-il la sortie ?
        print("    desaccords « modele cible / reel perte » (5 premiers) :")
        mm = [x for x in det if x[3][0] == 0 and (x[4] > 1.0) is False and x[4] < -0.5]
        for p, i, st, r, Rr in mm[:5]:
            t_out = p["t_out"]
            if t_out < idx[0] or t_out > idx[-1]:
                continue
            j = int(np.searchsorted(M["m1"]["t"], int(t_out.timestamp())))
            j = min(max(j, 0), len(M["m1"]["t"]) - 1)
            bid = float(M["m1"]["l"][j])
            sp = float(M["m1"]["spr"][j])
            print("      %s : entree %.5f TP modele %.5f | sortie reelle %.5f a %s | duree %.1f h | "
                  "R %+.2f | corpus a la sortie : plus-bas %.5f + spread %.5f = ask %.5f"
                  % (p["t_in"], p["p_in"], r[2], p["p_out"], t_out,
                     (p["t_out"] - p["t_in"]).total_seconds() / 3600.0, Rr, bid, sp, bid + sp))
        print("    desaccords « modele stop / reel gagnant » : %d"
              % int(np.sum((km == 1) & (kr == 0))))
    return 0


if __name__ == "__main__":
    sys.exit(main())
