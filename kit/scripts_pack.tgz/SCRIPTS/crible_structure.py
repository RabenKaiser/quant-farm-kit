﻿# -*- coding: utf-8 -*-
"""crible_structure : la famille PRICE ACTION — la structure de swing (Dow) mesuree causalement.

Round 542. La Market Map a donne les fenetres, crible_fib a donne le point de re-entree dans
l'impulsion ; cette famille mesure la STRUCTURE elle-meme — les trois comportements classiques du
price action, tous causaux (pivots ZigZag confirmes seulement, aucune anticipation) :

  STRUCT_CONT : continuation de structure. Tendance haussiere = dernier +1 pivot plus haut que le
      precedent (+1) ET dernier -1 pivot (Higher Low) plus haut que le precedent -1. Signal = le
      retest du Higher Low : low <= niveau && close >= niveau (achat dans la tendance, meme style
      RETOUR que fib). Miroir short : LH/LL et retest du Lower High.
  BOS_RETEST : cassure de structure puis retest. Un +1 pivot DEPASSE le +1 precedent (Break Of
      Structure haussier, confirme) ; signal = la reprise du niveau casse : low <= niveau &&
      close >= niveau, dans les HOLD*3 barres qui suivent la confirmation. Miroir short.
  SWEEP : balayage de liquidite. Une barre mord le dernier -1 pivot confirme (low < niveau) mais
      CLOTURE au-dessus (les stops sont pris, la structure tient) → achat de retournement.
      Miroir short : high > niveau && close < niveau.

Le sweep est le cousin du REJET avwap (meche au-dela, cloture en-deca) mais ancre sur les niveaux
de swing — une AUTRE information (la liquidite posee aux extremes), ce qui justifie la mesure.

Env : CORPUS=m1_ext TF_MIN=30 ZIG_ATR=3.0 ATR_N=14 TPRS=6,12 HOLD=64 PAIRES=... SORTIE=CRIBLE_STRUCTURE.csv
Sortie : CRIBLE_STRUCTURE.csv
"""
import csv
import os
import sys
from pathlib import Path

import numpy as np

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
sys.path.insert(0, str(B / "SCRIPTS"))
import crible_payoff as CP  # noqa: E402
import crible_fib as CF  # noqa: E402  (grille, atr_serie, zigzag, grille/evaluateur partages)
import spread_barrieres as SB  # noqa: E402

CORPUS = os.environ.get("CORPUS", "m1_ext")
SORTIE = B / os.environ.get("SORTIE", "CRIBLE_STRUCTURE.csv")
TF_MIN = int(os.environ.get("TF_MIN", "30"))
TPRS = [float(x) for x in os.environ.get("TPRS", "6,12").split(",")]
HOLD = int(os.environ.get("HOLD", "64"))
PAIRES = [x for x in os.environ.get("PAIRES", "").split(",") if x]
CLASSE = CP.CLASSE
OFFSETS = CP.OFFSETS


def signaux_structure(M, atr, famille, sens):
    """Les trois comportements de structure, pivots confirmes seulement."""
    c, h, l = M["c"], M["h"], M["l"]
    piv = CF.zigzag(M, atr)
    if len(piv) < 3:
        return np.array([], dtype=int)
    sig = np.zeros(len(c), dtype=bool)

    def plus_hauts():
        return [(i, c[i], ic) for (i, t, ic) in piv if t == 1]

    def plus_bas():
        return [(i, c[i], ic) for (i, t, ic) in piv if t == -1]

    if famille in ("STRUCT_CONT", "BOS_RETEST"):
        ph, pb = plus_hauts(), plus_bas()
        if sens == "L" and len(ph) >= 2 and len(pb) >= 1:
            # structure haussiere : HH + HL
            if famille == "STRUCT_CONT":
                for k in range(1, len(ph)):
                    if ph[k][1] > ph[k - 1][1]:
                        hl = pb[min(len(pb) - 1, k)]      # le Higher Low associe au HH k
                        hl_prev = pb[min(len(pb) - 1, k - 1)]
                        if hl[1] > hl_prev[1]:
                            niv = hl[1]
                            zone = slice(hl[2], min(len(c), hl[2] + HOLD * 3))
                            sig[zone] |= (l[zone] <= niv) & (c[zone] >= niv)
            else:
                for k in range(1, len(ph)):
                    if ph[k][1] > ph[k - 1][1]:
                        niv = ph[k - 1][1]                 # le sommet casse
                        zone = slice(ph[k][2], min(len(c), ph[k][2] + HOLD * 3))
                        sig[zone] |= (l[zone] <= niv) & (c[zone] >= niv)
        if sens == "S" and len(pb) >= 2 and len(ph) >= 1:
            if famille == "STRUCT_CONT":
                for k in range(1, len(pb)):
                    if pb[k][1] < pb[k - 1][1]:
                        lh = ph[min(len(ph) - 1, k)]
                        lh_prev = ph[min(len(ph) - 1, k - 1)]
                        if lh[1] < lh_prev[1]:
                            niv = lh[1]
                            zone = slice(lh[2], min(len(c), lh[2] + HOLD * 3))
                            sig[zone] |= (h[zone] >= niv) & (c[zone] <= niv)
            else:
                for k in range(1, len(pb)):
                    if pb[k][1] < pb[k - 1][1]:
                        niv = pb[k - 1][1]
                        zone = slice(pb[k][2], min(len(c), pb[k][2] + HOLD * 3))
                        sig[zone] |= (h[zone] >= niv) & (c[zone] <= niv)
    elif famille == "SWEEP":
        if sens == "L" and len(plus_bas()) >= 1:
            # dernier niveau de swing bas CONFIRME a chaque barre
            lows = sorted((ic, p) for (i, p, ic) in plus_bas())
            k = 0
            niv = np.nan
            nivs = np.full(len(c), np.nan)
            for i in range(len(c)):
                while k < len(lows) and lows[k][0] <= i:
                    niv = lows[k][1]
                    k += 1
                nivs[i] = niv
            sig |= (l < nivs) & (c > nivs) & np.isfinite(nivs)
        if sens == "S" and len(plus_hauts()) >= 1:
            highs = sorted((ic, p) for (i, p, ic) in plus_hauts())
            k = 0
            niv = np.nan
            nivs = np.full(len(c), np.nan)
            for i in range(len(c)):
                while k < len(highs) and highs[k][0] <= i:
                    niv = highs[k][1]
                    k += 1
                nivs[i] = niv
            sig |= (h > nivs) & (c < nivs) & np.isfinite(nivs)

    idx = np.flatnonzero(sig)
    idx = idx[(idx >= CF.ATR_N + 5) & (idx < len(c) - HOLD - 2)]
    garde, dernier_i = [], -10 ** 9
    for i in idx:
        if i - dernier_i >= HOLD:
            garde.append(i)
            dernier_i = i
    return np.array(garde, dtype=int)


def main():
    pairs = PAIRES or sorted(p.name[:-7] for p in (B / CORPUS).glob("*_M1.csv"))
    print("%s : %d paires | trame %d min | ZigZag %.1f ATR | detention %d barres"
          % (CORPUS, len(pairs), TF_MIN, CF.ZIG_ATR, HOLD))
    lignes = []
    for p in pairs:
        M = CF.grille(p)
        if M is None:
            continue
        atr = CF.atr_serie(M)
        cls = "INDICE" if p.endswith(".IDX") else CLASSE.get(p, "FX")
        for famille in ("STRUCT_CONT", "BOS_RETEST", "SWEEP"):
            for sens in ("L", "S"):
                sig = signaux_structure(M, atr, famille, sens)
                if len(sig) < 12:
                    continue
                for tpr in TPRS:
                    SB.HOLD = HOLD
                    m = CP.mesure_dir(M, sig, sens, tpr)
                    if m is None or m["sd"] <= 0:
                        continue
                    off = OFFSETS[cls][0 if sens == "S" else 1]
                    att = m["R"] - off
                    theta = max(att, 0.0) ** 2 * m["n"] / m["sd"] ** 2 / 6.0
                    ok = att > 0 and m["n_pos"] >= (2.0 / 3.0) * m["n_an"]
                    lignes.append(dict(paire=p, famille=famille, sens=sens, tpr=tpr, n=m["n"], R=m["R"],
                                       sigma=m["sd"], gagn=m["gagn"], attendu=att, theta=theta,
                                       npos=m["n_pos"], nan=m["n_an"], retenu=ok,
                                       annees=" ".join("%d %+.2f" % (y, v) for y, v in m["ans"].items())))
                    if ok:
                        print("%-10s %-12s %-4s %5d %+9.4f %7.1f %3d/%-2d RETENU"
                              % (p, famille, sens, m["n"], att, m["gagn"], m["n_pos"], m["n_an"]), flush=True)
        del M
    if not lignes:
        print("  aucune mesure")
        return 1
    with SORTIE.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(lignes[0].keys()))
        w.writeheader()
        w.writerows(lignes)
    ret = [x for x in lignes if x["retenu"]]
    print("\n=== %d mesures | %d retenues ===" % (len(lignes), len(ret)))
    for fam in ("STRUCT_CONT", "BOS_RETEST", "SWEEP"):
        g = [x for x in ret if x["famille"] == fam]
        if not g:
            print("  %-12s 0 retenue" % fam)
            continue
        print("  %-12s %3d retenues | R/tx moy %+.4f | meilleur %+.4f (%s)"
              % (fam, len(g), sum(x["attendu"] for x in g) / len(g),
                 max(g, key=lambda x: x["attendu"])["attendu"],
                 max(g, key=lambda x: x["attendu"])["paire"]))
    print("-> %s" % SORTIE.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
