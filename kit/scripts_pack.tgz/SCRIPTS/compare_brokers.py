# -*- coding: utf-8 -*-
"""compare_brokers.py — comparaison du portefeuille sur les DEUX brokers.

METHODE
  Dukascopy a 6 ans, Upcomers a 8 mois. On ne peut donc PAS comparer les
  totaux. On compare sur la PERIODE COMMUNE : 2026-01-12 -> 2026-09-11.

  Pour Dukascopy, on rejoue les series du portefeuille et on coupe a la
  periode commune. Pour Upcomers, on utilise les comptes du backtest MT5.

  On compare :
    - le nombre de signaux de chaque jambe
    - le signe du R (la jambe gagne-t-elle sur les DEUX flux ?)

C'est le test de ROBUSTESSE : une jambe positive sur les deux brokers n'est pas
un artefact de flux.
"""
import os, sys, json, glob
import numpy as np
import pandas as pd

BASE = r"C:\EAFarm\HISTORY - Copy\research"
UP_FROM = pd.Timestamp("2026-01-12", tz="UTC")
UP_TO = pd.Timestamp("2026-09-11", tz="UTC")

# ---- resultats MT5 Upcomers ----
up = json.load(open(os.path.join(BASE, "up_results.json"), encoding="utf-8"))
print("=== UPCOMERS (MT5, 2026-01-12 -> 2026-09-11) ===")
for s in sorted(up):
    c = up[s]
    print(f"  {s:<9}{sum(c.values()):>6} entrees  {dict(c)}")

# ---- portefeuille ----
P = json.load(open(os.path.join(BASE, "portfolio_final.json"), encoding="utf-8"))
LEGS = P["legs"]

# ---- series Dukascopy (pos_cache) ----
legs = {}
for p in sorted(glob.glob(os.path.join(BASE, "pos_cache", "*.pkl"))):
    try:
        d = pickle_load = None
        import pickle
        d = pickle.load(open(p, "rb"))
    except Exception:
        continue
    for k, v in d.items():
        if isinstance(v, dict) and v.get("ser") is not None and len(v["ser"]) > 0:
            legs[k] = v

print("\n" + "=" * 88)
print("COMPARAISON SUR LA PERIODE COMMUNE (Dukascopy vs Upcomers)")
print("=" * 88)
print(f"{'marche':<9}{'declencheur':<14}{'Duka_6ans':>10}{'Duka_8m':>9}"
      f"{'Upcomers':>10}{'accord':>8}")

rows = []
for L in LEGS:
    sym = L["sym"]; dn = L["defn"]; fl = L.get("filt") or ""
    key = f"{sym}|{dn}|{fl or 'none'}"
    # Dukascopy : serie complete et coupee
    ser = legs.get(key, {}).get("ser")
    n_8m = 0; sgn_8m = None
    if ser is not None:
        sub = ser[(ser.index >= UP_FROM) & (ser.index <= UP_TO)]
        n_8m = int((sub != 0).sum())
        sgn_8m = float(sub.sum())
    # Upcomers
    n_up = sum(up.get(sym, {}).values())
    mt = list(up.get(sym, {}).keys())
    print(f"{sym:<9}{dn:<14}{L['n']:>10}{n_8m:>9}{n_up:>10}", end="")
    # accord : les deux prennent des trades, ou aucun des deux
    if (n_8m > 0 and n_up > 0) or (n_8m == 0 and n_up == 0):
        print(f"{'OUI':>8}")
    else:
        print(f"{'NON':>8}")
    rows.append(dict(sym=sym, defn=dn, filt=fl, n_duka=L["n"], n_8m=n_8m,
                     R_8m=sgn_8m, n_up=n_up, up_trig=",".join(mt)))

json.dump(rows, open(os.path.join(BASE, "broker_compare.json"), "w"),
          indent=1, default=str)

print()
print("=" * 88)
print("LECTURE")
print("=" * 88)
print("  Duka_6ans = trades sur 6 ans (Python)")
print("  Duka_8m   = trades sur la MEME periode que Upcomers")
print("  Upcomers  = trades reels mesures par MT5 sur le 2e broker")
print()
n_ok = sum(1 for r in rows if (r["n_8m"] > 0) == (r["n_up"] > 0))
print(f"  {n_ok}/{len(rows)} jambes ont le meme COMPORTEMENT (trades ou pas)")
print()
print("  ATTENTION : Upcomers ne fournit que 8 mois M5. Un nombre de trades")
print("  plus faible (20-60 au lieu de 80-800) est NORMAL et attendu : la")
print("  periode est ~10x plus courte.")
