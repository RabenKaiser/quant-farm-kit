# -*- coding: utf-8 -*-
"""elaguer2.py — ELAGAGE PAR PAIRE (v2, 17/09 21 h 30).

CE QUI ETAIT FAUX. La premiere version ecrivait des identifiants GLOBAUX dans
lab_black.txt (ex. "NEST3_E|NONE|FIB_FVG_M30|L"). L'EA les lisait comme une
interdiction globale : la combinaison n'etait plus mesuree sur AUCUNE paire.
Or le tri ne porte que sur 5 paires.

Mesure du degat (verif_portefeuille.py) : sur les 21 lignes du portefeuille
construit sur les fenetres du plan classique, 16 etaient ecartees a tort --
dont NEST3_E|FIB_FVG_M30|L, R +0.674 sur USDCAD, uniquement parce qu'elle avait
echoue sur EURUSD. On confondait une propriete de la COMBINAISON et une
propriete du COUPLE (combinaison, paire).

LA REGLE DE CETTE VERSION
  Une mesure directe (plan classique, 4 a 5 trimestres, n >= 8) PRIME sur le
  tri fait sur deux mois. Concretement :
    1. un couple (ID, PAIRE) qui a un R positif sur le plan classique n'est
       JAMAIS ecarte, quel que soit le tri ;
    2. un couple qui echoue au tri est ecrit sous la forme "ID|PAIRE" : il
       n'est ecarte que sur cette paire ;
    3. une combinaison qui echoue sur TOUTES les paires ou elle a ete mesuree
       au tri (et qui n'est pas protegee) est ecrite globalement ;
    4. les entrees globales heritees de la version precedente sont CONSERVEES,
       sauf celles qui contredisent une mesure directe positive.

USAGE : python elaguer2.py [--simuler]
"""
import collections
import json
import statistics
import sys
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
BLACK = (Path.home() / "AppData/Roaming/MetaQuotes/Terminal/Common/Files"
         / "lab_black.txt")
ARCHIVE = (Path.home() / "AppData/Roaming/MetaQuotes/Terminal/Common/Files"
           / "lab_black_v1_global.txt")
TRI = {"2024.01", "2024.07"}
Q = {"2024Q1", "2024Q2", "2024Q3", "2024Q4", "2025Q1"}
PAIRES = ["EURUSD", "USDJPY", "EURJPY", "AUDJPY", "GBPJPY",
          "USDCAD", "CADJPY", "NZDUSD"]
OUT = BASE / "ELAGAGE.md"


def lire():
    """Un seul passage sur 440 Mo : on ramasse le tri ET le classique."""
    tri, cla = collections.defaultdict(dict), collections.defaultdict(dict)
    with open(BASE / "lab_results.jsonl", encoding="utf-8") as fh:
        for line in fh:
            if not line.strip():
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            if "r_x54" not in r:
                continue
            p = str(r.get("period", ""))
            if p in TRI:
                tri[(r["id"], r["sym"])][p] = r
            elif p in Q and r["n"] >= 3:
                cla[(r["id"], r["sym"])][p] = r
    return tri, cla


def main():
    simuler = "--simuler" in sys.argv
    tri, cla = lire()
    print("=" * 90)
    print("ELAGAGE PAR PAIRE v2 — %d couples mesures au TRI, %d au CLASSIQUE"
          % (len(tri), len(cla)))

    # ------------------------------------------------------------------ 1
    # EVIDENCE DIRECTE : qui a gagne sur le plan classique ?
    proteges, evid = set(), {}
    for (cid, sym), d in cla.items():
        v = [r["r_x54"] for r in d.values()]
        n = sum(r["n"] for r in d.values())
        R = statistics.mean(v)
        if R > 0 and n >= 8 and len(v) >= 2:
            proteges.add((cid, sym))
            evid[(cid, sym)] = (R, n, len(v))
    ids_proteges = {c for c, _ in proteges}
    print("\n1. COUPLES PROTEGES PAR UNE MESURE DIRECTE POSITIVE")
    print("   R > 0, n >= 8, au moins 2 trimestres : %d couples, %d combinaisons"
          % (len(proteges), len(ids_proteges)))
    porto = set()
    par = collections.defaultdict(list)
    for (cid, sym), d in cla.items():
        if sym in PAIRES and len(d) >= 4:
            par[sym].append((cid, statistics.mean([r["r_x54"]
                                                   for r in d.values()])))
    for sym, lst in par.items():
        lst.sort(key=lambda x: -x[1])
        porto |= {(c, sym) for c, _ in lst[:3]}
    print("   portefeuille classique (%d lignes) : %d deja protegees"
          % (len(porto), len(porto & proteges)))

    # ------------------------------------------------------------------ 2
    # TRI : qui echoue, et ou ?
    couples = []
    for (cid, sym), d in tri.items():
        couples.append(dict(
            id=cid, sym=sym,
            R=statistics.mean([r["r_x54"] for r in d.values()]),
            n=sum(r["n"] for r in d.values()), nf=len(d)))
    ecartes = [c for c in couples if c["n"] < 8 or c["nf"] < 2 or c["R"] <= 0]
    for c in couples:
        c["ecarte"] = c in ecartes
    print("\n2. TRI")
    print("   couples mesures              : %d" % len(couples))
    print("   couples ecartes par le tri   : %d (%.0f %%)"
          % (len(ecartes), 100.0 * len(ecartes) / max(1, len(couples))))
    print("     dont rares (< 8 trades)    : %d"
          % sum(1 for c in ecartes if c["n"] < 8))
    print("     dont vus sur 1 seule fen.  : %d"
          % sum(1 for c in ecartes if c["nf"] < 2))
    print("     dont R negatif             : %d"
          % sum(1 for c in ecartes if c["R"] <= 0 and c["nf"] >= 2))

    # combinaisons qui echouent PARTOUT (parmi les non protegees)
    tot, bons = collections.Counter(), collections.Counter()
    for c in couples:
        tot[c["id"]] += 1
        if not c["ecarte"]:
            bons[c["id"]] += 1
    globales = {cid for cid in tot
                if bons[cid] == 0 and cid not in ids_proteges}
    parpaire = {(c["id"], c["sym"]) for c in ecartes
                if c["id"] not in globales and (c["id"], c["sym"]) not in proteges}
    print("\n3. CE QU'ON ECRIT")
    print("   combinaisons ecartees partout : %d" % len(globales))
    print("   couples ecartes sur 1 paire   : %d" % len(parpaire))

    # ------------------------------------------------------------------ 3
    anciens = set()
    if BLACK.exists():
        anciens = {l.strip() for l in BLACK.read_text().splitlines() if l.strip()}
    degeles = {g for g in anciens if g in ids_proteges}
    if not simuler and anciens and not ARCHIVE.exists():
        ARCHIVE.write_text("\n".join(sorted(anciens)) + "\n", encoding="ascii")
    nouveaux = (anciens - degeles) | globales
    nouveaux |= {"%s|%s" % (c, s) for c, s in parpaire}
    print("\n4. LISTE NOIRE")
    print("   avant                         : %d" % len(anciens))
    print("   dont degeles (mesure directe) : %d combinaisons" % len(degeles))
    for g in sorted(degeles)[:6]:
        e = next((evid[k] for k in evid if k[0] == g), None)
        print("      %-46s R %+.3f" % (g[:46], e[0] if e else 0.0))
    print("   ajout global                  : %d" % len(globales - anciens))
    print("   ajout par paire               : %d" % len(parpaire))
    print("   apres                         : %d" % len(nouveaux))

    # ------------------------------------------------------------------ 4
    # LE CONTROLE QUI COMPTE
    bl = nouveaux
    ecrases = [(c, s) for (c, s) in porto
               if c in bl or ("%s|%s" % (c, s)) in bl]
    print("\n5. CONTROLE DU PORTEFEUILLE")
    print("   lignes du portefeuille        : %d" % len(porto))
    print("   lignes encore ecrasees        : %d %s"
          % (len(ecrases), "OK" if not ecrases else "*** A CORRIGER ***"))
    for c, s in ecrases[:8]:
        print("      %-40s %s" % (c[:40], s))

    if simuler:
        print("\n(simulation : lab_black.txt inchange)")
        return
    BLACK.write_text("\n".join(sorted(nouveaux)) + "\n", encoding="ascii")
    print("\n   -> %s" % BLACK)
    print("   -> archive de la liste precedente : %s" % ARCHIVE.name)


if __name__ == "__main__":
    main()
