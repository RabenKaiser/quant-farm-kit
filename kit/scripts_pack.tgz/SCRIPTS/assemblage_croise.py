"""assemblage_croise : les jambes qui sont positives SUR LES DEUX FEEDS.

Le point du round 256-257 : les +0,07 a +0,15 R/tx mesures sur 8 mois Upcomers 2026 ne
valent rien s'ils ne survivent pas au corpus long Dukascopy (~6,5 ans). Ce script mesure
donc CHAQUE paire sur les deux corpus avec exactement le meme code (compte_final.trades_pair)
et ne garde que les jambes positives des DEUX cotes. Ensuite il simule le portefeuille
croise sur chaque feed, separement, a plusieurs risques.

Sortie : tableau croise + simulations + (option DETAIL) mois par mois.
"""
import os
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compte_final as C
import sweep_256 as SW

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
COURT = ("EURCHF", "GBPCHF", "USDCHF", "EURGBP", "USDCAD", "EURAUD", "GBPUSD",
         "EURCAD", "EURUSD", "EURJPY", "AUDCAD", "NZDCAD", "AUDUSD", "CADJPY",
         "AUDJPY", "NZDUSD")


def mesure(source, paires):
    C.os.environ["SOURCE"] = source
    out = {}
    for p in paires:
        tr = C.trades_pair(p)
        if not tr:
            out[p] = None
            continue
        an = defaultdict(list)
        for t, r in tr:
            an[t.year].append(r)
        annees = sorted(an)
        out[p] = dict(n=len(tr), r=sum(r for _, r in tr) / len(tr), trades=tr,
                      par_an=dict((y, sum(an[y]) / len(an[y])) for y in annees),
                      pos=sum(1 for y in annees if sum(an[y]) > 0), na=len(annees))
        print("  %-9s %-10s %6d tx  R/tx %+.4f  annees+ %d/%d"
              % (source, p, out[p]["n"], out[p]["r"], out[p]["pos"], out[p]["na"]), flush=True)
    return out


def main():
    court = list(COURT) + ["SPXUSD", "NSXUSD", "SPCUSD.c", "DJCUSD.c", "XAUUSD"]
    long_ = sorted(f[:-7] for f in os.listdir(str(B / "m1_pos")) if f.endswith("_M1.csv"))
    paires = sorted(set(court) | set(long_))
    print("%d paires a mesurer sur les deux feeds" % len(paires), flush=True)

    print("\n--- feed Upcomers 2026", flush=True)
    up = mesure("m1_upcomers", paires)
    print("\n--- feed Dukascopy long", flush=True)
    po = mesure("m1_pos", paires)

    lignes = ["# Assemblage croise : jambes positives sur LES DEUX feeds", "",
              "Motif SR n=50 COURT, stop 1 ATR, cible 1 R, detention 32 barres M30, premier toucher "
              "(egalite = stop), cout = spread median non nul x tick deduit / ATR median.", "",
              "| paire | R/tx Upcomers 2026 | R/tx Dukascopy long | annees + (long) | verdict |",
              "|---|---|---|---|---|"]
    croise = []
    for p in paires:
        u, g = up.get(p), po.get(p)
        su = ("%+.4f" % u["r"]) if u else "-"
        sg = ("%+.4f" % g["r"]) if g else "-"
        sa = ("%d/%d" % (g["pos"], g["na"])) if g else "-"
        if u and g and u["r"] > 0 and g["r"] > 0:
            verdict = "RETENUE"
            croise.append(p)
        elif u and g:
            verdict = "rejetee"
        else:
            verdict = "donnees manquantes"
        lignes.append("| %s | %s | %s | %s | %s |" % (p, su, sg, sa, verdict))
    print("\njambes RETENUES (positives sur les deux feeds) : %s" % (", ".join(croise) or "aucune"), flush=True)
    lignes += ["", "## Jambes retenues : " + (", ".join(croise) if croise else "AUCUNE"), ""]

    if not croise:
        (B / "assemblage_croise.md").write_text("\n".join(lignes), encoding="utf-8")
        return 0

    risques = [float(x) for x in os.environ.get("RISQUES", "0.5,1.0,2.0,3.0").split(",")]
    for source, dat in (("m1_upcomers", up), ("m1_pos", po)):
        sous = dict((p, dat[p]["trades"]) for p in croise if dat.get(p))
        if len(sous) < 2:
            continue
        lignes += ["", "## Simulation sur %s (%d jambes)" % (source, len(sous)), "",
                   "| plafond/devise | risque | trades pris | R/tx | mois moy | pire mois | mois + | DD max | coupe |",
                   "|---|---|---|---|---|---|---|---|---|"]
        for cap in (1, 2, 0):
            for rk in risques:
                r = SW.simule(sous, rk, len(sous), cap)
                print("  %-11s cap %-4s risque %.1f %% : pris %5d | R/tx %+.4f | mois %+.2f %% | pire %+.2f %% | DD %.2f %% | %s"
                      % (source, cap or "aucun", rk, r["pris"], r["r_tx"], r["mois_moy"], r["pire"], r["dd"],
                         ("COUPE " + r["coupe"]) if r["coupe"] else "ok"), flush=True)
                lignes.append("| %s | %.1f %% | %d | %+.4f | %+.2f %% | %+.2f %% | %d/%d | %.2f %% | %s |"
                              % (cap or "aucun", rk, r["pris"], r["r_tx"], r["mois_moy"], r["pire"],
                                 r["mois_pos"], r["mois_n"], r["dd"], r["coupe"] or "-"))
                if os.environ.get("DETAIL"):
                    lignes += ["", "<details><summary>%s cap %s risque %.1f %% - mois</summary>" % (source, cap or "aucun", rk), ""]
                    lignes += ["- %s : %+.2f %%" % (m, x) for m, x in r["detail"]]
                    lignes += ["- par annee : " + ", ".join("%d %+.1f %%" % (y, v) for y, v in r["par_an"].items()), "", "</details>", ""]
    out = B / "assemblage_croise.md"
    out.write_text("\n".join(lignes), encoding="utf-8")
    print("ecrit %s" % out, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
