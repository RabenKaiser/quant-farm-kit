import polars as pl
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from pathlib import Path

src = Path(r"C:\EAFarm\HISTORY\chunks\EURUSD_202201.csv")
print("file exists:", src.exists(), src.stat().st_size if src.exists() else None)

lf = pl.scan_csv(
    src,
    schema_overrides={
        "Timestamp": pl.Utf8,
        "Bid price": pl.Float64,
        "Ask price": pl.Float64,
        "Bid volume": pl.Float64,
        "Ask volume": pl.Float64,
    },
    low_memory=True,
)
df = lf.head(5).collect()
print(df)

# test parse
t = df.with_columns(
    pl.col("Timestamp").str.replace(r":(\d{3})$", r".$1").str.to_datetime("%Y%m%d %H:%M:%S%.f").alias("ts"),
)
print(t)
print("null ts count:", t["ts"].null_count())

# test truncate + epoch
t2 = t.with_columns(pl.col("ts").dt.truncate("1m").dt.epoch("s").alias("time"))
print(t2[["ts", "time"]])
