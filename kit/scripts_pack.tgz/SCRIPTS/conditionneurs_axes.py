# -*- coding: utf-8 -*-
"""conditionneurs_axes.py — LA PISTE DES CONDITIONS TIENT-ELLE SUR 2020-2021 ?

C'EST LE TEST DECISIF DE LA SEULE PISTE POSITIVE DE LA NUIT
-----------------------------------------------------------
Trouvaille du 17/09 a 02 h : parmi 58 conditions, quelques-unes ameliorent le R
de facon coherente dans les DEUX moities de 2024-2025 :

    condition        delta A     delta B
    SPR_GAR_LO       +0.0495     +0.0486     <- cout relatif bas
    VOL_GK_HI        +0.0400     +0.0346     <- volatilite elevee
    GARSURP_LO       +0.0370     +0.0306
    KZNY             +0.0190     +0.0271     <- session New York

Mais ces deux moities sont dans la MEME annee, le MEME regime de marche. Depuis
cette nuit, le plan VINTAGE a mesure 2020-2021 (23 couples paire x fenetre sur
32, soit 72 %). C'est un axe REELLEMENT independant -- ces annees n'ont jamais
servi a choisir quoi que ce soit pour le portefeuille actuel.

LA QUESTION, donc : les memes conditions ressortent-elles en 2020-2021 ?
  - SI OUI : c'est le premier effet du projet qui replique sur deux axes
    independants. Il faudrait alors construire une entree autour, viser
    +0.14 R, et la tester en ordres reels.
  - SI NON : meme la piste du cout n'est qu'un classement de plus, et il ne
    reste rien.

PROTOCOLE (ecrit avant de regarder)
  - sortie : r_x47 (SL 12 ATR / TP 1 ATR) ;
  - delta d'une condition = R(trades ou la condition est vraie) - R(tous) ;
  - compare sur 2024-2025 (5 trimestres) et sur 2020-2021 (fenetres vintage) ;
  - une condition RETIENT l'attention si son delta depasse +0.01 R sur les DEUX
    axes, et si elle figure dans le tiers superieur des deux classements ;
  - garde-fou : au moins 6 couples (paire, fenetre) vintage mesures.

USAGE : python conditionneurs_axes.py
"""
import collections
import json
import statistics
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
LIVE = BASE / "lab_results.jsonl"
CH = "r_x47"
Q5 = ["2024Q1", "2024Q2", "2024Q3", "2024Q4", "2025Q1"]
VINT = ["2020.01", "2020.07", "2021.01", "2021.07"]
PAIRES = ["EURUSD", "USDJPY", "EURJPY", "AUDJPY", "GBPJPY",
          "USDCAD", "CADJPY", "NZDUSD"]
EXCLURE = {("USDJPY", "2020.01")}      # mesure sur 129 barres (voir vintage_controle.py)
NMIN = 1000


def main():
    # par condition et par axe : [somme R*n, n] ; et le total par axe
    par_cond = collections.defaultdict(lambda: {"q": [0.0, 0], "v": [0.0, 0]})
    tot = {"q": [0.0, 0], "v": [0.0, 0]}
    couv = collections.defaultdict(set)
    with open(LIVE, encoding="utf-8") as fh:
        for line in fh:
            if ('"%s"' % CH) not in line:
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            p = str(r.get("period", ""))
            if r["n"] < 3 or r.get(CH) is None:
                continue
            if p in Q5:
                axe = "q"
            elif p in VINT and r["sym"] in PAIRES:
                if (r["sym"], p) in EXCLURE:
                    continue
                axe = "v"
                couv[p].add(r["sym"])
            else:
                continue
            tok = r["id"].split("|")
            if len(tok) < 4:
                continue
            v, n = float(r[CH]), float(r["n"])
            tot[axe][0] += v * n
            tot[axe][1] += n
            for f in tok[1:3]:
                if f and f != "NONE":
                    e = par_cond[f][axe]
                    e[0] += v * n
                    e[1] += n

    n_couv = sum(len(s) for s in couv.values())
    print("=" * 100)
    print("LA PISTE DES CONDITIONS TIENT-ELLE SUR L'AXE INDEPENDANT ?")
    print("=" * 100)
    print("   couverture vintage : %d couples (paire x fenetre)" % n_couv)
    for p in sorted(couv):
        print("      %-9s %d paire(s) : %s" % (p, len(couv[p]),
                                               ", ".join(sorted(couv[p]))))
    if n_couv < 6:
        print("   >>> COUVERTURE INSUFFISANTE : on refuse de conclure.")
        return
    rq = tot["q"][0] / tot["q"][1] if tot["q"][1] else 0
    rv = tot["v"][0] / tot["v"][1] if tot["v"][1] else 0
    print()
    print("   R de TOUS les trades : 2024-2025 %+.4f (%d transactions)"
          % (rq, tot["q"][1]))
    print("                          2020-2021 %+.4f (%d transactions)"
          % (rv, tot["v"][1]))
    print()

    res = []
    for f, d in par_cond.items():
        if d["q"][1] < NMIN or d["v"][1] < NMIN:
            continue
        dq = d["q"][0] / d["q"][1] - rq
        dv = d["v"][0] / d["v"][1] - rv
        res.append((f, dq, dv, d["q"][1], d["v"][1]))
    res.sort(key=lambda x: -x[1])
    rangs_q = {x[0]: i + 1 for i, x in enumerate(res)}
    res_v = sorted(res, key=lambda x: -x[2])
    rangs_v = {x[0]: i + 1 for i, x in enumerate(res_v)}
    print("   %-20s %10s %10s %10s %10s %s"
          % ("condition", "delta 24-25", "delta 20-21", "rang 24-25",
             "rang 20-21", "les deux ?"))
    print("   " + "-" * 92)
    retenues = []
    for f, dq, dv, nq, nv in res[:20]:
        ok = (dq > 0.01 and dv > 0.01)
        if ok:
            retenues.append(f)
        print("   %-20s %+10.4f %+10.4f %10d %10d %s"
              % (f[:20], dq, dv, rangs_q[f], rangs_v[f], "OUI" if ok else ""))
    print()
    nq_pos = sum(1 for x in res if x[1] > 0.01)
    nv_pos = sum(1 for x in res if x[2] > 0.01)
    nboth = sum(1 for x in res if x[1] > 0.01 and x[2] > 0.01)
    print("   conditions testees : %d" % len(res))
    print("   positives sur 2024-2025 : %d   sur 2020-2021 : %d   sur LES DEUX : %d"
          % (nq_pos, nv_pos, nboth))
    print("   attendu par hasard : ~%.0f" % (len(res) * (nq_pos / len(res)) *
                                             (nv_pos / len(res))))
    print()
    if nboth <= len(res) * (nq_pos / len(res)) * (nv_pos / len(res)) * 1.5:
        print("   >>> LA PISTE NE REPLIQUE PAS. Le nombre de conditions positives")
        print("       sur les deux axes est celui du hasard. Les effets vus dans")
        print("       les deux moities de 2024-2025 etaient donc propres a cette")
        print("       annee : c'est encore un classement, pas un avantage.")
    else:
        print("   >>> DES CONDITIONS REPLIQUENT SUR LES DEUX AXES : %s"
              % ", ".join(retenues))
        print("       Premier effet du projet a passer deux axes independants.")
        print("       A construire et a tester en ordres reels avant de conclure.")


if __name__ == "__main__":
    main()
