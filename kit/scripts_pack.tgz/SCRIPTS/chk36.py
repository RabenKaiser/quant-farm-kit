﻿import json
sel = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\pos_selection.json", encoding="utf-8"))
print("Jambes EURAUD du portefeuille :")
for L in sel["legs"]:
    if L["sym"]=="EURAUD":
        print(f"  {L['trig']:<12} filt={L.get('filt')} n3={L['n3']:<5} R3={L['R3']:+7.1f}")
print()
import json as j
mt5 = j.load(open(r"C:\EAFarm\HISTORY - Copy\research\mt5_up_results.json", encoding="utf-8"))
m = mt5.get("EURAUD", {})
print("MT5 EURAUD :", m.get("n_mt5"), m.get("triggers"))
print()
print("Baseline python : 1542 (total 6 ans)")
print()
print("MT5 total = 155 seulement. Donc des jambes NE TRADENT PAS.")
