# -*- coding: utf-8 -*-
"""chk_idx_vols_r43.py — vols runs DJCUSD/SPCUSD/FRCEUR matches."""
import sys, glob, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
TARGET = [("DJCUSD", 16, 11051), ("SPCUSD", 18, 10200), ("FRCEUR", 9, 10203)]
for sym, nt, bt in TARGET:
    for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-120:]:
        try:
            runs = F.parse_stream(lp, "V3INT")
        except Exception:
            continue
        for key, data in runs.items():
            s0 = (key.split(" ")[0] or "")
            base = s0.split(",")[0]
            if base.replace(".c", "") != sym:
                continue
            closed = [t for t in data["trades"].values() if t["close"] is not None]
            if len(closed) != nt or abs((data.get("balance") or 0) - bt) > 3:
                continue
            vols = sorted({round(t.get("vol", 0), 2) for t in closed})
            t0 = closed[0]
            print(f"{base}: n={nt} bal={data.get('balance'):.0f} vols={vols}")
            print(f"   ex {t0}")
            break
        else:
            continue
        break
print("FIN")
