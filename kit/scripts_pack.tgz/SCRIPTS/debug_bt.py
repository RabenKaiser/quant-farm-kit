"""Debug backtest : htf_nest signaux existent, pourquoi 0 trades 2024 ?
Teste backtest_m1 (simple) vs backtest_m1_ptrail, et compte les entrées."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
import polars as pl
import numpy as np
import datetime as dt
import edge_correct as ec
import deep_signals as DS

E = lambda s: int(dt.datetime.strptime(s, "%Y-%m-%d").timestamp())
m1 = ec.load_m1("USDJPY")
tf = ec.to_tf(m1, 1800)
a, b = E("2024-01-01"), E("2025-01-01")
tfseg = tf.filter((pl.col("time") >= a) & (pl.col("time") < b))
m1seg = m1.filter((pl.col("time") >= a) & (pl.col("time") < b))
print(f"fenêtre 2024: {len(tfseg)} barres M30, {len(m1seg)} M1")

cfg = dict(htf_sec=14400, lookback=40, sl_atr=1.5, rr=99, pyramid_max=2,
           pyramid_trigger_r=1.5, trail_atr_mult=3.5, trail_trigger_r=1.0,
           commission_rt=4.0, tick_value_per_pt=0.67)
f = DS.htf_nest(tfseg, cfg)
n_sig = int((f["sig"] != 0).sum())
print(f"signaux dans 2024: {n_sig}")

# backtest simple (SL/TP fixe, rr=99 -> TP énorme)
tr1 = ec.backtest_m1(m1seg, tfseg, f, "USDJPY", dict(cfg, rr=2.0))
print(f"backtest_m1 (rr=2.0): {len(tr1)} trades")
tr2 = ec.backtest_m1(m1seg, tfseg, f, "USDJPY", dict(cfg))
print(f"backtest_m1 (rr=99): {len(tr2)} trades")

# ptrail
try:
    tr3 = ec.backtest_m1_ptrail(m1seg, tfseg, f, "USDJPY", cfg)
    print(f"backtest_m1_ptrail: {len(tr3)} trades")
    if tr3:
        nets = [t["r"]-t["cost_r"] for t in tr3]
        print(f"  net/trade={np.mean(nets):+.3f} total={sum(nets):+.1f}")
except Exception as e:
    print(f"ptrail ERREUR: {e}")
