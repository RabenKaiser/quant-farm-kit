# -*- coding: utf-8 -*-
"""cmp_w12_w24_r45.py — comparer VWAPTREND XAU win12-c20 vs win24-c20:
equity daily + corr + pire SL reel."""
import sys, glob, os
import pandas as pd
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
# cibles: w12c20 bal~20916 (n=89), w24c20 bal~19800 (n=118)
TARGETS = {"w12c20": (89, 20916), "w24c20": (118, 19800)}
found = {}
for EA in ("VWAPTREND",):
    for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-60:]:
        try:
            runs = F.parse_stream(lp, EA)
        except Exception:
            continue
        for key, data in runs.items():
            if "XAUUSD" not in key or "H1" not in key:
                continue
            closed = [t for t in data["trades"].values() if t["close"] is not None]
            b = data.get("balance") or 0.0
            for tag, (nt, bt) in TARGETS.items():
                if tag in found:
                    continue
                if len(closed) == nt and abs(b - bt) < 5:
                    found[tag] = {"trades": closed, "bal": b, "lp": lp}
if len(found) < 2:
    print("runs pas tous trouves:", {k: bool(v) for k, v in found.items()})
    # fallback: lister candidats
    for EA in ("VWAPTREND",):
        for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-60:]:
            try:
                runs = F.parse_stream(lp, EA)
            except Exception:
                continue
            for key, data in runs.items():
                if "XAUUSD" not in key:
                    continue
                closed = [t for t in data["trades"].values() if t["close"] is not None]
                if len(closed) in (89, 118):
                    print(f"  cand: n={len(closed)} bal={data.get('balance'):.0f} "
                          f"[{os.path.basename(lp)[:20]}]")

for tag in TARGETS:
    if tag not in found:
        continue
    tr = found[tag]["trades"]
    reel = found[tag]["bal"] - 10000
    rows = []
    for t in tr:
        try:
            rows.append((str(t["ts_entry"])[:10], F.pnl_usd(t)))
        except Exception:
            pass
    s = pd.Series([r[1] for r in rows], index=pd.DatetimeIndex([r[0] for r in rows]))
    ds = s.groupby(s.index).sum()
    k = reel / ds.sum() if ds.sum() != 0 else 1.0
    ds = ds * k
    losses = [F.pnl_usd(t) * k for t in tr if F.pnl_usd(t) < 0]
    found[tag]["eq"] = ds
    print(f"{tag}: n={len(tr)} reel={reel:+.0f} sum_j={ds.sum():+.0f} "
          f"pireSL={min(losses) if losses else 0:+.0f} "
          f"SLmoy={sum(losses)/len(losses) if losses else 0:+.0f} "
          f"min/j={ds.min():+.0f} max/j={ds.max():+.0f}")

if len(found) == 2:
    a = pd.concat([found["w12c20"]["eq"].rename("w12"),
                   found["w24c20"]["eq"].rename("w24")], axis=1,
                  join="outer").fillna(0.0)
    a = a.reindex(pd.bdate_range("2026-01-02", "2026-09-01")).fillna(0.0)
    print(f"corr w12-w24 = {a['w12'].corr(a['w24']):.2f}")
    print(f"w12 sum {a['w12'].sum():+.0f} std {a['w12'].std():.1f} | "
          f"w24 sum {a['w24'].sum():+.0f} std {a['w24'].std():.1f}")
    both = a.sum(axis=1)
    print(f"combine simple: sum {both.sum():+.0f} std {both.std():.1f}")
print("FIN", flush=True)
