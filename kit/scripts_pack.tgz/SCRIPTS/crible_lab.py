# -*- coding: utf-8 -*-
"""crible_lab.py — LE CRIBLE SUR LE LABO : MELANGE DE PERIODES, MILLIERS DE
COMBINAISONS, EN UNE SEULE PASSE.

DEMANDE DE L'UTILISATEUR (18/09, 19 h) : "fais attention au labo parce qu'il
peut tester beaucoup de trucs en meme temps. Et melange les periodes hostiles et
les bonnes. Et cree de vrais trades comme des combinaisons d'un paquet de trucs,
tout en ayant un bon nombre de trades."

C'EST EXACTEMENT CE QUE LE LABO FAIT MIEUX QUE LA SIMULATION
------------------------------------------------------------
Une passe du labo mesure TOUTE la grille (2 100 a 4 500 combinaisons) d'un coup.
On a donc, dans la base, des dizaines de milliers de lignes (combinaison, paire,
periode) deja mesurees. Il suffit de les croiser.

LE MELANGE DE PERIODES, ET POURQUOI C'EST LA BONNE FACON DE CHERCHER
    HOSTILES     2024Q1 (cout relatif moyen 50 %), 2024Q2,
                 2025Q2, 2025Q3, 2025Q4 (regime nouveau, ATR -27 %)
    BONNES       2024Q3, 2024Q4, 2025Q1
Une combinaison qui ne tient que dans les bonnes periodes est un artefact ; une
combinaison qui tient dans les DEUX est robuste. C'est le critere de retention.

LA COMBINAISON, C'EST DEJA "UN PAQUET DE TRUCS"
    chaque identifiant est  declencheur | filtre1 | filtre2 | sens
donc une ligne de resultat est deja une combinaison de trois mecanismes et d'un
sens. Le crible regarde EN PLUS quelles briques reviennent chez les survivantes.

LE NOMBRE DE TRADES est une contrainte dure : une combinaison qui ne fait que
20 transactions ne prouve rien. On exige au moins 100 transactions cumulees sur
les huit periodes, et on rapporte le nombre de transactions par an.

SORTIE : CRIBLE_LAB.md + affichage du classement.
USAGE : python crible_lab.py [--min-tx 100] [--min-periodes 6]
"""
import argparse
import collections
import json
import statistics
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
LIVE = BASE / "lab_results.jsonl"
HOSTILES = ["2024Q1", "2024Q2", "2025Q2", "2025Q3", "2025Q4"]
BONNES = ["2024Q3", "2024Q4", "2025Q1"]
TOUTES = ["2024Q1", "2024Q2", "2024Q3", "2024Q4", "2025Q1",
          "2025Q2", "2025Q3", "2025Q4"]
PAIRES = ["EURUSD", "USDJPY", "EURJPY", "AUDJPY", "GBPJPY", "USDCAD",
          "CADJPY", "NZDUSD", "EURGBP", "AUDUSD", "NZDJPY", "EURAUD"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--min-tx", type=int, default=100)
    ap.add_argument("--min-periodes", type=int, default=6)
    ap.add_argument("--sortie", default="CRIBLE_LAB.md")
    a = ap.parse_args()

    g = collections.defaultdict(dict)
    with open(LIVE, encoding="utf-8") as fh:
        for line in fh:
            if '"r_x54"' not in line:
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            p = str(r.get("period", ""))
            if p not in TOUTES or r["n"] < 3 or r["sym"] not in PAIRES:
                continue
            g[(r["id"], r["sym"])][p] = (float(r["r_x54"]), int(r["n"]))

    print("=" * 100)
    print("CRIBLE SUR LE LABO — MELANGE DE PERIODES HOSTILES ET BONNES")
    print("=" * 100)
    print("   couples (combinaison, paire) mesures : %d" % len(g))
    rep = collections.Counter(len(d) for d in g.values())
    print("   nombre de periodes mesurees par couple : %s"
          % ", ".join("%d periodes=%d" % (k, v) for k, v in sorted(rep.items())))

    res = []
    for (cid, sym), d in g.items():
        if len(d) < len(TOUTES):
            continue
        par_per = {p: d[p][0] for p in TOUTES}
        tx = sum(d[p][1] for p in TOUTES)
        if tx < a.min_tx:
            continue
        npos = sum(1 for v in par_per.values() if v > 0)
        pire = min(par_per.values())
        # moyenne ponderee par les transactions
        num = sum(d[p][0] * d[p][1] for p in TOUTES)
        moy = num / tx
        # comportement separe sur les deux familles de periodes
        th = sum(d[p][1] for p in HOSTILES)
        rh = sum(d[p][0] * d[p][1] for p in HOSTILES) / th if th else None
        tb = sum(d[p][1] for p in BONNES)
        rb = sum(d[p][0] * d[p][1] for p in BONNES) / tb if tb else None
        res.append(dict(id=cid, sym=sym, tx=tx, moy=moy, pire=pire,
                        npos=npos, rh=rh, rb=rb, par_per=par_per))
    print("   couples avec les 8 periodes et >= %d transactions : %d"
          % (a.min_tx, len(res)))
    print()
    retenus = [x for x in res if x["npos"] >= a.min_periodes and x["pire"] > 0]
    retenus.sort(key=lambda x: -x["pire"])
    print("   RETENUS (au moins %d periodes positives sur 8, et PIRE periode > 0)"
          % a.min_periodes)
    print("   -> %d configurations" % len(retenus))
    print()
    if retenus:
        print("   %-38s %-7s %6s %8s %8s %8s %8s"
              % ("combinaison", "paire", "tx", "R moyen", "PIRE", "hostile",
                 "bonnes"))
        for x in retenus[:25]:
            print("   %-38s %-7s %6d %+8.4f %+8.4f %+8.4f %+8.4f"
                  % (x["id"][:38], x["sym"], x["tx"], x["moy"], x["pire"],
                     x["rh"] or 0, x["rb"] or 0))
        print()
        # quelles briques reviennent ?
        briques = collections.Counter()
        paires_c = collections.Counter()
        for x in retenus:
            tok = x["id"].split("|")
            for b in tok:
                if b and b != "NONE":
                    briques[b] += 1
            paires_c[x["sym"]] += 1
        print("   BRIQUES QUI REVIENNENT CHEZ LES SURVIVANTES")
        for b, n in briques.most_common(15):
            print("      %-22s dans %d configurations sur %d"
                  % (b, n, len(retenus)))
        print("   PAIRES : %s"
              % ", ".join("%s=%d" % kv for kv in paires_c.most_common()))
    else:
        print("   >>> AUCUNE combinaison avec les 8 periodes et %d positives."
              % a.min_periodes)
        # on relache d'un cran pour voir ce qui s'en approche
        proche = sorted(res, key=lambda x: (-x["npos"], -x["pire"]))[:15]
        print("   Les plus proches :")
        print("   %-38s %-7s %6s %8s %8s %s"
              % ("combinaison", "paire", "tx", "R moyen", "PIRE", "positives"))
        for x in proche:
            print("   %-38s %-7s %6d %+8.4f %+8.4f %d/8"
                  % (x["id"][:38], x["sym"], x["tx"], x["moy"], x["pire"],
                     x["npos"]))
    # --- rapport --------------------------------------------------------
    with open(BASE / a.sortie, "w", encoding="utf-8") as fh:
        fh.write("# CRIBLE SUR LE LABO — melange de periodes\n\n")
        fh.write("Periodes HOSTILES : %s\n\n" % ", ".join(HOSTILES))
        fh.write("Periodes BONNES : %s\n\n" % ", ".join(BONNES))
        fh.write("Contrainte de volume : au moins %d transactions.\n\n" % a.min_tx)
        fh.write("Couples evalues : %d. Retenus (>= %d periodes positives sur 8) : %d\n\n"
                 % (len(res), a.min_periodes, len(retenus)))
        fh.write("| combinaison | paire | tx | R moyen | PIRE | hostile | bonnes |\n")
        fh.write("|---|---|---|---|---|---|---|\n")
        for x in retenus[:80]:
            fh.write("| %s | %s | %d | %+.4f | %+.4f | %s | %s |\n"
                     % (x["id"], x["sym"], x["tx"], x["moy"], x["pire"],
                        ("%+.4f" % x["rh"]) if x["rh"] is not None else "-",
                        ("%+.4f" % x["rb"]) if x["rb"] is not None else "-"))
    print()
    print("   -> %s" % (BASE / a.sortie))


if __name__ == "__main__":
    main()
