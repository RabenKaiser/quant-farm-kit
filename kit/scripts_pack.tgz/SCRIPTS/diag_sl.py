# -*- coding: utf-8 -*-
"""diag_sl.py — POURQUOI MT5 PERD ALORS QUE PYTHON GAGNE ?

CONSTAT (round 59)
------------------
CADJPY, parametres IDENTIQUES des deux cotes (SL=2 ATR, TP=3 R, hold=48) :

    python (legs_v2)  : 66-79 % de reussite, R_d = +544 / +910
    MT5 (ORION BILAN) : 31.2 % de reussite, 89 SL / 2 TP / 53 maxhold,
                        pnl = -641.87

Meme strategie, meme paire, memes parametres, resultat OPPOSE. Il faut trancher.

HYPOTHESES A TESTER
-------------------
H1. Le SL reel n'est pas 2 ATR.
    L'EA calcule risk = sl_atr * atr avec atr = RefAtr(i) = buffer 0 d'un
    handle ATR M15 (CopyBuffer(h, 0, 1, 1)). Le backtest python utilise un ATR
    M5 (ewm alpha=1/14). Un ATR M15 est plus GRAND qu'un ATR M5 (environ x1.7
    sur du bruit aleatoire) -> si l'EA prend l'ATR M15, le SL reel est ~1.7x
    plus large que prevu... ce qui DEVRAIT reduire les SL touches, pas les
    augmenter. A verifier dans les deux sens.

H2. L'entree n'est pas au meme prix.
    python : entry = open de la barre i+1.
    MT5 : market order au tick courant, donc plutot le close de la barre i.
    Un ecart systematique d'1 spread + 1 mouvement peut suffire a faire
    toucher un SL a 2 ATR.

H3. Le TP est trop loin en pratique.
    Seulement 2 TP sur 144 sorties (1 %). En python on attend 51 % de
    gagnants. Le TP a 3 R (= 6 ATR) n'est presque JAMAIS atteint en MT5.

H4. Le hold coupe trop tot.
    53 sorties sur 144 (37 %) sont des maxhold. En python, hold=48 barres.

CE SCRIPT : verifie H1 en priorite (c'est la plus mesurable), en comparant
l'ATR M5 et l'ATR M15 sur les vraies bougies, puis en recalculant ce que
donne le vrai SL en points.

MESURE DIRECTE DISPONIBLE : les lignes ORION OPEN du log contiennent
atr=, sl=, tp=. On peut donc extraire le SL reel et le comparer a l'ATR M5.
"""
import re, json
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
LOGD = (Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")
        / "CF0B997454318B475CF01419AFE2BBF3" / "Tester" / "logs")


def read_txt(lf):
    raw = open(lf, "rb").read()
    return (raw.decode("utf-16") if raw[:2] in (b"\xff\xfe", b"\xfe\xff")
            else raw.decode("utf-8", errors="replace"))


def latest_log():
    c = []
    for pat in ("*log*",):
        c += list(LOGD.glob(pat))
    c = [p for p in c if p.stat().st_size > 500]
    return max(c, key=lambda p: p.stat().st_mtime)


def m5(sym):
    p = BASE / "m1_pos" / f"{sym}_M1.csv"
    if not p.exists():
        return None
    df = pd.read_csv(p, usecols=["time", "open", "high", "low", "close"])
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time").sort_index()
    return pd.DataFrame({
        "open": df["open"].resample("5min").first(),
        "high": df["high"].resample("5min").max(),
        "low": df["low"].resample("5min").min(),
        "close": df["close"].resample("5min").last()}).dropna()


def m15(df):
    return pd.DataFrame({
        "open": df["open"].resample("15min").first(),
        "high": df["high"].resample("15min").max(),
        "low": df["low"].resample("15min").min(),
        "close": df["close"].resample("15min").last()}).dropna()


def atr_ewm(d, n=14):
    h = d["high"].to_numpy(float); l = d["low"].to_numpy(float)
    c = d["close"].to_numpy(float)
    pc = np.roll(c, 1); pc[0] = c[0]
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    return pd.Series(tr).ewm(alpha=1/n, adjust=False).mean().to_numpy()


SYM = "CADJPY"
lf = latest_log()
txt = read_txt(lf)
print(f"log : {lf.name}")

# ---- entrees MT5 : atr, sl, tp ----
pat = re.compile(r"(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s+ORION OPEN "
                 r"%s (\w+) side=(-?\d+) magic=(\d+) atr=([\d.]+) lots=([\d.]+) "
                 r"sl=([\d.]+) tp=([\d.]+)" % SYM)
ent = []
for m in pat.finditer(txt):
    ent.append(dict(t=m.group(1), trig=m.group(2), side=int(m.group(3)),
                    magic=m.group(4), atr=float(m.group(5)),
                    lots=float(m.group(6)), sl=float(m.group(7)),
                    tp=float(m.group(8))))
print(f"entrees parsees : {len(ent)}")
if not ent:
    raise SystemExit("aucune entree — verifier le format du log")

d5 = m5(SYM)
a5 = atr_ewm(d5)
a15 = atr_ewm(m15(d5))

# ---- H1 : SL reel (en points) vs 2*AtrM5 ----
print()
print("=" * 84)
print("H1 — LE SL REEL CORRESPOND-IL A 2 x ATR M5 ?")
print("=" * 84)
print(f"{'date':<21}{'atr_log':>10}{'sl_reel':>10}{'tp_reel':>10}"
      f"{'SL/atr_log':>12}{'atr_M5_moy':>12}")
rows = []
for e in ent[:14]:
    t = pd.Timestamp(e["t"].replace(".", "-", 2), tz="UTC")
    j = d5.index.get_indexer([t], method="nearest")[0]
    rows.append((e["t"], e["atr"], e["sl"], e["tp"], e["atr"], a5[j]))
    print(f"{e['t']:<21}{e['atr']:>10.5f}{e['sl']:>10.5f}{e['tp']:>10.5f}"
          f"{'?':>12}{a5[j]:>12.5f}")

# le SL en points : distance |entry - sl|. L'entree n'est pas dans le log,
# mais on peut la deduire : tp - sl = 5 * risk (TP=3R, SL=1R, total 4R)
# donc risk = (tp - sl) / 4
print()
print("=" * 84)
print("DEDUCTION DU RISQUE REEL : risk = (tp - sl) / (1 + TP_R)")
print("=" * 84)
ratios = []
for e in ent:
    risk = abs(e["tp"] - e["sl"]) / 4.0        # TP_R = 3 -> 1R + 3R = 4R
    ratios.append(risk / e["atr"] if e["atr"] else np.nan)
ratios = np.array([r for r in ratios if np.isfinite(r)])
print(f"  jambes analysees : {len(ratios)}")
print(f"  risk / atr_log   : moyenne {ratios.mean():.3f}  median {np.median(ratios):.3f}")
print(f"  attendu si SL = sl_atr x atr = 2 x atr : 2.000")
print()
if abs(np.median(ratios) - 2.0) < 0.05:
    print("  -> Le SL vaut bien 2 x l'ATR LOG. Le parametre est applique")
    print("     correctement. L'ecart avec python vient donc d'AILLEURS.")
else:
    print(f"  -> Le SL ne vaut PAS 2 x atr_log (median {np.median(ratios):.3f}).")
    print("     Regarder comment risk est calcule dans TryLeg().")

print()
print("=" * 84)
print("H2 — L'ATR LOG EST-IL UN ATR M15 (plus grand) OU M5 ?")
print("=" * 84)
ks = []
for e in ent[:200]:
    try:
        t = pd.Timestamp(e["t"].replace(".", "-", 2), tz="UTC")
        j = d5.index.get_indexer([t], method="nearest")[0]
        if j > 200:
            ks.append((e["atr"] / a5[j], e["atr"] / a15[j // 3]))
    except Exception:
        pass
ks = np.array([k for k in ks if np.isfinite(k).all()])
if len(ks):
    print(f"  atr_log / atr_M5  : median {np.median(ks[:,0]):.3f}")
    print(f"  atr_log / atr_M15 : median {np.median(ks[:,1]):.3f}")
    print()
    if abs(np.median(ks[:,0]) - 1.0) < abs(np.median(ks[:,1]) - 1.0):
        print("  -> l'ATR du log ressemble a un ATR **M5**")
    else:
        print("  -> l'ATR du log ressemble a un ATR **M15**")
        print("     (le handle est cree sur PERIOD_M15 : voir RefAtr)")

# ---- H3 / H4 : ou sont les sorties ? ----
print()
print("=" * 84)
print("H3/H4 — REPARTITION DES SORTIES")
print("=" * 84)
ex = re.findall(r"ORION EXIT %s magic=(\d+) reason=(-?\d+) profit=(-?[\d.]+)" % SYM, txt)
cnt = {}
for _, r, p in ex:
    cnt.setdefault(int(r), []).append(float(p))
lbl = {3: "EXPERT (maxhold)", 4: "SL", 5: "TP"}
for r, v in sorted(cnt.items()):
    v = np.array(v)
    print(f"  reason={r} {lbl.get(r,'?'):<16} n={len(v):<5} "
          f"win={100*(v>0).mean():>5.1f}%  pnl={v.sum():>9.2f}  "
          f"moy={v.mean():>7.2f}")
