"""CONTROLE DU CRIBLE CONTRE-COURANT : LE HARNAIS EST-IL HONNETE ?

POURQUOI (26/09, 03 h 35). Le crible vient d'afficher des mu de +0,5 a +1,08 R par transaction avec des t
de +15 a +28 sur presque tous les indices. **Un vrai edge ne ressemble pas a cela** : mu = 1,08 avec une
cible de 2 R et un stop de 1 R exige un taux de reussite de 69 % sur un signal de retournement. Avant de
croire quoi que ce soit, on passe le harnais a trois controles :

  1. **temoin de hasard** : memes points d'entree, sens TIRE AU HASARD. Si le hasard donne +0,5, le harnais
     fabrique du gain (regard vers l'avant, cout absent, sortie impossible) et le crible ne vaut rien.
  2. **temoin inverse** : entrer DANS le sens du mouvement. Un signal de retournement et son inverse ne
     peuvent pas etre tous deux gagnants : la somme des deux doit valoir a peu pres le cout.
  3. **repartition des sorties** : part de cible, de stop et d'echeance. Avec une cible a 3 ATR et un stop a
     1,5 ATR sur 64 barres, une jambe saine termine souvent a l'echeance ; si presque tout finit a la
     cible, c'est que la sortie est choisie apres coup.

On mesure ces trois controles sur les memes instruments, avec exactement la meme mecanique.
"""
import sys
import pathlib

import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import barrieres_m1 as BM  # noqa: E402
import crible_contre_courant as C  # noqa: E402

B = pathlib.Path(r"C:\EAFarm\HISTORY - Copy\research")
SYMS = [("m1_ext", "DEU.IDX"), ("m1_ext", "HKG.IDX"), ("m1_real", "XAUUSD")]
MINUTES, SEUIL = 180, 2.0


def joue(D, sens_mode):
    """Meme boucle que le crible, mais le sens vient de `sens_mode` : 'contre', 'avec' ou 'hasard'."""
    t, c, atr = D["t"], D["c30"], D["atr"]
    n = len(t)
    pas = max(1, int(MINUTES / 30))
    idx30 = [i for i in range(n) if i % 30 == 29 or (i + 1 < n and t[i + 1] - t[i] > 60)]
    rng = np.random.default_rng(20260926)
    out, kinds = [], []
    bloque = -1
    for k in range(pas, len(idx30)):
        i, j = idx30[k], idx30[k - pas]
        if i <= bloque or not np.isfinite(atr[i]) or atr[i] <= 0 or not np.isfinite(c[j]):
            continue
        move = c[i] - c[j]
        if abs(move) < SEUIL * atr[i]:
            continue
        contre = "S" if move > 0 else "L"
        if sens_mode == "contre":
            sens = contre
        elif sens_mode == "avec":
            sens = "L" if contre == "S" else "S"
        else:
            sens = "L" if rng.random() < 0.5 else "S"
        r = BM.issue(D, int(t[i]), float(c[i]), float(atr[i]), tpr=C.TPR, slr=C.SLR,
                     hold_min=C.HOLD, sens=sens, r_en_risque=True, par_barres=True)
        if r is None:
            continue
        kind, R, _p, t_sortie = r
        out.append(R)
        kinds.append(kind)
        bloque = int(np.searchsorted(t, t_sortie))
    return out, kinds


def resume(nom, R):
    if len(R) < 20:
        return "  %-26s trop peu de transactions" % nom
    a = np.array(R)
    mu = float(a.mean())
    sd = float(a.std(ddof=1)) if len(a) > 1 else 0.0
    t = mu / (sd / np.sqrt(len(a))) if sd > 0 else 0.0
    return "  %-26s n=%5d  mu %+.4f  t %+.2f" % (nom, len(a), mu, t)


def main():
    print("=" * 118)
    print("CONTROLE DU HARNAIS — signal de retournement a %d ATR en %d min, cible 2 R, stop 1,5 ATR" %
          (SEUIL, MINUTES))
    print("=" * 118)
    lignes = ["# CONTROLE DU CRIBLE CONTRE-COURANT (le harnais est-il honnete ?)", "",
              "Meme mecanique pour les trois lignes : seuls le SENS et le tirage changent. Un vrai signal de",
              "retournement doit etre positif, son inverse negatif, et le hasard proche du cout.", ""]
    for src, sym in SYMS:
        D = C.prepare(sym, src)
        if D is None:
            continue
        print("\n%s (%s)" % (sym, src))
        L = []
        for mode, nom in (("contre", "retournement (le signal)"), ("avec", "inverse (momentum)"),
                          ("hasard", "sens tire au hasard")):
            R, kinds = joue(D, mode)
            print(resume(nom, R))
            L.append((nom, R, kinds))
            if mode == "contre":
                k = np.array(kinds)
                part = "cible %.0f %% | stop %.0f %% | echeance %.0f %%" % (
                    100 * np.mean(k == 0), 100 * np.mean(k == 1), 100 * np.mean(k == 2))
                print("      sorties : " + part)
        lignes.append("\n## %s (%s)\n" % (sym, src))
        for nom, R, _k in L:
            if len(R) < 20:
                continue
            a = np.array(R)
            mu = float(a.mean())
            sd = float(a.std(ddof=1)) if len(a) > 1 else 0.0
            t = mu / (sd / np.sqrt(len(a))) if sd > 0 else 0.0
            lignes.append("- **%s** : n=%d, mu %+.4f, t %+.2f" % (nom, len(a), mu, t))
        # verdict local : si le hasard gagne, le harnais est en cause, pas le signal
        has = np.array(L[2][1])
        if len(has) > 20 and has.mean() > 0.10:
            lignes.append("\n**Le hasard gagne ici (%+.4f)** : le harnais fabrique du gain, aucune "
                          "conclusion n'est possible sur ce corpus." % has.mean())
    (B / "CONTROLE_CRIBLE.md").write_text("\n".join(lignes) + "\n", encoding="utf-8")
    print("\n  rapport ecrit dans CONTROLE_CRIBLE.md")
    print("\n  Lecture : si « sens tire au hasard » n'est pas nettement negatif, le crible est invalide,")
    print("  et les +0,5 a +1,08 R/tx qu'il affichait sont un artefact de mesure.")


if __name__ == "__main__":
    main()
