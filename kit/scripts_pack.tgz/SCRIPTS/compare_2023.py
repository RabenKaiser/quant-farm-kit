"""Comparaison finale : ptrail moteur vs MT5 sur 2023 (la seule fenêtre commune).
Si le moteur fait ~40 trades et MT5 225, le 6x est confirmé = réplication fausse."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
import polars as pl
import numpy as np
import datetime as dt
import edge_correct as ec
import deep_signals as DS

E = lambda s: int(dt.datetime.strptime(s, "%Y-%m-%d").timestamp())
m1 = ec.load_m1("USDJPY")
tf = ec.to_tf(m1, 1800)
a, b = E("2023-01-01"), E("2024-01-01")
tfseg = tf.filter((pl.col("time") >= a) & (pl.col("time") < b))
m1seg = m1.filter((pl.col("time") >= a) & (pl.col("time") < b))
print(f"2023: {len(tfseg)} barres M30")

cfg = dict(htf_sec=14400, lookback=40, sl_atr=1.5, rr=99, pyramid_max=2,
           pyramid_trigger_r=1.5, trail_atr_mult=3.5, trail_trigger_r=1.0,
           commission_rt=4.0, tick_value_per_pt=0.67)
f = DS.htf_nest(tfseg, cfg)
n_sig = int((f["sig"] != 0).sum())
print(f"signaux 2023: {n_sig}")

tr = ec.backtest_m1_ptrail(m1seg, tfseg, f, "USDJPY", cfg)
nets = np.array([t["r"] - t["cost_r"] for t in tr]) if tr else np.array([])
print(f"MOTEUR ptrail 2023: n={len(nets)}")
if len(nets):
    print(f"  net/trade={nets.mean():+.3f} total R={nets.sum():+.1f}")
print(f"MT5 EA 2023: n=225, profit +$1721 (testé plus tôt)")
if len(nets):
    print(f"  écart count: {225/len(nets):.1f}x")
