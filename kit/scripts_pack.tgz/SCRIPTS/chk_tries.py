# -*- coding: utf-8 -*-
"""chk_tries.py — compare le compteur `tries` du DIAG au nombre reel
d'ouvertures (`ORION OPEN`) et de rejets (`ORION REJET`).

POURQUOI : `tries` est incremente AVANT TryLeg. Il ne mesure donc pas les
entrees reelles mais les fois ou le declencheur a tire. Le croisement de
fidelite doit se faire sur `ORION OPEN`, pas sur `tries`.
"""
import os, re

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"

files = [(f, os.path.getmtime(os.path.join(LOGD, f)), os.path.getsize(os.path.join(LOGD, f)))
         for f in os.listdir(LOGD) if ".log" in f]
files.sort(key=lambda x: -x[1])
for f, m, s in files[:10]:
    p = os.path.join(LOGD, f)
    if s < 500:
        continue
    raw = open(p, "rb").read(4)
    enc = "utf-16" if raw[:2] in (b"\xff\xfe", b"\xfe\xff") else "utf-8"
    try:
        txt = open(p, encoding=enc, errors="replace").read()
    except Exception:
        continue
    if "ORION DIAG EURAUD" not in txt:
        continue
    tries = re.findall(r"ORION DIAG EURAUD : tries=(\d+)", txt)
    print(f"--- {f} ---")
    print(f"  tries (DIAG)      : {tries[-1] if tries else 'aucun'}")
    print(f"  ORION OPEN EURAUD : {txt.count('ORION OPEN EURAUD')}")
    print(f"  ORION REJET       : {txt.count('ORION REJET')}")
    # les REJET portent le code d'erreur MT5
    codes = re.findall(r"ORION REJET \S+ \S+ err=(-?\d+)", txt)
    if codes:
        from collections import Counter
        print(f"  codes d'erreur    : {Counter(codes).most_common(5)}")
    break
else:
    print("aucun log avec ORION DIAG EURAUD")
