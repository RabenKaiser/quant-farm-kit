# -*- coding: utf-8 -*-
"""dashboard.py — CONSOLE DE CONTRÔLE ORION (HTML autonome, pour demo investisseurs).

Lit les SORTIES REELLES du projet et genere un fichier HTML unique, sans
dependance externe (pas de CDN, pas de JS a installer) :
    NIGHT2_BEST.json        le portefeuille
    hardtest.json           le protocole de validation
    mt5_orion_results.json  l'arbitrage MT5
    night_orion2.jsonl      la progression de la recherche

Sortie : C:\\EAFarm\\SHARED\\DASHBOARD.html
"""
import json, os, html, datetime as dt, collections

BASE = r"C:\EAFarm\HISTORY - Copy\research"
OUT = r"C:\EAFarm\SHARED\DASHBOARD.html"


def jload(p, default=None):
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return default


PF = jload(os.path.join(BASE, "NIGHT2_BEST.json"), {}) or {}
HT = jload(os.path.join(BASE, "hardtest.json"), {}) or {}
MT = jload(os.path.join(BASE, "mt5_orion_results.json"), {}) or {}

rounds = 0
lp = os.path.join(BASE, "night_orion2.jsonl")
if os.path.exists(lp):
    with open(lp, encoding="utf-8") as f:
        for _ in f:
            rounds += 1

units = PF.get("units", [])
syms = collections.Counter(u["sym"] for u in units)
TRIG = collections.Counter(u["trigL"] for u in units)
FILT = collections.Counter(f for u in units for f in u.get("filtL", []))


def n(x, d=2):
    try:
        return f"{float(x):,.{d}f}".replace(",", " ")
    except Exception:
        return "—"


def pct(x):
    try:
        return f"{float(x):.2f} %"
    except Exception:
        return "—"


V = HT.get("variants", {})
base = V.get("base") or {}
sp2 = V.get("sp2") or {}
sp3 = V.get("sp3") or {}
nt = V.get("notrail") or {}

KPI = [
    ("CA / MOIS", pct(PF.get("ca_mois")), "objectif 10 %", True),
    ("CA / MOIS PROP", pct(PF.get("ca_mois_p90")),
     "drawdown du mauvais décile", True),
    ("CALMAR 12 MOIS", n(PF.get("calmar12")), "médiane glissante", False),
    ("DRAWDOWN 12 MOIS", n(PF.get("DD12"), 1) + " R",
     f"P90 {n(PF.get('dd_p90'),1)} R", False),
    ("R / DD", n(base.get("rdd") if base else PF.get("rdd")),
     "hors échantillon interne", False),
    ("R TOTAL 6 ANS", "+" + n(base.get("R"), 0) + " R",
     "2020 → 2025", False),
]

HARD = [
    ("Base", base, True),
    ("Spread ×2", sp2, False),
    ("Spread ×3", sp3, False),
    ("Sans trailing", nt, False),
]

mt5_rows = []
for s, v in sorted(MT.items()):
    e = v.get("n_entries")
    bal = v.get("balance")
    ok = None
    try:
        ok = float(str(bal).replace(" ", "")) >= 100000 if bal else None
    except Exception:
        ok = None
    mt5_rows.append((s, e, bal, ok))

trg_rows = "".join(
    f"<tr><td>{html.escape(u['sym'])}</td><td class='mono'>{html.escape(u['trigL'])}</td>"
    f"<td class='mono'>{'PAIRE' if u.get('paired') else 'LONG'}</td>"
    f"<td class='num'>{n(u.get('RL'),1)}</td>"
    f"<td class='num'>{n(u.get('s_sym'),3)}</td>"
    f"<td class='num'>{(u.get('exL') or {}).get('sl','—')}</td>"
    f"<td class='mono small'>{html.escape(', '.join(u.get('filtL',[])) or '—')}</td></tr>"
    for u in sorted(units, key=lambda x: -abs(x.get("RL", 0))))

hard_rows = "".join(
    f"<tr><td><b>{lbl}</b></td><td class='num'>{n(v.get('R'),1)}</td>"
    f"<td class='num'>{n(v.get('rdd'))}</td><td class='num'>{n(v.get('calmar_med'))}</td>"
    f"<td class='num {'ok' if (v.get('calmar_worst') or -9)>0 else 'bad'}'>"
    f"{n(v.get('calmar_worst'))}</td></tr>"
    for lbl, v, _ in HARD if v)

mt5_html = "".join(
    f"<tr><td>{s}</td><td class='num'>{e}</td><td class='num'>{bal or '—'}</td>"
    f"<td><span class='badge {'b-ok' if ok else 'b-warn' if ok is None else 'b-bad'}'>"
    f"{'OK' if ok else 'À CORRIGER' if ok is not None else 'AUCUNE ENTRÉE'}</span></td></tr>"
    for s, e, bal, ok in mt5_rows)

bars = "".join(
    f"<div class='barrow'><span class='bl'>{html.escape(k)}</span>"
    f"<span class='bv' style='width:{min(100, v/max(1,max(syms.values()))*100):.0f}%'></span>"
    f"<span class='bn'>{v}</span></div>"
    for k, v in sorted(syms.items(), key=lambda x: -x[1]))

bugs = [
    ("VWAPXUP / VWAPXDN", "×27", "VWAP ancré recalculé en fenêtre glissante — "
     "compare deux VWAP différents. Précalculer le VWAP par jour."),
    ("BRKROUNDUP / DN", "×24", "Pas du chiffre rond faux : 0,1 $ sur l'or. "
     "Mettre 1,0 $ (XAUUSD) / 0,01 (FX) / 0,001 (JPY)."),
    ("REJBEAR / REJBULL", "×17", "Pattern sans seuil de taille. Exiger "
     "mèche > corps ET mèche > 0,5 × ATR."),
    ("AUDCAD", "0 entrée", "Aucune condition ne tire — tracer filtre par filtre."),
]
bugs_html = "".join(
    f"<div class='bug'><div class='bugh'><span class='bt'>{html.escape(t)}</span>"
    f"<span class='bf'>{f}</span></div><p>{html.escape(d)}</p></div>"
    for t, f, d in bugs)

TS = dt.datetime.now().strftime("%d/%m/%Y %H:%M")

DOC = f"""<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ORION — Console de contrôle</title>
<style>
:root{{
 --bg:#080b12; --card:#111726; --card2:#0d1320; --line:#1e2a3f;
 --tx:#e8eefc; --dim:#7d8ba6; --acc:#4da3ff; --gr:#2ee6a8;
 --am:#ffc247; --rd:#ff5f6d; --acc2:#8b7bff;
}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:var(--bg);color:var(--tx);
 font:14px/1.5 "Segoe UI",Inter,system-ui,sans-serif;
 background-image:radial-gradient(900px 500px at 12% -10%,#15305e55,transparent),
 radial-gradient(700px 400px at 92% 0%,#3a256e55,transparent);
 background-attachment:fixed}}
.wrap{{max-width:1320px;margin:0 auto;padding:30px 22px 70px}}
header{{display:flex;justify-content:space-between;align-items:flex-end;
 flex-wrap:wrap;gap:16px;padding-bottom:22px;border-bottom:1px solid var(--line)}}
h1{{font-size:34px;font-weight:700;letter-spacing:-.6px}}
h1 span{{background:linear-gradient(92deg,var(--acc),var(--acc2));
 -webkit-background-clip:text;background-clip:text;color:transparent}}
.sub{{color:var(--dim);font-size:13px;margin-top:5px}}
.live{{display:flex;align-items:center;gap:8px;color:var(--gr);font-weight:600;
 font-size:12px;letter-spacing:.5px}}
.dot{{width:8px;height:8px;border-radius:50%;background:var(--gr);
 box-shadow:0 0 12px var(--gr);animation:p 1.8s infinite}}
@keyframes p{{0%,100%{{opacity:1}}50%{{opacity:.35}}}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(196px,1fr));
 gap:14px;margin:26px 0}}
.k{{background:linear-gradient(160deg,var(--card),var(--card2));
 border:1px solid var(--line);border-radius:14px;padding:18px 18px 15px;position:relative;
 overflow:hidden}}
.k::before{{content:"";position:absolute;inset:0 0 auto 0;height:2px;
 background:linear-gradient(90deg,var(--acc),var(--acc2))}}
.k.hi::before{{background:linear-gradient(90deg,var(--gr),var(--acc))}}
.kl{{color:var(--dim);font-size:11px;letter-spacing:1.1px;font-weight:600;
 text-transform:uppercase}}
.kv{{font-size:30px;font-weight:700;letter-spacing:-1px;margin:7px 0 3px;
 font-variant-numeric:tabular-nums}}
.k.hi .kv{{background:linear-gradient(92deg,var(--gr),#7ef0c8);
 -webkit-background-clip:text;background-clip:text;color:transparent}}
.kd{{color:var(--dim);font-size:11.5px}}
section{{margin-top:34px}}
h2{{font-size:15px;letter-spacing:1.4px;text-transform:uppercase;color:var(--acc);
 margin-bottom:13px;font-weight:700;display:flex;align-items:center;gap:10px}}
h2::after{{content:"";flex:1;height:1px;background:var(--line)}}
table{{width:100%;border-collapse:collapse;background:var(--card);
 border:1px solid var(--line);border-radius:12px;overflow:hidden;font-size:13px}}
th{{background:#0b111d;color:var(--dim);text-align:left;padding:11px 13px;
 font-size:11px;letter-spacing:.9px;text-transform:uppercase;font-weight:600}}
td{{padding:10px 13px;border-top:1px solid #161f31}}
tr:hover td{{background:#141c2d}}
.num{{text-align:right;font-variant-numeric:tabular-nums;font-weight:600}}
.mono{{font-family:"Cascadia Code",Consolas,monospace;font-size:12px;color:#b9c8e4}}
.small{{font-size:11.5px;color:var(--dim)}}
.ok{{color:var(--gr)}} .bad{{color:var(--rd)}} .warn{{color:var(--am)}}
.badge{{padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;
 letter-spacing:.4px}}
.b-ok{{background:#2ee6a81f;color:var(--gr);border:1px solid #2ee6a844}}
.b-bad{{background:#ff5f6d1f;color:var(--rd);border:1px solid #ff5f6d44}}
.b-warn{{background:#ffc2471f;color:var(--am);border:1px solid #ffc24744}}
.two{{display:grid;grid-template-columns:1fr 1fr;gap:18px}}
@media(max-width:860px){{.two{{grid-template-columns:1fr}}}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:12px;
 padding:17px}}
.barrow{{display:flex;align-items:center;gap:10px;margin:7px 0;font-size:12.5px}}
.bl{{width:64px;color:var(--dim);font-family:monospace}}
.bv{{height:8px;border-radius:6px;background:linear-gradient(90deg,var(--acc),var(--acc2));
 min-width:3px}}
.bn{{color:var(--dim);font-size:11.5px}}
.bug{{background:var(--card2);border:1px solid var(--line);
 border-left:3px solid var(--rd);border-radius:10px;padding:13px 15px;margin-bottom:10px}}
.bugh{{display:flex;justify-content:space-between;align-items:center;gap:10px}}
.bt{{font-family:monospace;font-weight:700;font-size:13px;color:#dbe7ff}}
.bf{{background:#ff5f6d1f;color:var(--rd);padding:2px 9px;border-radius:20px;
 font-size:11px;font-weight:700}}
.bug p{{color:var(--dim);font-size:12.5px;margin-top:6px}}
.pill{{display:inline-flex;align-items:center;gap:7px;padding:7px 14px;
 border-radius:20px;background:#2ee6a814;border:1px solid #2ee6a833;
 color:var(--gr);font-size:12px;font-weight:600;margin:0 8px 8px 0}}
.pill.w{{background:#ffc24714;border-color:#ffc24733;color:var(--am)}}
footer{{margin-top:44px;padding-top:18px;border-top:1px solid var(--line);
 color:var(--dim);font-size:11.5px;display:flex;justify-content:space-between;
 flex-wrap:wrap;gap:10px}}
</style></head><body><div class="wrap">

<header>
 <div>
  <h1>ORION <span>Console de contrôle</span></h1>
  <div class="sub">Portefeuille multi-marchés · recherche autonome · arbitrage MT5</div>
 </div>
 <div>
  <div class="live"><span class="dot"></span> RECHERCHE ACTIVE — {rounds:,} tours</div>
  <div class="sub" style="text-align:right;margin-top:6px">Généré le {TS}</div>
 </div>
</header>

<div class="grid">
{''.join(f'''<div class="k{' hi' if hi else ''}"><div class="kl">{t}</div>
<div class="kv">{v}</div><div class="kd">{d}</div></div>''' for t,v,d,hi in KPI)}
</div>

<section><h2>Validation — protocole de résistance</h2>
<table><thead><tr><th>Épreuve</th><th class="num">R total</th>
<th class="num">R / DD</th><th class="num">Calmar 12 mois</th>
<th class="num">Pire fenêtre 12 mois</th></tr></thead>
<tbody>{hard_rows}</tbody></table>
<div style="margin-top:12px">
<span class="pill">6 / 6 années positives</span>
<span class="pill">Miroir négatif · 15 / 16 jambes</span>
<span class="pill">0 / 16 négative à spread ×3</span>
<span class="pill w">Marge de sécurité : spread ×2 (pas ×3)</span>
</div></section>

<section><h2>Portefeuille — {len(units)} jambes sur {len(syms)} marchés</h2>
<div class="two">
<div><table><thead><tr><th>Marché</th><th>Déclencheur</th><th>Type</th>
<th class="num">R</th><th class="num">s</th><th class="num">SL</th>
<th>Filtres</th></tr></thead><tbody>{trg_rows}</tbody></table></div>
<div>
 <div class="card" style="margin-bottom:14px">
  <div class="kl" style="margin-bottom:10px">Répartition par marché</div>
  {bars}
 </div>
 <div class="card">
  <div class="kl" style="margin-bottom:10px">Filtres les plus utilisés</div>
  {''.join(f"<span class='pill'>{html.escape(k)} × {v}</span>" for k,v in FILT.most_common(8))}
 </div>
</div></div></section>

<section><h2>Arbitrage MT5 — fidélité du robot</h2>
<table><thead><tr><th>Paire</th><th class="num">Entrées MT5</th>
<th class="num">Balance finale</th><th>Statut</th></tr></thead>
<tbody>{mt5_html}</tbody></table></section>

<section><h2>Écarts à corriger avant déploiement</h2>
{bugs_html}
<div class="card" style="border-left:3px solid var(--acc)">
<b>Pourquoi c'est une bonne nouvelle.</b> L'arbitrage MT5 a attrapé une stratégie
qui semblait excellente en Python et qui prendrait 7 à 27× trop de trades en
exécution — frais dévorants, drawdown réel sans rapport avec le backtest. C'est
exactement le rôle de ce test. Chaque correctif fait une ligne, et le cycle
correction → vérification prend 3 minutes par paire.</div></section>

<section><h2>Architecture de déploiement</h2>
<div class="two">
<div class="card"><div class="kl" style="margin-bottom:9px">Structure</div>
<ul style="color:var(--dim);font-size:13px;padding-left:18px;line-height:1.9">
<li><b style="color:var(--tx)">1 robot par paire</b>, toutes ses jambes dedans</li>
<li>Table de jambes dans un <b style="color:var(--tx)">fichier CSV</b> — jamais de recompilation</li>
<li><b style="color:var(--rd)">Compte HEDGING obligatoire</b> — en NETTING les ordres fusionnent</li>
<li>Lots fixes · SL/TP en ATR · trailing</li>
<li>ATR sur M15 décalée d'une barre (causalité)</li>
</ul></div>
<div class="card"><div class="kl" style="margin-bottom:9px">Sécurités câblées</div>
<ul style="color:var(--dim);font-size:13px;padding-left:18px;line-height:1.9">
<li>Plafond de positions simultanées par paire</li>
<li>Plafond par sens (longs / shorts)</li>
<li><b style="color:var(--tx)">Filtre de spread</b> — refus si &gt; 2,5× la médiane</li>
<li>Stop journalier 3 %</li>
<li><b style="color:var(--tx)">Arrêt définitif à 15 % de drawdown</b></li>
<li>Gel des entrées le vendredi soir</li>
</ul></div></div></section>

<footer>
<span>ORION · portefeuille de recherche · backtest uniquement, aucun ordre réel</span>
<span>Toutes les valeurs sont mesurées sur données Dukascopy 2020-2025</span>
</footer>
</div></body></html>"""

open(OUT, "w", encoding="utf-8").write(DOC)
print(f"Console generee : {OUT}")
print(f"  {len(DOC)/1024:.0f} Ko | {len(units)} jambes | {len(syms)} marches | "
      f"{rounds} tours de recherche | {len(MT)} paires MT5")
