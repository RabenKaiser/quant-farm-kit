﻿"""Final family screen: HTF trend-following & breakout at H1/M30 with wide stops.

The 2022-2023 data had strong directional trends (EURUSD 1.14->0.95 in 2022).
Test classic trend-following with WIDE stops (survives friction) and
longer holds, one-position-at-a-time, through the correct engine.
"""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import polars as pl
import numpy as np
import sys, json
from pathlib import Path

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
from edge_correct import load_m1, to_tf, seg_of, backtest_m1, summarize, POINT

def make_signals_tf(tf, kind, cfg):
    lb = cfg.get("lookback", 40)
    f = tf.with_columns(
        pl.col("bid_h").rolling_max(lb).shift(1).alias("hh"),
        pl.col("bid_l").rolling_min(lb).shift(1).alias("ll"),
        (pl.col("bid_h") - pl.col("bid_l")).alias("rng"),
        (pl.col("bid_c") - pl.col("bid_c").shift(lb)).alias("mom"),
        pl.col("bid_c").rolling_mean(50).shift(1).alias("sma50"),
        pl.col("bid_c").rolling_mean(200).shift(1).alias("sma200"),
    ).with_columns(
        pl.col("rng").rolling_mean(14).shift(1).alias("atr"),
        pl.col("time").cast(pl.Int64).alias("ts"),
        ((pl.col("time") % 86400) // 3600).cast(pl.Int64).alias("hr"),
    )
    if cfg.get("session"):
        f = f.filter((pl.col("hr") >= cfg["session"][0]) & (pl.col("hr") <= cfg["session"][1]))
    if kind == "donchian":
        # classic: close > prior N-bar high -> long (breakout continuation)
        sig = (f["bid_c"] > f["hh"]).cast(pl.Int8) - (f["bid_c"] < f["ll"]).cast(pl.Int8)
    elif kind == "sma_cross":
        sig = ((f["sma50"] > f["sma200"]).cast(pl.Int8) - (f["sma50"] < f["sma200"]).cast(pl.Int8))
        # only on cross events? no - hold while aligned (positional)
        sig = sig
    elif kind == "momentum":
        thr = cfg.get("thr", 0.5)
        sig = ((f["mom"] > thr * f["atr"]).cast(pl.Int8) - (f["mom"] < -thr * f["atr"]).cast(pl.Int8))
    else:
        raise ValueError(kind)
    return f.with_columns(pl.Series("sig", sig).fill_null(0))

def grid(sym, tf_sec, kinds):
    m1 = load_m1(sym)
    tf = to_tf(m1, tf_sec)
    df = seg_of(tf)
    seg_names = [s for s in ["IS-1", "IS-2", "OOS"] if s in set(df["seg"].to_list())]
    segs = {s: df.filter(pl.col("seg") == s) for s in seg_names}
    m1_segs = seg_of(m1)
    m1_map = {s: m1_segs.filter(pl.col("seg") == s) for s in seg_names}
    print(f"{sym} M{tf_sec//60}: bars={len(tf)} segs=" + str({s: len(segs[s]) for s in seg_names}))

    results = []
    for kind in kinds:
        for lb in [20, 40, 80]:
            for sl_atr in [2.0, 3.0, 5.0]:
                for rr in [1.5, 2.0, 3.0]:
                    for sess in [None]:
                        cfg = {"lookback": lb, "thr": 0.5, "sl_atr": sl_atr, "rr": rr,
                               "session": sess, "slippage_pts": 0.5}
                        row = {"cfg": cfg, "kind": kind}
                        ok = True
                        for sname in seg_names:
                            f = make_signals_tf(segs[sname], kind, cfg)
                            trades = backtest_m1(m1_map[sname], segs[sname], f, sym, cfg,
                                                 max_hold_bars=1440)
                            row[sname] = summarize(trades)
                            if row[sname]["n"] < 10:
                                ok = False
                        if not ok:
                            continue
                        evs = [row[s]["net"] for s in seg_names]
                        if all(e > 0 for e in evs) or all(e < 0 for e in evs):
                            row["_sign"] = "ALL+" if evs[0] > 0 else "ALL-"
                            row["_mean"] = round(sum(evs) / len(evs), 4)
                            row["_total_n"] = sum(row[s]["n"] for s in seg_names)
                            results.append(row)
    results.sort(key=lambda r: r.get("_mean", -9), reverse=True)
    return results, seg_names

if __name__ == "__main__":
    sym = sys.argv[1] if len(sys.argv) > 1 else "EURUSD"
    tf = int(sys.argv[2]) if len(sys.argv) > 2 else 3600
    kinds = tuple(sys.argv[3:]) or ("donchian", "sma_cross", "momentum")
    res, seg_names = grid(sym, tf, kinds)
    print(f"\n=== TF {sym} M{tf//60} {kinds}: same-sign ===")
    for r in res[:20]:
        c = r["cfg"]
        print(f"  {r['kind']:10s} lb={c['lookback']} sl={c['sl_atr']} rr={c['rr']} "
              f"sign={r.get('_sign')} mean={r.get('_mean')} N={r.get('_total_n')}")
        for s in seg_names:
            x = r[s]
            print(f"    {s}: n={x['n']} gross={x['gross']} net={x['net']} wr={x['wr']}% t={x['t']} sl={x['sl']}pt")
    out = RESEARCH / f"grid_tf_{sym}_M{tf//60}.json" if (RESEARCH := Path(r"C:\EAFarm\HISTORY - Copy\research")) else None
    out.write_text(json.dumps(res, indent=1, default=str))
    print(f"saved -> {out}")
