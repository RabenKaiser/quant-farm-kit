"""crible_rearm_split : SR n=100 court hors echantillon, avec re-armement.

Le crible du round 165 (sans decoupage) donnait SR n=100 COURT a +0,0203 R/tx
net, 52,0 % de gagnants, 8 paires positives sur 11. Mais le motif a ete choisi en
regardant ces memes donnees. Ici on coupe : choix du motif et du sens sur
2020-2022, mesure des cinq seuils de gel sur 2023-2026, avec re-armement
(8 barres minimum entre deux entrees) et couts Upcomers reels.
"""
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import portefeuille_large as PL

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
OUT = B / "crible_rearm_split.md"
COUPE = "2023-01"
HOSTILE = (("2024-01", "2024-06"), ("2025-04", "2025-12"))
C = {"EURUSD": 0.10, "GBPUSD": 0.10, "AUDUSD": 0.10, "NZDUSD": 0.10,
     "USDCAD": 0.20, "USDCHF": 0.10, "EURGBP": 0.10, "EURJPY": 0.50,
     "GBPJPY": 0.70, "AUDJPY": 0.20, "CADJPY": 0.40}
MIN_ECART = 8


def mois(t):
    return "%04d-%02d" % (t.year, t.month)


def main():
    PL.STOP, PL.RR = 1.0, 1.0
    par_motif = defaultdict(dict)      # (motif,sens) -> paire -> {mois: r}
    for p, b, cout_duka in PL.charge_tout():
        if p not in C:
            continue
        pip = 0.01 if p.endswith("JPY") else 0.0001
        cout = C[p] * pip / float(b.atr.median())
        for (motif, sens), idx in PL.motifs(b).items():
            idx = idx[idx < len(b) - 34]
            if len(idx) < 200:
                continue
            keep, dern = [], None
            for k in idx:
                if dern is not None and k - dern < MIN_ECART:
                    continue
                keep.append(k)
                dern = k
            keep = np.array(keep, dtype=int)
            if len(keep) < 100:
                continue
            R, T = PL.r_par_trade(b, keep, sens, cout)
            if R is None:
                continue
            mm = np.array([mois(t) for t in T])
            per = defaultdict(list)
            for m, x in zip(mm, R):
                per[m].append(x)
            per = {m: float(np.mean(x)) for m, x in per.items() if len(x) >= 10}
            if len(per) >= 12:
                par_motif[(motif, sens)][p] = per
    print("couples mesures : %d" % len(par_motif), flush=True)

    # choix sur l'avant-2023 : R/tx moyen pondere le plus haut
    classement = []
    for k, paires in par_motif.items():
        av = [v for per in paires.values() for m, v in per.items() if m < COUPE]
        if len(av) < 50:
            continue
        classement.append((float(np.mean(av)), k))
    classement.sort(reverse=True)

    out = ["# SR n=100 court : hors echantillon avec re-armement", "",
           "Choix du motif sur 2020-2022, mesure sur 2023-2026 (> %s). Couts Upcomers, "
           "stop 1 ATR, objectif 1 R, re-armement %d barres." % (COUPE, MIN_ECART), "",
           "| motif retenu | sens | R/tx avant 2023 |", "|---|---|---|"]
    for r, k in classement[:5]:
        out.append("| %s | %s | %+.4f |" % (k[0], "L" if k[1] > 0 else "S", r))
    if not classement:
        OUT.write_text("\n".join(out), encoding="utf-8")
        return 1
    meilleur = classement[0][1]
    paires = par_motif[meilleur]
    par_mois = defaultdict(list)
    for per in paires.values():
        for m, v in per.items():
            if m >= COUPE:
                par_mois[m].append(v)
    ms = sorted(par_mois)
    s = [float(np.mean(par_mois[m])) for m in ms]
    eq = pic = dd = 0.0
    for x in s:
        eq += x
        pic = max(pic, eq)
        dd = max(dd, pic - eq)
    h = [x for m, x in zip(ms, s) if any(a <= m <= b for a, b in HOSTILE)]
    ann = sum(1 for m in ms if int(m[:4]) <= 2023)
    rdd = eq / dd if dd > 1e-9 else None
    tot = sum(len(per) for per in paires.values())
    rt = float(np.mean([v for per in paires.values() for m, v in per.items() if m >= COUPE]))
    pos_p = sum(1 for per in paires.values()
                if np.mean([v for m, v in per.items() if m >= COUPE] or [0]) > 0)
    out += ["", "**Motif retenu : %s %s**" % (meilleur[0], "L" if meilleur[1] > 0 else "S"), "",
            "| indicateur | valeur | seuil de gel | passe ? |", "|---|---|---|---|",
            "| R/tx hors echantillon | %+.4f | > 0 | %s |" % (rt, "OUI" if rt > 0 else "NON"),
            "| hostile | %+.4f | > 0 | %s |" % (float(np.mean(h)) if h else 0.0,
                                                "OUI" if h and np.mean(h) > 0 else "NON"),
            "| R total | %+.4f | — | — |" % eq,
            "| R/DD mensuel | %s | >= 3 | %s |" % ("%.2f" % rdd if rdd else "inf",
                                                   "OUI" if (rdd is None or rdd >= 3) else "NON"),
            "| fenetres | %d | >= 11 | %s |" % (len(ms), "OUI" if len(ms) >= 11 else "NON"),
            "| annuelles | %d | >= 2 | %s |" % (ann, "OUI" if ann >= 2 else "NON"),
            "| pire mois | %+.4f | — | — |" % (min(s) if s else 0.0),
            "| mois positifs | %d/%d | — | — |" % (sum(1 for x in s if x > 0), len(s)),
            "| paires positives | %d/%d | — | — |" % (pos_p, len(paires))]
    OUT.write_text("\n".join(out), encoding="utf-8")
    print("\n".join(out[-14:]), flush=True)
    print("ecrit %s" % OUT, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
