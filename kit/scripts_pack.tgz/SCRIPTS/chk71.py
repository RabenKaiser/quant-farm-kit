﻿import os, re
LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
files=[(os.path.getmtime(os.path.join(LOGD,f)), os.path.join(LOGD,f)) for f in os.listdir(LOGD) if ".log" in f]
files.sort(reverse=True)
for _,p in files[:4]:
    if os.path.getsize(p)<500: continue
    raw=open(p,"rb").read(4)
    enc="utf-16" if raw[:2] in (b"\xff\xfe",b"\xfe\xff") else "utf-8"
    try: txt=open(p,encoding=enc,errors="replace").read()
    except Exception: continue
    hits = re.findall(r"ORION OPEN EURAUD \w+ side=-?\d+ magic=\d+", txt)
    if hits:
        print(f"  {os.path.basename(p)[:34]} : {len(hits)} lignes avec magic")
        print(f"    exemple : {hits[0]}")
        break
else:
    print("  pas encore de ligne avec magic (le run precedent a peut-etre servi l'ancien ex5)")
