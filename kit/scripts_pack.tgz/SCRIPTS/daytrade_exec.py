# -*- coding: utf-8 -*-
"""daytrade_exec.py — exécution daytrading COPY (prop firm ONLY = simulation).

Compétition 17:00 UTC 31/08 -> 06/09 19:00 UTC. Paires COPY :
USDJPY/GBPUSD/NZDUSD/AUDCAD/EURCAD, magics 190011-190020.
Prop firm : k=0.5%/trade, stop TOUJOURS, MaxDailyLoss 4%, pas de martingale.

Usage :
  python daytrade_exec.py scan              # analyse H1 de mes paires
  python daytrade_exec.py open <pair> <buy|sell> <lots> <sl> [tp]
  python daytrade_exec.py close <pair> [--all]
  python daytrade_exec.py positions
  python daytrade_exec.py journal
"""
import sys, csv, os, datetime, json
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import MetaTrader5 as mt5

MAGIC_BASE = 190011
PAIRS = ["USDJPY", "GBPUSD", "NZDUSD", "AUDCAD", "EURCAD"]
LOG_CSV = r"C:\EAFarm\HISTORY - Copy\research\daytrade_log.csv"

def ensure_journal():
    if not os.path.exists(LOG_CSV):
        with open(LOG_CSV, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow(["ts_utc", "pair", "dir", "lots", "entry", "sl",
                                    "tp", "rr", "result", "note"])

def log_trade(**kw):
    ensure_journal()
    with open(LOG_CSV, "a", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow([kw.get(k, "") for k in
                                ["ts_utc", "pair", "dir", "lots", "entry", "sl",
                                 "tp", "rr", "result", "note"]])

def init():
    if not mt5.initialize(r"C:\MT5\terminal64.exe"):
        print("INIT FAIL:", mt5.last_error()); sys.exit(1)

def scan():
    for s in PAIRS:
        h4 = mt5.copy_rates_from_pos(s, mt5.TIMEFRAME_H4, 0, 220)
        h1 = mt5.copy_rates_from_pos(s, mt5.TIMEFRAME_H1, 0, 200)
        if h1 is None or len(h1) < 60:
            print(f"{s}: data insuffisante"); continue
        c = h1["close"]; vol = h1["tick_volume"]
        vwap = float(sum(c[-24:] * vol[-24:]) / max(sum(vol[-24:]), 1))
        price = float(c[-1])
        if h4 is not None and len(h4) > 200:
            c4 = h4["close"]
            s50 = float(sum(c4[-50:]) / 50); s200 = float(sum(c4[-200:]) / 200)
            trend = "long" if s50 > s200 else "short"
        else:
            trend = "?"
        bias = "long" if (price > vwap and trend != "short") else \
               ("short" if (price < vwap and trend != "long") else "melange")
        pip = 0.01 if "JPY" in s else 0.0001
        print(f"{s}: prix={price:.5f} VWAP={vwap:.5f} ({(price-vwap)/pip:+.1f}p) "
              f"trendH4={trend} -> {bias}")

def open_pos(pair, direction, lots, sl, tp=None):
    init()
    sym = mt5.symbol_info(pair)
    if not sym or sym.bid == 0:
        print(f"{pair} pas coté"); mt5.shutdown(); return
    price = sym.ask if direction == "buy" else sym.bid
    # filling mode : utiliser celui supporté par le symbole (Alpari = FOK souvent)
    fm = sym.filling_mode
    fill = mt5.ORDER_FILLING_FOK if (fm & 1) else (mt5.ORDER_FILLING_IOC if (fm & 2) else mt5.ORDER_FILLING_RETURN)
    req = {"action": mt5.TRADE_ACTION_DEAL, "symbol": pair, "volume": lots,
           "type": mt5.ORDER_TYPE_BUY if direction == "buy" else mt5.ORDER_TYPE_SELL,
           "price": price, "sl": sl, "tp": tp or 0.0, "deviation": 20,
           "magic": MAGIC_BASE, "comment": "COPY_DT",
           "type_time": mt5.ORDER_TIME_GTC, "type_filling": fill}
    res = mt5.order_send(req)
    if res and res.retcode == mt5.TRADE_RETCODE_DONE:
        print(f"OUVERT {direction} {pair} {lots} @ {price} sl={sl} tp={tp}")
        log_trade(ts_utc=datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M"),
                  pair=pair, dir=direction, lots=lots, entry=price, sl=sl, tp=tp or "")
    else:
        print("ECHEC:", res.retcode, res.comment if res else mt5.last_error())
    mt5.shutdown()

def positions():
    init()
    n = 0
    for p in mt5.positions_get() or []:
        if MAGIC_BASE <= p.magic <= MAGIC_BASE + 10:
            print(f"POS {p.symbol} {'buy' if p.type==0 else 'sell'} lots={p.volume} "
                  f"entry={p.price_open} sl={p.sl} profit={p.profit:.2f} t={p.ticket}")
            n += 1
    if not n:
        print("aucune position COPY")
    mt5.shutdown()

def close_pos(pair, all_=False):
    init()
    done = 0
    for p in mt5.positions_get(symbol=pair) or []:
        if not (MAGIC_BASE <= p.magic <= MAGIC_BASE + 10):
            continue
        sym = mt5.symbol_info(pair)
        price = sym.bid if p.type == mt5.POSITION_TYPE_BUY else sym.ask
        req = {"action": mt5.TRADE_ACTION_DEAL, "symbol": pair, "volume": p.volume,
               "type": mt5.ORDER_TYPE_SELL if p.type == mt5.POSITION_TYPE_BUY else mt5.ORDER_TYPE_BUY,
               "position": p.ticket, "price": price, "deviation": 20,
               "magic": p.magic, "comment": "COPY_DT_CLOSE",
               "type_filling": mt5.ORDER_FILLING_IOC}
        res = mt5.order_send(req)
        if res and res.retcode == mt5.TRADE_RETCODE_DONE:
            print(f"FERME {pair} t={p.ticket} profit={p.profit:.2f}")
            log_trade(ts_utc=datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M"),
                      pair=pair, result=f"close {p.profit:.2f}")
            done += 1
            if not all_:
                break
    if not done:
        print(f"aucune position {pair}")
    mt5.shutdown()

if __name__ == "__main__":
    args = sys.argv[1:]
    cmd = args[0] if args else "scan"
    if cmd == "scan":
        scan()
    elif cmd == "open" and len(args) >= 5:
        open_pos(args[1], args[2], float(args[3]), float(args[4]),
                 float(args[5]) if len(args) > 5 else None)
    elif cmd == "close" and len(args) >= 2:
        close_pos(args[1], "--all" in args)
    elif cmd == "positions":
        positions()
    else:
        print(__doc__)
