# -*- coding: utf-8 -*-
"""export_m1b_r286.py — export des VRAIES barres M1 via SCRIPT sur le terminal
LIVE (Farm/Dukascopy), lance par [StartUp] Script=EXPORT_M1.

Le Strategy Tester ne charge l historique M1 que progressivement -> au moment
d OnInit il n a que les premieres annees en cache -> "bars=0". Un SCRIPT sur le
terminal connecte voit TOUT l historique d un coup.
"""
import subprocess, sys, time, os, json, csv
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

FARM = Path(r"C:\EAFarm\MT5\Farm")
TERMINAL = FARM / "terminal64.exe"
METAEDITOR = FARM / "MetaEditor64.exe"
CONFIG = FARM / "Config" / "config_export_script.ini"
COMMON = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\Common\Files")
DATA = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3")
SCRIPT_SRC = DATA / "MQL5" / "Scripts" / "EXPORT_M1.mq5"
OUT = Path(r"C:\EAFarm\HISTORY - Copy\research\m1_real")

SYMBOLS = ["XAUUSD", "XAGUSD", "USATECH.IDX", "EURUSD", "GBPUSD", "AUDUSD",
           "NZDUSD", "USDCAD", "USDCHF", "EURJPY", "GBPJPY", "EURGBP",
           "EURAUD", "EURNZD", "AUDJPY", "CADJPY", "NZDJPY", "AUDNZD",
           "EURCAD", "EURCHF", "USDNOK", "EURNOK"]

OUT.mkdir(parents=True, exist_ok=True)

def compile_script():
    log = DATA / "MQL5" / "Scripts" / "export_m1_compile.log"
    subprocess.run([str(METAEDITOR), f"/compile:{SCRIPT_SRC}", f"/log:{log}"],
                   capture_output=True, text=True, timeout=180)
    ex5 = DATA / "MQL5" / "Scripts" / "EXPORT_M1.ex5"
    ok = ex5.exists()
    txt = ""
    if log.exists():
        for enc in ("utf-16", "utf-8"):
            try:
                txt = log.read_text(enc, errors="replace"); break
            except Exception:
                pass
    return ok, txt[-600:]

def kill_terminals():
    try:
        r = subprocess.run(["wmic", "process", "where", "name='terminal64.exe'",
                            "get", "ProcessId,ExecutablePath", "/format:csv"],
                           capture_output=True, text=True, timeout=20)
        for line in r.stdout.splitlines():
            if "Farm" in line and "terminal64.exe" in line:
                for p in [x.strip() for x in line.split(",")]:
                    if p.isdigit():
                        subprocess.run(["taskkill", "/F", "/PID", p], capture_output=True)
    except Exception:
        pass

def dump(sym, frm="2019.01.01", to="2026.12.31", max_wait=900):
    """Lance le terminal avec [StartUp] Script=EXPORT_M1 pour un symbole."""
    src = COMMON / f"{sym}_M1.csv"
    if src.exists():
        for _ in range(10):
            try:
                src.unlink(); break
            except Exception:
                time.sleep(2)
    cfg = (f"[StartUp]\nSymbol={sym}\nPeriod=M1\nScript=EXPORT_M1\n"
           f"[Tester]\n")
    CONFIG.write_text(cfg)
    kill_terminals()
    time.sleep(3)
    proc = subprocess.Popen([str(TERMINAL), f"/config:{CONFIG}"], cwd=str(FARM),
                            creationflags=0x08000000,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    prev = -1; stable = 0; w = 0
    while w < max_wait:
        time.sleep(5); w += 5
        cur = src.stat().st_size if src.exists() else 0
        if cur > 1000 and cur == prev:
            stable += 1
        else:
            stable = 0
        prev = cur
        # taille stable pendant 30 s -> l export est termine
        if stable >= 6:
            break
    kill_terminals()
    time.sleep(3)
    if src.exists() and src.stat().st_size > 1000:
        dst = OUT / f"{sym.replace('.', '_')}_M1.csv"
        for _ in range(15):
            try:
                if dst.exists(): dst.unlink()
                src.replace(dst); return dst
            except Exception:
                time.sleep(2)
    return None

def audit(f, sample=400000):
    """Verifie: doublons, ordre, qualite O==H==L==C, plage, volume."""
    n = 0; flat = 0; vols = set()
    times = []
    with open(f, errors="replace") as fh:
        rd = csv.reader(fh); next(rd, None)
        for row in rd:
            n += 1
            if n <= sample:
                if len(row) >= 5 and row[1] == row[2] == row[3] == row[4]:
                    flat += 1
                if len(row) >= 6:
                    vols.add(row[5])
                if n <= 3 or n % 200000 == 0:
                    times.append(row[0])
    return dict(n=n, flat_pct=round(flat / min(n, sample) * 100, 1) if n else 0,
                vol_uniq=len(vols))

if __name__ == "__main__":
    print("=" * 96)
    print("R286 — EXPORT M1 REEL via SCRIPT sur le terminal live (Farm)")
    print("=" * 96)
    ok, log = compile_script()
    print(f"compilation : {'OK' if ok else 'ECHEC'}")
    if not ok:
        print(log); sys.exit(1)
    only = sys.argv[1:] or SYMBOLS
    rep = {}
    for i, s in enumerate(only, 1):
        t0 = time.time()
        print(f"[{i}/{len(only)}] {s} ...", flush=True)
        try:
            f = dump(s)
        except Exception as e:
            print(f"    ERREUR {e}"); rep[s] = {"err": str(e)}; continue
        if f and f.exists():
            a = audit(f)
            mb = f.stat().st_size / 1e6
            rep[s] = dict(MB=round(mb, 1), secs=round(time.time() - t0, 1), **a)
            q = "SAIN" if a["flat_pct"] < 50 else "PAUVRE"
            print(f"    OK  {a['n']} barres | {mb:.1f} MB | O==H==L==C={a['flat_pct']}% "
                  f"| volume uniq={a['vol_uniq']} | {q} ({time.time()-t0:.0f}s)", flush=True)
        else:
            rep[s] = {"err": "pas de fichier"}
            print(f"    ECHEC", flush=True)
        json.dump(rep, open(OUT / "_export_report.json", "w"), indent=1)
    print("\n=== RESUME ===")
    for s, d in rep.items():
        if "err" in d:
            print(f"  {s:14s} ECHEC {d['err']}")
        else:
            q = "SAIN" if d["flat_pct"] < 50 else "PAUVRE"
            print(f"  {s:14s} {d['n']:9d} barres {d['MB']:7.1f} MB "
                  f"plat={d['flat_pct']:5.1f}% vol_uniq={d['vol_uniq']:6d} {q}")
    print("\nFIN", flush=True)
