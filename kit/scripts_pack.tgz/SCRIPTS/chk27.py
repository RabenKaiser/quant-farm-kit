﻿import os, re
LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
files=[(f,os.path.getmtime(os.path.join(LOGD,f)),os.path.getsize(os.path.join(LOGD,f))) for f in os.listdir(LOGD) if ".log" in f]
files.sort(key=lambda x:-x[1])
p=os.path.join(LOGD, files[0][0])
raw=open(p,"rb").read(4)
enc="utf-16" if raw[:2] in (b"\xff\xfe",b"\xfe\xff") else "utf-8"
txt=open(p,encoding=enc,errors="replace").read()
for kw in ("ORION REJET","ORION OPEN","ORION DIAG","ORION TRIG"):
    print(f"  {kw:<14} : {txt.count(kw)}")
print()
for mm in re.findall(r".*ORION REJET.*", txt)[:5]:
    print("  ", mm.split("Core")[-1].strip()[:120])
for mm in re.findall(r".*ORION DIAG XAUUSD : tries.*", txt)[-1:]:
    print("  DIAG:", mm.split("Core")[-1].strip()[:160])
