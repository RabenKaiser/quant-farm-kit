# -*- coding: utf-8 -*-
"""combine.py — LE FILTRE QUI TIENT + LE MECANISME QUI MARCHE MIEUX.

DEUX TROUVAILLES DU 18/09, PRISES SEPAREMENT
--------------------------------------------
1. FILTRE. Sur le regime 2025-2026 (grille complete, EURUSD et EURJPY), trois
   filtres seulement sont positifs dans les deux regimes, et les trois
   contiennent RANGE_LO : "le prix est dans le bas de son range". Le meilleur,
   RANGE_LO seul, fait +0.0205 en 2024 et +0.0496 en 2025-2026 -- il S'AMELIORE
   dans le marche actuel.

2. MECANISME. Le retour a la moyenne a barrieres serrees et detention courte
   (12 a 48 barres) donne ses meilleurs resultats sur EURUSD : +0.0237 R en
   2025-2026 contre +0.0048 en 2024, avec un temoin aleatoire de -0.0884 R sur
   les memes barrieres. Le mecanisme de tendance habituel (SL 12 / TP 24,
   192 barres) ne donne rien sur ces fenetres.

CE QUI EST TESTE ICI : LA COMBINAISON
    entree  : achat si le prix est dans les 20 % BAS du range des 96 dernieres
              barres (le filtre RANGE_LO) -- vente si dans les 20 % hauts
    sortie  : stop 1.0 a 3.0 x ATR, objectif 0.5 a 2.0 x ATR, duree 12/24/48
    cout    : spread paye a l'entree ET a la sortie
    paires  : 6, periodes : 2024 (apprentissage) et 2025Q2-2026Q1 (nouveau)
    temoin  : entrees aleatoires, MEMES barrieres, meme periode

CE QU'ON REGARDE, ET POURQUOI
  - R dans le nouveau regime (le marche d'aujourd'hui) ;
  - R dans l'ancien (est-ce que ca tient aussi ?) ;
  - NOMBRE DE TRANSACTIONS PAR AN, parce que l'objectif est de 500 R par an :
     500 R/an a +0.05 R/tx demande 10 000 transactions/an, soit 40 par jour.
     Un mecanisme qui ne fait que quelques centaines de transactions par an ne
     peut PAS atteindre 500 R, quelle que soit sa qualite.

USAGE : python combine.py
"""
import itertools
import statistics
from pathlib import Path

import pandas as pd

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
M1 = BASE / "m1_pos"
PAIRES = ["EURUSD", "EURJPY", "GBPJPY", "AUDJPY", "USDCAD", "NZDUSD"]
FEN_RANGE = 96
SEUIL_RANGE = 0.20
SLS = [1.0, 1.5, 2.0, 3.0]
TPS = [0.5, 1.0, 1.5, 2.0]
HOLDS = [12, 24, 48]
HOLD_MAX = max(HOLDS)
PAS = 3
TRAIN = ("2024-01-01", "2025-04-01")
NEUF = ("2025-04-01", "2026-01-01")


def point_de(close):
    ex = close.dropna().astype(str)
    ex = ex[~ex.str.contains("e", case=False, na=False)].head(2000)
    dec = 0
    for x in ex:
        if "." in x:
            dec = max(dec, len(x.split(".")[1]))
    return 10.0 ** (-dec)


def barres(sym):
    p = M1 / ("%s_M1.csv" % sym)
    if not p.exists():
        return None
    d = pd.read_csv(p, usecols=["time", "high", "low", "close", "spread"])
    d["time"] = pd.to_datetime(d["time"], unit="s", utc=True)
    d = d.set_index("time").sort_index()
    pt = point_de(d["close"])
    m5 = d.resample("5min").agg({"high": "max", "low": "min",
                                 "close": "last", "spread": "mean"}).dropna()
    m5["spr"] = m5["spread"] * pt
    pc = m5["close"].shift(1)
    tr = pd.concat([(m5["high"] - m5["low"]).abs(),
                    (m5["high"] - pc).abs(),
                    (m5["low"] - pc).abs()], axis=1).max(axis=1)
    m5["atr"] = tr.rolling(14).mean()
    m5["rhi"] = m5["high"].rolling(FEN_RANGE).max()
    m5["rlo"] = m5["low"].rolling(FEN_RANGE).min()
    return m5.dropna()


def simule(a, aleatoire=False):
    H = a["high"].to_numpy()
    L = a["low"].to_numpy()
    C = a["close"].to_numpy()
    A = a["atr"].to_numpy()
    S = a["spr"].to_numpy()
    HI = a["rhi"].to_numpy()
    LO = a["rlo"].to_numpy()
    n = len(C)
    couples = list(itertools.product(SLS, TPS))
    res = {}
    for sl_atr, tp_atr, hold in itertools.product(SLS, TPS, HOLDS):
        res[(sl_atr, tp_atr, hold)] = []
    for i in range(FEN_RANGE + 2, n - HOLD_MAX - 1, PAS):
        atr = A[i]
        if not (atr > 0) or HI[i] <= LO[i]:
            continue
        if aleatoire:
            sides = (1.0, -1.0)
        else:
            pos = (C[i] - LO[i]) / (HI[i] - LO[i])
            if pos < SEUIL_RANGE:
                sides = (1.0,)          # bas de range -> achat
            elif pos > 1.0 - SEUIL_RANGE:
                sides = (-1.0,)         # haut de range -> vente
            else:
                continue
        sp = S[i] if S[i] > 0 else 0.0
        for side in sides:
            ent = C[i] + side * sp / 2.0
            premiere = {}
            for j in range(i + 1, min(i + 1 + HOLD_MAX, n)):
                for (sl_atr, tp_atr) in couples:
                    if (sl_atr, tp_atr) in premiere:
                        continue
                    if side > 0:
                        adv, fav = ent - L[j], H[j] - ent
                    else:
                        adv, fav = H[j] - ent, ent - L[j]
                    if adv >= sl_atr * atr:
                        premiere[(sl_atr, tp_atr)] = (j, -1.0)
                    elif fav >= tp_atr * atr:
                        premiere[(sl_atr, tp_atr)] = (j, tp_atr / sl_atr)
                if len(premiere) == len(couples):
                    break
            for (sl_atr, tp_atr) in couples:
                touche = premiere.get((sl_atr, tp_atr))
                for hold in HOLDS:
                    if touche is not None and (touche[0] - i) <= hold:
                        rr = touche[1]
                    else:
                        sortie = C[min(i + hold, n - 1)] - side * sp / 2.0
                        rr = (sortie - ent) * side / (sl_atr * atr)
                    res[(sl_atr, tp_atr, hold)].append(rr)
    return res


def main():
    print("=" * 100)
    print("RANGE_LO + RETOUR A LA MOYENNE — LA COMBINAISON DES DEUX TROUVAILLES")
    print("=" * 100)
    print("   entree : prix dans les %d %% bas (ou hauts) du range de %d barres M5"
          % (int(100 * SEUIL_RANGE), FEN_RANGE))
    print("   sortie : stop 1 a 3 x ATR, objectif 0.5 a 2 x ATR, duree 12/24/48")
    print()
    res_paire = {}
    temoins = {}
    for sym in PAIRES:
        m5 = barres(sym)
        if m5 is None:
            continue
        a = m5.loc[TRAIN[0]:TRAIN[1]]
        b = m5.loc[NEUF[0]:NEUF[1]]
        if len(a) < 3000 or len(b) < 1500:
            continue
        ra = simule(a)
        rb = simule(b)
        rt = simule(b, aleatoire=True)
        res_paire[sym] = (ra, rb)
        temoins[sym] = {k: statistics.mean(v) for k, v in rt.items() if len(v) > 30}
        print("   %-8s termine" % sym)
    print()
    print("   %-8s %6s %6s %6s %10s %10s %10s %8s %9s"
          % ("paire", "stop", "obj", "duree", "R 2024", "R 2025-26",
             "temoin 25-26", "trades", "R/an"))
    print("   " + "-" * 92)
    tous = []
    for sym, (ra, rb) in res_paire.items():
        for cle in ra:
            va, vb = ra[cle], rb[cle]
            if len(va) < 300 or len(vb) < 150:
                continue
            ta = temoins[sym].get(cle)
            tous.append((sym, cle[0], cle[1], cle[2], statistics.mean(va),
                         statistics.mean(vb), ta, len(vb)))
    tous.sort(key=lambda x: -x[5])
    for x in tous[:24]:
        tx_an = x[7] / 0.75          # la periode 2025-26 fait 9 mois
        print("   %-8s %6.1f %6.1f %6d %+10.4f %+10.4f %+10.4f %8d %+9.1f"
              % (x[0], x[1], x[2], x[3], x[4], x[5],
                 x[6] if x[6] is not None else float("nan"), x[7], x[5] * tx_an))
    print()
    # --- ceux qui tiennent dans les deux ---------------------------------
    bons = [x for x in tous if x[4] > 0.0 and x[5] > 0.01
            and (x[6] is None or x[5] > x[6])]
    print("   CONFIGURATIONS POSITIVES DANS LES DEUX PERIODES ET MEILLEURES")
    print("   QUE LEUR TEMOIN ALEATOIRE : %d sur %d" % (len(bons), len(tous)))
    for x in bons[:20]:
        tx_an = x[7] / 0.75
        print("      %-8s stop %.1f obj %.1f duree %2d  ->  2024 %+.4f | "
              "2025-26 %+.4f | temoin %+.4f | %d tx (%.0f/an, %+.0f R/an)"
              % (x[0], x[1], x[2], x[3], x[4], x[5], x[6] or 0, x[7], tx_an,
                 x[5] * tx_an))
    print()
    if bons:
        parp = {}
        for x in bons:
            parp[x[0]] = parp.get(x[0], 0) + 1
        print("   par paire : %s"
              % ", ".join("%s=%d" % kv for kv in sorted(parp.items())))
        tot_an = sum(x[5] * x[7] / 0.75 for x in bons[:6])
        print()
        print("   ARITHMETIQUE DE L'OBJECTIF DES 500 R/AN")
        print("      en prenant les 6 meilleures configurations : %+.0f R/an" % tot_an)
        print("      objectif : 500 R/an")
        if tot_an >= 500:
            print("      -> l'objectif est atteignable sur le papier. A verifier")
            print("         en ordres reels avant tout.")
        else:
            print("      -> il manque %.0f R/an. Le levier n'est pas le R par" % (500 - tot_an))
            print("         transaction (il est petit) mais le NOMBRE de")
            print("         transactions : il faut multiplier les paires et les")
            print("         lignes, pas affiner le signal.")
    else:
        print("   >>> aucune configuration ne tient dans les deux periodes en")
        print("       battant son temoin. La combinaison ne sauve pas le")
        print("       mecanisme.")


if __name__ == "__main__":
    main()
