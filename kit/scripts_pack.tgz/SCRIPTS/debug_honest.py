# -*- coding: utf-8 -*-
"""debug_honest.py — pourquoi 0 trade honnete? Compter OB confirmes et
retests dans les X barres apres confirmation."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import c13v2_py_v3 as F
import numpy as np
import pandas as pd

sym = "EURUSD"; year = 2024
m1 = F.load_m1(sym)
start = pd.Timestamp(f"{year}-01-01", tz="UTC")
end = pd.Timestamp(f"{year + 1}-01-01", tz="UTC")
wu = start - pd.Timedelta(days=260)
m5 = F.resample(m1.loc[wu:end], "5min").loc[start:end]
m15 = F.resample(m1.loc[wu:end], "15min")

cfg = {"imp_atr": 0.9, "imp_vol": 1.0, "imp_look": 6}
bull, bear = F.detect_ob(m15, cfg, lookahead=False)
print(f"OB bull confirmes: {len(bull)}, bear: {len(bear)} sur {len(m15)} barres M15")

# compter les retests M5 dans les 96 barres M5 (8h) apres confirmation
m15_t = m15.index.values.astype("datetime64[ns]")
m5_t = m5.index.values.astype("datetime64[ns]")
idx15 = np.clip(np.searchsorted(m15_t, m5_t, side="right") - 1, 0, len(m15)-1)
o5 = m5["open"].to_numpy(); h5 = m5["high"].to_numpy()
l5 = m5["low"].to_numpy(); c5 = m5["close"].to_numpy()
pip = 0.0001
body5 = np.abs(c5 - o5)

# pour chaque OB bull confirme a dispo d, compter les touches M5 dans d..d+96
n_retest = 0
for jj, (dispo, zl0, zh0) in list(bull.items())[:2000]:
    zl, zh = min(zl0, zh0), max(zl0, zh0)
    # barres M5 avec idx15 dans [dispo, dispo+16]
    for i in range(len(m5)):
        i15 = idx15[i]
        if i15 < dispo:
            continue
        if i15 > dispo + 16:
            break
        if h5[i] >= zl and l5[i] <= zh:
            n_retest += 1
            break
print(f"OB bull avec retest dans 16 barres M15 apres confirmation: {n_retest}/{min(2000, len(bull))}")
