# -*- coding: utf-8 -*-
"""compile_trigger_lab.py -- compile TRIGGER_LAB.mq5 (round 108, double
croisement) dans les DEUX dossiers de donnees, puis verifie que l'ex5 a bien
ete reecrit et que le journal de compilation ne contient pas d'erreur.

MetaEditor SANS /s (avec /s = verification seule, pas d'ex5).
Lance : python SCRIPTS\\compile_trigger_lab.py
"""
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

FARM = Path(r"C:\EAFarm\MT5\Farm")
MT5DIR = Path(r"C:\MT5")
DATA = {
    "farm": Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal"
                 r"\CF0B997454318B475CF01419AFE2BBF3\MQL5\Experts\eepeek"),
    "mt5": Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal"
                r"\E23367DD11DBEB0EF97D08185EAB7295\MQL5\Experts\eepeek"),
}
# Source de verite : la copie farm (c'est elle qu'on edite).
SRC = DATA["farm"] / "TRIGGER_LAB.mq5"


def kill_metaeditor():
    try:
        subprocess.run(["taskkill", "/F", "/IM", "metaeditor64.exe"],
                       capture_output=True, timeout=15)
    except Exception:
        pass


def compile_in(dossier, metaeditor):
    mq5 = DATA[dossier] / "TRIGGER_LAB.mq5"
    ex5 = mq5.with_suffix(".ex5")
    old = ex5.stat().st_mtime if ex5.exists() else 0.0
    try:
        if ex5.exists():
            ex5.unlink()
    except Exception:
        pass
    kill_metaeditor()
    time.sleep(1)
    log = mq5.with_suffix(".log")
    try:
        if log.exists():
            log.unlink()
    except Exception:
        pass
    proc = subprocess.Popen([str(metaeditor), "/compile:" + str(mq5)],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL)
    ok = False
    for _ in range(40):
        time.sleep(1)
        if ex5.exists() and ex5.stat().st_size > 5000 \
           and ex5.stat().st_mtime > old:
            ok = True
            break
    try:
        proc.kill()
    except Exception:
        pass
    kill_metaeditor()
    texte = ""
    try:
        if log.exists():
            texte = log.read_text(encoding="utf-16", errors="replace")
    except Exception:
        pass
    return ok, ex5, texte


def main():
    if not SRC.exists():
        print("source introuvable : %s" % SRC)
        return 2
    print("source : %s (%d octets)" % (SRC, SRC.stat().st_size))
    # La copie mt5 est un simple miroir de la copie farm.
    shutil.copy2(SRC, DATA["mt5"] / SRC.name)
    res = {}
    for dossier, metaeditor in (("farm", FARM / "MetaEditor64.exe"),
                                ("mt5", MT5DIR / "MetaEditor64.exe")):
        ok, ex5, texte = compile_in(dossier, metaeditor)
        err = len(re.findall(r":\s*(error|erreur)\s", texte, re.I))
        warn = len(re.findall(r":\s*(warning|avertissement)\s", texte, re.I))
        print("%s : ex5=%s | erreurs=%d | avertissements=%d"
              % (dossier, ok, err, warn))
        if texte:
            for ln in texte.splitlines():
                if re.search(r"\b(error|erreur)\b", ln, re.I):
                    print("    %s" % ln.strip())
                if "ROUND108" in ln or "DOUBLE CROISEMENT" in ln:
                    print("    %s" % ln.strip())
        res[dossier] = ok and err == 0
    if all(res.values()):
        print("OK : les deux ex5 sont a jour")
        return 0
    print("FAIL : %s" % res)
    return 1


if __name__ == "__main__":
    sys.exit(main())
