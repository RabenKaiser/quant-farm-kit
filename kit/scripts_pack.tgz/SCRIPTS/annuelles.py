import json, os, subprocess, sys, time
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
B = r"C:\EAFarm\HISTORY - Copy\research"
COMMON = os.path.join(os.path.expanduser("~"),
                      "AppData", "Roaming", "MetaQuotes", "Terminal",
                      "Common", "Files")
AUT = ("autorisation utilisateur 19/09/2026 - confrontations des candidats a "
       "trois criteres aux fenetres ANNUELLES 2020-2023")
# Les six portefeuilles qui passent R/tx>0 ET hostile>0 ET R/DD>=3 --
# mais sur 9 trimestres de 2024-2025 seulement. On les confronte a 2020-2023.
CIBLES = [("g_g1_eurusd_s6_t12.txt", "ann_g1_s6_t12", 6, 2.0),
          ("g_g1_eurusd_s12_t1.txt", "ann_g1_s12_t1", 12, 0.0833),
          ("g_g1_eurusd_s6_t4.txt", "ann_g1_s6_t4", 6, 0.6667)]


def occupe():
    r = subprocess.run(["powershell", "-NoProfile", "-Command",
                        "@(Get-CimInstance Win32_Process -Filter "
                        "\"Name='python.exe'\" | Where-Object { $_.CommandLine "
                        "-match 'lab_parallel|reel_continue' }).Count"],
                       capture_output=True, text=True)
    try:
        return int((r.stdout or "0").strip().splitlines()[-1]) > 0
    except Exception:
        return True


print("attente de la ferme libre...", flush=True)
t0 = time.time()
while occupe() and time.time() - t0 < 3600:
    time.sleep(30)
print("ferme libre apres %.0f s" % (time.time() - t0), flush=True)

for f, tag, sl, tpr in CIBLES:
    sf = os.path.join(COMMON, f)
    if not os.path.exists(sf):
        print("   %s : setfile absent" % f, flush=True)
        continue
    lg = os.path.join(B, "%s.log" % tag)
    cmd = [sys.executable, os.path.join(B, "SCRIPTS", "lab_parallel.py"),
           "--only", "farm", "--syms", "EURUSD", "--setfile", f, "--tag", tag,
           "--sl-atr", str(sl), "--tp-r", str(tpr), "--hold-bars", "192",
           "--annuel", "--resume", "--holdout", AUT]
    print("   LANCE %-16s stop %d (13 fenetres)" % (tag, sl), flush=True)
    with open(lg, "w", encoding="utf-8") as fh:
        p = subprocess.Popen(cmd, cwd=B, stdout=fh, stderr=subprocess.STDOUT)
        p.wait()
    pf = os.path.join(B, "par_farm_%s.jsonl" % tag)
    txs = []
    if os.path.exists(pf):
        for line in open(pf, encoding="utf-8", errors="replace"):
            if line.strip().startswith("{"):
                try:
                    txs.append(int(json.loads(line).get("trades", 0)))
                except ValueError:
                    pass
    txs = [t for t in txs if t > 0]
    med = sorted(txs)[len(txs) // 2] if txs else 0
    suspect = [t for t in txs if med and (t > 3 * med or t * 3 < med)]
    print("      -> %d fenetres, %d transactions, %s"
          % (len(txs), sum(txs), "SUSPECT (a jeter)" if suspect else "coherent"),
          flush=True)
print("termine", flush=True)
