# -*- coding: utf-8 -*-
"""diag_degeler.py — COMBIEN DE COMBINAISONS FAUT-IL DEGELER, ET A QUEL SEUIL ?

Le probleme. L'elagage precedent a ecrit des interdictions GLOBALES. Mesure du
degat : 16 des 21 lignes du portefeuille classique etaient ecrasees a tort. Il
faut donc degeler -- mais pas tout : si on degele trop, chaque bloc remesure
plus de combinaisons que le plafond de l'EA (MAXC 5000) et la mesure sature.

Ce script ne decide rien : il MESURE. Pour chaque seuil de protection
(R minimum, nombre de trades minimum, nombre de trimestres minimum) il donne
  - le nombre de combinaisons degelees ;
  - la taille finale de la liste noire ;
  - le nombre de combinaisons restant a mesurer par bloc ;
  - si les 21 lignes du portefeuille survivent.

USAGE : python diag_degeler.py
"""
import collections
import json
import statistics
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
BLACK = (Path.home() / "AppData/Roaming/MetaQuotes/Terminal/Common/Files"
         / "lab_black.txt")
TRI = {"2024.01", "2024.07"}
Q = {"2024Q1", "2024Q2", "2024Q3", "2024Q4", "2025Q1"}
PAIRES = ["EURUSD", "USDJPY", "EURJPY", "AUDJPY", "GBPJPY",
          "USDCAD", "CADJPY", "NZDUSD"]
MAXC = 5000


def main():
    tri = collections.defaultdict(dict)
    cla = collections.defaultdict(dict)
    ids = set()
    syms = set()
    with open(BASE / "lab_results.jsonl", encoding="utf-8") as fh:
        for line in fh:
            if not line.strip():
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            if "r_x54" not in r:
                continue
            ids.add(r["id"])
            syms.add(r["sym"])
            p = str(r.get("period", ""))
            if p in TRI:
                tri[(r["id"], r["sym"])][p] = r
            elif p in Q and r["n"] >= 3:
                cla[(r["id"], r["sym"])][p] = r
    # ATTENTION : un identifiant de combinaison contient DEJA des barres
    # verticales (NEST3_E|NONE|FIB_FVG_M30|L). On ne peut donc pas reconnaitre
    # une entree par paire a la presence d'un "|" : il faut que le dernier
    # morceau soit un symbole REELLEMENT present dans les donnees. La liste des
    # symboles vient des donnees, pas de la liste noire (sinon on tourne en
    # rond : "NEST3_D|NONE|HQUIET" a bien 6 lettres majuscules lui aussi).
    txt = BLACK.read_text().splitlines() if BLACK.exists() else []
    tous = {l.strip() for l in txt if l.strip()}
    parpaire = {l for l in tous if l.split("|")[-1] in syms}
    anciens = tous - parpaire

    # meilleur couple classique de chaque combinaison bloquee
    meilleur = {}
    for (cid, sym), d in cla.items():
        v = [r["r_x54"] for r in d.values()]
        R, n, q = statistics.mean(v), sum(r["n"] for r in d.values()), len(v)
        if cid not in meilleur or R > meilleur[cid][0]:
            meilleur[cid] = (R, n, q, sym)

    # portefeuille classique : top 3 par paire
    par = collections.defaultdict(list)
    for (cid, sym), d in cla.items():
        if sym in PAIRES and len(d) >= 4:
            par[sym].append((cid, statistics.mean([r["r_x54"]
                                                   for r in d.values()])))
    porto = set()
    for sym, lst in par.items():
        lst.sort(key=lambda x: -x[1])
        porto |= {(c, sym) for c, _ in lst[:3]}

    # couples du tri ecartes (regle v2)
    ecartes, tot, bons = [], collections.Counter(), collections.Counter()
    for (cid, sym), d in tri.items():
        R = statistics.mean([r["r_x54"] for r in d.values()])
        n = sum(r["n"] for r in d.values())
        ok = not (n < 8 or len(d) < 2 or R <= 0)
        ecartes.append((cid, sym, ok))
        tot[cid] += 1
        if ok:
            bons[cid] += 1

    print("=" * 92)
    print("DIAGNOSTIC DU DEGELAGE")
    print("   combinaisons connues                   : %d" % len(ids))
    print("   entrees globales dans la liste noire   : %d" % len(anciens))
    print("   lignes du portefeuille classique       : %d" % len(porto))
    print("   combinaisons bloquees SANS mesure      : %d"
          % sum(1 for a in anciens if a not in meilleur))
    print("   combinaisons bloquees AVEC mesure      : %d"
          % sum(1 for a in anciens if a in meilleur))
    print()
    print("   %-22s %8s %8s %10s %8s %8s"
          % ("seuil de protection", "degelees", "black", "a mesurer",
             "par paire", "porto"))
    for rmin, nmin, qmin in [(0.0, 8, 2), (0.05, 10, 2), (0.10, 15, 3),
                             (0.15, 20, 3), (0.20, 20, 3), (0.25, 25, 4),
                             (0.30, 25, 4), (0.40, 30, 4)]:
        def protege(c):
            return (c in meilleur and meilleur[c][0] >= rmin
                    and meilleur[c][1] >= nmin and meilleur[c][2] >= qmin)
        deg = {c for c in anciens if protege(c)}
        glob = (anciens - deg) | {c for c in tot if bons[c] == 0 and not protege(c)}
        ppr = {(c, s) for (c, s, ok) in ecartes
               if not ok and not protege(c)}
        surv = len(ids - glob)
        ecr = sum(1 for (c, s) in porto
                  if c in glob or (c, s) in ppr)
        print("   R>=%.2f n>=%d T>=%d      %8d %8d %10d %8d %8d %s"
              % (rmin, nmin, qmin, len(deg), len(glob), surv, len(ppr),
                 len(porto) - ecr,
                 "SATURE" if surv > MAXC else ""))

    print()
    print("LES 21 LIGNES DU PORTEFEUILLE, UNE PAR UNE")
    print("   %-40s %-8s %8s %6s %4s %8s %6s"
          % ("combinaison", "paire", "R class", "n", "T", "R tri", "n"))
    for (c, s) in sorted(porto, key=lambda x: x[1]):
        d = cla.get((c, s), {})
        v = [r["r_x54"] for r in d.values()]
        Rc = statistics.mean(v) if v else float("nan")
        nc = sum(r["n"] for r in d.values())
        t = tri.get((c, s), {})
        vt = [r["r_x54"] for r in t.values()]
        Rt = statistics.mean(vt) if vt else float("nan")
        nt = sum(r["n"] for r in t.values())
        prot = "oui" if (Rc == Rc and Rc > 0 and nc >= 8 and len(v) >= 2) else "NON"
        print("   %-40s %-8s %+8.3f %6d %4d %+8.3f %6d  %s"
              % (c[:40], s, Rc, nc, len(v), Rt, nt, prot))
    print()
    print("   Une ligne marquee NON a un R classique negatif (ou trop peu de")
    print("   trades) : elle n'a pas de mesure directe positive a opposer au")
    print("   tri. La bloquer est donc defendable -- mais c'est un choix a")
    print("   valider, pas un effet de bord a subir.")

    print()
    print("RAPPEL : sous 5 000, un bloc tient. Au-dessus, l'EA sature et")
    print("         l'avertissement de saturation apparait dans le journal.")


if __name__ == "__main__":
    main()
