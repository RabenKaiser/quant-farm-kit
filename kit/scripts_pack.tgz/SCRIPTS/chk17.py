﻿import pandas as pd
from datetime import datetime, timezone
p = r"C:\EAFarm\HISTORY - Copy\research\m1_pos\NZDJPY_M1.csv"
df = pd.read_csv(p)
print(f"lignes : {len(df):,}")
t = df['time']
print(f"min : {datetime.fromtimestamp(int(t.min()), tz=timezone.utc)}")
print(f"max : {datetime.fromtimestamp(int(t.max()), tz=timezone.utc)}")
print(f"monotone : {bool((t.diff().dropna()>0).all())}")
# trouve les valeurs aberrantes
bad = df[(t < 1000000000)]   # avant 2001
print(f"\nlignes avec timestamp aberrant (< 2001) : {len(bad)}")
if len(bad): print(bad.head(5).to_string())
