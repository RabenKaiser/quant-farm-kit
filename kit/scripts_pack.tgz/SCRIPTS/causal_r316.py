# -*- coding: utf-8 -*-
"""causal_r316.py — VERIFICATION INDEPENDANTE DU LOOK-AHEAD SIGNALE PAR sweeper_duka.

LA THESE: `detect_signals` rend un OB utilisable des que i15 >= dispo(=kk, la
barre M15 qui CONFIRME l OB). Or c[kk]/body[kk] ne sont connus qu a la CLOTURE
de la barre kk. Si l entree M5 tombe DANS la barre kk, on utilise de
l information future.

verification: on instrumente detect_signals pour compter, parmi les trades,
ceux dont la barre de signal est DANS la barre M15 de confirmation, et on
mesure (a) leur part, (b) leur R, (c) le R du sous-ensemble STRICTEMENT causal
(dispo < i15).

Puis on construit une variante CAUSALE du moteur et on compare.
"""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import pandas as pd, numpy as np
import c13v2_py_v3 as F
import c13v2_engine as ENG
from pathlib import Path

M1R = Path(r"C:\EAFarm\HISTORY - Copy\research\m1_real")


def load_real(sym):
    df = pd.read_csv(M1R / f"{sym}_M1.csv")
    idx = pd.to_datetime(df["time"].astype("int64"), unit="s", utc=True)
    o = pd.DataFrame({"open": df["open"].to_numpy(float), "high": df["high"].to_numpy(float),
                      "low": df["low"].to_numpy(float), "close": df["close"].to_numpy(float),
                      "volume": df["tick_volume"].to_numpy(float),
                      "spread": df["spread"].to_numpy(float)})
    o.index = idx
    return o[~o.index.duplicated(keep="first")].sort_index()


BASE = {"imp_atr": 0.7, "imp_vol": 1.0, "imp_look": 6, "ob_age": 4,
        "rej_wick": 0.4, "rej_vol": 1.0, "close_zone": 0.15, "bias": "vwap",
        "excl_hours": [21, 22, 23, 0, 1, 2, 3], "lookahead": False,
        "vwap_len": 96, "tp_r": 99, "min_stop": 0.00025, "buf_atr": 1.0,
        "bias_src": "m5_asof"}

print("=" * 100)
print("R316 — VERIFICATION DU LOOK-AHEAD (these sweeper_duka)")
print("=" * 100)
m = load_real("XAUUSD")
s = pd.Timestamp("2020-01-01", tz="UTC"); e = pd.Timestamp("2026-01-01", tz="UTC")
w = m.loc[s - pd.Timedelta(days=260):e]
m5 = F.resample(w, "5min").loc[s:e]
m15 = F.resample(w, "15min"); h4 = F.resample(w, "4h")

# --- 1) reproduit detect_signals en gardant l info de causalite ---
o15 = m15["open"].to_numpy(); h15 = m15["high"].to_numpy()
l15 = m15["low"].to_numpy(); c15 = m15["close"].to_numpy()
v15 = m15["volume"].to_numpy()
a15v = ENG.SW.F.atr_s(m15, 14).to_numpy()
av = pd.Series(v15).rolling(50).mean().to_numpy()
n15 = len(m15)
body = np.abs(c15 - o15)
is_bull = c15 > o15; is_bear = c15 < o15
L = BASE["imp_look"]; imp_mult = BASE["imp_atr"]; vol_mult = BASE["imp_vol"]
bull = {}; bear = {}
for jj in range(n15):
    if not np.isfinite(a15v[jj]) or a15v[jj] <= 0:
        continue
    thr = a15v[jj] * imp_mult
    if is_bear[jj]:
        for k in range(1, L + 1):
            kk = jj + k
            if kk >= n15: break
            vok = (not np.isfinite(av[kk])) or v15[kk] >= av[kk] * vol_mult
            if is_bull[kk] and body[kk] >= thr and c15[kk] > h15[jj] and vok:
                bull[jj] = (kk, l15[jj], o15[jj]); break
    if is_bull[jj]:
        for k in range(1, L + 1):
            kk = jj + k
            if kk >= n15: break
            vok = (not np.isfinite(av[kk])) or v15[kk] >= av[kk] * vol_mult
            if is_bear[kk] and body[kk] >= thr and c15[kk] < l15[jj] and vok:
                bear[jj] = (kk, o15[jj], h15[jj]); break

m15_t = m15.index.values.astype("datetime64[ns]")
m5_t = m5.index.values.astype("datetime64[ns]")
idx15 = np.clip(np.searchsorted(m15_t, m5_t, side="right") - 1, 0, n15 - 1)

# pour chaque barre M5, l OB dispo (non causal) et sa barre de confirmation
lastB = {}; lastS = {}
bi = si = 0
curB = curS = None
bull_items = sorted(bull.items()); bear_items = sorted(bear.items())
dispo_map = {}
for i15 in range(n15):
    while bi < len(bull_items) and bull_items[bi][0] <= i15:
        jj, (dispo, zl, zh) = bull_items[bi]
        if dispo <= i15:
            curB = (zl, zh, jj, dispo); bi += 1
        else:
            break
    while si < len(bear_items) and bear_items[si][0] <= i15:
        jj, (dispo, zl, zh) = bear_items[si]
        if dispo <= i15:
            curS = (zl, zh, jj, dispo); si += 1
        else:
            break
    lastB[i15] = curB; lastS[i15] = curS

print(f"\nM5={len(m5)} M15={n15}")
print(f"OB bull detectes: {len(bull)} | OB bear: {len(bear)}")

# --- 2) compte les signaux dont la barre M5 est DANS la M15 de confirmation ---
sig, _ = ENG.detect_signals(m5, m15, dict(BASE))
n_in = n_out = 0
for i in sig:
    i15 = idx15[i]
    z = lastB.get(i15) if sig[i][0] == 1 else lastS.get(i15)
    if z is None: continue
    dispo = z[3]
    if i15 == dispo: n_in += 1
    else: n_out += 1
print(f"\nSIGNAUX par rapport a la barre M15 de confirmation:")
print(f"  DANS la barre de confirmation (i15 == dispo) -> LOOK-AHEAD : {n_in}")
print(f"  dans une barre ULTERIEURE   (i15 >  dispo) -> CAUSAL      : {n_out}")
if n_in + n_out:
    print(f"  part look-ahead = {n_in/(n_in+n_out)*100:.1f} %")

# --- 3) R des deux sous-ensembles (via le moteur, en filtrant les trades) ---
def run_filtered(keep_mode):
    """keep_mode: 'all' | 'causal' | 'noncausal' -- on rejoue la boucle en
    n utilisant que les signaux du sous-ensemble."""
    keep = {}
    for i in sig:
        i15 = idx15[i]
        z = lastB.get(i15) if sig[i][0] == 1 else lastS.get(i15)
        if z is None: continue
        is_in = (i15 == z[3])
        if keep_mode == "causal" and is_in: continue
        if keep_mode == "noncausal" and not is_in: continue
        keep[i] = sig[i]
    # boucle identique a run_exit mais avec `keep`
    return ENG.run_exit(m5, m15, h4, dict(BASE), exit_mode="extend", ext_atr=6.0,
                        tp_r=99, spread_pips=14.0, point_size=0.01,
                        atr_ref=None, ext_fill="close", slip_points=1.0,
                        _signals=keep) if False else _loop(keep)


def _loop(keep):
    """copie de la boucle de run_exit avec le dict de signaux impose."""
    import types
    a15 = ENG.SW.F.atr_s(m15, 14)
    a15i = a15.reindex(a15.index.union(m5.index)).ffill().reindex(m5.index).to_numpy()
    tv = (h4["high"] + h4["low"] + h4["close"]) / 3
    vwap = (tv * h4["volume"]).rolling(96).sum() / h4["volume"].rolling(96).sum()
    _v = vwap.dropna()
    bv = _v.reindex(_v.index.union(m5.index)).ffill().reindex(m5.index).to_numpy()
    o5 = m5["open"].to_numpy(); h5 = m5["high"].to_numpy()
    l5 = m5["low"].to_numpy(); c5 = m5["close"].to_numpy()
    hour = m5.index.hour.to_numpy()
    SP = 14.0 * 0.01; SLIP = 0.01
    excl = set(BASE["excl_hours"]); buf = BASE["buf_atr"]
    pos = None; trades = []
    for i in range(1, len(m5)):
        if pos is not None:
            d = pos["d"]; entry = pos["entry"]; risk = pos["risk"]
            pos["hi"] = max(pos["hi"], h5[i]) if d == 1 else pos["hi"]
            pos["lo"] = min(pos["lo"], l5[i]) if d == -1 else pos["lo"]
            ext = pos["hi"] if d == 1 else pos["lo"]
            a5 = a15i[i]
            eff_l = l5[i] - SP if d == 1 else l5[i] + SP
            eff_h = h5[i] - SP if d == 1 else h5[i] + SP
            hs = (eff_l <= pos["sl"]) if d == 1 else (eff_h >= pos["sl"])
            dist = d * (ext - entry)
            he = bool(np.isfinite(a5) and a5 > 0 and dist >= 6.0 * a5)
            if hs or he:
                if hs:
                    r = (pos["sl"] - entry - SP - SLIP) / risk if d == 1 \
                        else (entry - pos["sl"] - SP - SLIP) / risk
                else:
                    r = (c5[i] - entry - SP - SLIP) / risk if d == 1 \
                        else (entry - c5[i] - SP - SLIP) / risk
                trades.append(r); pos = None
        if pos is None and i in keep and hour[i] not in excl:
            sg = keep[i]; d = sg[0]
            bb = bv[i - 1]
            if np.isfinite(bb):
                cv = c5[i - 1]
                if (d == 1 and cv <= bb) or (d == -1 and cv >= bb):
                    continue
                a5 = a15i[i]
                if not np.isfinite(a5) or a5 <= 0: continue
                entry = c5[i] + d * SLIP
                zlo, zhi = min(sg[1], sg[2]), max(sg[1], sg[2])
                if d == 1:
                    sl0 = zlo - buf * a5; risk = entry - sl0
                else:
                    sl0 = zhi + buf * a5; risk = sl0 - entry
                if risk <= 0: continue
                pos = {"d": d, "entry": entry, "sl": sl0, "risk": risk,
                       "hi": entry, "lo": entry}
    if not trades:
        return dict(n=0, R=0.0, pf=0.0, wr=0.0, dd=0.0)
    arr = np.array(trades)
    w = arr[arr > 0]; lo = arr[arr < 0]
    eq = np.cumsum(arr); dd = float((np.maximum.accumulate(eq) - eq).max())
    return dict(n=len(arr), R=float(arr.sum()),
                pf=float(w.sum() / -lo.sum()) if len(lo) else 99.0,
                wr=float(len(w) / len(arr) * 100), dd=dd)


print("\n--- R des sous-ensembles (meme config: buf1.0/ext6/ob_age4/nuit) ---")
for lab in ("all", "causal", "noncausal"):
    r = run_filtered(lab)
    rdd = r["R"] / r["dd"] if r["dd"] > 0 else 0
    print(f"  {lab:10s} : n={r['n']:4d} R={r['R']:+8.1f} pf={r['pf']:5.2f} "
          f"wr={r['wr']:5.1f}% dd={r['dd']:6.1f} R/DD={rdd:5.2f}")

print("\n" + "=" * 100)
print("VERDICT")
print("=" * 100)
print("  Si 'causal' est tres inferieur a 'all', le look-ahead est CONFIRME et le")
print("  R/DD 20,5 est un ARTEFACT. La reference valide devient la version causale.")
print("\nFIN", flush=True)
