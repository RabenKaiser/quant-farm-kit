# -*- coding: utf-8 -*-
"""cout_niveau.py — OU LE COUT LAISSE-T-IL DE LA PLACE ?

Le classement des combinaisons ne se repete pas (persistance_rang.py : -0.033).
Reste donc une seule piste, celle qui a repliqué partout : le COUT.

Deux questions differentes, qu'il ne faut pas confondre :
  - le R moyen de la POPULATION est-il meilleur sur les paires bon marche ?
    (niveau)
  - le classement y est-il plus stable ? (persistance)

Ce script repond aux deux, paire par paire, sur la population ">= 4 trimestres"
(celle du portefeuille), et sur deux moities de periode.

USAGE : python cout_niveau.py
"""
import collections
import json
import statistics
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
A = ["2024Q1", "2024Q2"]
B = ["2024Q3", "2024Q4"]
Q = ["2024Q1", "2024Q2", "2024Q3", "2024Q4", "2025Q1"]
COUT = {"EURUSD": 6.3, "USDJPY": 6.1, "EURJPY": 13.9, "AUDJPY": 17.9,
        "GBPJPY": 23.6, "USDCAD": 32.6, "CADJPY": None, "NZDUSD": 35.8,
        "USDCHF": 31.7, "EURGBP": 39.5, "EURAUD": 43.2, "GBPCAD": 59.3,
        "AUDNZD": 75.1}


def main():
    g = collections.defaultdict(dict)
    with open(BASE / "lab_results.jsonl", encoding="utf-8") as fh:
        for line in fh:
            if not line.strip():
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            p = str(r.get("period", ""))
            if p not in Q or r["n"] < 3 or "r_x54" not in r:
                continue
            g[(r["id"], r["sym"])][p] = r

    par = collections.defaultdict(list)
    for (cid, sym), d in g.items():
        if len(d) < 4:
            continue
        par[sym].append(dict(id=cid, sym=sym, d=d,
                             R=statistics.mean([r["r_x54"] for r in d.values()]),
                             n=sum(r["n"] for r in d.values())))
    print("=" * 90)
    print("1. LE NIVEAU, PAIR PAR PAIR (population >= 4 trimestres)")
    print("=" * 90)
    print("   %-8s %7s %9s %11s %10s %9s"
          % ("paire", "cout %", "combos", "R/trade", "trades", "% R>0"))
    lignes = []
    for s, cs in par.items():
        tR = sum(c["R"] * c["n"] for c in cs)
        tN = sum(c["n"] for c in cs)
        pos = 100.0 * sum(1 for c in cs if c["R"] > 0) / len(cs)
        lignes.append((COUT.get(s), s, len(cs), tR / tN if tN else 0, tN, pos))
    for c, s, n, R, tN, pos in sorted(lignes, key=lambda x: (x[0] is None, x[0])):
        print("   %-8s %7s %9d %+11.3f %10d %8.1f%%"
              % (s, ("%.1f" % c) if c is not None else "-", n, R, tN, pos))

    print()
    print("=" * 90)
    print("2. LE CLASSEMENT SE REPETE-T-IL MIEUX SUR LES PAIRES BON MARCHE ?")
    print("=" * 90)
    print("   %-8s %7s %10s %11s %10s"
          % ("paire", "cout %", "Spearman", "top10% B", "reste B"))
    for c, s, n, R, tN, pos in sorted(lignes, key=lambda x: (x[0] is None, x[0])):
        cs = []
        for x in par[s]:
            va = [x["d"][q]["r_x54"] for q in A if q in x["d"]]
            vb = [x["d"][q]["r_x54"] for q in B if q in x["d"]]
            if va and vb:
                cs.append((statistics.mean(va), statistics.mean(vb),
                           sum(x["d"][q]["n"] for q in B if q in x["d"])))
        if len(cs) < 50:
            print("   %-8s %7s %10s %11s %10s"
                  % (s, ("%.1f" % c) if c is not None else "-", "n/a", "-", "-"))
            continue
        o = sorted(range(len(cs)), key=lambda i: -cs[i][0])
        k = max(1, len(o) // 10)
        h = [cs[i] for i in o[:k]]
        b = [cs[i] for i in o[k:]]
        rh = sum(x[1] * x[2] for x in h) / max(1, sum(x[2] for x in h))
        rb = sum(x[1] * x[2] for x in b) / max(1, sum(x[2] for x in b))
        # correlation de rang
        ra, rbb = [x[0] for x in cs], [x[1] for x in cs]
        ma, mb = statistics.mean(ra), statistics.mean(rbb)
        num = sum((x - ma) * (y - mb) for x, y in zip(ra, rbb))
        da = sum((x - ma) ** 2 for x in ra) ** 0.5
        db = sum((y - mb) ** 2 for y in rbb) ** 0.5
        rho = num / (da * db) if da and db else 0.0
        print("   %-8s %7s %+10.3f %+11.3f %+10.3f"
              % (s, ("%.1f" % c) if c is not None else "-", rho, rh, rb))
    print()
    print("   Lecture : si le R moyen reste negatif meme sur les paires a")
    print("   spread/ATR de 6 % (EURUSD, USDJPY), alors le probleme n'est PAS")
    print("   le cout : c'est que le couple declencheur/sortie n'a aucun")
    print("   avantage, et aucun filtre de cout ne le sauvera.")


if __name__ == "__main__":
    main()
