"""court_sweep : le panier le plus simple (tout COURT, SR n=50, 1 ATR / 1 R).

Resultat du round 139 : la version SANS sophistication -- une jambe par paire,
toutes COURTES, motif SR n=50, stop 1 ATR, objectif 1 R -- passe les cinq seuils
(R/tx +0,0113, hostile +0,0292, R/DD 7,79, 26/36 mois positifs), alors que la
version « intelligente » (sens choisi par stabilite) ne fait que 68,8e
percentile face au hasard.

Ce script fait les deux verifications qui ont tue tous les candidats precedents :
  1. BALAYAGE DES COUPURES : le resultat tient-il pour d'autres dates de coupure ?
  2. DETAIL PAR PAIR : quelles paires portent, quelles paires coulent.
"""
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import portefeuille_large as PL

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
OUT = B / "court_sweep.md"
HOSTILE = (("2024-01", "2024-06"), ("2025-04", "2025-12"))
INDICES = ("SPXUSD", "NSXUSD", "UDXUSD")
COUPURES = ("2021-01", "2021-07", "2022-01", "2022-07", "2023-01", "2023-07", "2024-01")


def mois(t):
    return "%04d-%02d" % (t.year, t.month)


def main():
    PL.STOP, PL.RR = 1.0, 1.0
    donnees = {}
    for p, b, cout in PL.charge_tout():
        if p in INDICES:
            continue
        idx = PL.motifs(b).get(("SR n=50", -1))
        if idx is None:
            continue
        idx = idx[idx < len(b) - 34]
        pip = 0.01 if p.endswith("JPY") else 0.0001
        c_up = {"EURUSD":0.10,"GBPUSD":0.10,"AUDUSD":0.10,"NZDUSD":0.10,"USDCAD":0.20,"USDCHF":0.10,"EURGBP":0.10,"EURJPY":0.50,"GBPJPY":0.70,"AUDJPY":0.20,"CADJPY":0.40}.get(p)
        if c_up:
            cout = c_up * pip / float(b.atr.median())
        R, T = PL.r_par_trade(b, idx, -1, cout)
        if R is None:
            continue
        mm = np.array([mois(t) for t in T])
        per = defaultdict(list)
        for m, x in zip(mm, R):
            per[m].append(x)
        per = {m: float(np.mean(x)) for m, x in per.items() if len(x) >= 10}
        if len(per) >= 12:
            donnees[p] = dict(per=per, rt=float(np.mean(R)))
    print("paires : %d" % len(donnees), flush=True)

    out = ["# Panier simple : une jambe par paire, TOUTES COURTES (SR n=50, 1 ATR / 1 R)", "",
           "| coupure | paires | mois test | R/tx | R total | pire mois | hostile | R/DD | annuelles | mois + | GELE ? |",
           "|---|---|---|---|---|---|---|---|---|---|---|"]
    for c in COUPURES:
        par_mois = defaultdict(list)
        for d in donnees.values():
            for m, v in d["per"].items():
                if m >= c:
                    par_mois[m].append(v)
        ms = sorted(par_mois)
        s = [float(np.mean(par_mois[m])) for m in ms]
        eq = pic = dd = 0.0
        for x in s:
            eq += x
            pic = max(pic, eq)
            dd = max(dd, pic - eq)
        h = [x for m, x in zip(ms, s) if any(a <= m <= b for a, b in HOSTILE)]
        ann = sum(1 for m in ms if int(m[:4]) <= 2023)
        rdd = eq / dd if dd > 1e-9 else None
        rt = float(np.mean([d["rt"] for d in donnees.values()]))
        passe = (rt > 0 and (np.mean(h) > 0 if h else False)
                 and (rdd is None or rdd >= 3) and len(ms) >= 11 and ann >= 2)
        out.append("| %s | %d | %d | %+.4f | %+.4f | %+.4f | %+.4f | %s | %d | %d/%d | %s |"
                   % (c, len(donnees), len(ms), rt, eq, min(s) if s else 0.0,
                      float(np.mean(h)) if h else 0.0,
                      "%.2f" % rdd if rdd else "inf", ann,
                      sum(1 for x in s if x > 0), len(s), "OUI" if passe else "non"))
        print("coupure %s : R/tx %+.4f | R %+.4f | pire %+.4f | hostile %+.4f | R/DD %s | mois + %d/%d | %s"
              % (c, rt, eq, min(s) if s else 0.0, float(np.mean(h)) if h else 0.0,
                 "%.2f" % rdd if rdd else "inf", sum(1 for x in s if x > 0), len(s),
                 "GELE" if passe else "non"), flush=True)

    c = "2023-01"
    out += ["", "## detail par paire apres %s (tout COURT)" % c]
    det = []
    for p, d in donnees.items():
        ap = [v for m, v in d["per"].items() if m >= c]
        if not ap:
            continue
        det.append((p, float(np.mean(ap)), float(np.min(ap)),
                    sum(1 for x in ap if x > 0), len(ap)))
    for p, mo, pi, pos, n in sorted(det, key=lambda x: -x[1]):
        out.append("- **%s** : moy %+.4f | pire %+.4f | %d/%d mois +" % (p, mo, pi, pos, n))
    pos_p = [x for x in det if x[1] > 0]
    out += ["", "**Paires positives apres la coupure : %d sur %d** (%s)"
            % (len(pos_p), len(det), ", ".join(x[0] for x in pos_p))]
    OUT.write_text("\n".join(out), encoding="utf-8")
    print("paires positives apres %s : %d/%d" % (c, len(pos_p), len(det)), flush=True)
    print("ecrit %s" % OUT, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())

