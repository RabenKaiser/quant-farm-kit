﻿import MetaTrader5 as mt5
mt5.initialize(path=r"C:\EAFarm\MT5\Farm\terminal64.exe")
syms = ["GBPUSD","EURUSD","AUDNZD","XAGUSD","EURJPY","EURAUD","GBPJPY","USDCAD","XAUUSD"]
print(f"{'sym':<9}{'visible':>9}{'select':>8}{'path':>34}")
for s in syms:
    i = mt5.symbol_info(s)
    if not i: print(f"{s:<9}{'ABSENT':>9}"); continue
    print(f"{s:<9}{str(i.visible):>9}{str(i.select):>8}{i.path:>34}")
mt5.shutdown()
