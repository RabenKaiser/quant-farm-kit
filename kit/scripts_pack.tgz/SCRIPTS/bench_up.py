# -*- coding: utf-8 -*-
"""bench_up.py — LE MEME BANC SUR UPCOMERS (2e broker, en parallele).

POURQUOI
--------
L'utilisateur veut les DEUX MT5. Dukascopy tourne la DECOUVERTE (2024),
Upcomers tourne la meme chose sur SA periode (2026).

Les deux terminaux sont des installations SEPAREES, donc ils peuvent tourner
en meme temps. La seule precaution : chacun sa table (l'EA ne lit que
Common\\Files, qui est partage) -> prefixe UP_.

Upcomers n'a du M5 que depuis 2026.01.16, donc les fenetres sont courtes :
  DISC : 2026.02.01 -> 2026.05.01  (3 mois)
  VAL  : 2026.05.01 -> 2026.08.01  (3 mois)

MODELE : Model=2 sur Upcomers. Model=4 (ticks reels) demande de telecharger
les ticks, et le flux Upcomers n'en fournit pas d'historique exploitable.
"""
import os, sys, json, time, glob, subprocess, re
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
FARM = Path(r"C:\MT5")
TM = FARM / "terminal64.exe"
DATA = (Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")
        / "E23367DD11DBEB0EF97D08185EAB7295")
COMM = (Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")
        / "Common" / "Files")
CFGD = FARM / "Config"
OUT = BASE / "bench_up.json"

PERIODS = {
    "DISC": ("2026.02.01", "2026.05.01"),
    "VAL":  ("2026.05.01", "2026.08.01"),
}

MODEL = 2

STRUCTS = [
    "FVGDN10", "FVGDN20",
    "VWAPXDN", "VWAPWXDN", "VWAPMXDN", "VWAP24XDN",
    "REJBULL", "PINBULL", "NOWICKDN",
    "SWEEPLO", "SWEEPLO20", "SWEEPLO50", "SWEEPLO100",
    "BRKLL20", "BRKLL50", "BRKLL100", "LLLH",
]
FILTS = ["", "VOLLO", "HQUIET"]
SYMS = ["CADJPY", "EURUSD", "GBPJPY", "AUDUSD", "USDCHF", "EURJPY",
        "NZDUSD", "USDCAD", "EURGBP", "AUDJPY"]


def kill():
    """Tue UNIQUEMENT le terminal Upcomers (C:\\MT5).

    Ne PAS utiliser `taskkill /IM terminal64.exe` : ca tuerait aussi le
    terminal Dukascopy qui tourne en parallele.
    """
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='terminal64.exe'\" | "
          "Where-Object { $_.ExecutablePath -like 'C:\\MT5\\*' } | "
          "ForEach-Object { Stop-Process -Id $_.ProcessId -Force "
          "-ErrorAction SilentlyContinue }")
    subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def find_logs():
    """Les logs du testeur Upcomers sont dans le dossier AGENT."""
    c = []
    c += glob.glob(str(DATA / "Tester" / "logs" / "*log*"))
    root = (Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes")
            / "Tester" / DATA.name)
    c += glob.glob(str(root / "Agent-*" / "logs" / "*log*"))
    return c


def write_tables(sym, sl, tp, hold):
    files = {}
    for i, st in enumerate(STRUCTS):
        for j, fl in enumerate(FILTS):
            fn = f"UP_BN_{sym}_{st}_{fl or 'N'}.csv"
            (COMM / fn).write_text(
                "%s,1,%s,%.3f,%.1f,%.3f,%d,%d\n"
                % (st, fl, sl, tp, 0.0, hold, 996000 + i * 10 + j),
                encoding="ascii")
            files[(st, fl)] = fn
    return files


def run(sym, fn, p0, p1, wait=900):
    cfg = CFGD / "bench_up.ini"
    cfg.write_text(
        "[Tester]\nExpert=eepeek\\ORION_ROBOT.ex5\nSymbol=%s\nPeriod=M5\n"
        "Model=%d\nOptimization=0\nFromDate=%s\nToDate=%s\nDeposit=100000\n"
        "Currency=USD\nLeverage=100\nReplaceReport=1\nShutdownTerminal=1\n"
        "[TesterInputs]\nInpLots=0.10\nInpMaxPos=1\nInpMaxPerSide=1\n"
        "InpLegsFile=%s\nInpMaxSpreadMult=0\nInpMaxSpreadAtr=1.5\n"
        "InpSessStart=0\nInpSessEnd=24\n"
        "InpDayStopPct=0\nInpMaxDDStopPct=0\n"
        "InpVerbose=true\nInpTrace=false\nInpNoHedge=true\n"
        % (sym, MODEL, p0, p1, fn))
    kill(); time.sleep(2)
    p = subprocess.Popen([str(TM), "/config:" + str(cfg)], cwd=str(FARM),
                         creationflags=0x08000000,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    w = 0
    while w < wait:
        time.sleep(2); w += 2
        rr = subprocess.run(["tasklist", "/FI", "PID eq %d" % p.pid],
                            capture_output=True, text=True)
        if "terminal64" not in rr.stdout:
            break
    kill(); time.sleep(2)
    best, bt = None, 0
    for lf in find_logs():
        try:
            if os.path.getsize(lf) < 300:
                continue
            t = os.path.getmtime(lf)
        except OSError:
            continue
        if t > bt:
            best, bt = lf, t
    if not best:
        return None
    raw = open(best, "rb").read()
    txt = (raw.decode("utf-16") if raw[:2] in (b"\xff\xfe", b"\xfe\xff")
           else raw.decode("utf-8", errors="replace"))
    mb = re.search(r"ORION BILAN %s sorties=(\d+) SL=(\d+) TP=(\d+) "
                   r"MAXHOLD=(\d+) autres=(\d+) gagnantes=(\d+) "
                   r"win=([\d.]+)%% pnl=(-?[\d.]+)" % sym, txt)
    if not mb:
        return None
    g = mb.groups()
    return dict(n=int(g[0]), sl=int(g[1]), tp=int(g[2]), mx=int(g[3]),
                win_n=int(g[5]), win=float(g[6]), pnl=float(g[7]))


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "DISC"
    p0, p1 = PERIODS[which]
    sl, tp, hold = 2.0, 1.5, 48
    res = json.load(open(OUT, encoding="utf-8")) if OUT.exists() else {}
    res.setdefault(which, {})
    total = len(SYMS) * len(STRUCTS) * len(FILTS)
    print("=" * 96)
    print(f"BANC UPCOMERS — {which} ({p0} -> {p1}) | Model={MODEL} | {total} runs")
    print("=" * 96)
    t0 = time.time(); done = 0
    for sym in SYMS:
        files = write_tables(sym, sl, tp, hold)
        res[which].setdefault(sym, {})
        for (st, fl), fn in files.items():
            k = f"{st}|{fl or 'N'}"
            if k in res[which][sym]:
                continue
            r = run(sym, fn, p0, p1)
            res[which][sym][k] = r
            done += 1
            if r and r["n"] >= 5:
                print(f"  [{done}/{total}] {sym:<7}{st:<11}{fl or '-':<8}"
                      f"n={r['n']:>3} SL={100*r['sl']/r['n']:>3.0f}% "
                      f"TP={100*r['tp']/r['n']:>3.0f}% win={r['win']:>5.1f}% "
                      f"pnl={r['pnl']:>8.2f}", flush=True)
            json.dump(res, open(OUT, "w"), indent=1)
        print(f"  --- {sym} fait ({time.time()-t0:.0f}s) ---", flush=True)

    print()
    print("=" * 96)
    print(f"SYNTHESE UPCOMERS {which}")
    print("=" * 96)
    agg = {}
    for sym in SYMS:
        for k, r in res[which].get(sym, {}).items():
            if not r or r["n"] < 5:
                continue
            a = agg.setdefault(k, dict(n=0, pnl=0.0, pos=0, tot=0, wins=0.0))
            a["n"] += r["n"]; a["pnl"] += r["pnl"]; a["tot"] += 1
            a["wins"] += r["win"] * r["n"]
            if r["pnl"] > 0:
                a["pos"] += 1
    for k, a in sorted(agg.items(), key=lambda kv: -kv[1]["pnl"])[:20]:
        print(f"{k:<24}{a['n']:>7}{a['pnl']:>11.2f}"
              f"{a['pos']:>6}/{a['tot']:<4}{100*a['wins']/max(1,a['n']):>7.1f}%")
    print(f"\n-> {OUT}")
