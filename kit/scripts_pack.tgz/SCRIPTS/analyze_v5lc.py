"""Analyse approfondie V5L_C : distribution mensuelle + réplication.
V5L_C (lb30) est le meilleur plateau (positif 3/3, stable). Vérifions :
1) médiane mensuelle > 0 (pas un tail)
2) base (quartile bas) > 0
3) répartition des gains (pas 2-3 mois monstres)
4) count MT5 vs moteur (réplication)
Parse les trades du log MT5 archivé."""
import sys, json, re
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner as m
from pathlib import Path
import numpy as np

# 1) re-lancer V5L_C 2023/2024/2025 pour avoir les archives
for year, (f, t) in {"2023": ("2023.01.01", "2024.01.01"),
                     "2024": ("2024.01.01", "2025.01.01"),
                     "2025": ("2025.01.01", "2026.01.01")}.items():
    r = m.run_backtest("V5L_C", "USDJPY", "M30", f, t, 10000)
    print(f"[V5L_C {year}] ${r.get('profit',0):+.0f} n={r.get('trades',0)} _archive={r.get('_archive')}")

# 2) analyser la dernière archive (2025) pour la distribution
FARM = Path(r"C:\EAFarm\MT5\Farm\MT5_RUNS")
archives = sorted(FARM.glob("V5L_C_*"), key=lambda p: p.stat().st_mtime)
if archives:
    latest = archives[-1]
    log = latest / "tester_agent.log"
    print(f"\narchive la plus récente: {latest.name}")
    if log.exists():
        raw = log.read_text("utf-16", errors="replace")
        lines = raw.splitlines()
        # extraire les entrées avec date
        entries = []
        for l in lines:
            me = re.search(r"(\d{4}\.\d{2}\.\d{2}) \d{2}:\d{2}:\d{2}\s+market (buy|sell)", l)
            if me:
                entries.append(me.group(1))
        # distribution par mois
        from collections import Counter
        months = Counter(d[:7] for d in entries)
        print(f"entrées: {len(entries)}, mois: {len(months)}")
        for mo in sorted(months):
            print(f"  {mo}: {months[mo]} trades")
