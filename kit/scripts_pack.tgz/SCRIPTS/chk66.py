﻿import pandas as pd, numpy as np, sys, gc
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT, deep_lib as D
G._cache.clear(); gc.collect()
F = G.get_frames("CADJPY"); m5,m1 = F["m5"],F["m1"]
h1z,hh,ll,a1,gb,gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd,zlo,zhi = MT.project(m5.index,h1z,hh,ll,gb,gr,max_age_h=48)
M = NL.build(m5,F,zd,zlo,zhi); M.update(FE.more(m5,F,m1))
T0,T1 = m5.index[0], m5.index[-1]
df = pd.read_csv(r"C:\EAFarm\HISTORY - Copy\research\m1_pos\CADJPY_M1.csv", usecols=["time","spread"])
df["ts"] = pd.to_datetime(df["time"], unit="s", utc=True)
sp5 = df.set_index("ts")["spread"].resample("5min").mean().reindex(m5.index).ffill().to_numpy()
med = np.nanmedian(sp5)
print(f"CADJPY spread median = {med:.1f}")
print()
print("=== xup_vwapD|bb_low (jambe CADJPY) ===")
s = NL.sig(M, "xup_vwapD", ["bb_low"])
print(f"  signaux bruts : {int((s!=0).sum())}")
st = D.run_ex("CADJPY", s, 1.5, 99.0, 960, trail_atr=None, t0=T0, t1=T1, use_m1=False)
print(f"  trades sans filtre : {st.get('n')}")
for mult in (2.5, 4.0, 6.0, 10.0):
    ok = sp5 <= mult*med
    s2 = s.copy(); s2[~ok]=0
    st2 = D.run_ex("CADJPY", s2, 1.5, 99.0, 960, trail_atr=None, t0=T0, t1=T1, use_m1=False)
    print(f"  avec filtre x{mult:<4} : {st2.get('n')} trades  "
          f"({100*(~ok).mean():.1f} % des barres filtrees)")
print()
print("MT5 produit 480 entrees pour VWAPXUP (CADJPY).")
