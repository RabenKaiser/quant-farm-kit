# -*- coding: utf-8 -*-
"""audit_trigmap.py — detecte TOUTES les collisions de mapping.

PROBLEME (bug n44)
------------------
TRIGMAP envoie 3 declencheurs Python distincts (xup_vwapD, xup_vwapW,
vwap_xup) vers UN SEUL code MQL5 (VWAPXUP). L'EA n'implemente qu'une version
(le VWAP journalier), donc les jambes utilisant la version hebdomadaire sont
executees avec la MAUVAISE definition.

Ce script enumere toutes les collisions et verifie, pour chacune, si les
declencheurs Python regroupes sont REELLEMENT identiques ou non.
"""
import sys, re, os
from collections import defaultdict

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")

TRIGMAP = {
    "rej_bull":"REJBULL","rej_bear":"REJBEAR","big_bull":"BIGBULL","big_bear":"BIGBEAR",
    "no_wick_up":"NOWICKUP","no_wick_dn":"NOWICKDN","morning":"MORNING","evening":"EVENING",
    "pin_bull":"PINBULL","pin_bear":"PINBEAR","harami_bull":"HARAMIBULL","harami_bear":"HARAMIBEAR",
    "brk_round_up":"BRKROUNDUP","brk_round_dn":"BRKROUNDDN","at_round":"ATROUND",
    "xup_vwapD":"VWAPXUP","xdn_vwapD":"VWAPXDN","xup_vwapW": "VWAPWXUP","xdn_vwapW": "VWAPWXDN",
    "vwap_xup":"VWAPXUP","vwap_xdn":"VWAPXDN","vwapmx_up":"VWAPMXUP","vwapmx_dn":"VWAPMXDN",
    "brk_hh20":"BRKHH20","brk_ll20":"BRKLL20","hh_hl":"HHHL","ll_lh":"LLLH",
    "at_PDH":"ATPDH","at_PDL":"ATPDL","at_PP":"ATPP","fade_PDH":"FADEPDH","fade_PDL":"FADEPDL",
    "three_up":"THREEUP","three_dn":"THREEDN","brk_PDH":"BRKPDH","brk_PDL":"BRKPDL",
    "above_PP":"ABOVEPP","below_PP":"BELOWPP","sweep_lo":"SWEEPLO","sweep_hi":"SWEEPHI",
    "div_bull":"DIVBULL","div_bear":"DIVBEAR","brk_asia_lo":"BRKASIALO","brk_asia_hi":"BRKASIAHI",
    "fade_asia_lo":"FADEASIALO","fade_asia_hi":"FADEASIAHI","macd_xup":"MACDXUP","macd_xdn":"MACDXDN",
    "stoch_xup":"STOCHXUP","stoch_xdn":"STOCHXDN","rsi_xup":"RSIXUP","rsi_xdn":"RSIXDN",
    "roc_up":"ROCUP","roc_dn":"ROCDN","bull":"BULL","bear":"BEAR","inside_bar":"INSIDEBAR",
}

# reverse : code MQL5 -> liste des declencheurs python
rev = defaultdict(list)
for py, mq in TRIGMAP.items():
    rev[mq].append(py)

print("=" * 74)
print("COLLISIONS DE MAPPING (plusieurs declencheurs Python -> 1 code MQL5)")
print("=" * 74)
coll = {k: v for k, v in rev.items() if len(v) > 1}
for mq, pys in sorted(coll.items()):
    print(f"  {mq:<12} <- {len(pys)} declencheurs : {', '.join(sorted(pys))}")

print(f"\n  {len(coll)} codes MQL5 partages par plusieurs declencheurs")
print(f"  {len(TRIGMAP)} declencheurs Python -> {len(rev)} codes MQL5")

# ---- pour chaque collision, comparer les DEFINITIONS ----
print("\n" + "=" * 74)
print("COMPARAISON DES DEFINITIONS (sont-ils reellement identiques ?)")
print("=" * 74)

import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT
import numpy as np

G._cache.clear()
F = G.get_frames("EURNZD")
m5, m1 = F["m5"], F["m1"]
h1z, hh, ll, a1, gb, gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd, zlo, zhi = MT.project(m5.index, h1z, hh, ll, gb, gr, max_age_h=48)
M = NL.build(m5, F, zd, zlo, zhi); M.update(FE.more(m5, F, m1))

print(f"  (mesure sur EURNZD, {len(m5)} barres M5)\n")
bad = []
for mq, pys in sorted(coll.items()):
    rates = {}
    for p in sorted(pys):
        if p in M:
            rates[p] = float(M[p].mean())
        else:
            rates[p] = None
    vals = [v for v in rates.values() if v is not None]
    if not vals:
        print(f"  {mq:<12} : aucun declencheur trouve dans les features")
        continue
    same = (max(vals) - min(vals)) < 1e-9 if len(vals) > 1 else True
    tag = "IDENTIQUES" if same else "*** DIFFERENTS ***"
    print(f"  {mq:<12} : {tag}")
    for p, r in rates.items():
        if r is None:
            print(f"      {p:<14} ABSENT des features")
        else:
            print(f"      {p:<14} taux={r:.5f}")
    if not same:
        bad.append(mq)

print("\n" + "=" * 74)
print("VERDICT")
print("=" * 74)
if bad:
    print(f"  {len(bad)} code(s) MQL5 regroupent des declencheurs DIFFERENTS :")
    for b in bad:
        print(f"    - {b} : {rev[b]}")
    print("\n  -> L'EA ne peut pas les distinguer. Les jambes utilisant la")
    print("     variante non implementee sont executees avec la MAUVAISE")
    print("     definition (bug n44).")
else:
    print("  Aucune divergence detectee.")

# ---- quelles jambes du portefeuille sont touchees ? ----
import json
J = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\honest_test.json",
                   encoding="utf-8"))
print("\n" + "=" * 74)
print("JAMBES DU PORTEFEUILLE AFFECTEES")
print("=" * 74)
n = 0
for L in J["A"]["legs"]:
    t = L.get("trig") or L["k"].split("|")[1]
    mq = TRIGMAP.get(t)
    if mq in bad:
        n += 1
        print(f"  {L['sym']:<8} {t:<14} -> {mq}  (regroupe {rev[mq]})")
print(f"\n  {n}/{len(J['A']['legs'])} jambes affectees")
