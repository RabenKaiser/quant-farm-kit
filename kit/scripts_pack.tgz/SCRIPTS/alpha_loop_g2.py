﻿"""ALPHA LOOP â€” gÃ©nÃ©ration 2 : rÃ©gimes de spread + survivants g1.

L'hypothÃ¨se : la friction est LA contrainte (0,05 R/trade). Si on ne trade que
les barres Ã  spread serrÃ© (<= p25/p50 de spread_med), le coÃ»t chute et le net
peut passer positif si le brut survit. MÃªme protocole P0->P3, stockage g2.
"""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import json, time
from pathlib import Path
from collections import defaultdict

import polars as pl
import numpy as np

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
from edge_correct import (load_m1, to_tf, seg_of, backtest_m1, summarize,
                          POINT, COMMISSION_RT, TICK_VALUE_PER_PT)
from edge_correct import make_signals as ms_base

RESEARCH = Path(r"C:\EAFarm\HISTORY - Copy\research")
ALPHA = RESEARCH / "alpha"
ALPHA.mkdir(exist_ok=True)
SYM = "EURUSD"
PT = POINT[SYM]

def add_costs(cfg):
    cfg = dict(cfg)
    cfg["commission_rt"] = COMMISSION_RT[SYM]
    cfg["tick_value_per_pt"] = TICK_VALUE_PER_PT[SYM]
    return cfg

def make_sig(tf, kind, cfg):
    return ms_base(tf, kind, cfg)

def spread_filter(tf, cfg):
    """Filtre : ne garder que les barres dont spread_med <= seuil pts."""
    thr = cfg.get("spread_max_pts")
    if not thr:
        return tf
    return tf.filter((tf["spread_med"] / PT) <= thr)

def run_cfg(frames, kind, cfg):
    out = {}
    for sname, (m1seg, tfseg) in frames.items():
        f = make_sig(spread_filter(tfseg, cfg), kind, cfg)
        tr = backtest_m1(m1seg, tfseg, f, SYM, cfg)
        out[sname] = summarize(tr)
    return out

def configs_g2(family, stage):
    c = []
    sess = [None]
    # spread seuils en pts (EURUSD mÃ©diane ~4 pts) : p25â‰ˆ3, p50â‰ˆ4
    sp = [3.0, 4.0, None]
    if stage == "P0":
        for s in sp:
            c.append({"lookback": 40, "w": 6, "thr": 0.2, "sl_atr": 2.5, "rr": 2.5,
                      "session": None, "slippage_pts": 0.5, "spread_max_pts": s})
    else:
        if family in ("range_fade", "ofi_cont"):
            for lb in [20, 40]:
                for sl in [1.5, 2.5]:
                    for rr in [1.5, 2.5]:
                        for s in sp:
                            for se in sess:
                                c.append({"lookback": lb, "w": 6, "thr": 0.15 if family == "ofi_cont" else 0.2,
                                          "sl_atr": sl, "rr": rr, "session": se,
                                          "slippage_pts": 0.5, "spread_max_pts": s})
    return c

def load_frames(seg_bounds):
    m1 = load_m1(SYM)
    out = {}
    for tf_sec in [300, 900, 1800]:
        tf = to_tf(m1, tf_sec)
        df = seg_of(tf)
        m1s = seg_of(m1)
        frames = {}
        for sname, (t0, t1) in seg_bounds.items():
            frames[sname] = (m1s.filter((pl.col("ts") >= t0) & (pl.col("ts") < t1)),
                             df.filter((pl.col("ts") >= t0) & (pl.col("ts") < t1)))
        out[tf_sec] = frames
    return out

import datetime as _dt
def E(d):
    return int(_dt.datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=_dt.timezone.utc).timestamp())
B = {
    "P0": {"toy": (E("2022-01-01"), E("2022-02-01"))},
    "P1": {"p1": (E("2022-01-01"), E("2022-04-01"))},
    "IS": {"IS-1": (E("2022-01-01"), E("2022-07-01")),
           "IS-2": (E("2022-07-01"), E("2023-01-01"))},
    "OOS": {"OOS": (E("2023-01-01"), E("2024-01-01"))},
    "REPRO": {"M5": (E("2022-01-01"), E("2023-01-01")),
              "M30": (E("2022-01-01"), E("2023-01-01"))},
}

def main():
    t0 = time.time()
    log = {"generation": 2, "stages": {}, "note": "spread-regime conditioning"}

    f0 = load_frames(B["P0"])
    p0 = 0
    for fam in ["range_fade", "ofi_cont"]:
        for cfg in configs_g2(fam, "P0"):
            p0 += 1
            run_cfg(f0[900], fam, add_costs(cfg))
    log["stages"]["P0"] = {"tested": p0}
    print(f"P0: {p0} configs en {time.time()-t0:.0f}s", flush=True)

    f1 = load_frames(B["P1"])
    p1_keep = {}
    n1 = 0
    for fam in ["range_fade", "ofi_cont"]:
        for cfg in configs_g2(fam, "P1"):
            n1 += 1
            r = run_cfg(f1[900], fam, add_costs(cfg))
            if r["p1"]["n"] >= 15 and r["p1"]["gross"] > 0:
                p1_keep[f"{fam}|{json.dumps(cfg, sort_keys=True)}"] = (fam, cfg, r)
    log["stages"]["P1"] = {"tested": n1, "gross_pos": len(p1_keep)}
    print(f"P1: {n1} testÃ©s, {len(p1_keep)} brut positif", flush=True)

    fIS = load_frames(B["IS"])
    fam_med = defaultdict(list)
    p2 = {}
    for key, (fam, cfg, r) in p1_keep.items():
        res = run_cfg(fIS[900], fam, add_costs(cfg))
        e1, e2 = res["IS-1"], res["IS-2"]
        if e1["n"] >= 15 and e2["n"] >= 15:
            fam_med[fam].append(e1["net"])
            if e1["net"] > 0 and e2["net"] > 0:
                p2[key] = (fam, cfg, res)
    fmed = {f: float(np.median(v)) for f, v in fam_med.items()}
    # condition c: top-5 removal IS-1
    p2k = {}
    for key, (fam, cfg, res) in p2.items():
        if fmed.get(fam, -1) <= 0:
            continue
        f = make_sig(spread_filter(fIS[900]["IS-1"][1], add_costs(cfg)), fam, add_costs(cfg))
        tr = backtest_m1(fIS[900]["IS-1"][0], fIS[900]["IS-1"][1], f, SYM, add_costs(cfg))
        if not tr:
            continue
        r5 = np.sort([t["r"] for t in tr])[:-5]
        if r5.mean() - np.mean([t["cost_r"] for t in tr]) <= 0:
            continue
        p2k[key] = (fam, cfg, res)
    log["stages"]["P2"] = {"cands_ab": len(p2), "kept_dc": len(p2k),
                           "family_median": {k: round(v, 4) for k, v in fmed.items()}}
    print(f"P2: {len(p2)} candidats (a+b), {len(p2k)} aprÃ¨s c+d; mÃ©dianes={ {k: round(v,4) for k,v in fmed.items()} }", flush=True)

    fOOS = load_frames(B["OOS"])
    finals = []
    for key, (fam, cfg, res) in p2k.items():
        ro = run_cfg(fOOS[900], fam, add_costs(cfg))
        finals.append({"id": key, "family": fam, "cfg": cfg,
                       "IS1": res["IS-1"], "IS2": res["IS-2"], "OOS": ro["OOS"]})
    log["stages"]["P3"] = {"oos_looks": len(finals),
                           "oos_positive": sum(1 for x in finals if x["OOS"]["net"] > 0)}
    print(f"P3: {len(finals)} regards OOS, {sum(1 for x in finals if x['OOS']['net'] > 0)} positifs", flush=True)

    fRep = load_frames(B["REPRO"])
    keeps = []
    for x in finals:
        fam, cfg = x["family"], x["cfg"]
        r5 = run_cfg(fRep[300], fam, add_costs(cfg))
        r30 = run_cfg(fRep[1800], fam, add_costs(cfg))
        tf_ok = r5["M5"]["net"] > 0 or r30["M30"]["net"] > 0
        keeps.append({"id": x["id"], "family": fam, "cfg": cfg,
                      "IS1_net": x["IS1"]["net"], "IS2_net": x["IS2"]["net"],
                      "OOS_net": x["OOS"]["net"], "M5_net": r5["M5"]["net"], "M30_net": r30["M30"]["net"],
                      "a": x["IS1"]["net"] > 0 and x["IS2"]["net"] > 0 and x["OOS"]["net"] > 0,
                      "b": tf_ok, "GARDE": x["IS1"]["net"] > 0 and x["IS2"]["net"] > 0 and x["OOS"]["net"] > 0 and tf_ok})

    deg = []
    for x in finals:
        ism = (x["IS1"]["net"] + x["IS2"]["net"]) / 2
        deg.append((ism, x["OOS"]["net"]))
    if deg:
        im = float(np.mean([d[0] for d in deg])); om = float(np.mean([d[1] for d in deg]))
        log["degradation"] = {"mean_IS": round(im, 4), "mean_OOS": round(om, 4),
                              "factor": round(om / im, 2) if im > 0 else None}

    (ALPHA / "strategies_all_g2.json").write_text(json.dumps(finals, indent=1, default=str))
    (ALPHA / "strategies_keep_g2.json").write_text(json.dumps(keeps, indent=1, default=str))
    log["elapsed_s"] = round(time.time() - t0, 1)
    (ALPHA / "generation_log_g2.json").write_text(json.dumps(log, indent=1, default=str))
    print(f"== g2 terminÃ©e en {log['elapsed_s']}s; GARDE: {sum(1 for k in keeps if k['GARDE'])}", flush=True)
    for k in keeps:
        print(f"   {k['id']} net IS1={k['IS1_net']:.4f} IS2={k['IS2_net']:.4f} OOS={k['OOS_net']:.4f} M5={k['M5_net']:.4f} M30={k['M30_net']:.4f} GARDE={k['GARDE']}", flush=True)

if __name__ == "__main__":
    main()
