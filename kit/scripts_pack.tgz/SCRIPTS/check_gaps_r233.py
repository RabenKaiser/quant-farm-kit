# -*- coding: utf-8 -*-
"""check_gaps_r233.py — AUDIT de la couverture temporelle des parquets M1.
Un trou de donnees fausse tout backtest. On liste les mois manquants."""
import sys, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import pandas as pd

BARS = r"C:\EAFarm\HISTORY - Copy\research\bars"
for f in sorted(os.listdir(BARS)):
    if not f.endswith("_M1_db.parquet"):
        continue
    sym = f.replace("_M1_db.parquet", "")
    try:
        df = pd.read_parquet(os.path.join(BARS, f), columns=["ts_event"])
    except Exception as e:
        print(f"{sym}: ERR {e}")
        continue
    idx = pd.DatetimeIndex(df["ts_event"]).sort_values()
    # compter les barres par mois
    per = idx.to_period("M").value_counts().sort_index()
    # mois avec < 1000 barres (trou) - un mois normal a ~20000-40000 M1 barres
    trous = [str(m) for m, c in per.items() if c < 5000]
    print(f"{sym}: {idx.min().strftime('%Y-%m')} -> {idx.max().strftime('%Y-%m')} "
          f"| {len(idx)} barres | mois faibles/trous: {len(trous)}")
    if trous:
        print(f"    {trous[:30]}")
