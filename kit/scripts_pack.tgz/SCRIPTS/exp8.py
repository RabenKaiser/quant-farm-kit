﻿import subprocess, time, glob, os, re
from pathlib import Path
FARM = Path(r"C:\EAFarm\MT5\Farm"); TM = FARM/"terminal64.exe"
LOGD = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")/"CF0B997454318B475CF01419AFE2BBF3"/"Tester"/"logs"
CFG = FARM/"Config"/"config_probe_m1.ini"
sym="GBPUSD"
cfg = (f"[Tester]\nExpert=eepeek\\EXPORT_M1_PROBE.ex5\nSymbol={sym}\nPeriod=M1\n"
       f"Model=0\nOptimization=0\nFromDate=2021.01.01\nToDate=2021.12.31\n"
       f"Deposit=10000\nCurrency=USD\nLeverage=100\nReplaceReport=1\nShutdownTerminal=1\n"
       f"[TesterInputs]\nInpSymbol={sym}\nInpFrom=2021.01.01\nInpTo=2021.12.31\n")
CFG.write_text(cfg)
st=time.strftime("%Y%m%d_%H%M%S")
for lf in glob.glob(str(LOGD/"*.log")):
    try: os.rename(lf, lf+".pr"+st)
    except Exception: pass
p=subprocess.Popen([str(TM),"/config:"+str(CFG)],cwd=str(FARM),
                   creationflags=0x08000000,
                   stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
w=0
while w<300:
    time.sleep(4); w+=4
    if "terminal64" not in subprocess.run(["tasklist","/FI",f"PID eq {p.pid}"],
        capture_output=True,text=True).stdout: break
subprocess.run(["taskkill","/F","/IM","terminal64.exe"],capture_output=True)
time.sleep(2)
print(f"duree {w}s")
best=None
for f in os.listdir(str(LOGD)):
    if ".log" not in f: continue
    pa=os.path.join(str(LOGD),f)
    if os.path.getsize(pa)<300: continue
    if best is None or os.path.getmtime(pa)>os.path.getmtime(best): best=pa
raw=open(best,"rb").read(4)
enc="utf-16" if raw[:2] in (b"\xff\xfe",b"\xfe\xff") else "utf-8"
txt=open(best,encoding=enc,errors="replace").read()
for mm in re.findall(r".*PROBE.*", txt):
    print("  ", mm.split("Core")[-1].strip()[:120])
