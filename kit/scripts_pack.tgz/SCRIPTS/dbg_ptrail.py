"""Compile + run la version DEBUG du ptrail pour diagnostiquer 0 trades."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner as m

SRC = r"C:\EAFarm\HISTORY - Copy\research\EAs\USDJPY_M30_PTRAIL.mq5"
DST = r"C:\EAFarm\MT5\Farm\MQL5\Experts\USDJPY_M30_PTRAIL_DEBUG.mq5"

src = open(SRC, encoding="utf-8").read()
counter = """int _diag_ticks=0, _diag_ent=0, _diag_h4=0;
void OnTick(){
   _diag_ticks++;
   if(_diag_ticks==1 || _diag_ticks==50000) Print("diag ticks=",_diag_ticks," h4ok=",_diag_h4," entries=",_diag_ent);
"""
src = src.replace("void OnTick(){", counter, 1)
src = src.replace(
    "if(CopyRates(_Symbol, PERIOD_H4, 0, HTF_SMA+2, r4) < HTF_SMA+2) return 0;",
    "int _g4 = CopyRates(_Symbol, PERIOD_H4, 0, HTF_SMA+2, r4);\n   if(_g4 < HTF_SMA+2){ _diag_h4++; return 0; }", 1)
src = src.replace("if(c1 > hh && trend==1) dir=1;",
                  "if(c1 > hh && trend==1){ dir=1; _diag_ent++; }", 1)
open(DST, "w", encoding="utf-8").write(src)
print("source debug écrite")

ok, ex5, tail = m.compile_ea(DST)
print("compile:", "OK" if ok else "ECHEC")
if ok:
    r = m.run_backtest("USDJPY_M30_PTRAIL_DEBUG", "USDJPY", "M30",
                       "2023.01.01", "2024.01.01", 10000)
    print("profit:", r.get("profit"), "trades:", r.get("trades"))
