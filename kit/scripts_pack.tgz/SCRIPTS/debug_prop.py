# -*- coding: utf-8 -*-
"""debug_prop.py — inspecter la propagation lastB."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import c13v2_py_v3 as F
import numpy as np
import pandas as pd

sym = "EURUSD"; year = 2024
m1 = F.load_m1(sym)
start = pd.Timestamp(f"{year}-01-01", tz="UTC")
end = pd.Timestamp(f"{year + 1}-01-01", tz="UTC")
wu = start - pd.Timedelta(days=260)
m15 = F.resample(m1.loc[wu:end], "15min")
n15 = len(m15)

cfg = {"imp_atr": 0.9, "imp_vol": 1.0, "imp_look": 6}
bull, bear = F.detect_ob(m15, cfg, lookahead=False)
bull_items = sorted(bull.items())
print(f"bull items (jj -> (dispo,zl,zh)): {len(bull_items)}")
print("5 premiers:", bull_items[:5])
print("dispo max:", max(d for _, (d, _, _) in bull_items))

# simuler la propagation
bi = 0
curB = None
n_cur = 0
lastB = {}
for i15 in range(n15):
    while bi < len(bull_items) and bull_items[bi][0] <= i15:
        jj, (dispo, zl, zh) = bull_items[bi]
        if dispo <= i15:
            curB = (zl, zh, jj)
        bi += 1
    lastB[i15] = curB
    if curB is not None:
        n_cur += 1
print(f"i15 avec OB bull dispo: {n_cur}/{n15}")
# verifier sur les 500 premieres barres
cnt = sum(1 for i15 in range(500) if lastB[i15] is not None)
print(f"500 premieres barres avec OB: {cnt}")
