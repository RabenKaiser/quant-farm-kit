# -*- coding: utf-8 -*-
r"""classif_patterns.py -- CARTE MOTIF -> PROBABILITE DE TRANSITION.

Troisieme etage du dictionnaire (apres les etats v2 et les predicteurs
cause2) : l'utilisateur demande de relier des MOTIFS aux probabilites de
changement d'etat.

MOTIF = le cours des dernieres 24 h encode en mots : l'enchainement des
etats sur les 6 dernieres barres H4 (24 barres M30). Exemple de motif :
"R,R,C,C,E,E" (Range, Range, Compression, Compression, Expansion,
Expansion). Le motif courant est cherche dans l'historique ; quand on
l'a deja vu N fois, on connait la distribution des etats 8 h / 16 h /
32 h plus tard. C'est une CHAINE DE MARKOV d'ordre 6 sur les etats H4.

SORTIE
------
1. La table motif -> P(etat futur a +8h/+16h/+32h), avec n (fiabilite).
2. Les TOP motifs precedant chaque transition cible, avec proba et lift
   contre la probabilite de base.
3. Le test de validation : backtest du "motif courant" sur les dernieres
   annees (entrainement 2020-2023, verification 2024+) — le gate WF
   habituel du projet.
"""
import os
import sys
from collections import defaultdict, Counter

import numpy as np
import pandas as pd

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parent))
import nuit_motifs as NM
from classif_m5 import er, adx_like, z_prix, pentes
import classif_m5_v2 as V2

JAMBES = [x.strip() for x in os.environ.get(
    "PAIRES", "EURUSD,GBPUSD,USDCHF,AUDUSD,NZDUSD,EURJPY,XAUUSD").split(",")
    if x.strip()]
H4 = 8                 # barres M30 par bloc H4
MOTIF_LEN = 6          # 6 blocs H4 = 24 h de memoire
HORIZONS = (16, 32, 64)  # +8 h, +16 h, +32 h en barres M30
MIN_N = 60             # n minimum pour publier un motif


def etat_h4(lab):
    """Vote majoritaire par bloc H4 -> sequence d'etats H4."""
    n = (len(lab) // H4) * H4
    blocs = lab[:n].reshape(-1, H4)
    out = []
    for b in blocs:
        vals, cnt = np.unique(b, return_counts=True)
        out.append(vals[cnt.argmax()])
    return np.array(out, dtype=object)


def lettre(e):
    # 10/13 20:15 : REGROUPEMENT en 4 classes — 7 etats purs donnent 7^6 =
    # 117k motifs pour 65k blocs (n moyen 0.55 : impossible). 4 classes x
    # 4 blocs = 256 motifs, n moyen ~250 : mesurable.
    return {"EXPANSION_VIVE": "E", "RANGE_MOURE": "E",
            "COMPRESS_SECHE": "C", "RANGE_ETABLI": "R",
            "TREND_CROISSANT": "T", "TREND_NAISSANT": "T",
            "TREND_FINISSANT": "T"}.get(e, "?")


def main():
    print("CARTE MOTIF -> PROBABILITE | memoire %d blocs H4 (%d h) | horizons "
          "%s M30" % (MOTIF_LEN, MOTIF_LEN * 4, HORIZONS))
    # ---- passe 1 : collecter les sequences par paire ----------------------
    seqs = {}
    for p in JAMBES:
        D = NM.charge(p, "m1_pos")
        if D is None:
            continue
        lab, _ = V2.etats(D)
        seqs[p] = etat_h4(lab)
        print("  %-8s : %d blocs H4" % (p, len(seqs[p])))
    # ---- passe 2 : construire la table motif -> futurs --------------------
    # entrainement 2020-2023 : on apprend les probabilites ; verification
    # 2024+ : on teste si les probas tenaient (gate WF).
    table = defaultdict(Counter)     # motif -> Counter(etat futur)
    table_valid = defaultdict(Counter)
    # pour la verification il faut les dates : on refait avec les idx.
    idx_h4 = {}
    for p in JAMBES:
        D = NM.charge(p, "m1_pos")
        if D is None:
            continue
        lab, _ = V2.etats(D)
        n = (len(lab) // H4) * H4
        idx_h4[p] = np.asarray(D["idx"])[:n].reshape(-1, H4)[:, -1]
    for p, seq in seqs.items():
        dts = idx_h4[p]
        n = len(seq)
        for i in range(MOTIF_LEN, n - max(HORIZONS)):
            motif = "".join(lettre(x) for x in seq[i - MOTIF_LEN:i])
            annee = pd.Timestamp(dts[i]).year
            cible = table if annee <= 2023 else table_valid
            for H in HORIZONS:
                if i + H // H4 < n:
                    cible[motif + "|%d" % H][seq[i + H // H4]] += 1
    # ---- passe 3 : publication des motifs fiables -------------------------
    print("\n=== MOTIFS les plus informatifs (train 2020-23, n>=%d) ==="
          % MIN_N)
    # 10/13 20:20 : on publie pour chaque motif le TOP-ecart : la classe dont
    # la probabilite conditionnelle s'ecarte le plus de sa base.
    # BUG corrige (20:35) : table est keyed "motif|H" et le Counter compte
    # des etats COMPLETS -> on convertit en lettres ici.
    bases = {"R": 0.72, "C": 0.12, "E": 0.15, "T": 0.03}
    # bases mesurees plutot que devinees : distribution globale des |16
    glob = Counter()
    for cle, cnt in table.items():
        if cle.endswith("|16"):
            for etat, niv in cnt.items():
                glob[lettre(etat)] += niv
    tg = sum(glob.values())
    if tg:
        bases = {k: v / tg for k, v in glob.items()}
    print("  bases mesurees : %s" % "  ".join(
        "%s=%.0f%%" % (k, 100.0 * v) for k, v in sorted(bases.items())))

    def classe16(cnt):
        """Distribution en lettres d'un Counter d'etats."""
        d = defaultdict(int)
        for etat, niv in cnt.items():
            d[lettre(etat)] += niv
        return d

    rows = []
    for cle, cnt in table.items():
        if not cle.endswith("|16"):
            continue
        motif = cle[:-3]
        c16 = classe16(cnt)
        t = sum(c16.values())
        if t < MIN_N:
            continue
        best, best_lift = None, 0.0
        for cls, niv in c16.items():
            lift = (niv / t) / bases.get(cls, 0.25)
            if lift > best_lift:
                best, best_lift = cls, lift
        rows.append((best_lift, motif, best, 100.0 * c16[best] / t, t))
    rows.sort(reverse=True)
    for lift, motif, cls, prob, t in rows[:25]:
        print("  %s  -> %s %4.1f%% (base %.0f%%, lift %.2f, n=%d)"
              % (motif, cls, prob, 100.0 * bases.get(cls, 0.25), lift, t))
    print("\n%d motifs |16 evaluates (top-ecart publies: 25)" % len(rows))
    # ---- passe 4 : verification 2024+ --------------------------------------
    ok, tot = 0, 0
    for cle, cnt in table_valid.items():
        if not cle.endswith("|16"):
            continue
        c_train = table.get(cle)
        if not c_train:
            continue
        c16t = classe16(c_train)
        if sum(c16t.values()) < MIN_N:
            continue
        pred = max(c16t.items(), key=lambda z: z[1])[0]
        c16v = classe16(cnt)
        t = sum(c16v.values())
        if t < 5:
            continue
        ok += c16v.get(pred, 0)
        tot += t
    if tot:
        print("\nVERIFICATION 2024+ : le motif train predit la classe +16h "
              "dans %.1f%% des cas (n=%d) — hasard = %.1f%%"
              % (100.0 * ok / tot, tot,
                 100.0 * sum(v * v for v in bases.values())))


if __name__ == "__main__":
    main()
