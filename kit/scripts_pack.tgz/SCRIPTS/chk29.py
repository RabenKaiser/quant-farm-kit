﻿import json
d = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\NIGHT2_BEST.json", encoding="utf-8"))
print(f"tour={d['round_no']}  calmar12={d['calmar12']:.2f}  R/DD={d['rdd']:.2f}  CA/mois={d['ca_mois']:.2f}%")
