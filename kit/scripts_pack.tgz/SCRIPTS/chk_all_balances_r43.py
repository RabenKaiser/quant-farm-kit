# -*- coding: utf-8 -*-
"""chk_all_balances_r43.py — pour chaque equity CSV, retrouver LE run reel source
(sym, TF, EA, n trades approx) et comparer parse sum vs balance reel.
Signale les files non rescalees."""
import sys, glob, os
import pandas as pd
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
TEAM = r"C:\EAFarm\HISTORY - Copy\research\prop_team\equities"

# (csv, EA, sym, plage n)
WANT = [("equity_UPC-V3INT-EURUSD.csv", "V3INT", "EURUSD", (10, 25)),
        ("equity_UPC-V3INT-GBPJPY.csv", "V3INT", "GBPJPY", (4, 12)),
        ("equity_UPC-V3INT-NZDJPY.csv", "V3INT", "NZDJPY", (5, 15)),
        ("equity_UPC-V3INT-AUDUSD.csv", "V3INT", "AUDUSD", (5, 15)),
        ("equity_UPC-V3INT-NZDUSD.csv", "V3INT", "NZDUSD", (5, 15)),
        ("equity_UPC-GBPUSD-620.csv", "V3INT", "GBPUSD", (20, 30)),
        ("equity_UPC-DOW.csv", "V3INT", "DJCUSD", (12, 22)),
        ("equity_UPC-SPX.csv", "V3INT", "SPCUSD", (14, 24)),
        ("equity_UPC-FRCEUR.csv", "V3INT", "FRCEUR", (6, 14))]

for fn, EA, sym, rng in WANT:
    csvp = os.path.join(TEAM, fn)
    if not os.path.exists(csvp):
        print(fn, "ABSENT")
        continue
    x = pd.read_csv(csvp, index_col=0, parse_dates=True).iloc[:, 0]
    csvsum = x.sum()
    ncsv = int((x != 0).sum())
    best = None
    for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-100:]:
        try:
            runs = F.parse_stream(lp, EA)
        except Exception:
            continue
        for key, data in runs.items():
            if "20260101" not in key.replace(".", "") or sym not in key:
                continue
            closed = [t for t in data["trades"].values() if t["close"] is not None]
            if not (rng[0] <= len(closed) <= rng[1]):
                continue
            b = data.get("balance") or 0.0
            d = abs(b - 10000) / 4000.0
            if best is None or d < best["d"]:
                best = {"d": d, "n": len(closed), "bal": b, "lp": lp}
    if best is None:
        print(f"{fn:38s} csv_sum {csvsum:+8.1f} (j={ncsv}) | run introuvable")
        continue
    reel = best["bal"] - 10000
    ratio = csvsum / reel if reel != 0 else float("nan")
    ok = "OK " if abs(ratio - 1) < 0.10 or abs(csvsum - reel) < 10 else "!!  "
    print(f"{fn:38s} csv_sum {csvsum:+8.1f} (j={ncsv}) | reel {reel:+8.0f} "
          f"(n={best['n']}) | ratio {ratio:6.3f} {ok}")
print("FIN", flush=True)
