"""Vérif finale MFR M15 : le 10x était-il réel ou un artefact de fenêtre ?
Compare moteur vs MT5 sur la MÊME fenêtre 2023 (données moteur dispo)."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
import polars as pl
import numpy as np
import datetime as dt
import edge_correct as ec
import deep_signals as DS

E = lambda s: int(dt.datetime.strptime(s, "%Y-%m-%d").timestamp())
m1 = ec.load_m1("GBPUSD")
tf = ec.to_tf(m1, 900)
a, b = E("2023-01-01"), E("2024-01-01")
tfseg = tf.filter((pl.col("time") >= a) & (pl.col("time") < b))
m1seg = m1.filter((pl.col("time") >= a) & (pl.col("time") < b))
print(f"MFR M15 GBPUSD 2023: {len(tfseg)} barres")

cfg = dict(z_thr=1.5, va_pct=0.70, sl_atr=2.0, rr=4.0, be_trigger_r=1.0,
           z_period=20, short_only=True, max_hold_bars=2880, tick_size=1e-5,
           stop_ticks_min=10, stop_ticks_max=150,
           commission_rt=4.0, tick_value_per_pt=1.0)
f = DS.mfr_fbr(tfseg, cfg)
n_sig = int((f["sig"] != 0).sum())
print(f"signaux moteur 2023: {n_sig}")
tr = ec.backtest_m1(m1seg, tfseg, f, "GBPUSD", cfg)
nets = np.array([t["r"] - t["cost_r"] for t in tr]) if tr else np.array([])
print(f"MOTEUR MFR M15 2023: n={len(nets)} net/trade={nets.mean():+.3f}" if len(nets) else "0")
print(f"MT5 MFR M15 2023: n=2145, profit -$321 (testé plus tôt)")
if len(nets):
    print(f"  écart count: {2145/len(nets):.1f}x")
