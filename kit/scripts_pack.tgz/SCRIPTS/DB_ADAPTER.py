# -*- coding: utf-8 -*-
"""DB_ADAPTER.py — Convertit les parquet Databento (CME futures) vers le
schéma standard du pipeline ML : time(epoch s), bid_o/h/l/c, n_ticks, spread.
Databento : ts_event(datetime), open/high/low/close, volume (CME real volume).
Adaptation : time=epoch, bid_*=OHLC, n_ticks=volume, spread_med=0 (futures).
Sortie : <SYM>_M1_full.parquet (priorisé par ML_MINE_9/11 automatiquement).
Usage : python DB_ADAPTER.py [EURUSD USDJPY GBPUSD]
"""
import sys, os
from pathlib import Path
import polars as pl

BARS = Path(r"C:\EAFarm\HISTORY - Copy\research\bars")

def convert(sym):
    src = BARS / f"{sym}_M1_db.parquet"
    if not src.exists():
        print(f"{sym}: {src.name} absent"); return False
    df = pl.read_parquet(src)
    df = df.with_columns([
        pl.col("ts_event").dt.epoch("s").cast(pl.Int64).alias("time"),
        pl.col("open").alias("bid_o"),
        pl.col("high").alias("bid_h"),
        pl.col("low").alias("bid_l"),
        pl.col("close").alias("bid_c"),
        pl.col("volume").cast(pl.Float64).alias("n_ticks"),
        pl.lit(0.0).alias("spread_med"),
        pl.lit(0.0).alias("spread_max"),
        (pl.col("volume") * 0.5).cast(pl.Float64).alias("bid_vol"),
        (pl.col("volume") * 0.5).cast(pl.Float64).alias("ask_vol"),
    ]).select(["time","bid_o","bid_h","bid_l","bid_c","n_ticks",
               "spread_med","spread_max","bid_vol","ask_vol"])
    df = df.unique(subset=["time"]).sort("time")
    out = BARS / f"{sym}_M1_full.parquet"
    df.write_parquet(out)
    print(f"{sym}: {df.height} barres -> {out} ({out.stat().st_size/1e6:.1f} MB)")
    print(f"  plage: {df['time'].min()} -> {df['time'].max()}")
    return True

if __name__ == "__main__":
    syms = sys.argv[1:] or ["EURUSD", "USDJPY", "GBPUSD"]
    for s in syms:
        convert(s)
