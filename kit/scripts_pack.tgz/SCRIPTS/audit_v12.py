"""AUDIT DE V12 : CHAQUE JAMBE EST-ELLE POSITIVE DANS LES DEUX ETAGES ?

POURQUOI (28/09, 14 h 15). La regle d'admission du projet est simple et sans exception : **une jambe n'entre
au portefeuille que si elle est positive cote ferme ET cote juge**, sur des ordres reels. V12 est deja
installe sur le terminal de l'utilisateur pour une semaine de test vivant ; il faut donc savoir, jambe par
jambe, ce que la regle dit vraiment -- et non ce qu'on croit se rappeler.

Ce script relit les deux etages :
  * ferme : les textes bruts des campagnes (moteur de mesure du projet, signe corrige) ;
  * juge : le tableau `MESURE_MT5.md` ecrit par la voie Upcomers (2026Q1).
Il rend un verdict par jambe, et le compte final : admises, non mesurees, rejetees.
"""
import re
import sys
import pathlib

import numpy as np

B = pathlib.Path(r"C:\EAFarm\HISTORY - Copy\research")
sys.path.insert(0, str(B / "SCRIPTS"))
import reel_sans_constante as RS  # noqa: E402

# jambe : (nom, lot ferme, symbole ferme, ligne ferme, lot juge, seuil de coherence juge)
JAMBES = [
    ("or — Keltner 32 h achat (stop 6 ATR)", "g3_kelt32xau_slr6", "XAUUSD", "KELTHIGH", "up_kelt6_xauusd"),
    ("Dax — Keltner 32 h achat", "g3_kelt32_deu", "DEU.IDX", "KELTHIGH", "up_kelt_geceur_m15"),
    ("Nikkei — Keltner 32 h achat", "g3_kelt32_jpn", "JPN.IDX", "KELTHIGH", "up_kelt_jpcjpy_m15"),
    ("Dow — SR97 achat (1,5 ATR)", "g3_sr15_usa30", "USA30.IDX", "SR97L", "up_sr97b_djcusd"),
    ("Dow — SR97W20L achat", "g3_sr15_usa30", "USA30.IDX", "SR97W20L", "up_sr97b_djcusd"),
    ("CAC — divergence RSI achat", "g3_div_fra_s15", "FRA.IDX", "RSI_DIV_LO", "up_rsidiv_frceur_s15"),
    ("Euro Stoxx — SR100 achat (4 R)", "g3_m15_eusidx_4", "EUS.IDX", "SR100L", "up_sr100_exceur"),
    ("AUDCAD — SR97 vente (CRESTM)", "g3_lot_audcad_2", "AUDCAD", "SR97S", "up_sr97c_audcad"),
]


def ferme(lot, sym, ligne):
    p = B / ("raw_farm_%s.txt" % lot)
    if not p.exists():
        return None
    corpus = "m1_ext" if sym.endswith(".IDX") else "m1_pos"
    tx = RS.transactions_texte(p.read_text(encoding="utf-8", errors="replace"), corpus, 0, symboles=[sym])
    sel = [t for t in tx if t["ligne"] == ligne]
    if len(sel) < 30:
        return None
    R = np.array([t["R"] for t in sel])
    return {"n": len(R), "mu": float(R.mean()),
            "t": float(R.mean() / (R.std(ddof=1) / np.sqrt(len(R)))) if R.std(ddof=1) > 0 else 0.0,
            "ans": len({t["t_in"].year for t in sel})}


def juge(tableau, lot):
    f = B / "MESURE_MT5.md"
    if not f.exists():
        return None
    for l in f.read_text(encoding="utf-8", errors="replace").splitlines():
        m = re.match(r"\|\s*%s\s*\|\s*(\d+)\s*\|\s*([+-][\d.]+)\s*\|" % re.escape(lot), l)
        if m:
            return {"n": int(m.group(1)), "mu": float(m.group(2))}
    return None


def main():
    L = ["# AUDIT DE V12 — LA RÈGLE DES DEUX ÉTAGES, JAMBE PAR JAMBE (28/09)", "",
         "Une jambe n'est admise que si elle est positive **en ordres réels côté ferme ET côté juge**. Les",
         "mesures ferme viennent des textes bruts (moteur du projet, signe corrigé) ; les mesures juge de",
         "`MESURE_MT5.md`, écrit par la voie Upcomers sur 2026Q1.", "",
         "| jambe | ferme (n, R/tx, t, années) | juge (n, R/tx) | verdict |",
         "|---|---|---|---|"]
    adm, att, rej = [], [], []
    for nom, lot_f, sym, ligne, lot_j in JAMBES:
        mf, mj = ferme(lot_f, sym, ligne), juge(None, lot_j)
        cf = ("n=%d, **%+.4f**, t %+.2f, %d ans" % (mf["n"], mf["mu"], mf["t"], mf["ans"])) if mf else "—"
        cj = ("n=%d, **%+.4f**" % (mj["n"], mj["mu"])) if mj else "non mesuré"
        if mf and mj:
            if mf["mu"] > 0 and mj["mu"] > 0:
                verdict = "**ADMISE**"
                adm.append(nom)
            else:
                verdict = "REJETÉE (un étage négatif)"
                rej.append(nom)
        elif mf and not mj:
            verdict = "EN ATTENTE (juge non mesuré)"
            att.append(nom)
        else:
            verdict = "ferme non mesurée"
            rej.append(nom)
        L.append("| %s | %s | %s | %s |" % (nom, cf, cj, verdict))

    L += ["", "## Ce que la règle dit de V12", ""]
    L.append("- **Admises (%d)** : %s" % (len(adm), ", ".join(adm) if adm else "aucune"))
    L.append("- **En attente de mesure au juge (%d)** : %s" % (len(att), ", ".join(att) if att else "aucune"))
    L.append("- **Rejetées (%d)** : %s" % (len(rej), ", ".join(rej) if rej else "aucune"))
    L += ["", "Rappel : une jambe « en attente » n'est ni admise ni rejetée. Le portefeuille installé pour la",
          "semaine de test contient donc des jambes que la règle n'a pas encore validées — c'est écrit dans",
          "le `LISEZ-MOI.txt` du dossier `PortfolioV12`, et c'est le test vivant lui-même qui apportera la",
          "mesure manquante.", ""]
    (B / "AUDIT_V12.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n".join(L))


if __name__ == "__main__":
    main()
