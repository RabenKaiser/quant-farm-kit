# -*- coding: utf-8 -*-
"""agrege_paires.py — LE MECANISME, AGREGE SUR PLUSIEURS PAIRES.

POURQUOI AGREGEGER (18/09, 18 h)
--------------------------------
Les mesures precedentes, paire par paire, montrent un mecanisme de retour a la
moyenne aux extremes de range (stop 3 ATR, objectif 2 ATR, 48 barres) qui donne :

    EURUSD : 2024 +0.0156  |  2025-26 -0.0010  (temoin -0.0189)
    EURJPY : 2024 -0.0106  |  2025-26 +0.0323  (temoin -0.0286)

Chaque paire prise seule est donc instable : positive dans une periode,
negative dans l'autre. MAIS les deux ne basculent pas en meme temps, et c'est
exactement ce qu'un portefeuille doit absorber : l'agregat de plusieurs paires
independantes a une variance bien plus faible que chacune.

C'EST LA SEULE CHOSE QUI N'AI PAS ETE TESTEE : la version PORTEFEUILLE.

CE QUE LE SCRIPT MESURE
  - les entrees du mecanisme sur 6 paires, agregees (chaque entree pese pareil) ;
  - le R moyen par transaction dans les deux periodes, et contre le temoin ;
  - le nombre de transactions par an et le R par an, qui est l'objectif
    (500 R/an) ;
  - la courbe cumulee par mois, pour voir si c'est regulier ou concentre.

USAGE : python agrege_paires.py
"""
import collections
import statistics
from pathlib import Path

import pandas as pd

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
M1 = BASE / "m1_pos"
PAIRES = ["EURUSD", "EURJPY", "GBPJPY", "AUDJPY", "USDCAD", "NZDUSD"]
FEN_RANGE = 96
SEUIL_RANGE = 0.20
SL_ATR, TP_ATR, HOLD = 3.0, 2.0, 48
PAS = 3
TRAIN = ("2024-01-01", "2025-04-01")
NEUF = ("2025-04-01", "2026-01-01")


def point_de(close):
    ex = close.dropna().astype(str)
    ex = ex[~ex.str.contains("e", case=False, na=False)].head(2000)
    dec = 0
    for x in ex:
        if "." in x:
            dec = max(dec, len(x.split(".")[1]))
    return 10.0 ** (-dec)


def barres(sym):
    p = M1 / ("%s_M1.csv" % sym)
    if not p.exists():
        return None
    d = pd.read_csv(p, usecols=["time", "high", "low", "close", "spread"])
    d["time"] = pd.to_datetime(d["time"], unit="s", utc=True)
    d = d.set_index("time").sort_index()
    pt = point_de(d["close"])
    m5 = d.resample("5min").agg({"high": "max", "low": "min",
                                 "close": "last", "spread": "mean"}).dropna()
    m5["spr"] = m5["spread"] * pt
    pc = m5["close"].shift(1)
    tr = pd.concat([(m5["high"] - m5["low"]).abs(),
                    (m5["high"] - pc).abs(),
                    (m5["low"] - pc).abs()], axis=1).max(axis=1)
    m5["atr"] = tr.rolling(14).mean()
    m5["rhi"] = m5["high"].rolling(FEN_RANGE).max()
    m5["rlo"] = m5["low"].rolling(FEN_RANGE).min()
    return m5.dropna()


def entrees(a, aleatoire=False):
    """Rend la liste de (R, mois) pour les entrees du mecanisme."""
    H = a["high"].to_numpy()
    L = a["low"].to_numpy()
    C = a["close"].to_numpy()
    A = a["atr"].to_numpy()
    S = a["spr"].to_numpy()
    HI = a["rhi"].to_numpy()
    LO = a["rlo"].to_numpy()
    mois = a.index
    n = len(C)
    out = []
    for i in range(FEN_RANGE + 2, n - HOLD - 1, PAS):
        atr = A[i]
        if not (atr > 0) or HI[i] <= LO[i]:
            continue
        if aleatoire:
            sides = (1.0, -1.0)
        else:
            pos = (C[i] - LO[i]) / (HI[i] - LO[i])
            if pos < SEUIL_RANGE:
                sides = (1.0,)
            elif pos > 1.0 - SEUIL_RANGE:
                sides = (-1.0,)
            else:
                continue
        sp = S[i] if S[i] > 0 else 0.0
        for side in sides:
            ent = C[i] + side * sp / 2.0
            dist = SL_ATR * atr
            sl = ent - side * dist
            tp = ent + side * TP_ATR * atr
            R = None
            for j in range(i + 1, min(i + 1 + HOLD, n)):
                if side > 0:
                    if L[j] <= sl:
                        R = -1.0
                        break
                    if H[j] >= tp:
                        R = TP_ATR / SL_ATR
                        break
                else:
                    if H[j] >= sl:
                        R = -1.0
                        break
                    if L[j] <= tp:
                        R = TP_ATR / SL_ATR
                        break
            if R is None:
                sortie = C[min(i + HOLD, n - 1)] - side * sp / 2.0
                R = (sortie - ent) * side / dist
            out.append((R, mois[i].strftime("%Y-%m")))
    return out


def main():
    print("=" * 100)
    print("LE MECANISME AGREGE SUR %d PAIRES" % len(PAIRES))
    print("=" * 100)
    print("   achat dans les 20 %% bas du range de %d barres, vente dans les hauts"
          % FEN_RANGE)
    print("   stop %.1f ATR / objectif %.1f ATR / %d barres, spread paye deux fois"
          % (SL_ATR, TP_ATR, HOLD))
    print()
    res = {}
    tem = {}
    for sym in PAIRES:
        m5 = barres(sym)
        if m5 is None:
            continue
        a = m5.loc[TRAIN[0]:TRAIN[1]]
        b = m5.loc[NEUF[0]:NEUF[1]]
        if len(a) < 3000 or len(b) < 1500:
            continue
        ra = entrees(a)
        rb = entrees(b)
        rt = entrees(b, aleatoire=True)
        if not ra or not rb:
            continue
        res[sym] = (ra, rb, rt)
    if not res:
        print("   aucune paire exploitable")
        return
    print("   %-8s %10s %10s %10s %8s %8s %8s"
          % ("paire", "R 2024", "R 2025-26", "temoin 25-26", "tx 2024",
             "tx 25-26", "R/an"))
    tous_a, tous_b, tous_t = [], [], []
    mois_b = collections.defaultdict(list)
    for sym, (ra, rb, rt) in sorted(res.items()):
        va = statistics.mean(x[0] for x in ra)
        vb = statistics.mean(x[0] for x in rb)
        vt = statistics.mean(x[0] for x in rt)
        tr_an = len(rb) / 0.75
        tous_a += [x[0] for x in ra]
        tous_b += [x[0] for x in rb]
        tous_t += [x[0] for x in rt]
        for r, m in rb:
            mois_b[m].append(r)
        print("   %-8s %+10.4f %+10.4f %+10.4f %8d %8d %+8.0f"
              % (sym, va, vb, vt, len(ra), len(rb), vb * tr_an))
    print()
    print("=" * 100)
    print("   AGREGAT (chaque transaction pese pareil)")
    print("=" * 100)
    ma = statistics.mean(tous_a)
    mb = statistics.mean(tous_b)
    mt = statistics.mean(tous_t)
    ea = statistics.pstdev(tous_a) / len(tous_a) ** 0.5
    eb = statistics.pstdev(tous_b) / len(tous_b) ** 0.5
    print("   R moyen 2024     : %+.4f  (+- %.4f)  sur %d transactions"
          % (ma, ea, len(tous_a)))
    print("   R moyen 2025-26  : %+.4f  (+- %.4f)  sur %d transactions"
          % (mb, eb, len(tous_b)))
    print("   temoin 2025-26   : %+.4f  (entrees aleatoires, memes barrieres)"
          % mt)
    an = len(tous_b) / 0.75
    print("   transactions/an  : %.0f" % an)
    print("   R par an         : %+.0f" % (mb * an))
    print("   objectif         : +500 R/an")
    print()
    print("   R par mois sur le nouveau regime :")
    for m in sorted(mois_b):
        v = mois_b[m]
        print("      %s : %+7.4f R  (%4d transactions)" % (m, statistics.mean(v), len(v)))
    print()
    if mb > 0 and ma > 0:
        print("   >>> L'AGREGAT EST POSITIF DANS LES DEUX PERIODES (%.4f et"
              % ma)
        print("       %.4f) et bat le temoin (%.4f). C'est la premiere" % (mb, mt))
        print("       construction du projet dans ce cas. A confirmer en ordres")
        print("       reels avant toute conclusion -- et le nombre de")
        print("       transactions par an dit si 500 R/an est atteignable.")
    elif mb > 0:
        print("   >>> positif seulement dans le regime actuel (%.4f) : c'est le" % mb)
        print("       regime qui parle, pas le mecanisme.")
    else:
        print("   >>> l'agregat reste negatif dans le regime actuel.")


if __name__ == "__main__":
    main()
