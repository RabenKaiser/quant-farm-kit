﻿import numpy as np, sys, gc
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G
G._cache.clear(); gc.collect()
F = G.get_frames("EURAUD")
a15i = F["a15i"]; c5=F["c5"]
ok = np.isfinite(a15i) & (a15i>0)
print(f"ATR M15 (a15i) sur EURAUD : median={np.nanmedian(a15i):.5f}")
print(f"prix EURAUD median : {np.median(c5):.5f}")
print()
print("PYTHON : sl0 = entry - 1.5 * a15i")
print(f"  soit {1.5*np.nanmedian(a15i):.5f} de distance = {100*1.5*np.nanmedian(a15i)/np.median(c5):.3f} % du prix")
print()
print("EA : risk = sl_atr * atr  ou atr = RefAtr(i) = iATR(M15,14) au shift 1")
print("  => MEME formule. Mais le SL est pose par le BROKER en prix absolu,")
print("     et le broker peut REFUSER si trop proche (stops level).")
print("     Verifions le stops level du symbole.")
