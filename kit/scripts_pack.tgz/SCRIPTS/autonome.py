"""autonome : la boucle qui fait tout tourner sans surveillance (demande de l'utilisateur).

Elle enchaine en continu, jusqu'a l'heure limite :
  - le moteur RAPIDE de combinaisons sur les quatre trames (M5, M15, M30, H1) et les deux feeds ;
  - le moteur de precurseurs (la methode inversee : partir du mouvement, regarder en arriere) ;
  - la carte de chaleur des etats et le dictionnaire x TPO, une fois par cycle ;
  - la regeneration de l'inventaire et de la table du portefeuille ;
  - un garde-fou de DISQUE : au-dessous de 12 Go elle purge les caches testeur et les journaux
    anciens, parce que c'est ce qui a failli arreter la nuit precedente.

Elle est detachee du processus appelant : elle survit a la conversation. Tout est journalise dans
autonome.log, et chaque moteur ecrit ses propres fichiers de resultats.
"""
import datetime
import os
import shutil
import subprocess
import sys
from pathlib import Path

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
LOG = B / "autonome.log"
DUREE_H = float(os.environ.get("DUREE_H", "24"))
TRAMES = ["5min", "15min", "30min", "60min"]
FEEDS = ["m1_pos", "m1_upcomers"]
TESTER = Path(os.path.expandvars(r"%APPDATA%\MetaQuotes\Tester"))


def note(m):
    with LOG.open("a", encoding="utf-8") as f:
        f.write("%s %s\n" % (datetime.datetime.now().strftime("%d/%m %H:%M:%S"), m))


def libre_go():
    return shutil.disk_usage("C:\\").free / 1e9


def purge():
    """Journaux de testeur d'avant aujourd'hui + fichiers .xp : surs, jamais utilises en direct."""
    if libre_go() > 12:
        return
    note("disque bas (%.1f Go) -> purge" % libre_go())
    aujourdhui = datetime.date.today()
    for f in TESTER.rglob("*"):
        try:
            if not f.is_file():
                continue
            if f.suffix in (".xp",) or (f.suffix == ".log"
                                        and datetime.date.fromtimestamp(f.stat().st_mtime) < aujourdhui):
                f.unlink()
        except Exception:
            continue
    note("apres purge : %.1f Go" % libre_go())


def tour(script, env_sup, nom):
    env = dict(os.environ)
    env.update(env_sup)
    note("lancement %s" % nom)
    with (B / ("auto_%s.log" % nom)).open("a", encoding="utf-8") as f:
        subprocess.run([sys.executable, str(B / "SCRIPTS" / script)], cwd=str(B), env=env,
                       stdout=f, stderr=f)
    note("termine %s (disque %.1f Go)" % (nom, libre_go()))


def main():
    fin = datetime.datetime.now() + datetime.timedelta(hours=DUREE_H)
    note("BOUCLE AUTONOME demarree, fin prevue %s" % fin.strftime("%d/%m %H:%M"))
    while datetime.datetime.now() < fin:
        purge()
        for corpus in FEEDS:
            for tf in TRAMES:
                if datetime.datetime.now() >= fin:
                    break
                tour("combos_tf.py", {"CORPUS": corpus, "TF": tf, "TAILLE": "2"},
                     "combos_%s_%s" % (corpus, tf))
            if datetime.datetime.now() >= fin:
                break
            tour("precurseurs.py", {"CORPUS": corpus, "TF": "15min"}, "prec_%s" % corpus)
            tour("heatmap_etats.py", {"CORPUS": corpus}, "heatmap_%s" % corpus)
            tour("dico_tpo.py", {"CORPUS": corpus}, "dicotpo_%s" % corpus)
        if datetime.datetime.now() < fin:
            tour("organise.py", {}, "inventaire")
        note("cycle complet termine, on recommence")
    note("BOUCLE AUTONOME terminee")
    return 0


if __name__ == "__main__":
    sys.exit(main())
