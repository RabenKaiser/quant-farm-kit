# -*- coding: utf-8 -*-
"""c13v2_engine.py — MOTEUR complet C13V2 avec gestion de sortie pluggable.
Separe: (1) detection signaux (OB+frais+VWAP+rejet) validee, (2) simulateur
avec modes de sortie: tp-fixe | breakeven | trailing ATR | trailing Donchian
| sortie par extension.

La detection de signaux = celle du sweep r205 (qui a donne pf 1.3-1.5 multi
paires). On garde les memes signaux et on fait varier UNIQUEMENT l exit."""
import numpy as np
import pandas as pd
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import sweep_py_r205 as SW  # prep_frames + detect_ob via SW.F


def detect_signals(m5, m15, cfg):
    """retourne signals: list (i, dirn, zl, zh, ob_idx) et vwap pour bias."""
    # bias vwap
    h4 = None  # passe par cfg? besoin de h4
    # On reutilise la logique de detection de r205 en extrayant les signaux
    # AVANT la sim. Copie du debut de SW.bt.
    o = m15["open"].to_numpy(); h = m15["high"].to_numpy()
    l = m15["low"].to_numpy(); c = m15["close"].to_numpy()
    v = m15["volume"].to_numpy()
    a15 = SW.F.atr_s(m15, 14).to_numpy()
    av = pd.Series(v).rolling(cfg.get("vol_look", 50)).mean().to_numpy()
    n15 = len(m15)
    body = np.abs(c - o)
    is_bull = c > o
    is_bear = c < o
    L = cfg.get("imp_look", 6)
    imp_mult = cfg.get("imp_atr", 0.9)
    vol_mult = cfg.get("imp_vol", 1.0)
    bull = {}; bear = {}
    for jj in range(n15):
        if not np.isfinite(a15[jj]) or a15[jj] <= 0:
            continue
        thr = a15[jj] * imp_mult
        if is_bear[jj]:
            for k in range(1, L + 1):
                kk = jj + k
                if kk >= n15:
                    break
                vok = (not np.isfinite(av[kk])) or v[kk] >= av[kk] * vol_mult
                if is_bull[kk] and body[kk] >= thr and c[kk] > h[jj] and vok:
                    bull[jj] = (kk, l[jj], o[jj]); break
        if is_bull[jj]:
            for k in range(1, L + 1):
                kk = jj + k
                if kk >= n15:
                    break
                vok = (not np.isfinite(av[kk])) or v[kk] >= av[kk] * vol_mult
                if is_bear[kk] and body[kk] >= thr and c[kk] < l[jj] and vok:
                    bear[jj] = (kk, o[jj], h[jj]); break
    n = n15
    max_age = cfg.get("ob_age", 100000)
    bull_items = sorted(bull.items())
    bear_items = sorted(bear.items())
    lastB = {}; lastS = {}
    bi = si = 0
    curB = curS = None
    for i15 in range(n):
        while bi < len(bull_items) and bull_items[bi][0] <= i15:
            jj, (dispo, zl, zh) = bull_items[bi]
            # *** CORRECTIF LOOK-AHEAD (r316, trouve par sweeper_duka) ***
            # L OB est valide par la CLOTURE de la barre M15 kk=dispo. Il ne doit
            # donc etre utilisable qu a partir de la barre M15 SUIVANTE.
            # Avec `dispo <= i15` le moteur entrait au close d une barre M5 SITUEE
            # DANS la barre de confirmation -> prix d avant l information.
            # Mesure XAUUSD: 53,6 % des signaux etaient en look-ahead et
            # produisaient 88,7 % du R (R/DD 20,5 -> 1,13 en causal).
            # C est exactement la semantique de l EA (C13V2_MT5_EA UpdateOB:
            # confirmation kk=cand-k avec kk>=1 = barre CLOSE, enregistrement a
            # l ouverture de la M15 suivante).
            if dispo < i15:
                curB = (zl, zh, jj); bi += 1
            else:
                break
        while si < len(bear_items) and bear_items[si][0] <= i15:
            jj, (dispo, zl, zh) = bear_items[si]
            if dispo < i15:                      # idem (correctif look-ahead)
                curS = (zl, zh, jj); si += 1
            else:
                break
        lastB[i15] = curB
        lastS[i15] = curS
    m15_t = m15.index.values.astype("datetime64[ns]")
    m5_t = m5.index.values.astype("datetime64[ns]")
    idx15 = np.clip(np.searchsorted(m15_t, m5_t, side="right") - 1, 0, n - 1)
    o5 = m5["open"].to_numpy(); h5 = m5["high"].to_numpy()
    l5 = m5["low"].to_numpy(); c5 = m5["close"].to_numpy()
    pip = 0.0001
    body5 = np.abs(c5 - o5)
    rej_wick = cfg.get("rej_wick", 1.0)
    close_in = cfg.get("close_zone", 0.15)
    signals = {}
    for i in range(len(m5)):
        i15 = idx15[i]
        b = lastB.get(i15)
        if b is not None and i15 - b[2] <= max_age:
            zl, zh = min(b[0], b[1]), max(b[0], b[1])
            zoneH = max(zh - zl, pip * 0.5)
            lowerW = min(o5[i], c5[i]) - l5[i]
            if (body5[i] >= pip * 0.5 and l5[i] <= zh and
                c5[i] >= zl + zoneH * close_in and c5[i] <= zh and
                c5[i] > o5[i] and body5[i] > 0 and
                (lowerW / body5[i]) >= rej_wick):
                signals[i] = (1, zl, zh, b[2])
        s_ = lastS.get(i15)
        if s_ is not None and i15 - s_[2] <= max_age:
            zl, zh = min(s_[0], s_[1]), max(s_[0], s_[1])
            zoneH = max(zh - zl, pip * 0.5)
            upperW = h5[i] - max(o5[i], c5[i])
            if (body5[i] >= pip * 0.5 and h5[i] >= zl and
                c5[i] <= zh - zoneH * close_in and c5[i] >= zl and
                c5[i] < o5[i] and body5[i] > 0 and
                (upperW / body5[i]) >= rej_wick):
                signals[i] = (-1, zl, zh, s_[2])
    return signals, idx15


def run_exit(m5, m15, h4, cfg, exit_mode="tp", spread_pips=0.0,
             point_size=0.0001, slip_points=0.0, atr_ref=None, **ekw):
    """Simulation avec mode de sortie. spread_pips = spread en POINTS du
    marche (x point_size). point_size: 0.0001 FX, 0.01 XAU/JPY, 1.0 indices.
    DECOUVERTE r246: sans spread le python est optimiste (~1.5 pips/trade).

    slip_points (sub1/r257): SLIPPAGE en points, applique a l ENTREE (prix
    degrade contre nous) ET a la SORTIE. spread_pips ne degradait que la
    sortie + le hit test; le MT5 reel degrade AUSSI l entree (buy au ask,
    sell au bid) -> slip_points comble ce trou du modele.
    atr_ref (sub1/r257): tableau ATR aligne sur l index M5, utilise pour le
    SL et les distances TP/extension AU LIEU de l ATR M5. Sert a emuler
    l EA qui calibre tout sur l ATR M15 (AtrOf(PERIOD_M15)).
    bias_src (cfg): "m5_asof" (defaut, ATR/VWAP H4 de la barre H4 EN COURS
    = leger look-ahead), "h4_closed" (derniere H4 CLOTUREE, comme l EA
    VwapH4(1)), "ea_h4" (close H4 cloturee vs VWAP H4 cloture, comme l EA)."""
    signals, idx15 = detect_signals(m5, m15, cfg)
    SP = spread_pips * point_size   # spread en prix
    SLIP = slip_points * point_size  # slippage en prix (entree + sortie)
    # bias vwap
    tv = (h4["high"] + h4["low"] + h4["close"]) / 3
    vwap = (tv * h4["volume"]).rolling(cfg.get("vwap_len", 96)).sum() / \
           h4["volume"].rolling(cfg.get("vwap_len", 96)).sum()
    if cfg.get("bias") == "ema":
        # InpBiasMode=2 de l EA: close H4 vs EMA(H4, InpHtfEmaPeriod)
        vwap = h4["close"].ewm(span=cfg.get("ema", 200), adjust=False).mean()
    # --- source du bias (sub1/r257: reproduire le shift de l EA) ---
    bias_src = cfg.get("bias_src", "m5_asof")
    if bias_src in ("h4_closed", "ea_h4"):
        # l EA VwapH4(1)/iClose(H4,1) = derniere H4 CLOTUREE -> on decale
        # l index H4 de +4h (disponible seulement quand la barre est finie)
        vw = vwap.copy(); vw.index = vw.index + pd.Timedelta(hours=4)
        h4c = h4["close"].copy()
        h4c.index = h4c.index + pd.Timedelta(hours=4)
    else:
        vw = vwap
        h4c = h4["close"]
    _vw_ok = vw.dropna()
    _bv = _vw_ok.reindex(_vw_ok.index.union(m5.index)).ffill().reindex(m5.index)
    bv_arr = _bv.to_numpy()
    if bias_src == "ea_h4":
        _hc = h4c.reindex(h4c.index.union(m5.index)).ffill().reindex(m5.index)
        cmp_arr = _hc.to_numpy()
    else:
        cmp_arr = None
    o5 = m5["open"].to_numpy(); h5 = m5["high"].to_numpy()
    l5 = m5["low"].to_numpy(); c5 = m5["close"].to_numpy()
    a15v = SW.F.atr_s(m15, 14).to_numpy()
    # ATR5 pour trailing
    a5s = m5["high"].sub(m5["low"])
    atr5v = pd.concat([
        m5["high"] - m5["low"],
        (m5["high"] - m5["close"].shift(1)).abs(),
        (m5["low"] - m5["close"].shift(1)).abs()], axis=1).max(axis=1)
    atr5v = atr5v.rolling(14).mean().to_numpy()
    atr_use = atr5v if atr_ref is None else atr_ref
    pip = 0.0001
    excl = set(cfg.get("excl_hours", []))
    hour = m5.index.hour.to_numpy()
    tp_r = ekw.get("tp_r", cfg.get("tp_r", 2.0))
    trail_after = ekw.get("trail_after", 1.0)
    trail_mult = ekw.get("trail_mult", 1.5)
    don_N = ekw.get("don_N", 20)
    fibo = ekw.get("fibo", 0.382)
    ext_atr = ekw.get("ext_atr", 3.0)
    buf = cfg.get("buf_atr", 0.25)
    min_stop = cfg.get("min_stop", 0.00025)

    pos = None
    trades = []  # (dirn, entry, sl_init, exit, r, dur_bars, exit_mode)
    used = set()
    for i in range(1, len(m5)):
        if pos is not None:
            d = pos["dir"]
            entry = pos["entry"]; sl = pos["sl"]; tp = pos["tp"]
            a5 = atr_use[i]
            if d == 1:
                pos["hi"] = max(pos.get("hi", entry), h5[i])
                ext = pos["hi"]
            else:
                pos["lo"] = min(pos.get("lo", entry), l5[i])
                ext = pos["lo"]
            gain_r = d * (c5[i] - entry) / pos["risk"] if pos["risk"] else 0
            # MAJ SL selon mode
            new_sl = sl
            if exit_mode in ("be", "atr", "don", "fibo") and gain_r >= trail_after and a5 and np.isfinite(a5):
                if exit_mode == "be":
                    cand = entry
                elif exit_mode == "atr":
                    cand = c5[i] - d * trail_mult * a5
                elif exit_mode == "don":
                    lo2 = max(0, i - don_N)
                    cand = float(l5[lo2:i].min()) if d == 1 else float(h5[lo2:i].max())
                elif exit_mode == "fibo":
                    lvl = entry + (ext - entry) * fibo
                    cand = lvl
                better = (d == 1 and cand > sl) or (d == -1 and sl == 0) or \
                         (d == -1 and cand < sl)
                if d == 1 and cand > sl:
                    sl = cand
                    pos["sl"] = cand      # BUG FIX (r259): persister le SL
                elif d == -1 and (sl == 0 or cand < sl):
                    sl = cand
                    pos["sl"] = cand      # BUG FIX (r259): persister le SL
            # sortie (avec SPREAD: le prix effectif paye est degrade de SP)
            eff_l = l5[i] - SP if d == 1 else l5[i] + SP
            eff_h = h5[i] - SP if d == 1 else h5[i] + SP
            hit_sl = (eff_l <= sl) if d == 1 else (eff_h >= sl)
            hit_tp = False
            exit_px = None
            mode_exit = None
            if exit_mode == "extend":
                # sortie quand extension > ext_atr ATR depuis entree
                dist_r = d * (ext - entry)
                a5 = atr_use[i]
                if a5 and np.isfinite(a5) and dist_r >= ext_atr * a5:
                    hit_tp = True
                    # ext_fill="thresh" (sub1/r258): remplissage au SEUIL
                    # (comme un TP broker du MT5) et non a l'extreme de la
                    # barre -- l extreme est un remplissage OPTIMISTE.
                    # ext_fill="close" (r279, subagent MT5): MODELE REEL DE L EA.
                    # L EA ManagePos (l.220-239) teste l excursion max depuis
                    # l entree contre l ATR **COURANT** et ferme ensuite avec
                    # `trade.PositionClose(tk)` = AU PRIX COURANT. Consequence:
                    # si l ATR se contracte apres une rechute, la position se
                    # ferme EN PERTE. Mesure du subagent: 10-22% des sorties
                    # extension du MT5 sont PERDANTES, alors que le python
                    # (thresh/extreme) n en produit JAMAIS -- les deux autres
                    # modes sont structurellement incapables de perdre sur une
                    # sortie extension. C est ~85% de l ecart python/MT5.
                    _ef = ekw.get("ext_fill", "extreme")
                    if _ef == "thresh":
                        exit_px = entry + d * ext_atr * a5
                    elif _ef == "close":
                        exit_px = c5[i]
                    else:
                        exit_px = entry + d * dist_r
                    mode_exit = "ext"
            elif exit_mode == "tpatr":
                # TP BROKER GELE A L ENTREE (modele exact de l EA avec
                # InpTpAtr > 0, ligne 305/313 du C13V2_MT5_EA.mq5:
                #   tp = entry + InpTpAtr * atr15   [calcule a l ENTREE])
                # C est le mode RECOMMANDE pour l execution reelle: le broker
                # remplit EXACTEMENT au seuil, sans giveback. Le mode `extend`
                # (fermeture manuelle au prix courant) rend du terrain et c est
                # lui qui cree les 10-22% de sorties perdantes mesurees en MT5.
                hit_tp = (eff_h >= tp) if d == 1 else (eff_l <= tp)
                mode_exit = "tpatr"
            else:
                hit_tp = (eff_h >= tp) if d == 1 else (eff_l <= tp)
                mode_exit = "tp"
            if hit_sl or hit_tp:
                if hit_sl and hit_tp:
                    exit_px = sl if d == 1 else sl
                elif hit_tp:
                    exit_px = exit_px if exit_px else tp
                else:
                    exit_px = sl
                # le P&L est degrade du spread (frais aller-retour) + slippage
                r = (exit_px - entry - SP - SLIP) / pos["risk"] if d == 1 \
                    else (entry - exit_px - SP - SLIP) / pos["risk"]
                # EDGEHUNT (sweeper_upc) : 4e element = RISQUE du trade en prix.
                # Ajout ADDITIF (les 3 premiers elements sont inchanges) pour
                # pouvoir controler l'integrite de l'unite R : un R n'est une
                # unite de risque que si risk/ATR15 est d'un ordre raisonnable.
                trades.append((r, m5.index[i], pos.get("ts"), pos["risk"]))
                pos = None
        if pos is None and i in signals and hour[i] not in excl:
            sig = signals[i]
            d = sig[0]
            # filtres bias VWAP (comme r205)
            if bias_src == "none":
                bias = d          # aucun filtre de biais (sensibilite)
            else:
                bv = bv_arr[i - 1]
                if not np.isfinite(bv):
                    continue
                cv = c5[i - 1] if cmp_arr is None else cmp_arr[i - 1]
                if not np.isfinite(cv):
                    continue
                bias = 1 if cv > bv else -1
            if (d == 1 and bias != 1) or (d == -1 and bias != -1):
                continue
            a5 = atr_use[i]
            if not np.isfinite(a5) or a5 is None:
                a5 = 5 * pip
            # ENTREE degradee du slippage (buy au ask, sell au bid)
            entry = c5[i] + d * SLIP
            zlo, zhi = min(sig[1], sig[2]), max(sig[1], sig[2])
            if d == 1:
                sl0 = zlo - buf * a5
                risk = entry - sl0
                if risk < min_stop:
                    sl0 = entry - min_stop
                    risk = min_stop
                if exit_mode == "tpatr":
                    # TP broker GELE a l entree, en multiples d ATR (comme
                    # InpTpAtr de l EA, calcule avec l atr15 du moment)
                    tp0 = entry + ekw.get("tp_atr", ext_atr) * a5
                elif exit_mode == "extend":
                    tp0 = 1e9
                else:
                    tp0 = entry + risk * tp_r
                pos = {"dir": 1, "entry": float(entry), "sl": float(sl0),
                       "tp": float(tp0), "risk": float(risk),
                       "ts": m5.index[i]}
            else:
                sl0 = zhi + buf * a5
                risk = sl0 - entry
                if risk < min_stop:
                    sl0 = entry + min_stop
                    risk = min_stop
                if exit_mode == "tpatr":
                    tp0 = entry - ekw.get("tp_atr", ext_atr) * a5
                elif exit_mode == "extend":
                    tp0 = -1e9
                else:
                    tp0 = entry - risk * tp_r
                pos = {"dir": -1, "entry": float(entry), "sl": float(sl0),
                       "tp": float(tp0), "risk": float(risk),
                       "ts": m5.index[i]}
    if not trades:
        return {"n": 0, "R": 0.0, "wr": 0, "pf": 0, "dd": 0, "trades": []}
    if isinstance(trades[0], tuple):
        arr = np.array([t[0] for t in trades])
    else:
        arr = np.array(trades)
    wins = arr[arr > 0]; losses = arr[arr < 0]
    gw = wins.sum(); gl = -losses.sum()
    eq = np.cumsum(arr)
    dd = float((np.maximum.accumulate(eq) - eq).max())
    return {"n": len(arr), "R": float(arr.sum()),
            "wr": float(len(wins) / len(arr) * 100),
            "pf": float(gw / gl) if gl > 0 else 99.0, "dd": dd,
            "trades": trades}
