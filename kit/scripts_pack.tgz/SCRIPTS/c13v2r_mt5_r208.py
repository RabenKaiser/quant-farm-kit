# -*- coding: utf-8 -*-
"""c13v2r_mt5_r208.py — validation MT5 model=0 des configs robustes python
(C13V2_MT5_EA avec inputs = configs gagnantes). Fidelite python<->MT5."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\c13v2r_mt5_r208.jsonl"


def cfg(mg, imp, wick, tp, age):
    return dict(InpMagic=mg, InpLots=0.10, InpTpR=tp, InpAtrPeriod=14,
                InpImpAtrMult=imp, InpImpVolMult=1.0, InpVolLookback=50,
                InpImpLook=6, InpObMaxAge=age, InpRejWickRatio=wick,
                InpRejVolMult=1.0, InpCloseInZone=0.15, InpBufferAtrFrac=0.25,
                InpMinStopPips=3.0, InpTrailAtrMult=0.0, InpTrailAfterR=1.0,
                InpBiasMode=1, InpVwapLen=96, InpHtfEmaPeriod=200,
                InpUseHourFilter=True, InpExcludedHours="6,7,12,15,19,23",
                InpUseDailyStop=True, InpDailyStopPct=2.0, InpMaxTradesDay=0,
                InpUtcOffset=2, InpVerbose=False)


def main():
    mg = 780000
    RUNS = [
        # EURUSD: imp0.9 wick0.8 tp2.0 age16
        ("EUR23-W08-T20", "EURUSD", "2023.01.01", "2024.01.01", 0.9, 0.8, 2.0, 16),
        ("EUR24-W08-T20", "EURUSD", "2024.01.01", "2025.01.01", 0.9, 0.8, 2.0, 16),
        ("EUR25-W08-T20", "EURUSD", "2025.01.01", "2026.01.01", 0.9, 0.8, 2.0, 16),
        # EURUSD alt wick1.0
        ("EUR23-W10-T20", "EURUSD", "2023.01.01", "2024.01.01", 0.9, 1.0, 2.0, 16),
        ("EUR24-W10-T20", "EURUSD", "2024.01.01", "2025.01.01", 0.9, 1.0, 2.0, 16),
        ("EUR25-W10-T20", "EURUSD", "2025.01.01", "2026.01.01", 0.9, 1.0, 2.0, 16),
        # GBPUSD: imp0.9 wick2.0 tp3.0 age16
        ("GBP23-W20-T30", "GBPUSD", "2023.01.01", "2024.01.01", 0.9, 2.0, 3.0, 16),
        ("GBP24-W20-T30", "GBPUSD", "2024.01.01", "2025.01.01", 0.9, 2.0, 3.0, 16),
        ("GBP25-W20-T30", "GBPUSD", "2025.01.01", "2026.01.01", 0.9, 2.0, 3.0, 16),
    ]
    with open(OUT, "a", encoding="utf-8") as fo:
        for tag, sym, frm, to, imp, wick, tp, age in RUNS:
            mg += 1
            c = cfg(mg, imp, wick, tp, age)
            print(f"[r208 {tag}] MT5 {sym} ...", flush=True)
            r = RF.run_backtest("C13V2_MT5_EA", symbol=sym, tf="M5",
                                from_d=frm, to_d=to, deposit=10000,
                                max_wait=3600, inputs=c)
            fo.write(json.dumps({"tag": tag, "r": r}, default=str) + "\n")
            fo.flush()
            print(f"[{tag}] " + ("null" if r is None else
                  f"p={r.get('profit')} n={r.get('trades')} "
                  f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
            time.sleep(2)
    print("FIN r208", flush=True)


if __name__ == "__main__":
    main()
