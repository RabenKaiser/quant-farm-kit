# -*- coding: utf-8 -*-
"""debug_counts.py — compter OB detectes et rejets pour deboguer."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import c13v2_py_fast2 as F
import numpy as np
import pandas as pd

sym = "EURUSD"; year = 2024
m1 = F.load_m1(sym)
start = pd.Timestamp(f"{year}-01-01", tz="UTC")
end = pd.Timestamp(f"{year + 1}-01-01", tz="UTC")
wu = start - pd.Timedelta(days=260)
m15 = F.resample(m1.loc[wu:end], "15min")
o = m15["open"].to_numpy(); h = m15["high"].to_numpy()
l = m15["low"].to_numpy(); c = m15["close"].to_numpy()
v = m15["volume"].to_numpy()
a15 = F.atr_s(m15, 14).to_numpy()
av = pd.Series(v).rolling(50).mean().to_numpy()
n = len(m15)
body = np.abs(c - o)
is_bull = c > o
is_bear = c < o
thr = a15 * 1.2
nb = 0; ns = 0
for jj in range(n):
    if not np.isfinite(a15[jj]) or a15[jj] <= 0:
        continue
    if is_bear[jj]:
        for k in range(1, 6):
            kk = jj + k
            if kk >= n: break
            if is_bull[kk] and body[kk] >= thr[jj] and c[kk] > h[jj]:
                nb += 1; break
    if is_bull[jj]:
        for k in range(1, 6):
            kk = jj + k
            if kk >= n: break
            if is_bear[kk] and body[kk] >= thr[jj] and c[kk] < l[jj]:
                ns += 1; break
print(f"m15 bars={n} | OB bull={nb} bear={ns}")
print(f"par jour: {nb/252:.1f} bull/j, {ns/252:.1f} bear/j")
# volume filter impact
nbv = 0
for jj in range(n):
    if not np.isfinite(a15[jj]) or a15[jj] <= 0: continue
    if is_bear[jj]:
        for k in range(1, 6):
            kk = jj + k
            if kk >= n: break
            vok = (not np.isfinite(av[kk])) or v[kk] >= av[kk]*1.5
            if is_bull[kk] and body[kk] >= thr[jj] and c[kk] > h[jj] and vok:
                nbv += 1; break
print(f"OB bull avec volume filter={nbv}")
