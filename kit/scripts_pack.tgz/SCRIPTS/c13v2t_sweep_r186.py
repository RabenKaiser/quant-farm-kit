# -*- coding: utf-8 -*-
"""c13v2t_sweep_r186.py — sweep params C13V2T sur GBPUSD 2025 (le pire cas):
- TP magnetique vs fixe (2.0R/2.5R/3.0R)
- trailing 1.5/2.0/2.5 ATR
- wick ratio 1.0/1.5 (selectivite rejet)
- lookback mag 40/80
Trouve la config qui rend GBPUSD positif."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\c13v2t_sweep_r186.jsonl"


def cfg(mg, tpr, trail, after, wick, maglb):
    return dict(InpMagic=mg, InpLots=0.10, InpRiskPct=0.0, InpTpR=tpr,
                InpMagLookbackH4=maglb, InpTrailAtrMult=trail, InpTrailAfterR=after,
                InpImpulseAtrMult=0.9, InpImpulseLook=6, InpAtrPeriod=14,
                InpHtfEmaPeriod=200, InpPinWickRatio=wick, InpCloseInZoneMin=0.15,
                InpMinStopPips=2.5, InpBufferAtrFrac=0.25, InpMaxSpreadPts=80,
                InpUseHourFilter=True, InpExcludedHoursCSV="6,7,12,15,19,23",
                InpUseDailyStop=True, InpDailyStopR=3.0, InpMaxTradesDay=0,
                InpUtcOffset=2, InpVerbose=False)


def main():
    mg = 752000
    RUNS = [
        ("T20-TR15-A05-W15", 2.0, 1.5, 0.5, 1.5, 60),
        ("T20-TR15-A10-W10", 2.0, 1.5, 1.0, 1.0, 60),
        ("T25-TR20-A05-W15", 2.5, 2.0, 0.5, 1.5, 60),
        ("T30-TR15-A10-W15", 3.0, 1.5, 1.0, 1.5, 60),
        ("MAG40-T20-W15", 2.0, 1.5, 0.5, 1.5, 40),
        ("MAG80-T25-W15", 2.5, 2.0, 0.5, 1.5, 80),
        ("FIXE-T20-TR15-A05", 2.0, 1.5, 0.5, 1.0, 0),
        ("FIXE-T25-TR20-A10", 2.5, 2.0, 1.0, 1.0, 0),
    ]
    with open(OUT, "a", encoding="utf-8") as fo:
        for tag, tpr, trail, after, wick, maglb in RUNS:
            mg += 1
            c = cfg(mg, tpr, trail, after, wick, maglb)
            print(f"[r186 {tag}] GBPUSD 2025 ...", flush=True)
            r = RF.run_backtest("C13V2T_EA", symbol="GBPUSD", tf="M5",
                                from_d="2025.01.01", to_d="2026.01.01",
                                deposit=10000, max_wait=3600, inputs=c)
            fo.write(json.dumps({"tag": tag, "r": r}, default=str) + "\n")
            fo.flush()
            print(f"[{tag}] " + ("null" if r is None else
                  f"p={r.get('profit')} n={r.get('trades')} "
                  f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
            time.sleep(2)
    print("FIN r186", flush=True)


if __name__ == "__main__":
    main()
