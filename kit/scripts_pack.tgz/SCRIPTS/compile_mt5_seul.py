"""compile_mt5_seul : recompiler UNIQUEMENT le profil cible (Upcomers).

`compile_trigger_lab.py` recompile les deux profils et supprime l'ex5 avant de compiler.
C'est sans danger quand rien ne tourne, mais ce n'est pas le cas : la campagne d'ordres
reels sur Dukascopy est en cours et son terminal tient l'ex5 farm ouvert. Ce lanceur
n'utilise que le dossier de donnees Upcomers, dont la campagne vient de se terminer.

Usage : python SCRIPTS\\compile_mt5_seul.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compile_trigger_lab as C


def main():
    ok, ex5, texte = C.compile_in("mt5", Path(r"C:\MT5\MetaEditor64.exe"))
    import re
    err = len(re.findall(r":\s*(error|erreur)\s", texte, re.I))
    warn = len(re.findall(r":\s*(warning|avertissement)\s", texte, re.I))
    if not texte.strip() and not ok:
        # ROUND 386 : « erreurs=0 » sur un journal ABSENT n est PAS une compilation
        # reussie -- c est ainsi qu un .ex5 a disparu sans alerte. On le dit.
        print("mt5 : JOURNAL ABSENT et aucun .ex5 -- compilation NON CONCLUANTE")
        return 1
    print("mt5 : ex5=%s | erreurs=%d | avertissements=%d" % (ok, err, warn))
    if texte:
        for ln in texte.splitlines():
            if re.search(r"\b(error|erreur)\b", ln, re.I):
                print("    %s" % ln.strip())
    return 0 if (ok and err == 0) else 1


if __name__ == "__main__":
    sys.exit(main())
