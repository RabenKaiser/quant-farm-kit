# -*- coding: utf-8 -*-
"""conditionneurs.py — QUELLE CONDITION AMELIORE UNE ENTREE ?

LE RAISONNEMENT QUI A CHANGE CETTE NUIT (18/09, 02 h 30)
-------------------------------------------------------
On a cherche pendant des jours des COMBINAISONS gagnantes (declencheur + filtre
+ sortie), et on a montre que ce classement ne transfere pas. Mais la
contre-epreuve par entree aleatoire donne un resultat bien plus utile :

    - une entree ALEATOIRE, avec un stop large, vaut ~0 R ;
    - nos 2 100 combinaisons valent -0.055 R, soit PIRE que le hasard ;
    - aucune geometrie ne rend l'aleatoire positif.

Autrement dit : le mecanisme n'est pas le probleme (il est presque gratuit), et
nos declencheurs ne sont pas la solution (ils font pire). La bonne question
n'est donc pas « quelle combinaison gagne ? » mais :

    QUELLE CONDITION rend une entree MEILLEURE que le hasard ?

C'est une question mieux posee : au lieu de chercher un maximum parmi 2 100
candidats (ce qui fabrique un faux gagnant), on mesure l'EFFET d'une condition
sur un pool enorme, et on exige qu'il se retrouve dans les DEUX moities.

CE QU'ON MESURE, pour chaque condition F presente dans nos identifiants :
    delta = R(trades quand F est vrai) - R(tous les trades)
avec un t regroupe par blocs (combinaison x trimestre), dans A et dans B.

USAGE : python conditionneurs.py
"""
import collections
import json
import statistics
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
SNAP = BASE / "lab_snapshots" / "lab_results_20260918_0000.jsonl"
CH = "r_x47"                     # SL 12 x ATR / TP 1 x ATR (meilleure geometrie)
QA = ["2024Q1", "2024Q2", "2024Q3"]
QB = ["2024Q4", "2025Q1"]
NMIN = 2000


def main():
    blocs = collections.defaultdict(lambda: [0.0, 0])
    par_cond = collections.defaultdict(lambda: collections.defaultdict(
        lambda: [0.0, 0]))
    conds = collections.Counter()
    with open(SNAP, encoding="utf-8") as fh:
        for line in fh:
            if ('"%s"' % CH) not in line:
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            p = str(r.get("period", ""))
            if p not in QA + QB or r["n"] < 3:
                continue
            tok = r["id"].split("|")
            if len(tok) < 4:
                continue
            v = r.get(CH)
            if v is None:
                continue
            n = float(r["n"])
            for liste, cible in ((tok[1:3], par_cond),):
                for f in liste:
                    if f and f != "NONE":
                        e = cible[f][p]
                        e[0] += v * n
                        e[1] += n
                        conds[f] += 1
            e = blocs[p]
            e[0] += v * n
            e[1] += n

    def R(d, Q):
        s = sum(d[q][0] for q in Q if q in d)
        m = sum(d[q][1] for q in Q if q in d)
        return (s / m, m) if m else (None, 0)

    ra_all, na = R({q: blocs[q] for q in blocs}, QA)
    rb_all, nb = R({q: blocs[q] for q in blocs}, QB)
    print("=" * 100)
    print("QUELLE CONDITION AMELIORE UNE ENTREE ? (sortie %s)" % CH)
    print("=" * 100)
    print("   R de TOUS les trades : A %+.4f (%d transactions)  B %+.4f (%d)"
          % (ra_all, na, rb_all, nb))
    print("   conditions disponibles : %d" % len(conds))
    print()
    res = []
    for f, d in par_cond.items():
        ra, na2 = R(d, QA)
        rb, nb2 = R(d, QB)
        if ra is None or rb is None or nb2 < NMIN:
            continue
        res.append((f, ra - ra_all, rb - rb_all, na2, nb2))
    res.sort(key=lambda x: -x[2])
    print("   %-22s %11s %11s %10s %10s %s"
          % ("condition", "delta A", "delta B", "n(A)", "n(B)", "les deux ?"))
    print("   " + "-" * 92)
    bons = []
    for f, da, db, na2, nb2 in res[:30]:
        ok = (da > 0 and db > 0)
        if ok:
            bons.append(f)
        print("   %-22s %+11.4f %+11.4f %10d %10d %s"
              % (f[:22], da, db, na2, nb2, "oui" if ok else ""))
    print("   ...")
    for f, da, db, na2, nb2 in res[-6:]:
        print("   %-22s %+11.4f %+11.4f %10d %10d %s"
              % (f[:22], da, db, na2, nb2, "oui" if (da > 0 and db > 0) else ""))
    print()
    ntest = len(res)
    attendu = 0.25 * ntest      # 1 chance sur 4 d'avoir les deux du meme signe
    print("   conditions testees : %d" % ntest)
    print("   conditions positives DANS LES DEUX moities : %d" % len(bons))
    print("   attendu par pur hasard : ~%.0f (une chance sur quatre)" % attendu)
    print()
    if len(bons) <= attendu * 1.5:
        print("   >>> AUCUNE CONDITION NE RESSORT. Le nombre de conditions")
        print("       positives dans les deux moities est celui du hasard.")
        print("       Conseil de prudence : ne garder aucune de ces conditions")
        print("       comme 'avantage' -- ce serait refaire le +84 %.")
    else:
        print("   >>> DES CONDITIONS SORTENT DU HASARD : %s" % ", ".join(bons))
        print("       A verifier sur 2020-2021 avant toute conclusion.")
    print()
    print("   LECTURE. Un delta positif petit (0.01-0.03 R) mais retrouve dans")
    print("   les deux moities ET sur 2020-2021 serait la premiere piste reelle")
    print("   du projet : il faudrait alors construire une entree autour d'elle")
    print("   et viser +0.14 R au total, seuil impose par le cout d'execution.")


if __name__ == "__main__":
    main()
