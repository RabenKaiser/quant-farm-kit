"""dico_tpo : le « market dictionary » croise avec le TPO - Python pour les PROBABILITES.

Deux idees de l'utilisateur, combinees :
  - le DICTIONNAIRE DE MARCHE encode chaque fenetre de N clotures en un MOT (log, z-normalisation,
    compression en W segments, lettres par points de rupture) : c'est deja un moteur de
    probabilites conditionnelles ;
  - le TPO fournit le CONTEXTE de prix : POC, value area (70 % des TPO) et range de la SESSION
    PRECEDENTE.

La question posee n'est donc pas « le mot X monte-t-il ? » mais « le mot X monte-t-il QUAND le prix
est sous le POC de la veille / vient de casser la VAL / est hors du range de la veille ? ». C'est
la conjonction qui peut sortir des pourcentages eleves, et rien d'autre.

Tout est CAUSAL (mot jusqu'a t, niveaux TPO de la session precedente) et VECTORISE : la premiere
version calculait les mots barre par barre en Python, ce qui demandait des heures pour huit paires
(500 000 barres x 32 operations). Ici tout passe par des moyennes glissantes.
"""
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
N_WORD = 32
W_LET = 4
SEG = N_WORD // W_LET
BREAKS = (-0.6745, 0.0, 0.6745)
HORIZONS = (12, 24)
BINS = 50


def charge(corpus, paire):
    f = B / corpus / ("%s_M1.csv" % paire)
    if not f.exists():
        return None
    d = pd.read_csv(f, usecols=["time", "open", "high", "low", "close"])
    if len(d) < 100000:
        return None
    d["t"] = pd.to_datetime(d["time"], unit="s")
    d = d.set_index("t")
    m5 = d.resample("5min").agg(o=("open", "first"), high=("high", "max"),
                                low=("low", "min"), close=("close", "last")).dropna()
    if len(m5) < 20000:
        return None
    tr = pd.concat([m5.high - m5.low, (m5.high - m5.close.shift()).abs(),
                    (m5.low - m5.close.shift()).abs()], axis=1).max(axis=1)
    return m5, tr.rolling(14).mean().values


def mots(m5):
    """VECTORISE. mot[t] = 4 lettres decrivant les 32 clotures jusqu'a t (inclus)."""
    logc = pd.Series(np.log(m5.close.values))
    mu = logc.rolling(N_WORD).mean().values
    sd = logc.rolling(N_WORD).std(ddof=0).values
    with np.errstate(invalid="ignore", divide="ignore"):
        z = (logc.values - mu) / np.where(sd > 0, sd, np.nan)
    seg8 = pd.Series(z).rolling(SEG).mean().values          # moyenne de chaque segment de 8
    n = len(logc)
    code = np.full(n, -1, dtype=np.int32)
    ok = np.isfinite(seg8) & np.isfinite(z)
    # le segment s de la fenetre se termine a l'index t - N_WORD + SEG*(s+1) - 1
    lettres = []
    for s in range(W_LET):
        dec = N_WORD - SEG * (s + 1)
        v = np.full(n, np.nan)
        v[dec:] = seg8[:n - dec] if dec else seg8
        let = np.zeros(n, dtype=np.int32)
        for b in BREAKS:
            let += (v >= b).astype(np.int32)
        lettres.append(np.where(np.isfinite(v), let, -1))
    ok &= np.all([l >= 0 for l in lettres], axis=0)
    for s in range(W_LET):
        code = np.where(ok, np.where(code < 0, 0, code) * 4 + np.maximum(lettres[s], 0), -1)
    return code


def tpo_veille(m5):
    j = pd.Series(m5.index.date, index=m5.index).values
    poc = np.full(len(m5), np.nan)
    vah = np.full(len(m5), np.nan)
    val = np.full(len(m5), np.nan)
    haut = np.full(len(m5), np.nan)
    bas = np.full(len(m5), np.nan)
    niveaux = {}
    for d in sorted(set(j)):
        m = (j == d)
        h, l = m5.high.values[m], m5.low.values[m]
        if len(h) < 10:
            continue
        lo, hi = l.min(), h.max()
        if hi <= lo:
            continue
        bords = np.linspace(lo, hi, BINS + 1)
        idx = np.clip(np.searchsorted(bords, (h + l) / 2.0) - 1, 0, BINS - 1)
        tpo = np.bincount(idx, minlength=BINS).astype(float)
        p = int(np.argmax(tpo))
        acc, cible = tpo[p], 0.7 * tpo.sum()
        a = b = p
        while acc < cible and (a > 0 or b < BINS - 1):
            g = tpo[a - 1] if a > 0 else -1.0
            dr = tpo[b + 1] if b < BINS - 1 else -1.0
            if dr >= g:
                b += 1
                acc += tpo[b]
            else:
                a -= 1
                acc += tpo[a]
        niveaux[d] = (0.5 * (bords[p] + bords[p + 1]), bords[b + 1], bords[a], hi, lo)
    prec = None
    for d in sorted(set(j)):
        m = (j == d)
        # certains jours n'ont pas de profil (moins de 10 barres, ou range nul) : ils ne sont pas
        # dans `niveaux`, et les indexer levait un KeyError. On garde alors le dernier profil
        # disponible, ce qui est aussi le comportement voulu (niveau de la derniere session cotee).
        if prec is not None and prec in niveaux:
            p0, vh0, vl0, h0, l0 = niveaux[prec]
            poc[m], vah[m], val[m], haut[m], bas[m] = p0, vh0, vl0, h0, l0
        prec = d
    return poc, vah, val, haut, bas


def etats_tpo(m5, atr, poc, vah, val, haut, bas):
    c = m5.close.values
    ok = np.isfinite(poc) & np.isfinite(vah) & np.isfinite(val) & (atr > 0)
    dist = np.where(ok, (c - poc) / np.where(atr > 0, atr, np.nan), np.nan)
    return {
        "sous le POC": ok & (dist <= -0.5),
        "au-dessus du POC": ok & (dist >= 0.5),
        "dans la value area": ok & (c >= val) & (c <= vah),
        "casse VAH (au-dessus)": ok & (c > vah),
        "casse VAL (en dessous)": ok & (c < val),
        "hors range veille": ok & ((c > haut) | (c < bas)),
    }


def resultats(m5, atr, code, masque, horizon, sens):
    """p(1R avant stop) etc. pour un masque donne."""
    c, h, l = m5.close.values, m5.high.values, m5.low.values
    n = len(c)
    idx = np.flatnonzero(masque & (code >= 0))
    idx = idx[(idx < n - horizon - 1) & (atr[idx] > 0)]
    if len(idx) < 120:
        return None
    off = np.arange(1, horizon + 1)
    Hh, Ll = h[idx[:, None] + off], l[idx[:, None] + off]
    if sens < 0:
        mfe = (c[idx][:, None] - Ll) / atr[idx][:, None]
        mae = (Hh - c[idx][:, None]) / atr[idx][:, None]
    else:
        mfe = (Hh - c[idx][:, None]) / atr[idx][:, None]
        mae = (c[idx][:, None] - Ll) / atr[idx][:, None]
    mfe, mae = mfe.max(axis=1), mae.max(axis=1)
    return dict(n=len(idx), p_mfe1=100 * float(np.mean(mfe >= 1)),
                p_1r=100 * float(np.mean((mfe >= 1) & (mae < 1))),
                p_2r=100 * float(np.mean((mfe >= 2) & (mae < 1))),
                ratio=float(np.mean(mfe) / np.mean(mae)) if np.mean(mae) > 0 else 0,
                mfe=float(np.mean(mfe)), mae=float(np.mean(mae)))


def mot_en_texte(code):
    s = ""
    for _ in range(W_LET):
        s = "abcd"[code % 4] + s
        code //= 4
    return s


def main():
    corpus = os.environ.get("CORPUS", "m1_pos")
    limite = int(os.environ.get("PAIRES_MAX", "8"))
    paires = [p.stem.replace("_M1", "") for p in sorted((B / corpus).glob("*_M1.csv"))][:limite]
    par_etat = defaultdict(lambda: defaultdict(list))
    par_mot = defaultdict(lambda: defaultdict(list))
    tous_mots = defaultdict(lambda: defaultdict(list))   # (mot) x (etat)
    for paire in paires:
        ch = charge(corpus, paire)
        if ch is None:
            continue
        m5, atr = ch
        code = mots(m5)
        poc, vah, val, haut, bas = tpo_veille(m5)
        etats = etats_tpo(m5, atr, poc, vah, val, haut, bas)
        n_mots = len(set(code[code >= 0].tolist()))
        for nom, masque in etats.items():
            for h in HORIZONS:
                for sens in (-1, 1):
                    r = resultats(m5, atr, code, masque, h, sens)
                    if r:
                        for k in ("n", "p_mfe1", "p_1r", "p_2r", "ratio", "mfe", "mae"):
                            par_etat[(nom, h, sens)][k].append(r[k])
            # le croisement : chaque MOT dans cet etat TPO
            sous = np.flatnonzero(masque & (code >= 0))
            if len(sous) < 500:
                continue
            for mot in np.unique(code[sous]):
                mm = (code == mot) & masque
                if mm.sum() < 150:
                    continue
                for h in HORIZONS:
                    for sens in (-1, 1):
                        r = resultats(m5, atr, code, mm, h, sens)
                        if r:
                            for k in ("n", "p_mfe1", "p_1r", "p_2r", "ratio"):
                                tous_mots[(mot_en_texte(mot), nom, h, sens)][k].append(r[k])
        print("  %-9s %d mots distincts" % (paire, n_mots), flush=True)

    lignes = ["# Dictionnaire de marche x TPO - probabilites conditionnelles", "",
              "Mot = %d dernieres clotures M5, log + z-normalisation, compressees en %d lettres (points de"
              % (N_WORD, W_LET), "rupture aux quartiles de la normale : -0,6745 / 0 / +0,6745). Etat TPO =",
              "position du prix par rapport au POC, a la value area et au range de la SESSION PRECEDENTE.",
              "Tout est causal. Seuils d'equilibre : 33,3 % pour une cible 2 R, 50 % pour 1 R.", "",
              "## 1. Les etats TPO seuls", "",
              "| etat TPO | sens | horizon | n | p(MFE>=1) | p(1R avant stop) | p(2R avant stop) | MFE/MAE |",
              "|---|---|---|---|---|---|---|---|"]
    for (nom, h, sens) in sorted(par_etat, key=lambda k: -float(np.mean(par_etat[k]["p_1r"]))):
        d = par_etat[(nom, h, sens)]
        n = int(np.mean(d["n"]))
        if n < 300:
            continue
        v = lambda k: float(np.mean(d[k]))
        lignes.append("| %s | %s | %dh | %d | %.1f %% | **%.1f %%** | %.1f %% | %.2f |"
                      % (nom, "COURT" if sens < 0 else "LONG", h // 12, n, v("p_mfe1"),
                         v("p_1r"), v("p_2r"), v("ratio")))
    lignes += ["", "## 2. Les MEILLEURES CONJONCTIONS mot x etat TPO", "",
              "Une ligne par couple (mot, etat) qui atteint au moins 150 observations, classe par",
              "`p(1R avant stop)`. C'est la table a chercher : le « quand ce mot apparait DANS ce",
              "contexte » de l'utilisateur.", "",
              "| mot | etat TPO | sens | horizon | n | p(MFE>=1) | p(1R avant stop) | p(2R avant stop) | MFE/MAE |",
              "|---|---|---|---|---|---|---|---|---|"]
    rangs = []
    for cle, d in tous_mots.items():
        n = int(np.sum(d["n"]))
        if n < 200:
            continue
        v = lambda k: float(np.average(d[k], weights=d["n"]))
        rangs.append((v("p_1r"), cle, n, v))
    rangs.sort(reverse=True, key=lambda x: x[0])
    for p1, (mot, nom, h, sens), n, v in rangs[:40]:
        lignes.append("| `%s` | %s | %s | %dh | %d | %.1f %% | **%.1f %%** | %.1f %% | %.2f |"
                      % (mot, nom, "COURT" if sens < 0 else "LONG", h // 12, n,
                         v("p_mfe1"), p1, v("p_2r"), v("ratio")))
        print("  MOT %s | %-22s | %-5s %2dh | n=%5d | p(1R avant stop) %4.1f%% | p(2R) %4.1f%% | MFE/MAE %.2f"
              % (mot, nom, "COURT" if sens < 0 else "LONG", h // 12, n, p1, v("p_2r"), v("ratio")), flush=True)
    (B / ("DICO_TPO_%s.md" % corpus)).write_text("\n".join(lignes), encoding="utf-8")
    print("\n%d conjonctions retenues -> DICO_TPO_%s.md" % (len(rangs), corpus), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
