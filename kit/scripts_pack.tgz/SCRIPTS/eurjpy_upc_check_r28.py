# -*- coding: utf-8 -*-
"""eurjpy_upc_check_r28.py — balance reelle EURJPY Upcomers 2026 (runs V3INT)."""
import os, sys, glob
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
best = {}
for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-16:]:
    runs = F.parse_stream(lp, "V3INT")
    for key, data in runs.items():
        if "20260101" not in key.replace(".", "") or "EURJPY" not in key:
            continue
        closed = [t for t in data["trades"].values() if t["close"] is not None]
        if len(closed) < 5:
            continue
        b = data.get("balance") or 0.0
        k = len(closed)
        if k not in best or abs(b - 10000) < abs(best[k][1] - 10000):
            best[k] = (b, len(closed))
for k, (b, n) in sorted(best.items()):
    print(f"EURJPY run {n}t: balance {b:.0f} -> reel {b-10000:+.0f}$")
print("FIN", flush=True)
