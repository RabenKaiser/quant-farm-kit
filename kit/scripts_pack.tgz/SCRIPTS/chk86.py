﻿import sys, numpy as np, gc, pandas as pd
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT, deep_lib as D
G._cache.clear(); gc.collect()
F = G.get_frames("CADJPY"); m5,m1=F["m5"],F["m1"]
h1z,hh,ll,a1,gb,gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd,zlo,zhi = MT.project(m5.index,h1z,hh,ll,gb,gr,max_age_h=48)
M = NL.build(m5,F,zd,zlo,zhi); M.update(FE.more(m5,F,m1))
s = NL.sig(M, "xup_vwapD", ["bb_low"])
nz = np.nonzero(s)[0]
print(f"signaux xup_vwapD|bb_low : {len(nz)}")
st = D.run_ex("CADJPY", s, 1.5, 99.0, 960, trail_atr=None,
              t0=m5.index[0], t1=m5.index[-1], use_m1=False)
print(f"trades python sans filtre spread : {st.get('n')}")
# avec filtre spread
df = pd.read_csv(r"C:\EAFarm\HISTORY - Copy\research\m1_pos\CADJPY_M1.csv", usecols=["time","spread"])
df["ts"] = pd.to_datetime(df["time"], unit="s", utc=True)
sp5 = df.set_index("ts")["spread"].resample("5min").mean().reindex(m5.index).ffill().to_numpy()
med = np.nanmedian(sp5)
for mult in (2.5, 5.0):
    ok = sp5 <= mult*med
    s2 = s.copy(); s2[~ok]=0
    st2 = D.run_ex("CADJPY", s2, 1.5, 99.0, 960, trail_atr=None,
                   t0=m5.index[0], t1=m5.index[-1], use_m1=False)
    print(f"  avec filtre x{mult} : {st2.get('n')} trades ({100*(~ok).mean():.1f} % barres filtrees)")
print()
print("MT5 : 495 entrees")
print()
print("=> python avec filtre x2.5 ne garde que 18 sur 185. MT5 en garde 495.")
print("   MT5 > python SANS filtre (185) ! Donc l'EA prend PLUS de trades que")
print("   le signal python n'en produit.")
