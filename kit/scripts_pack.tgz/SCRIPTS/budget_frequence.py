# -*- coding: utf-8 -*-
r"""budget_frequence.py -- COMBIEN DE JAMBES POUR 12 TRANSACTIONS PAR JOUR, ET
CE QUE 12 x 0,35 % IMPLIQUE POUR LA COUPE JOURNALIERE.

LA CIBLE DE L'UTILISATEUR (15/10) : « 15 jambes, ~12 transactions par jour,
0,35 % de risque par transaction ». Ce script dit deux choses :

1) LA CAPACITE. Le portefeuille actuel produit ~3 transactions/jour avec 6
   jambes (mesure sur ordres reels, chargeur corrige). On mesure le DEBIT PAR
   JAMBE et on en deduit combien de jambes il faut pour atteindre 6, 9 et 12
   transactions/jour. On ne peut pas trader ce que les jambes ne produisent pas :
   le plafond journalier est une capacite, pas un levier.

2) LE RISQUE. A 12 transactions/jour et 0,35 % par transaction, l'exposition
   quotidienne atteint 4,2 %. Avec la regle dure de -3 % par jour, cela veut
   dire qu'environ 9 transactions perdantes d'affilee suffisent a fermer la
   journee. On chiffre donc la probabilite d'une journee a -3 % en fonction du
   risque par transaction, a partir de la dispersion REELLE (ecart-type des R
   mesures sur ordres reels) : P(jour <= -3 %) ~ Phi(-3 / (sd_R * risque *
   sqrt(n))).
"""
import os
import sys
from datetime import datetime
from pathlib import Path

import math

import numpy as np

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE / "SCRIPTS"))
os.environ.setdefault("CORPUS", "m1_ext")
import charge_propre as CH

D0 = datetime(2024, 1, 2)

JAMBES = ["g3_kelt16h_xauusd", "g3_sr100_usa30idx_4", "g3_kelt32deu_slr6",
          "g3_kelt32jpn_slr6", "g3_scr_keltbrk_ej"]
HF = "HF_VWAPB_XAUUSD"


def stats():
    R, jours = [], set()
    par_jambe = []
    for t in JAMBES:
        tx = [x for x in CH.transactions_propres(t) if x["t_in"] >= D0]
        if len(tx) < 20:
            continue
        j = len({x["t_in"].date() for x in tx})
        r = np.array([x["R"] for x in tx])
        par_jambe.append((t, len(tx), j, len(tx) / max(j, 1), float(r.mean()), float(r.std(ddof=1))))
        R.extend(r.tolist())
        jours |= {x["t_in"].date() for x in tx}
    import json
    f = BASE / "SERIE_R_XAUUSD.json"
    if f.exists():
        s = [(d, r) for d, r in json.loads(f.read_text(encoding="utf-8"))
             if datetime.fromisoformat(str(d)[:19]) >= D0]
        if s:
            r = np.array([x[1] for x in s])
            j = len({str(x[0])[:10] for x in s})
            par_jambe.append((HF, len(s), j, len(s) / max(j, 1), float(r.mean()), float(r.std(ddof=1))))
            R.extend(r.tolist())
            jours |= {str(x[0])[:10] for x in s}
    return par_jambe, np.array(R), len(jours)


def phi(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def main():
    par_jambe, R, jours = stats()
    print("DEBIT PAR JAMBE (ordres reels 2024+, chargeur corrige)")
    print("%-26s %6s %6s %9s %9s %9s" % ("jambe", "tx", "jours", "tx/jour", "mu(R)", "sd(R)"))
    for t, n, j, d, mu, sd in sorted(par_jambe, key=lambda x: -x[3]):
        print("%-26s %6d %6d %9.2f %+9.4f %9.3f" % (t[:26], n, j, d, mu, sd))
    debit_total = sum(x[3] for x in par_jambe)
    mu = float(R.mean())
    sd = float(R.std(ddof=1))
    print()
    print("PORTEFEUILLE ACTUEL : %d jambes, %.2f transactions/jour, mu %+.4f R/tx, sd %.3f R"
          % (len(par_jambe), debit_total, mu, sd))
    print()
    print("CAPACITE : combien de jambes pour la cible ?")
    deb_moy = debit_total / max(len(par_jambe), 1)
    print("   debit moyen par jambe : %.2f tx/jour" % deb_moy)
    for cible in (6, 9, 12):
        print("   pour %2d tx/jour : %4.1f jambes de ce debit (ou %d jambes si elles tiennent 1,0 tx/jour)"
              % (cible, cible / max(deb_moy, 0.01), int(np.ceil(cible / 1.0))))
    print()
    print("RISQUE : journee a -3 % (regle dure) selon le risque par transaction")
    print("%9s %10s %12s %14s %14s" % ("tx/jour", "risq %", "expo jour %",
                                       "sd jour %", "P(jour<=-3 %)"))
    for n in (6, 9, 12):
        for risque in (0.20, 0.25, 0.35):
            expo = n * risque
            sdj = sd * risque * np.sqrt(n)
            p = 1.0 - phi(3.0 / sdj) if sdj > 0 else 0.0
            print("%9d %10.2f %12.2f %14.2f %13.2f %%" % (n, risque, expo, sdj, 100.0 * p))
    print()
    print("RENDEMENT ATTENDU si le mu tient : mu x n x 20 jours x risque")
    for n in (6, 9, 12):
        for risque in (0.20, 0.35):
            print("   %2d tx/jour a %.2f %% : %+.2f %% par mois (20 jours)" %
                  (n, risque, 100.0 * mu * n * 20 * (risque / 100.0)))


if __name__ == "__main__":
    main()