﻿import os,re
LOGD=r'C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs'
files=[(f,os.path.getmtime(os.path.join(LOGD,f)),os.path.getsize(os.path.join(LOGD,f))) for f in os.listdir(LOGD) if '.log' in f]
files.sort(key=lambda x:-x[1])
for f,m,s in files[:8]:
    p=os.path.join(LOGD,f)
    if s<500: continue
    raw=open(p,'rb').read(4)
    enc='utf-16' if raw[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8'
    try: txt=open(p,encoding=enc,errors='replace').read()
    except Exception: continue
    if 'ORION DIAG EURAUD' not in txt: continue
    tries = re.findall(r'ORION DIAG EURAUD : tries=(\d+)', txt)
    opens = txt.count('ORION OPEN EURAUD')
    rej   = txt.count('ORION REJET')
    print(f'--- {f} ---')
    print(f'  tries (DIAG)      : {tries[-1] if tries else \"?\"}')
    print(f'  ORION OPEN EURAUD : {opens}')
    print(f'  ORION REJET       : {rej}')
    break
