"""Re-lance le run ptrail 2024 et analyse la DISTRIBUTION des PnL.
Question : les +$8797 viennent-ils de 2-3 trades monstres (tail) ou d'une
distribution saine ? On parse le log du run 2024 avec les prix des deals."""
import sys, re
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner as m
from pathlib import Path

# 1) run 2024 seul (log frais)
r = m.run_backtest("USDJPY_M30_PTRAIL", "USDJPY", "M30", "2024.01.01", "2025.01.01", 10000)
print("run 2024:", r)

# 2) parser le log pour la distribution des PnL par position
CF = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3")
raw = (CF / "Tester" / "logs" / "20260823.log").read_text("utf-16", errors="replace")
lines = raw.splitlines()

# chaque position ptrail : entrée "market buy/sell VOL at PRICE" puis sortie
# "stop loss triggered #N ... at PRICE" ou trail. On reconstitue les paires.
# Format entrée :  deal #N buy VOL USDJPY at PRICE
# Format sortie SL : deal #M sell VOL USDJPY at PRICE (après "stop loss triggered")
entries = []   # (deal_no, dir, vol, price)
exits = []     # (deal_no, dir, vol, price)
for l in lines:
    me = re.search(r"deal #(\d+) (buy|sell) ([\d.]+) USDJPY at ([\d.]+) done", l)
    if me and "based on order" in l:
        entries.append((int(me.group(1)), me.group(2), float(me.group(3)), float(me.group(4))))
    mx = re.search(r"deal #(\d+) (buy|sell) ([\d.]+) USDJPY at ([\d.]+) done", l)
    if mx and "stop loss triggered" in l:
        exits.append((int(mx.group(1)), mx.group(2), float(mx.group(3)), float(mx.group(4))))

print(f"\nentrées: {len(entries)}, sorties SL: {len(exits)}")
# apparier par volume (même vol -> position)
# (approximation : les ptrail ajoutent des unités; on groupe par paire entrée/sortie de même volume)
import collections
pnls = []
used = set()
for e in entries:
    if e[0] in used:
        continue
    for x in exits:
        if x[0] in used:
            continue
        if abs(x[2] - e[2]) < 0.001:   # même volume
            # buy sorti par sell (SL) -> pnl = (sell_price - buy_price)*vol*100000
            # sell sorti par buy -> pnl = (buy... ) inversé
            if e[1] == "buy" and x[1] == "sell":
                pnl = (x[3] - e[3]) * e[2] * 100000
            elif e[1] == "sell" and x[1] == "buy":
                pnl = (e[3] - x[3]) * e[2] * 100000
            else:
                continue
            pnls.append(pnl)
            used.add(e[0]); used.add(x[0])
            break

pnls.sort(reverse=True)
print(f"positions appariées: {len(pnls)}")
if pnls:
    import numpy as np
    a = np.array(pnls)
    print(f"  total: {a.sum():+.0f} | moyenne: {a.mean():+.0f} | médiane: {np.median(a):+.0f}")
    print(f"  top5: {[round(x) for x in a[:5]]}")
    print(f"  top5 % du total: {100*a[:5].sum()/a.sum():.0f}%")
    print(f"  gagnants: {(a>0).sum()} ({100*(a>0).mean():.0f}%) | gros gagnants >1000: {(a>1000).sum()}")
    print(f"  perdants: {(a<0).sum()}")
