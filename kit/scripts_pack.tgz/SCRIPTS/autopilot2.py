# -*- coding: utf-8 -*-
"""autopilot2.py v3 — AUTOPILOT parallèle avec état (ne rejoue JAMAIS une
campagne déjà complétée en logfix).

v1 défaut : rotation fixe des 3 scripts → rejouait en boucle des campagnes
déjà finies → doublons append + mélange de logs (jsonl pollués).
v3 : registre d'état LOGS/autopilot_state.json : {script: {finie: bool,
ts_fin: ...}}. Ne lance un script que s'il n'est pas marqué fini. Les scripts
doivent eux-mêmes skip les runs déjà présents (checkpoint intégré) et écrire
en logfix (parse fix). Si une campagne échoue (rc != 0) → pas marquée finie,
retentée plus tard.

Farm (7072) JAMAIS touché. La rotation de log se fait dans le runner.
"""
import sys, time, json, subprocess, threading
import numpy as np
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from pathlib import Path

LOGDIR = Path(r"C:\EAFarm\HISTORY - Copy\research\LOGS")
OUT = LOGDIR / "autopilot2.jsonl"
STATE = LOGDIR / "autopilot_state.json"
CLOUD = Path(r"C:\EAFarm\HISTORY - Copy\research\CLOUD")
SCRIPTS = Path(r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")

def log(msg):
    with open(OUT, "a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": time.time(), "msg": msg}) + "\n")
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)

def load_state():
    if STATE.exists():
        try:
            return json.loads(STATE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}

def save_state(st):
    try:
        STATE.write_text(json.dumps(st, indent=1), encoding="utf-8")
    except Exception:
        pass

def terminals_test_running():
    """Vrai si un terminal de TEST (non-Farm) tourne."""
    try:
        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq terminal64.exe"],
                           capture_output=True, text=True)
        import re
        pids = re.findall(r"terminal64\.exe\s+(\d+)", r.stdout)
        return any(p != "7072" for p in pids)
    except Exception:
        return False

def research_loop(stop):
    """Boucle recherche : gen_exhaustive (systematique, sans doublons)."""
    p = CLOUD / "gen_exhaustive.py"
    while not stop.is_set():
        if p.exists():
            try:
                subprocess.run([sys.executable, str(p), "40"],
                               cwd=str(CLOUD), timeout=900,
                               stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL)
            except Exception:
                pass
        stop.wait(20)

def mt5_loop(stop):
    """Boucle MT5 : campagnes NON-finies quand le terminal est libre.
    Les campagnes pointent vers revalidate_fix.py (écrit en fix/ neufs) puis
    les scripts d'exploration dédiés — ajoutés ici au fil des découvertes."""
    st = load_state()
    # file de campagnes : (clé, script, [args]) — ne jamais rejouer une finie
    jobs = [
        ("revalidate_bilateral", SCRIPTS / "revalidate_fix.py", ["bilateral"]),
        ("revalidate_pack", SCRIPTS / "revalidate_fix.py", ["pack"]),
        ("revalidate_session713", SCRIPTS / "revalidate_fix.py", ["session713"]),
        ("opti713", SCRIPTS / "v45g_opti_713.py", []),
        ("combo712", SCRIPTS / "v45g_combo712.py", []),
    ]
    i = 0
    while not stop.is_set():
        # un job fini ? on le marque dans l'état
        for key, script, args in jobs:
            if st.get(key, {}).get("running"):
                log(f"MT5: {key} semble encore actif — attente")
                st[key]["running"] = False
                save_state(st)
        # trouver le prochain job non fini
        nxt = None
        for key, script, args in jobs:
            if not st.get(key, {}).get("finie"):
                nxt = (key, script, args)
                break
        if nxt is None:
            log("MT5: toutes les campagnes connues sont finies — recherche seule")
            stop.wait(600)
            continue
        key, script, args = nxt
        if terminals_test_running():
            stop.wait(90)
            continue
        log(f"MT5: lance {key} ({script.name} {args})")
        st[key] = {"running": True, "ts": time.time()}
        save_state(st)
        try:
            proc = subprocess.Popen([sys.executable, str(script)] + args,
                                    cwd=str(script.parent),
                                    stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL)
        except Exception as e:
            log(f"MT5: echec lancement {key}: {e}")
            st[key] = {"running": False, "error": str(e)}
            save_state(st)
            stop.wait(120)
            continue
        try:
            rc = proc.wait(timeout=3600)
        except subprocess.TimeoutExpired:
            log(f"MT5: {key} timeout 60min — kill PID {proc.pid}")
            proc.kill()
            st[key] = {"running": False, "timeout": True}
            save_state(st)
            # tuer le terminal de test par PID (jamais le Farm)
            try:
                r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq terminal64.exe"],
                                   capture_output=True, text=True)
                import re
                for p in re.findall(r"terminal64\.exe\s+(\d+)", r.stdout):
                    if p != "7072":
                        subprocess.run(["taskkill", "/F", "/PID", p],
                                       capture_output=True)
            except Exception:
                pass
            stop.wait(60)
            continue
        finie = (rc == 0)
        st[key] = {"finie": finie, "rc": rc, "ts_fin": time.time()}
        save_state(st)
        log(f"MT5: {key} termine rc={rc} {'FINIE' if finie else '(retentee plus tard)'}")
        stop.wait(30)

def farm_check_loop(stop):
    """Verifie le Farm toutes les 30 min."""
    while not stop.is_set():
        try:
            r = subprocess.run(["tasklist", "/FI", "PID eq 7072"],
                               capture_output=True, text=True)
            alive = "terminal64" in r.stdout
            log(f"farm alive: {alive}")
        except Exception:
            log("farm check error")
        stop.wait(1800)

def main():
    log("=== AUTOPILOT V3 DEMARRE (etat: ne rejoue jamais une campagne finie) ===")
    stop = threading.Event()
    t1 = threading.Thread(target=research_loop, args=(stop,), daemon=True)
    t2 = threading.Thread(target=mt5_loop, args=(stop,), daemon=True)
    t3 = threading.Thread(target=farm_check_loop, args=(stop,), daemon=True)
    t1.start(); t2.start(); t3.start()
    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        stop.set()
        log("AUTOPILOT V3 ARRETE")

if __name__ == "__main__":
    main()
