# -*- coding: utf-8 -*-
"""archive_r130.py — append REGISTRE round 130 + maj deploy doc."""
import os

REG = r"C:\EAFarm\SHARED\REGISTRE_MEILLEURES_STRATEGIES.md"
DEP = r"C:\MT5\DEPLOIEMENT_UPCOMERS.txt"

reg_blk = """
================================================================================
ROUND 130 - DEPLOY FINAL CORRIGE: toutes les equities RESCALEES au balance reel
des logs (autoritaire). Verif systematique parse-vs-reel par leg:
- EURGBP: parse +50.24 vs reel +24 (factor 0.472) -> CSV rescale. AUDUSD,
  NZDJPY, NZDUSD, EURUSD, GBPJPY, DOW, SPX, FRCEUR aussi ecarts 9-950% ->
  TOUTES rescalees au reel (matcher run par dates de trades, cov=1.00).
- VWAPF-XAU +4629$ reel / VWAPT-XAU +9738$ reel (parse surestimait/divergent)
- AUDIT RISQUE pire SL reel aux lots deploy d'avant: EURGBP 20 lots = SL moy
  13 pips ~ -2.9% par trade (pire -3.7%) = VIOLATION (kill -3% ne rattrape pas
  un SL). FRCEUR -2.0%, DOW -1.7%, SPX -1.6%, GBPUSD620 -1.7%, VWAPT pire
  queue -2.4% (SL 1.5xATR24h en forte vol) -> TOUS RE-CALIBRES ~1-1.2%.
- NOUVEAUX LOTS DEPLOY (presets Upcomers mis a jour): EURUSD 1.9 | GBPJPY 2.4
  | NZDJPY 1.1 | AUDUSD 2.3 | NZDUSD 2.4 | EURGBP 5.0 (etait 20!) | GBPUSD620
  1.1 | DOW 0.35 | SPX 1.1 | FRCEUR 1.2 | VWAPF-XAU 0.1 | VWAPT-XAU 0.06.
- SIM DEPLOY (equities reel, lots exacts, regles Upcomers daily -4%/floor -5%):
  sigma 0.91%/jour | mean +0.329%/jour | pire jour -1.4% | 0 jours kill |
  jamais de stop -5% | net 8 mois +28,495$ | ~+5.9%/mois.
  Pire SL single <= 1.5% (FRCEUR -710$ 1.42%, VWAPT -731$ 1.46% sur 50k).
  => deploy reel HONNETE et compatible regles prop (marge 2.5% sous le -4%
  firme meme avec 2-3 SL simultanes; kill EA -3% interne en 2e filet).
- CAVEAT: sample Upcomers = 8 mois 2026 uniquement; XAU VWAP SL vol-scale
  (1.5xATR24h) => en regime de vol extreme le $/SL monte (marge incluse).
================================================================================
"""
with open(REG, "ab") as f:
    f.write(reg_blk.encode("utf-8"))
print("REGISTRE round 130 appende", len(reg_blk))

dep_txt = """DEPLOIEMENT UPCOMERS (C:\\MT5) - 2026-09-07 v7 FINAL CORRIGE (round 130)
================================================
EAs a utiliser sur Upcomers: V3INT_EA (dossier MQL5\\Experts\\UPCOMERS) +
VWAPFADE_EA / VWAPTREND_EA (XAU H1). V45G/RVWAP/V3 = DUKASCOPY ONLY.

LOTS DEPLOY FINAUX (presets a jour, risque ~1-1.2%/trade, pire SL <=1.5%):
  V3INT_EA/EURUSD_H1.set              1.9    (15t, 6-20 UTC)
  V3INT_EA/GBPJPY_H1.set              2.4    (8t, 6-20)
  V3INT_EA/NZDJPY_H1.set              1.1    (9t, 6-20)
  V3INT_EA/AUDUSD_H1.set              2.3    (8t, 8-17)
  V3INT_EA/NZDUSD_H1.set              2.4    (7t, 8-17)
  V3INT_EA/EURGBP_H1.set              5.0    (15t, 6-20)  <- ETAIT 20 (trop!)
  V3INT_EA/GBPUSD_H1.set              1.1    (24t c055, 6-20)
  V3INT_EA/DJCUSD_H1_INDICE_DOW.set   0.35   (16t, 8-17)
  V3INT_EA/SPCUSD_H1_INDICE_SPX.set   1.1    (18t, 8-17)
  V3INT_EA/FRCEUR_H1_INDICE_FR40.set  1.2    (9t, 8-17)
  VWAPFADE_EA/XAUUSD_H1.set           0.10   (110t win24, 7-20 close-20)
  VWAPTREND_EA/XAUUSD_H1.set          0.06   (128t win24, 7-20 close-20)
Magics: EURUSD 713101 | GBPJPY 713601 | NZDJPY 713401 | AUDUSD 714402 |
NZDUSD 714401 | EURGBP 713301 | GBPUSD620 713501 | DOW 715503 | SPX 715502 |
FR40 715504 | XAU-FADE 718202 | XAU-TREND 718401. 1 magic/chart, tout H1.

VERIF DEPLOY (equities RESCALEES au balance reel des logs, round 130):
sigma 0.91%/jour | mean +0.33%/jour | pire jour -1.4% (8 mois) | 0 kill -4%
| jamais de stop -5% | ~+5.9%/mois sim | net +28.5k/8 mois.
Pire SL single ~1.0-1.5% par trade => jamais de breach firme -4% meme avec
2-3 SL simultanes; kill EA -3% interne = 2e filet. CE DEPLOY EST REGLE-COMPATIBLE
(le ~10%/mois des sims @30%vol = sizing 3%/trade NON deployable reel).

RAPPELS:
- Sessions deploy: EURUSD/GBPJPY/NZDJPY/EURGBP/GBPUSD620 6-20 UTC;
  AUDUSD/NZDUSD/DOW/SPX/FR40 8-17; XAU VWAP 7-20 (flat 20:00 = 0 swap).
- XAU VWAP SL = 1.5xATR(24h): en vol extreme le $/SL monte (deja calibre).
- Sample Upcomers = 2026 seulement (8 mois). Watchlist crosses (n petit):
  EURJPY/AUDCAD/NZDCHF. USATECH.IDX Dukascopy en attente donnees.
"""
with open(DEP, "w", encoding="utf-8") as f:
    f.write(dep_txt)
print("DEPLOIEMENT_UPCOMERS.txt mis a jour", len(dep_txt))
