# -*- coding: utf-8 -*-
"""debug_rej.py — compter touches vs rejets pour trouver le bug."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import c13v2_py_fast2 as F
import numpy as np
import pandas as pd

sym = "EURUSD"; year = 2024
m1 = F.load_m1(sym)
start = pd.Timestamp(f"{year}-01-01", tz="UTC")
end = pd.Timestamp(f"{year + 1}-01-01", tz="UTC")
wu = start - pd.Timedelta(days=260)
m5 = F.resample(m1.loc[wu:end], "5min").loc[start:end]
m15 = F.resample(m1.loc[wu:end], "15min")

o = m15["open"].to_numpy(); h = m15["high"].to_numpy()
l = m15["low"].to_numpy(); c = m15["close"].to_numpy()
n = len(m15)
a15 = F.atr_s(m15, 14).to_numpy()

# OB bull bruts (params boss)
ob_b = []
for jj in range(n):
    if not np.isfinite(a15[jj]) or a15[jj] <= 0: continue
    thr = a15[jj] * 0.9
    if c[jj] < o[jj]:
        for k in range(1, 7):
            kk = jj + k
            if kk >= n: break
            if c[kk] > o[kk] and abs(c[kk]-o[kk]) >= thr and c[kk] > h[jj]:
                ob_b.append(jj); break
print(f"OB bull: {len(ob_b)}")

# touches M5 (h>=zl & l<=zh) en comptant la propagation honnete
zb = {}
for jj in ob_b:
    zb[jj] = (l[jj], o[jj])
m15_t = m15.index.values.astype("datetime64[ns]")
m5_t = m5.index.values.astype("datetime64[ns]")
idx15 = np.clip(np.searchsorted(m15_t, m5_t, side="right") - 1, 0, n-1)
o5 = m5["open"].to_numpy(); h5 = m5["high"].to_numpy()
l5 = m5["low"].to_numpy(); c5 = m5["close"].to_numpy()
v5 = m5["volume"].to_numpy()
av5 = pd.Series(v5).rolling(50).mean().to_numpy()
body5 = np.abs(c5 - o5)
pip = 0.0001

n_touch = 0
n_rej = 0
n_rej_vol = 0
for i in range(len(m5)):
    i15 = idx15[i]
    # dernier OB bull dispo (dispo = jj+kk <= i15)
    last = None
    for jj in ob_b:
        if jj >= i15: break
        # chercher la dispo (kk minimal qui confirme)
        thr = a15[jj] * 0.9
        for k in range(1, 7):
            kk = jj + k
            if kk >= n: break
            if c[kk] > o[kk] and abs(c[kk]-o[kk]) >= thr and c[kk] > h[jj]:
                if kk <= i15:
                    last = jj
                break
    if last is None:
        continue
    zl, zh = l[last], o[last]
    zoneH = max(zh - zl, pip*0.5)
    touch = (h5[i] >= zl) and (l5[i] <= zh)
    if not touch:
        continue
    n_touch += 1
    lowerW = min(o5[i], c5[i]) - l5[i]
    inzone = (l5[i] <= zh) and (c5[i] >= zl + zoneH*0.15) and (c5[i] <= zh)
    bullc = c5[i] > o5[i]
    wick = body5[i] > 0 and (lowerW/body5[i]) >= 1.0
    if inzone and bullc and wick:
        n_rej += 1
        if not np.isfinite(av5[i]) or v5[i] >= av5[i]*1.0:
            n_rej_vol += 1
print(f"touches M5: {n_touch} | rejets (inzone+bull+wick): {n_rej} | +vol: {n_rej_vol}")
