# -*- coding: utf-8 -*-
"""patcher2_classif_m5.py -- version 2 du classificateur (10/13 19 h).

Corrections demandees par le diagnostic du premier passage :
  1. CASCADE EXCLUSIVE avec priorite decroissante, le defaut RANGE_ETABLI
     ne doit plus absorber 86 % : EXPANSION_VIVE -> COMPRESS_SECHE ->
     TREND_FINISSANT -> TREND_NAISSANT -> TREND_CROISSANT -> RANGE_MOURE
     -> RANGE_ETABLI (residu cible 45-65 %).
  2. EXPANSION_VIVE : |z| >= 1.5 (au lieu de 2.0) OU corps M5 extreme.
  3. VWAP comme 8e confirmateur (demande explicite de l'utilisateur) :
     distance standardisee au VWAP du JOUR (recalcule chaque jour a 00h
     serveur). Pres de VWAP = trading de valeur (range) ; loin = trend
     ou extension. Deux mesures : d_vwap (en ATR) et sa pente.
  4. Les sous-etats sont calcules en M30 PUIS croises avec l'etat M5
     (vote majoritaire) : le mot final du dictionnaire = M30 x M5.
"""
import os
import sys

import numpy as np
import pandas as pd

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parent))
import nuit_motifs as NM
from classif_m5 import charge_m5, er, adx_like, z_prix, pentes

ER_SEUIL = 0.30
ATR_LO, ATR_HI = 0.30, 0.70
ADX_MIN = 15.0
Z_VIVE = 1.5
SERR_PENTE = -0.02
VWAP_FAR = 2.0          # distance au VWAP journalier, en ATR M30

SSE = ["EXPANSION_VIVE", "COMPRESS_SECHE", "TREND_FINISSANT",
       "TREND_NAISSANT", "TREND_CROISSANT", "RANGE_MOURE", "RANGE_ETABLI"]


def vwap_jour(idx, c, h, l):
    """VWAP du jour (ancrage 00h serveur) + distance en ATR."""
    jour = idx.date
    tp = (h + l + c) / 3.0
    vwap = np.full(len(c), np.nan)
    acc_tp = 0.0
    cnt = 0
    cur = None
    for i in range(len(c)):
        d = jour[i]
        if d != cur:
            cur = d
            acc_tp = 0.0
            cnt = 0
        acc_tp += tp[i]
        cnt += 1
        vwap[i] = acc_tp / cnt
    return vwap


def etats(D, vwap_on=True):
    c, h, l, a = D["c"], D["h"], D["l"], D["a"]
    e = er(c, 64)
    e_p = pentes(e, 8)
    atr_p = pd.Series(a).rolling(1000).rank(pct=True).values
    atr_pente = pentes(atr_p, 12)
    adx, pdi, mdi = adx_like(D)
    rsi = NM.rsi(c, 14)
    rsi_ext = np.abs(rsi - 50.0) > 25.0
    dw = (pd.Series(h).rolling(50).max().values
          - pd.Series(l).rolling(50).min().values) / a
    dw_p = pentes(dw, 12)
    z = z_prix(D)
    vwap = vwap_jour(D["idx"], c, h, l) if vwap_on else None
    d_vwap = (c - vwap) / a if vwap_on else np.zeros(len(c))

    n = len(c)
    tendance = np.nan_to_num(e) > ER_SEUIL
    lab = np.empty(n, dtype=object)
    lab[:] = ""

    # 1. EXPANSION_VIVE : ATR haut ET (surprise OU corps franc)
    vive = (np.nan_to_num(atr_p) > ATR_HI) & \
        ((np.abs(np.nan_to_num(z)) >= Z_VIVE) |
         (np.nan_to_num(np.abs(d_vwap)) >= VWAP_FAR))
    lab = np.where(vive, "EXPANSION_VIVE", lab)

    # 2. COMPRESS_SECHE : ATR bas ET largeur qui se resserre
    lab = np.where((lab == "") & (np.nan_to_num(atr_p) < ATR_LO) &
                   (np.nan_to_num(dw_p) < SERR_PENTE), "COMPRESS_SECHE", lab)

    # 3-5. tendance : ER + pente ER + ADX
    finissant = tendance & ((np.nan_to_num(e_p) < -0.02) |
                            (rsi_ext & (np.nan_to_num(e_p) < 0)))
    naissant = tendance & ~finissant & (np.nan_to_num(e_p) > 0.02) & \
        (np.nan_to_num(adx) > ADX_MIN)
    croissant = tendance & (lab == "") & ~naissant & ~finissant
    lab = np.where((lab == "") & finissant, "TREND_FINISSANT", lab)
    lab = np.where((lab == "") & naissant, "TREND_NAISSANT", lab)
    lab = np.where((lab == "") & croissant, "TREND_CROISSANT", lab)

    # 6-7. range : mouve (cassure recente) sinon etabli
    sur = (h > pd.Series(h).rolling(50).max().values) | \
        (l < pd.Series(l).rolling(50).min().values)
    moure = np.roll(np.nan_to_num(sur).astype(float), 1).astype(bool)
    lab = np.where((lab == "") & moure, "RANGE_MOURE", lab)
    lab = np.where(lab == "", "RANGE_ETABLI", lab)
    return lab, dict(e=e, atr_p=atr_p, adx=adx, rsi=rsi, z=z, d_vwap=d_vwap)


def main():
    print("SOUS-ETATS v2 — cascade exclusive + VWAP | ER>%.2f ADX>%.0f "
          "|z|>%.1f |d_vwap|>%.1f" % (ER_SEUIL, ADX_MIN, Z_VIVE, VWAP_FAR))
    for trame, fn in (("M30", lambda p: NM.charge(p, "m1_pos")),
                      ("M5", charge_m5)):
        agg = {}
        for p in ("EURUSD", "GBPUSD", "USDCHF", "AUDUSD", "NZDUSD",
                  "EURJPY", "XAUUSD"):
            D = fn(p)
            if D is None:
                continue
            lab, met = etats(D)
            rep = {k: 100.0 * float(np.mean(lab == k)) for k in SSE}
            agg[p] = rep
            print("  [%s] %-8s %s" % (trame, p, "  ".join(
                "%s %4.1f" % (k.replace("TREND_", "T_").replace("_", "")[:9], x)
                for k, x in rep.items())))
        if agg:
            print("  [%s] MOYENNE :" % trame)
            for k in SSE:
                print("      %-16s %5.1f%%" % (k, float(np.mean(
                    [r.get(k, 0.0) for r in agg.values()]))))


if __name__ == "__main__":
    main()
