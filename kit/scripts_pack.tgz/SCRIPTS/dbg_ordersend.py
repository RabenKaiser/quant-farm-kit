﻿"""Capture order_send retcode directly for USDJPY inside ST5."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import logging
from datetime import datetime
from pathlib import Path

import MetaTrader5 as mt5
from strategytester5.MetaTrader5.api import VirtualMetaTrader5
from strategytester5.tester import run_backtesting

TERM = r"C:\EAFarm\MT5\Farm\terminal64.exe"
ST5DATA = r"C:\EAFarm\HISTORY - Copy\research\st5data"
RESEARCH = Path(r"C:\EAFarm\HISTORY - Copy\research")
SYMBOL = "USDJPY"
SEEN = {}

def main():
    tick = VM.symbol_info_tick(SYMBOL)
    if tick is None:
        return
    t = tick.time
    key = t // 3600
    if key in SEEN:
        return
    SEEN[key] = 1
    # only test a few times
    if len(SEEN) > 5:
        return
    price = tick.ask
    sl = price - 3.0 * 0.5
    tp = price + 2.0 * 3.0 * 0.5
    request = {
        "action": VM.TRADE_ACTION_DEAL,
        "symbol": SYMBOL,
        "volume": 0.1,
        "type": VM.ORDER_TYPE_BUY,
        "price": price,
        "deviation": 100,
        "magic": 20263,
        "comment": "dbg",
        "type_time": VM.ORDER_TIME_GTC,
        "type_filling": 1,
        "sl": sl,
        "tp": tp,
    }
    res = VM.order_send(request)
    print(f"  t={t} buy @{price:.3f} sl={sl:.3f} tp={tp:.3f} -> retcode={res.retcode if res else None}", flush=True)

if __name__ == "__main__":
    if not mt5.initialize(path=TERM):
        raise RuntimeError(f"init failed: {mt5.last_error()}")
    VM = VirtualMetaTrader5(parent_mt5=mt5, custom_broker_data_path=ST5DATA)
    VM.history_manager.synchronize_all_timeframes = lambda *a, **k: None
    VM.history_manager.synchronize_bars = lambda *a, **k: None
    VM.history_manager.synchronize_ticks = lambda *a, **k: None
    cfg = {
        "bot_name": "dbg_usdjpy",
        "symbols": [SYMBOL],
        "timeframe": "H1",
        "start_date": "01.01.2022",
        "end_date": "15.01.2022",
        "modelling": "1 minute OHLC",
        "deposit": 10000,
        "leverage": "1:100",
    }
    run_backtesting(main_function=main, tester_config=cfg, virtual_mt5=VM,
                    logging_level=logging.ERROR, logs_dir=str(RESEARCH / "st5_logs"),
                    trading_history_dir=str(RESEARCH / "st5_trades"),
                    is_optimization_mode=True)
    mt5.shutdown()
