"""analyse_manques.py -- OU SONT LES TROUS DU PANIER ?

Le panier verifie tient 7 jambes sur 36 marches du pool : les 29 autres marches n'ont
AUCUNE jambe. Ce script dit, pour chaque marche sans jambe, quelle campagne est la plus
proche d'y entrer (positive dans les deux moities), et lesquelles echouent de peu. C'est
la carte de chasse du prochain criblage -- et elle ne depend pas du courtier, donc elle
reste utilisable meme quand la ferme de burst est bloquee.

Usage : python analyse_manques.py [chemin/SPLIT_HALF.json]
"""
import json
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
CHEMIN = Path(sys.argv[1]) if len(sys.argv) > 1 else (BASE / "vast_resultats" / "SPLIT_HALF.json")

if not CHEMIN.exists():
    print("registre absent :", CHEMIN)
    sys.exit(1)

d = json.loads(CHEMIN.read_text(encoding="utf-8"))
print("campagnes evaluees :", len(d))

# marches deja servis par une jambe qui passe
servis = {}
for nom, v in d.items():
    if v.get("passe"):
        servis.setdefault(v["sym"], []).append((nom, v))

print("\n=== MARCHES SERVIS (%d) ===" % len(servis))
for sym, jambes in sorted(servis.items()):
    meilleure = max(jambes, key=lambda x: x[1]["mu"])
    print("  %-14s %-28s n=%4d mu=%+.4f" % (sym, meilleure[0], meilleure[1]["n"], meilleure[1]["mu"]))

# marches avec des campagnes evaluees mais aucune jambe qui passe
print("\n=== MARCHES SANS JAMBE : LA MEILLEURE CANDIDATE ===")
par_marche = {}
for nom, v in d.items():
    if v.get("passe"):
        continue
    par_marche.setdefault(v["sym"], []).append((nom, v))

lignes = []
for sym, camps in par_marche.items():
    # on classe par : deux moities positives d'abord, puis mu
    def cle(x):
        v = x[1]
        deux = 1 if (v.get("h1", 0) > 0 and v.get("h2", 0) > 0) else 0
        return (deux, v.get("mu", -9))
    nom, v = max(camps, key=cle)
    deux = "DEUX" if (v.get("h1", 0) > 0 and v.get("h2", 0) > 0) else "    "
    lignes.append((v.get("mu", -9), sym, nom, v, deux))

lignes.sort(reverse=True)
for mu, sym, nom, v, deux in lignes[:20]:
    print("  %-14s %-30s n=%4d mu=%+.4f  moities %+.4f / %+.4f  %s" % (
        sym, nom[:30], v.get("n", 0), v.get("mu", 0), v.get("h1", 0), v.get("h2", 0), deux))

print("\n=== RESUME ===")
print("  marches du pool avec une jambe :", len(servis))
print("  marches cribles sans jambe    :", len(par_marche))
deux_pos = sum(1 for _, _, _, v, deux in lignes if deux == "DEUX")
print("  candidats positifs dans les DEUX moities (a confirmer) :", deux_pos)
