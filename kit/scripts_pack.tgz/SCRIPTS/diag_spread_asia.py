# -*- coding: utf-8 -*-
"""diag_spread_asia.py — LE SPREAD A L'OUVERTURE ASIATIQUE EXPLIQUE-T-IL TOUT ?

INDICE FORT
-----------
Sur CADJPY, les 10 premieres entrees MT5 se font a 00:10:00 et 00:15:00
(heure serveur) et les sorties arrivent 40 s a 56 min plus tard, TOUTES par
stop loss. Une sortie 40 SECONDES apres une entree sur un SL place a 2 ATR
est impossible en marche calme : 2 ATR sur CADJPY valent ~0.085, soit 85
points. Il faudrait un mouvement violent instantane.

L'EXPLICATION PROBABLE : LE SPREAD.
L'EA achete a l'ASK. Le SL est pose sous l'ASK, mais il se declenche quand le
BID passe dessous. L'ecart bid/ask est donc franchi INSTANTANEMENT a l'entree :
le SL n'est reellement qu'a (2 ATR - spread) du prix de sortie.

A 00:10 (ouverture asiatique, liquidite minimale) le spread CADJPY peut
exploser : 5, 10, 20 points ou plus, contre 1-2 en seance. Si le spread vaut
10 points et le SL 85 points, on perd immediatement 12 % de la marge — et si
le spread vaut 40-80 points, le SL est touche a la seconde.

CE QUE L'EA DEVRAIT FAIRE
-------------------------
Elle a deja un filtre InpMaxSpreadMult=2.5, mais il compare le spread a sa
MEDIANE (SpreadMedian). A l'ouverture asiatique, la mediane elle-meme est
haute, donc le filtre ne bloque rien : le ratio spread/mediane reste proche
de 1.

CE SCRIPT MESURE
----------------
1. La distribution du spread CADJPY par heure (fichier M1 Dukascopy : colonne
   'spread' si presente).
2. Le taux de SL si l'on ajoute un cout de spread REALISTE a l'entree selon
   l'heure, au lieu d'un spread constant.
3. Combien de trades MT5 tombent dans les heures a spread large.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
SYM = "CADJPY"

p = BASE / "m1_pos" / f"{SYM}_M1.csv"
head = pd.read_csv(p, nrows=3)
print(f"colonnes de {p.name} : {list(head.columns)}")
has_spread = "spread" in head.columns

df = pd.read_csv(p)
df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
df = df.set_index("time").sort_index()

if not has_spread:
    print()
    print("PAS de colonne 'spread' dans le M1 Dukascopy.")
    print("-> on mesure l'effet par l'ECART HIGH-LOW immediat a l'entree,")
    print("   qui majore le cout d'execution reel.")

    m5 = pd.DataFrame({
        "open": df["open"].resample("5min").first(),
        "high": df["high"].resample("5min").max(),
        "low": df["low"].resample("5min").min(),
        "close": df["close"].resample("5min").last()}).dropna()

    h = m5["high"].to_numpy(float); l = m5["low"].to_numpy(float)
    c = m5["close"].to_numpy(float); o = m5["open"].to_numpy(float)
    pc = np.roll(c, 1); pc[0] = c[0]
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    atr = pd.Series(tr).ewm(alpha=1/14, adjust=False).mean().to_numpy()
    sig = h < (np.roll(l, 2) - 1.0 * atr)
    sig[:5] = False

    # spread proxy : amplitude de la barre de signal en fraction d'ATR
    amp = (h - l)
    hours = m5.index.hour.to_numpy()

    print()
    print("=" * 88)
    print("AMPLITUDE DE LA BARRE DE SIGNAL PAR HEURE (proxy du spread)")
    print("=" * 88)
    print(f"{'heure':>6}{'n signaux':>11}{'amp moy':>10}{'amp/ATR':>10}"
          f"{'SL%':>7}{'TP%':>7}{'R tot':>9}")
    print("-" * 88)
    idx = np.where(sig)[0]
    N = len(c)
    for hh in range(24):
        sub = [i for i in idx if hours[i] == hh]
        if len(sub) < 30:
            continue
        # simulation avec cet echantillon seulement
        last = -1
        rets = []; nsl = ntp = 0
        for i in sub:
            if i <= last or i + 2 >= N:
                continue
            e = i + 1
            a = atr[i]
            if not np.isfinite(a) or a <= 0:
                continue
            entry = o[e]; risk = 2.0 * a
            sl = entry - risk; tp = entry + 3.0 * risk
            got = None
            for k in range(e, min(e + 48, N)):
                if l[k] <= sl:
                    got = -1.0; nsl += 1; last = k; break
                if h[k] >= tp:
                    got = 3.0; ntp += 1; last = k; break
            if got is None:
                k = min(e + 48 - 1, N - 1)
                got = (c[k] - entry) / risk; last = k
            rets.append(got)
        if not rets:
            continue
        x = np.array(rets)
        am = np.mean([amp[i] for i in sub])
        aa = np.mean([amp[i] / atr[i] for i in sub])
        print(f"{hh:>6}{len(sub):>11}{am:>10.4f}{aa:>10.2f}"
              f"{100*nsl/len(rets):>6.0f}%{100*ntp/len(rets):>6.0f}%{x.sum():>9.0f}")

    print()
    print("=" * 88)
    print("HEURES DES ENTREES MT5 OBSERVEES (repartition)")
    print("=" * 88)
    print("  (mesure precedente : 0h=14, 1h=8, 2h=7, 5h=3, 6h=5, 7h=10, 8h=9,")
    print("   12h=6, 13h=7, 14h=3, 15h=2, 18h=3, 19h=7, 20h=10, 21h=18,")
    print("   22h=9, 23h=22)")
    print()
    print("  Les entrees sont CONCENTREES sur 20h-02h et 21h-23h, c'est-a-dire")
    print("  exactement l'ouverture/fermeture asiatique et le rollover, ou le")
    print("  spread est le plus large.")
