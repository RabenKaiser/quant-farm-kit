# -*- coding: utf-8 -*-
"""agg_r52.py — agrege v3int_farm_multiyear_r52.jsonl: tableau paire x fenetre
(profit reel, n, pf parse) + verdict durabilite (nb fenetres positives)."""
import json, sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

P = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\v3int_farm_multiyear_r52.jsonl"
WINS = [("2017-2019", 0), ("2019-2021", 1), ("2021-2023", 2),
        ("2023-2025", 3), ("2025-2026", 4), ("2026", 5)]
rows = {}
order = []
with open(P, encoding="utf-8") as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        o = json.loads(line)
        sym = o["sym"]
        tag = f"{o['from'][:4]}-{o['to'][:4]}"
        wlab = tag
        rows.setdefault(sym, {})[wlab] = o["r"]
        if sym not in order:
            order.append(sym)

hdr = "paire      | " + " | ".join(w[0].ljust(10) for w in WINS) + " | pos"
print(hdr)
print("-" * len(hdr))
for sym in order:
    cells = []
    pos = 0
    for wlab, _ in WINS:
        # matcher les labels possibles
        key = None
        for k in rows[sym]:
            if k.startswith(wlab[:4]) or (wlab == "2025-2026" and k == "2025-2026"):
                key = k
        r = rows[sym].get(key) if key else rows[sym].get(wlab)
        if r is None:
            cells.append("--".ljust(10))
            continue
        p = r.get("profit")
        n = r.get("trades")
        if p is None:
            cells.append("null".ljust(10))
            continue
        try:
            p = float(p)
        except Exception:
            cells.append("err".ljust(10))
            continue
        if p > 0:
            pos += 1
        cells.append(f"{p:+.0f}/{n}".ljust(10))
    print(f"{sym:12s} | " + " | ".join(cells) + f" | {pos}/{len(WINS)}")
print("FIN")
