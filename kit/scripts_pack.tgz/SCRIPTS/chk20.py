﻿import os, sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G
POS = G.POS
for s in ("AUDUSD","USDCAD","XAUUSD","NZDUSD","AUDCAD"):
    p = POS / f"{s}_M1.csv"
    src = G.MK.get(s, ("?",))[0]
    print(f"  {s:<8} fichier POS: {'oui' if p.exists() else 'non':<4} "
          f"taille={p.stat().st_size/1e6 if p.exists() else 0:6.1f} Mo | "
          f"source MK = {src}")
print()
print("=> ces symboles sont declares 'duka' dans MK. Leur version POS existe")
print("   desormais sur disque mais n'est PAS utilisee : pas de collision.")
print("   Elle peut servir de CONTROLE : comparer duka vs pos sur la meme paire.")
