# -*- coding: utf-8 -*-
"""diag_tp_unit.py — bug n58 : PYTHON INTERPRETAIT LE TP EN ATR, PAS EN R.

LA DECOUVERTE
-------------
sl_tp_sweep.py, ligne 62 :
    entry = o[e]; sl = entry - sl_atr * a; tp = entry + tp_atr * a

Le second parametre s'appelle `tp_atr` et il est multiplie par l'ATR. Donc la
grille SYS_TP = [1.5, 3.0, 5.0, 10.0, 20.0] etait lue comme des MULTIPLES
D'ATR, alors que tout le reste du projet (et l'EA, et les tables CSV) la lit
comme des MULTIPLES DE R.

Consequence pour le reglage retenu (sl_atr=2.0, tp_atr=3.0) :
    SL = 2.0 ATR  -> 1 R = 2.0 ATR
    TP = 3.0 ATR  = 1.5 R          <-- PAS 3 R !
Et le sweep enregistrait `r = tp_atr = 3.0` pour un gain qui ne valait que 1.5 R.
Le taux de reussite eleve (51 %) venait donc d'un TP PROCHE, pas d'un vrai 1:3.

CE SCRIPT
---------
Compare, sur les vraies bougies, quatre variantes :
  A. ce que le sweep a REELLEMENT simule : SL 2 ATR, TP 3 ATR, hold 48
     -> et en corrigeant le R enregistre (1.5 au lieu de 3.0)
  B. ce que l'EA a fait AVANT le fix n56 : SL 2 ATR_M15, TP 3R (=6 ATR_M15)
  C. ce que l'EA fait APRES le fix n56 : SL 2 ATR_M5, TP 3R (=6 ATR_M5)
  D. la variante honnete : SL 2 ATR_M5, TP 3 ATR_M5, hold 48 (ratio 1:1.5)

Le but : savoir quel reglage est REELLEMENT le meilleur une fois les unites
alignees, au lieu de se fier a une grille mal etiquetee.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
PORT = json.load(open(BASE / "portfolio_v2.json", encoding="utf-8"))


def m5(sym):
    p = BASE / "m1_pos" / f"{sym}_M1.csv"
    if not p.exists():
        return None
    df = pd.read_csv(p, usecols=["time", "open", "high", "low", "close"])
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time").sort_index()
    return pd.DataFrame({
        "open": df["open"].resample("5min").first(),
        "high": df["high"].resample("5min").max(),
        "low": df["low"].resample("5min").min(),
        "close": df["close"].resample("5min").last()}).dropna()


def atr_series(h, l, c, n=14):
    pc = np.roll(c, 1); pc[0] = c[0]
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    return pd.Series(tr).ewm(alpha=1/n, adjust=False).mean().to_numpy()


def bt(df, mask, sl_atr_mult, tp_atr_mult, hold, atr):
    """SL = sl_atr_mult x ATR ; TP = tp_atr_mult x ATR.

    Les deux sont en MULTIPLES D'ATR : c'est exactement ce que sl_tp_sweep.py
    fait. Le R d'un gain vaut donc tp_atr_mult / sl_atr_mult.
    """
    h = df["high"].to_numpy(float); l = df["low"].to_numpy(float)
    o = df["open"].to_numpy(float); c = df["close"].to_numpy(float)
    N = len(c)
    rets = []; last = -1
    for i in np.where(mask)[0]:
        if i <= last or i + 2 >= N:
            continue
        e = i + 1
        a = atr[i]
        if not np.isfinite(a) or a <= 0:
            continue
        entry = o[e]
        sl = entry - sl_atr_mult * a
        tp = entry + tp_atr_mult * a
        R_unit = sl_atr_mult * a          # 1 R en unite de prix
        r = None
        for k in range(e, min(e + hold, N)):
            if l[k] <= sl:
                r = -1.0; last = k; break          # un SL coute TOUJOURS -1 R
            if h[k] >= tp:
                r = tp_atr_mult / sl_atr_mult; last = k; break
        if r is None:
            k = min(e + hold - 1, N - 1)
            r = (c[k] - entry) / R_unit; last = k
        rets.append(r)
    return np.array(rets) if rets else np.array([])


CONFIGS = [
    ("A. sweep REEL  SL2/TP3 ATR", 2.0, 3.0, 48, "duka"),
    ("B. EA avant n56 (M15 2x)",   3.9, 11.7, 48, "duka"),
    ("C. EA apres n56 (M5 2R->6)", 2.0, 6.0, 48, "duka"),
    ("D. honest 1:1.5 (SL2/TP3 R)", 2.0, 3.0, 48, "duka"),
]

print("=" * 96)
print("BUG n58 — LE TP DU SWEEP ETAIT EN ATR, PAS EN R")
print("=" * 96)
print()
print("Config A : TP = 3.0 x ATR = 1.5 R  (ce que le sweep a VRAIMENT simule)")
print("Config B : TP = 3R d'un stop M15   (ce que l'EA faisait avant n56)")
print("Config C : TP = 3R d'un stop M5    (ce que l'EA fait apres n56)")
print("Config D : TP = 3 x ATR = 1.5 R, identique a A (verification)")
print()

rows = {}
for name, slm, tpm, hold, src in CONFIGS:
    tot_n = 0; tot_R = 0.0; wins = 0; nsl = 0; ntp = 0
    for sym in sorted(PORT):
        d = m5(sym)
        if d is None or len(d) < 5000:
            continue
        h = d["high"].to_numpy(float); l = d["low"].to_numpy(float)
        c = d["close"].to_numpy(float)
        a = atr_series(h, l, c)
        sig = h < (np.roll(l, 2) - 1.0 * a)
        sig[:5] = False
        if sig.sum() < 50:
            continue
        x = bt(d, sig, slm, tpm, hold, a)
        if len(x) == 0:
            continue
        tot_n += len(x); tot_R += x.sum(); wins += int((x > 0).sum())
    rows[name] = (tot_n, tot_R, 100*wins/max(1, tot_n))
    print(f"{name:<30} n={tot_n:>7}  R total={tot_R:>9.0f}  "
          f"win={100*wins/max(1,tot_n):>5.1f}%  R/trade={tot_R/max(1,tot_n):>6.3f}")

print()
print("=" * 96)
print("LECTURE")
print("=" * 96)
print("  Le classement REELLEMENT mesure (toutes unites alignees) :")
rk = sorted(rows.items(), key=lambda kv: -kv[1][1])
for i, (k, v) in enumerate(rk, 1):
    print(f"    {i}. {k:<30} R total = {v[1]:>8.0f}   win {v[2]:>5.1f}%")
print()
print("  -> Le sweep avait classe SL=2/TP=3/h48 premier avec 51 % de reussite.")
print("     Avec TP reellement a 3 x ATR (=1.5 R), c'est coherent :")
print("     un TP plus proche touche plus souvent.")
print()
print("  -> L'EA, lui, place un VRAI 3R. Ce n'est PAS le meme trade que la")
print("     config A. Comparer les deux etait l'erreur de fond.")
