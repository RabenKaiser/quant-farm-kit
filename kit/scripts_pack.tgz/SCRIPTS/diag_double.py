# -*- coding: utf-8 -*-
"""diag_double.py — diagnostic: combien d OB uniques vs re-entre sur le meme."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import sweep_py_r205 as SW
import c13v2_engine as ENG

BASE = {"imp_atr": 0.9, "imp_vol": 1.0, "imp_look": 6, "ob_age": 16,
        "rej_wick": 0.8, "rej_vol": 1.0, "close_zone": 0.15, "tp_r": 2.0,
        "bias": "vwap", "excl_hours": [6, 7, 12, 15, 19, 23],
        "min_stop": 0.00025, "buf_atr": 0.25, "lookahead": False}
m5, m15, h4 = SW.prep_frames("EURUSD", 2024)
# compte signaux uniques OB
sig, idx15 = ENG.detect_signals(m5, m15, dict(BASE))
ob_set = set(s[3] for s in sig.values())
print(f"signaux: {len(sig)} | OB distincts: {len(ob_set)}")
# n r205
r_ref = SW.bt(m5, m15, h4, dict(BASE))
print(f"r205 n: {r_ref['n']}")
# verifier si le pb vient de atr5 vs atr15 pour SL (pas le n)
# -> le n double vient de la detection: r205 detecte dans sa BOUCLE de sim
# les signaux AU MOMENT (i15 courant), engine les pre-calcule pour TOUS i.
# Si r205 re-calcule lastB/LS A CHAQUE i (dynamique) et engine pre-calcule
# fige -> difference.
print("NB: r205 calcule signaux dynamiquement dans sa sim; engine les");
print("    pre-calcule pour TOUS les i d un coup. Si la boucle r205 ne");
print("    marque pas used, elle re-entre AUSSI -> differente logique.")
