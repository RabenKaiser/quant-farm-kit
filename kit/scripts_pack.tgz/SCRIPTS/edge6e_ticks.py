# -*- coding: utf-8 -*-
"""EDGE_6E en vrais ticks Dukascopy par année — le candidat short complémentaire."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_duka as d

for y0, y1 in [("2023.01.01", "2024.01.01"), ("2024.01.01", "2025.01.01"),
               ("2025.01.01", "2026.01.01")]:
    r = d.run_backtest("EDGE_6E", "EURUSD", "M30", y0, y1, 10000, max_wait=300)
    if r:
        print(f"EDGE_6E EURUSD {y0[:4]}: profit=${r.get('profit')} n={r.get('trades')}")
    else:
        print(f"{y0[:4]}: None")
