# -*- coding: utf-8 -*-
"""corr_gbpusd_m15_r170.py — correlation GBPUSD-M15 vs legs existants:
(1) Duka: vs equity V3INT EURUSD/GBPJPY/NZDJPY Duka si dispo, sinon vs
Upcomers; (2) Upcomers: vs equity_UPC-GBPUSD-620 (le leg GBPUSD H1)."""
import os, sys
import pandas as pd
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TEAM = r"C:\EAFarm\HISTORY - Copy\research\prop_team\equities"
a = {}
# charger tout ce qui existe avec dates
for fn in os.listdir(TEAM):
    if not fn.endswith(".csv"):
        continue
    p = os.path.join(TEAM, fn)
    try:
        x = pd.read_csv(p, index_col=0, parse_dates=True).iloc[:, 0]
        a[fn.replace(".csv", "")] = x
    except Exception:
        pass

cands = [k for k in a if "GBPUSD-M15" in k or "GBPUSD-620" in k or "GBPUSD" in k]
print("fichiers GBPUSD:", cands)
# combiner toutes sur le meme index (union de dates), reindex jour ouvre
allidx = sorted(set().union(*[set(x.index) for x in a.values()]))
A = pd.DataFrame({k: a[k].reindex(allidx).fillna(0.0) for k in a})
print(f"n fichiers: {len(a)} | dates: {len(allidx)}")

for m15 in [k for k in a if "M15" in k]:
    print(f"\n=== corr {m15} ===")
    row = []
    for k in a:
        if k == m15:
            continue
        c = A[m15].corr(A[k])
        if abs(c) > 0.15:
            row.append((k, round(float(c), 2)))
    row.sort(key=lambda x: -abs(x[1]))
    for k, c in row[:10]:
        print(f"  {k:45s} corr={c:+.2f}")
print("FIN", flush=True)
