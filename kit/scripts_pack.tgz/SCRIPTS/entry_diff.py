# -*- coding: utf-8 -*-
"""entry_diff.py — compare les DATES D'ENTREE python et MT5 pour une jambe.

OBJECTIF : comprendre pourquoi MT5 produit 449 entrees la ou python en attend
1349, alors que le declencheur (2.29 % vs 2.50 %) et le filtre (39.43 % vs
39.42 %) concordent.

METHODE : on dumpe les timestamps d'entree python pour la jambe etudiee, puis
on les compare aux lignes `ORION OPEN` du log MT5 (meme symbole, meme
declencheur). On regarde :
  - le nombre d'entrees dans les deux cas
  - les dates de la PREMIERE et de la DERNIERE entree
  - la distribution par ANNEE (un decalage d'annee revelerait un probleme de
    fenetre, pas de logique)

Sortie : entry_diff.json + affichage
"""
import os, re, sys, json
import numpy as np
import pandas as pd

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT, deep_lib as D

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"


def py_entries(sym, trig, filt, sl, tp, hm, tr, t0=None, t1=None):
    """retourne les timestamps d'entree python (index de la barre d'entree)."""
    G._cache.clear()
    F = G.get_frames(sym)
    m5, m1 = F["m5"], F["m1"]
    h1z, hh, ll, a1, gb, gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
    zd, zlo, zhi = MT.project(m5.index, h1z, hh, ll, gb, gr, max_age_h=48)
    M = NL.build(m5, F, zd, zlo, zhi)
    M.update(FE.more(m5, F, m1))
    s = NL.sig(M, trig, filt)
    idx5 = m5.index
    n5 = len(m5)
    cand = np.nonzero(s)[0]
    if t0 is not None:
        cand = cand[idx5[np.minimum(cand + 1, n5 - 1)] >= t0]
    if t1 is not None:
        cand = cand[idx5[np.minimum(cand + 1, n5 - 1)] <= t1]
    times = []
    last_exit = -1
    for i in cand:
        if i + 1 >= n5 - 1:
            break
        b0 = i + 1
        if b0 <= last_exit:
            continue
        a5 = F["a15i"][i]
        if not np.isfinite(a5) or a5 <= 0:
            continue
        # on ne rejoue pas la sortie : on veut juste savoir QUELS signaux
        # deviennent des entrees. On utilise run_ex global pour la coherence.
        times.append(idx5[i + 1])
    return times, len(cand)


def mt5_entries(sym, trig):
    """lit les dates ORION OPEN du log MT5 le plus fourni."""
    best, bestn = None, -1
    for f in os.listdir(LOGD):
        if ".log" not in f:
            continue
        p = os.path.join(LOGD, f)
        if os.path.getsize(p) < 500:
            continue
        raw = open(p, "rb").read(4)
        enc = "utf-16" if raw[:2] in (b"\xff\xfe", b"\xfe\xff") else "utf-8"
        try:
            txt = open(p, encoding=enc, errors="replace").read()
        except Exception:
            continue
        pat = r"(\d{4}\.\d\d\.\d\d) (\d\d:\d\d:\d\d)\s+ORION OPEN " + sym + r" " + trig
        hits = re.findall(pat, txt)
        if len(hits) > bestn:
            best, bestn = hits, len(hits)
    return best or []


if __name__ == "__main__":
    sym = sys.argv[1] if len(sys.argv) > 1 else "EURAUD"
    trig = sys.argv[2] if len(sys.argv) > 2 else "big_bear"
    mtrig = sys.argv[3] if len(sys.argv) > 3 else "BIGBEAR"
    filt = (sys.argv[4].split(",") if len(sys.argv) > 4 else ["vol_lo"])
    print(f"=== {sym} | {trig} | filtre {filt} ===")
    times, nsig = py_entries(sym, trig, filt, 1.5, 99.0, 192, 3.5)
    print(f"  signaux python (candidats) : {nsig}")
    print(f"  entrees python (apres last_exit) : {len(times)}")
    if times:
        print(f"    premiere : {times[0]}")
        print(f"    derniere : {times[-1]}")
        yr = pd.Series([t.year for t in times]).value_counts().sort_index()
        print(f"    par annee : {dict(yr)}")
    m = mt5_entries(sym, mtrig)
    print(f"  entrees MT5 ({mtrig}) : {len(m)}")
    if m:
        print(f"    premiere : {m[0][0]}")
        print(f"    derniere : {m[-1][0]}")
        yrm = pd.Series([int(x[0][:4]) for x in m]).value_counts().sort_index()
        print(f"    par annee : {dict(yrm)}")
    if times and m:
        print(f"\n  RATIO : {len(m)}/{len(times)} = {len(m)/len(times):.2f}")
