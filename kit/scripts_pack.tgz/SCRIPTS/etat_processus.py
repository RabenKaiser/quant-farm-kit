# -*- coding: utf-8 -*-
"""etat_processus.py -- QUI TOURNE, ET QUI DEVRAIT TOURNER (chaine de commandement).

Verifie les six processus autonomes de l'atelier et signale les absents. C'est le
controle militaire : la chaine doit etre complete, sinon le cycle journalier a un
trou (pic sans voie, creux sans tenue de comptes).
"""
import subprocess
import sys

ATTENDUS = {
    "usine_9h": ("maitre du cycle (03 h -> 12 h)", True),
    "boucle_nuit": ("voie FERME (campagnes d'ordres reels)", True),
    "lane_upcomers": ("voie JUGE (2e flux Upcomers)", True),
    "deux_voies": ("superviseur de secours de la ferme", False),
    "planificateur": ("travaux lourds hors pic", True),
    "veille": ("tenue de comptes horaire", True),
    "gardien_maitre": ("gardien du maitre de cycle (relance si mort)", True),
}


def main():
    cmd = ("Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
           "ForEach-Object { $_.ProcessId.ToString() + ' ' + $_.CommandLine }")
    out = subprocess.run(["powershell", "-NoProfile", "-Command", cmd],
                         capture_output=True, text=True).stdout or ""
    lignes = out.splitlines()
    print("CHAINE DE COMMANDEMENT DE L'ATELIER")
    manquants = []
    for cle, (role, requis) in ATTENDUS.items():
        pids = [l.split()[0] for l in lignes if cle in l]
        etat = ("PID " + ",".join(pids)) if pids else "ABSENT"
        if not pids and requis:
            manquants.append(cle)
        print("   %-14s %-42s %s" % (cle, role, etat))
    print()
    if manquants:
        print("!! MAILLONS MANQUANTS : %s" % ", ".join(manquants))
        print("   (les relancer : python SCRIPTS\\<nom>.py en tache de fond)")
    else:
        print("Chaine complete.")


if __name__ == "__main__":
    sys.exit(main())