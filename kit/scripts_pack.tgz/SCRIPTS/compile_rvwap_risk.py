# -*- coding: utf-8 -*-
"""compile_rvwap_risk.py — compile RVWAP_CHOCH_EA (module PROP risque) dans
le data folder Farm CF0B997 (eepeek). MetaEditor SANS /s (avec /s = check
only, pas d'ex5). Si l'ex5 n'est pas ecrit (MetaEditor a besoin du terminal
pour les include paths), relance le terminal Farm puis recompile.
"""
import shutil, subprocess, time, sys, os
from pathlib import Path
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

FARM = Path(r"C:\EAFarm\MT5\Farm")
METAEDITOR = FARM / "MetaEditor64.exe"
TERMINAL = FARM / "terminal64.exe"
DATA_EXP = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\MQL5\Experts\eepeek")
SRC = Path(r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS\stack_eas\RVWAP_CHOCH_EA.mq5")

def kill_me():
    try:
        subprocess.run(["taskkill", "/F", "/IM", "metaeditor64.exe"],
                       capture_output=True, timeout=10)
    except Exception:
        pass

def compile_one(dst_mq5):
    """Retourne True si l'ex5 a ete (re)ecrit (>5000b)."""
    ex5 = dst_mq5.with_suffix(".ex5")
    old = ex5.stat().st_mtime if ex5.exists() else 0
    if ex5.exists():
        try: ex5.unlink()
        except Exception: pass
    kill_me()
    time.sleep(1)
    try:
        proc = subprocess.Popen([str(METAEDITOR), f"/compile:{dst_mq5}"],
                                stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL)
    except Exception as e:
        print(f"Popen echec: {e}", flush=True)
        return False
    written = False
    for _ in range(30):
        time.sleep(1)
        if ex5.exists() and ex5.stat().st_size > 5000 \
           and ex5.stat().st_mtime > old:
            written = True
            break
    if not written:
        time.sleep(3)
        if ex5.exists() and ex5.stat().st_size > 5000 \
           and ex5.stat().st_mtime > old:
            written = True
    try:
        proc.kill()
    except Exception:
        pass
    kill_me()
    return written

def main():
    DATA_EXP.mkdir(parents=True, exist_ok=True)
    dst = DATA_EXP / SRC.name
    shutil.copy2(SRC, dst)
    ok = compile_one(dst)
    if not ok:
        print("1er compile sans resultat -> relance terminal Farm puis retry",
              flush=True)
        try:
            t = subprocess.Popen([str(TERMINAL)], cwd=str(FARM),
                                 creationflags=0x08000000)
            time.sleep(10)
            ok = compile_one(dst)
            try:
                t.terminate()
            except Exception:
                pass
        except Exception as e:
            print(f"echec terminal: {e}", flush=True)
    ex5 = dst.with_suffix(".ex5")
    if ok and ex5.exists():
        print(f"OK {ex5} ({ex5.stat().st_size}b)", flush=True)
        # copie aussi dans la racine E23367 (l'autre lane la cherche parfois)
        d2 = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\MQL5\Experts")
        d2.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ex5, d2 / ex5.name)
        shutil.copy2(SRC, d2 / SRC.name)
        print(f"copie E23367: {d2 / ex5.name}", flush=True)
        sys.exit(0)
    print("FAIL: ex5 non ecrit", flush=True)
    sys.exit(1)

if __name__ == "__main__":
    main()
