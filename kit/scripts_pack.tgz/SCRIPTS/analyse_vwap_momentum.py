# -*- coding: utf-8 -*-
"""ANALYSE VWAP — pourquoi le trailing a échoué ? Où est l'info ?
1. Distribution des trades VWAP réels (fill vs niveau)
2. Le CROSS VWAP comme signal MOMENTUM (acheter au-dessus, pas mean-rev)
3. Les BANDES VWAP (VWAP ± k*σ) comme zones de réaction"""
import polars as pl
import numpy as np
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
from edge_correct import load_m1, to_tf
import deep_signals as DS

# ---- 1. Distribution des trades VWAP qui ont échoué (le log Farm) ----
print("=" * 70)
print("1. POURQUOI LE TRAILING VWAP A ÉCHOUÉ (analyse des trades réels)")
print("=" * 70)
# Le VWAP trailing fermait au bid traversé (fill au marché vs au niveau)
# -> chaque sortie coûtait ~0.1-0.3R de slippage. Sur 800+ trades/an, ça tue.
# MAIS : le signal (reclaim) lui-même était-il bon ? Testons le CROSS.

# ---- 2. CROSS VWAP MOMENTUM (l'utilisation que l'utilisateur décrit) ----
print("\n2. CROSS VWAP MOMENTUM : acheter quand close > VWAP (pas de trailing)")
print("   (l'inverse de ce qu'on faisait — VWAP = filtre directionnel, pas stop)")
m1 = load_m1("GBPUSD")
tf = to_tf(m1, 3600)  # H1
f = DS._base(tf, {})
vwap = DS._vwap_series(f, 86400)
c = tf["bid_c"].to_numpy()
o = tf["bid_o"].to_numpy()
h = tf["bid_h"].to_numpy()
l = tf["bid_l"].to_numpy()
atr = f["atr"].to_numpy()
t = tf["time"].to_numpy()
n = len(c)

# Signal : le prix RESTE au-dessus du VWAP (close > VWAP sur X barres consécutives)
# = momentum directionnel, pas un croisement isolé
def test_cross_vwap(min_above=3, sl_atr=3.0, rr=2.0):
    above = c > vwap
    trades = []
    last_exit = -1
    i = 0
    while i < n - 1:
        # chercher une séquence de min_above barres au-dessus
        if i > 0 and above[i] and not above[i-1]:
            # croisement haussier -> compter les barres au-dessus
            cnt = 0
            j = i
            while j < n and above[j]:
                cnt += 1
                j += 1
            if cnt >= min_above:
                entry = o[i+1]
                R = sl_atr * atr[i]
                stop = entry - R
                tgt = entry + rr * R
                for k in range(i+1, min(i+150, n)):
                    if l[k] <= stop: r = -1.0; last_exit = k; break
                    elif h[k] >= tgt: r = rr; last_exit = k; break
                else:
                    r = (c[min(i+149,n-1)] - entry) / R; last_exit = min(i+149,n-1)
                trades.append({"ts": int(t[i]), "r": r})
                i = last_exit
        i += 1
    return trades

for min_above in [2, 3, 5]:
    tr = test_cross_vwap(min_above)
    if not tr: continue
    r = np.array([x["r"] for x in tr])
    if r.std() == 0:
        print(f"  cross+{min_above} barres: n={len(r)} std=0 (résultat constant)"); continue
    net = r.mean(); tt = net / (r.std()/np.sqrt(len(r)))
    print(f"  cross+{min_above} barres: n={len(r)} net={net:+.3f}R t={tt:+.2f} somme={r.sum():+.1f}R")

# ---- 3. BANDES VWAP (VWAP ± k*σ) : zones de réaction ----
print("\n3. BANDES VWAP (3e band) : le prix réagit aux extrêmes du VWAP")
# σ = écart-type des (close - vwap) sur la journée
print("   (à implémenter : VWAP ± 2σ = zone de surachat/survente intraday)")
print("   -> achat quand price touche bande BASSE + reclaim au-dessus")
