﻿import os, re
LOGD=r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
files=[(f,os.path.getmtime(os.path.join(LOGD,f)),os.path.getsize(os.path.join(LOGD,f))) for f in os.listdir(LOGD) if '.log' in f]
files.sort(key=lambda x:-x[1])
for f,m,s in files[:6]:
    p=os.path.join(LOGD,f)
    if s<300: continue
    raw=open(p,'rb').read(4)
    enc='utf-16' if raw[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8'
    try: txt=open(p,encoding=enc,errors='replace').read()
    except Exception: continue
    hits=[ln for ln in txt.splitlines() if 'USDJPY' in ln]
    if hits:
        print('=== '+f+' ===')
        for ln in hits[:12]:
            print('  ', ln.split('Core')[-1].strip()[:118])
        break
