"""degrade_execution : la mesure survit-elle a une execution realiste ?

Question posee par les six echecs en ordres reels : les 67,8 % mesures en Python sont-ils un
artefact d'execution ? Le modele suppose trois choses optimistes :

  1. l'entree se fait au CLOSE de la barre de signal - alors que l'EA entre au marche au tick
     suivant, et le signal est justement un franchissement de seuil (moment ou le prix bouge) ;
  2. le cout vaut `spread median x tick / stop` - alors que le spread reel au moment du signal est
     plus large, surtout sur un mouvement ;
  3. le stop et l'objectif sont places exactement a 1 ATR et 1 R du prix d'entree.

On degrade ces trois hypotheses une par une et on regarde ce que devient le taux de premieres
touches favorables. Si le 67,8 % tombe a 40-50 %, la mesure etait juste et c'est l'EXECUTION qui
coute tout (auquel cas il faut une execution plus fine : ordre limite dans la zone plutot qu'au
marche). S'il survit, alors la mesure est biaisee par autre chose.
"""
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import combos_facteurs as CF

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
SEUIL = float(os.environ.get("SEUIL", "1.5"))
HORIZON = 24
CIBLE = 1.0


def mesure(m5, atr, cout, decalage, mult_cout, stop_mult):
    c, h, l = m5.close.values, m5.high.values, m5.low.values
    tp = pd.Series((h + l + c) / 3.0, index=m5.index)
    j = pd.Series(m5.index.date, index=m5.index)
    v = (tp.groupby(j).cumsum() / (tp.groupby(j).cumcount() + 1)).values
    v30 = pd.Series(v[::2], index=m5.index[::2]).reindex(m5.index, method="ffill").values
    c30 = pd.Series(c[::2], index=m5.index[::2]).reindex(m5.index, method="ffill").values
    sd30 = pd.Series(c30 - v30).rolling(200).std().values
    dev30 = (c - v30) / np.where(sd30 > 0, sd30, np.nan)
    amed = pd.Series(atr).rolling(500, min_periods=50).median().values
    volb = atr < 1.0 * np.nan_to_num(amed, nan=0.0)
    ok = np.isfinite(atr) & (atr > 0)
    masque = ok & volb & (np.nan_to_num(dev30, nan=0.0) >= SEUIL)
    idx = np.flatnonzero(masque) + decalage
    idx = idx[(idx < len(c) - HORIZON - 1) & (idx >= 0)]
    if len(idx) < 50:
        return None
    off = np.arange(1, HORIZON + 1)
    Hh, Ll = h[idx[:, None] + off], l[idx[:, None] + off]
    e, a = c[idx], atr[idx] * stop_mult
    ht = (Ll <= e[:, None] - CIBLE * a[:, None])
    hs = (Hh >= e[:, None] + a[:, None])
    it = np.where(ht.any(1), ht.argmax(1), 10 ** 6)
    isl = np.where(hs.any(1), hs.argmax(1), 10 ** 6)
    gagne = (it < isl)
    pa = gagne.mean()
    return len(idx), 100.0 * float(pa)


def main():
    corpus = os.environ.get("CORPUS", "m1_pos")
    os.environ["TF"] = "15min"
    os.environ["MINBAR"] = "20000"
    paires = [p.stem.replace("_M1", "") for p in sorted((B / corpus).glob("*_M1.csv"))]
    scenarios = [
        ("modele Python : entree au close, cout normal", 0, 1.0, 1.0),
        ("entree a la barre suivante", 1, 1.0, 1.0),
        ("entree a la barre suivante + cout x2", 1, 2.0, 1.0),
        ("entree a la barre suivante + cout x3", 1, 3.0, 1.0),
        ("entree a la barre suivante + cout x2 + stop x1,2", 1, 2.0, 1.2),
    ]
    tot = {}
    for paire in paires:
        ch = CF.charge(corpus, paire)
        if ch is None:
            continue
        m5, atr = ch
        d = pd.read_csv(B / corpus / ("%s_M1.csv" % paire), usecols=["close", "spread"])
        dcl = d["close"].diff().abs()
        nzc = dcl[dcl > 0]
        s = d["spread"].astype(float)
        nz = s[s > 0]
        if not len(nzc) or not len(nz):
            continue
        cout = float(nz.median()) * float(nzc.min())
        for nom, dec, mc, sm in scenarios:
            r = mesure(m5, atr, cout, dec, mc, sm)
            if not r:
                continue
            n, p = r
            tot.setdefault(nom, []).append((n, p * n, p))
        print("  %-9s mesure" % paire, flush=True)
    print("\n=== SURVIE A L'EXECUTION (corpus %s, 1,5 sigma + volatilite sous la mediane) ===" % corpus)
    for nom, _, _, _ in scenarios:
        v = tot.get(nom)
        if not v:
            continue
        n = sum(x[0] for x in v)
        p = sum(x[1] for x in v) / n
        print("  %-52s %6d transactions | p(1er toucher) %.1f %%" % (nom, n, p), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
