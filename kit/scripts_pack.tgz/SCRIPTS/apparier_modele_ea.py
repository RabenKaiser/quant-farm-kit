"""apparier_modele_ea : le modele, evalue sur LES TRANSACTIONS DE L'EA, donne-t-il 41 % ou 26 % ?

Round 361. Neuf hypotheses ont ete ecartees par la mesure (trame, densite, instants, mecanique de
sortie, pertes non honorees, roulement, spread, moteur de premier toucher, divergence des donnees) et
l'ecart demeure : le modele annonce 41,4 % de gagnantes, les ordres reels 26,1 %.

Il reste une possibilite que rien n'a encore testee : **les deux populations de transactions ne sont
pas les memes.** Le modele evalue TOUS ses signaux ; l'EA, lui, n'en prend qu'une partie (rearmerement
de 32 h, disponibilite du creneau, refus d'ordre...). Si les transactions prises par l'EA sont un
sous-ensemble defavorable, la comparaison des moyennes n'a aucun sens.

Ce script prend donc les **instants d'entree reellement utilises par l'EA** (lignes `JRN`, sens = 0,
profil Dukascopy) et demande au modele son verdict **sur ces instants precis**, avec la meme geometrie
honnete. Trois issues :

  - le modele donne ~41 % sur ces instants -> la population n'est pas la cause, le modele se trompe
    sur l'issue des memes transactions ;
  - le modele donne ~26 % sur ces instants -> le modele est juste, et c'est la SELECTION de l'EA (quels
    signaux elle prend) qui fait la difference : il faudra instrumenter l'EA, pas le modele ;
  - le modele ne trouve presque aucun signal a ces instants -> l'EA trade des instants que le modele
    ne connait pas, et c'est la definition du declencheur qu'il faut aligner.
"""
import os
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
PROFILS = {"mt5": "E23367DD11DBEB0EF97D08185EAB7295",
           "farm": "CF0B997454318B475CF01419AFE2BBF3"}
TESTER = (Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Tester")
          / PROFILS.get(os.environ.get("PROFIL", "farm"), ""))
PAIRE = sys.argv[1] if len(sys.argv) > 1 else "EURCHF"
HOLD, TPR, SL, RANGE, MOM, SEUIL = 64, 2.0, 1.0, 50, 2.0, 0.97


def entrees_ea():
    """Instants d'entree reels, RESTREINTS a la ligne de jeu SR97 (round 361).

    CORRECTION : la premiere version lisait toutes les lignes JRN du symbole, donc aussi celles des
    campagnes precedentes (table SR50/SR100, devtrame DEVX...) -- 4 311 instants au lieu des ~600
    attendus pour SR97 seul, et des transactions etrangeres a la configuration etudiee. Les lignes JRN
    portent l'identifiant de la ligne de jeu : on filtre dessus.
    """
    ligne_id = os.environ.get("LIGNE", "SR97S").replace("|", r"\|")
    out = set()
    for lg in TESTER.glob("Agent-*/logs/*.log"):
        for enc in ("utf-16", "utf-8"):
            try:
                txt = lg.read_text(encoding=enc, errors="replace")
            except OSError:
                continue
            for m in re.finditer(r"JRN %s (\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}) (%s[^\s]*) 0 "
                                 r"\d+ [\d.]+ " % (re.escape(PAIRE), ligne_id), txt):
                out.add(pd.Timestamp(m.group(1).replace(".", "-", 2).replace(".", " ")))
    return sorted(out)


def resultat(D, sig):
    c, h, l, o, a = D["c"], D["h"], D["l"], D["o"], D["a"]
    sig = np.asarray(sig, dtype=int)
    sig = sig[(sig >= RANGE) & (sig < len(c) - HOLD - 3)]
    sig = sig[np.isfinite(a[sig]) & (a[sig] > 0)]
    if len(sig) < 5:
        return None
    ent = sig + 1
    ent = ent[ent < len(c) - HOLD - 2]
    e, st = o[ent], a[sig[:len(ent)]]
    sp = D["cout"]
    tp, sl = e - (TPR + sp) * st, e + max(SL - sp, 0.1) * st
    off = np.arange(1, HOLD + 1)
    Hh, Ll = h[ent[:, None] + off], l[ent[:, None] + off]
    htp, hsl = Ll <= tp[:, None], Hh >= sl[:, None]
    it = np.where(htp.any(1), htp.argmax(1), 10 ** 6)
    isl = np.where(hsl.any(1), hsl.argmax(1), 10 ** 6)
    tph, slh = htp.any(1), hsl.any(1)
    kind = np.where(tph & (~slh | (it < isl)), 0, np.where(slh, 1, 2))
    R = np.where(kind == 0, TPR, np.where(kind == 1, -1.0,
                 ((e - c[ent + HOLD]) / st) - sp))
    ok = np.isfinite(R)
    return 100.0 * float(np.mean(kind[ok] == 0)), len(R[ok]), float(np.mean(R[ok]))


def main():
    ea = entrees_ea()
    if len(ea) < 20:
        print("trop peu d'entrees reelles pour %s (%d)" % (PAIRE, len(ea)))
        return 1
    D = NM.charge(PAIRE, "m1_pos")
    if D is None:
        print("corpus absent")
        return 1
    idx = D["idx"]
    # l'EA entre a la barre SUIVANT l'instant JRN : la barre de signal est celle de l'entree
    sig = np.array(sorted({max(0, int(idx.searchsorted(t)) - 1) for t in ea}))
    r_ea = resultat(D, sig)
    # population complete du modele, pour memoire
    df = pd.DataFrame({"h": D["h"], "l": D["l"]})
    hi = df.h.rolling(RANGE).max().values
    lo = df.l.rolling(RANGE).min().values
    pos = (D["c"] - lo) / np.where(hi - lo > 0, hi - lo, np.nan)
    momok = np.abs(D["c"] - np.roll(D["c"], 8)) <= MOM * D["a"]
    heures = idx.hour.values
    tous = np.flatnonzero(np.nan_to_num(pos, nan=-9.0) >= SEUIL)
    tous = tous[momok[tous] & ((heures[tous] < 7) | (heures[tous] > 16))]
    r_tous = resultat(D, tous)
    print("=== %s : le modele juge les MEMES transactions que l'EA (%d instants reels) ==="
          % (PAIRE, len(ea)))
    print("  population complete du modele : %s" % (
        "%.1f %% sur %d positions, R/tx %+.4f" % r_tous if r_tous else "--"))
    print("  instants REELS de l'EA        : %s" % (
        "%.1f %% sur %d positions, R/tx %+.4f" % r_ea if r_ea else "--"))
    print("\n  lecture : si le modele donne ici ~26 % comme le reel, il est juste et c'est la")
    print("  SELECTION de l'EA qu'il faut instrumenter. S'il donne ~41 %, c'est le modele qui se")
    print("  trompe sur l'issue des memes transactions.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
