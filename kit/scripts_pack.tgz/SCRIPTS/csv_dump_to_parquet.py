# -*- coding: utf-8 -*-
"""csv_dump_to_parquet.py — convertit le dump M1 serveur (time local GMT+1/+2 DST)
en bars\\<SYM>_M1_db.parquet (ts_event UTC tz-aware + OHLCV, schema GBPUSD_M1_db)."""
import sys
from zoneinfo import ZoneInfo

import pandas as pd

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

src = sys.argv[1]
dst = sys.argv[2]
TZ = ZoneInfo("Europe/Paris")  # CET/CEST = UTC+1/+2, meme DST que le serveur

df = pd.read_csv(src)
print("lignes brutes:", len(df))
df = df.rename(columns={"volume": "volume"})
# time serveur naive -> Europe/Paris -> UTC
ts = pd.to_datetime(df["time"], format="%Y.%m.%d %H:%M")
ts = ts.dt.tz_localize(TZ, ambiguous="NaT", nonexistent="NaT").dt.tz_convert("UTC")
df["ts_event"] = ts
df = df.dropna(subset=["ts_event"])
for c in ["open", "high", "low", "close"]:
    df[c] = df[c].astype(float)
df["volume"] = df["volume"].astype("int64")
df = df[["ts_event", "open", "high", "low", "close", "volume"]]
df = df.drop_duplicates("ts_event").sort_values("ts_event").reset_index(drop=True)
df.to_parquet(dst, index=False)
span = (df["ts_event"].max() - df["ts_event"].min()).days / 365.25
print(f"OK -> {dst} | n={len(df):,} | {df['ts_event'].min()} -> {df['ts_event'].max()} "
      f"({span:.1f} ans)")
# sanity: ouverture hebdo en UTC = dimanche 22:00 ?
wk = df.set_index("ts_event")["open"]
sundays = wk[wk.index.dayofweek == 6]
if len(sundays):
    h = sundays.index.hour.value_counts().sort_index()
    print("ouverture hebdo (UTC): heures des dimanches ->", h.to_dict())
