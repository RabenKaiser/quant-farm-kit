"""derive_horizon : le signal porte-t-il une DERIVE, ou seulement une geometrie de barrieres ?

Round 384. La table honnete s'effondre au stop 1 ATR (60 couples, 0 retenus) et ne survit qu'a partir
du stop 3 ATR, uniquement sur AUDCAD r=50 et r=100. Or un stop de 3 ATR n'est presque jamais touche en
32 h : la « configuration qui survit » n'est donc plus une histoire de barrieres, c'est **une histoire
de derive** -- vendre au sommet d'un range de 50 ou 100 barres, puis tenir N heures.

Ce script mesure exactement cela, sans aucune barriere : R a l'echeance = (entree - sortie a l'ask)/ATR,
pour chaque horizon, chaque paire, DANS LES DEUX SENS :
  - S : vendre quand le close est au sommet du range (SR97) ;
  - L : acheter quand le close est au fond du range (SR03), meme filtre MOM2 et memes heures.

Ce que l'on regarde : la moyenne, l'ecart-type, le t de Student (moyenne / erreur-type), le pire annee,
et le rapport mu/sigma^2 qui decide de la composition d'un portefeuille. Env : SENS (S/L/LESDEUX),
HEURES (defaut 8,16,32,64), SOURCE, SORTIE.
"""
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import barrieres_m1 as BM  # noqa: E402
import spread_barrieres as SB  # noqa: E402

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
RANGES = [int(x) for x in os.environ.get("RANGES", "50,100").split(",")]
HEURES = [int(x) for x in os.environ.get("HEURES", "8,16,32,64").split(",")]


def signaux(M, range_, sens, seuil):
    SB.RANGE, SB.HOLD, SB.SEUIL, SB.MOM = range_, 8, seuil, 2.0
    c, h, l, a, idx = M["c"], M["h"], M["l"], M["a"], M["idx"]
    hi = pd.Series(h).rolling(range_).max().values
    lo = pd.Series(l).rolling(range_).min().values
    pos = (c - lo) / np.where(hi - lo > 0, hi - lo, np.nan)
    momok = np.abs(c - np.roll(c, 8)) <= 2.0 * a
    dehors = ~((idx.hour >= 7) & (idx.hour <= 16))
    sig = np.flatnonzero(np.nan_to_num(pos, nan=-9.0) >= seuil) if sens == "S" \
        else np.flatnonzero(np.nan_to_num(pos, nan=9.0) <= 1.0 - seuil)
    sig = sig[momok[sig] & dehors[sig]]
    sig = sig[(sig >= range_) & np.isfinite(a[sig]) & (a[sig] > 0)]
    return sig


def mesure(M, range_, sens, heures):
    """R moyen a l'echeance, sans barriere (stop et cible a 999 ATR), une position par paire."""
    sig = signaux(M, range_, sens, 0.97)
    if len(sig) < 12:
        return None
    o, a, idx = M["o"], M["a"], M["idx"]
    hold_min = heures * 60
    ent = sig + 1
    ent = ent[ent < len(idx) - 2 * heures - 2]
    res = []
    for k in ent:
        st = float(a[k - 1])
        if not np.isfinite(st) or st <= 0:
            continue
        # r_en_risque=False : sans barriere, le R est exprime en ATR (sinon la division par un stop
        # de 999 ATR ecraserait la mesure a zero).
        r = BM.issue(M["m1"], int(pd.Timestamp(idx[k]).timestamp()), float(o[k]),
                     st, 999.0, 999.0, hold_min, sens, r_en_risque=False)
        if r is not None:
            res.append((k, r[1]))
    if len(res) < 12:
        return None
    ent = np.array([k for k, _ in res])
    R = np.array([r for _, r in res])
    kind = np.zeros(len(R), dtype=int)
    g = SB.bloque(idx, ent, R, kind)
    if len(g) < 12:
        return None
    R = R[g]
    ans = defaultdict(list)
    for k, r in zip(g, R):
        ans[idx[ent[k]].year].append(r)
    mu = float(np.mean(R))
    sd = float(np.std(R, ddof=1))
    return dict(n=len(R), mu=mu, sd=sd, t=mu / (sd / np.sqrt(len(R))) if sd > 0 else 0.0,
                pire=min(float(np.mean(v)) for v in ans.values()), ans=dict(ans))


def main():
    source = os.environ.get("SOURCE", "m1_pos")
    sens_txt = os.environ.get("SENS", "S")
    sens_liste = ["S", "L"] if sens_txt.upper() in ("LESDEUX", "BOTH") else [sens_txt.upper()]
    print("DERIVE A L'ECHEANCE, sans barriere | corpus %s | sens %s | ranges %s | heures %s\n"
          % (source, sens_liste, RANGES, HEURES), flush=True)
    lignes = []
    for p in sorted(x.name[:-7] for x in (B / source).glob("*_M1.csv")):
        M = BM.charge_m30(p, source)
        if M is None:
            continue
        for s in sens_liste:
            for r_ in RANGES:
                for h in HEURES:
                    m = mesure(M, r_, s, h)
                    if m is None:
                        continue
                    lignes.append((p, s, r_, h, m))
                    print("  %-8s %s r=%-3d %3d h : n=%3d  mu %+.4f  sigma %.3f  t %+5.2f  "
                          "pire an %+.3f"
                          % (p, s, r_, h, m["n"], m["mu"], m["sd"], m["t"], m["pire"]), flush=True)
    dest = Path(os.environ.get("SORTIE", str(B / ("DERIVE_HORIZON_%s.md" % sens_txt))))
    out = ["# Derive a l'echeance apres le signal, sans barriere (moteur honnete a la minute)",
           "", "R = (entree - sortie a l'ask) / ATR. t = mu / erreur-type. S = vendre au sommet du "
           "range, L = acheter au fond.", "",
           "| paire | sens | range | heures | n | mu (R/tx) | sigma | t | pire annee |",
           "|---|---|---|---|---|---|---|---|---|"]
    for p, s, r_, h, m in sorted(lignes, key=lambda x: -x[4]["t"]):
        out.append("| %s | %s | %d | %d | %d | %+.4f | %.3f | %+.2f | %+.3f |"
                   % (p, s, r_, h, m["n"], m["mu"], m["sd"], m["t"], m["pire"]))
    dest.write_text("\n".join(out), encoding="utf-8")
    fort = [x for x in lignes if x[4]["t"] > 2.5 and x[4]["pire"] > 0]
    print("\n  %d mesures ; %d avec t > 2,5 ET pire annee > 0 -> %s"
          % (len(lignes), len(fort), dest.name), flush=True)
    for x in sorted(fort, key=lambda y: -y[4]["t"])[:12]:
        print("    %-8s %s r=%-3d %3d h n=%3d mu %+.4f t %+5.2f pire %+.3f"
              % (x[0], x[1], x[2], x[3], x[4]["n"], x[4]["mu"], x[4]["t"], x[4]["pire"]), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
