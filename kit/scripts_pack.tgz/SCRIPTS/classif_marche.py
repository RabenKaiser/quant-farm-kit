# -*- coding: utf-8 -*-
r"""classif_marche.py -- DICTIONNAIRE DES ETATS DU MARCHE (demande explicite
de l'utilisateur, 10/13) + cross-tab etat x declencheur.

PRINCIPE
--------
Chaque declencheur du projet PRESUPPOSE un regime (SR97 = sommet de range,
KELT = canal, BB3 = expansion) mais aucun organe ne DISAIT quel etat le
marche occupait. Ce module fabrique un DICTIONNAIRE objectif : a chaque
barre, un etat parmi 5, defini par des seuils fixes (aucun fitting, aucune
vision retrospective) :

  RANGE       : largeur Donchian(50) petite + position SR qui VELOCE cyclée
                (l'efficacite directionnelle est basse)
  TREND_H     : efficacite directionnelle haute a la hausse (ER > 0.38 sur
                64 barres) + plus-hauts progressifs
  TREND_B     : symetrique baissier
  COMPRESSION : percentile ATR faible ET largeur Donchian etroite ET
                l'efficacite basse (le resserrement avant l'explosion)
  EXPANSION   : percentile ATR fort ET corps moyen surdimensionne

La multi-TRAME est une demande explicite : les etats sont calcules en M30
(trame du moteur) ET a l'echelle H4 (agregation 8x30min) ET D1 (agregation
48x30min). Trois lentilles, concorde ou non.

USAGE
-----
    python SCRIPTS\\classif_marche.py                 # repartition + transi
    python SCRIPTS\\classif_marche.py --crosstab     # etat x declencheur -> R

La cross-tab repond a la question du dictionnaire : QUEL declencheur gagne
dans QUEL etat ? Chaque case porte n, mu, et son surplus contre le temoin
meme-etat direction aleatoire (la regle du 10/12 est obligatoire).
"""
import argparse
import os
import sys
from collections import defaultdict

import numpy as np
import pandas as pd

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parent))
import nuit_motifs as NM

JAMBES = [x.strip() for x in os.environ.get(
    "PAIRES", "EURUSD,GBPUSD,USDCHF,AUDUSD,NZDUSD,EURJPY,GBPJPY,AUDJPY,"
    "CADJPY,NZDJPY,EURGBP,XAUUSD").split(",") if x.strip()]

ER_N = 64          # horizon d'efficacite (2 jours M30)
DON_N = 50         # fenetre Donchian (celle de SR97)
ATR_PCT_N = 1000   # fenetre du percentile ATR (~3 semaines)
ER_TREND = 0.38    # seuil d'efficacite (le meme que le regime d'ou s'est
                   # sorti le portefeuille kelt) -- SEUIL FIXE, pas fitte
ATR_LO, ATR_HI = 0.30, 0.70   # percentiles bas/hauts de l'ATR

ETATS = ["RANGE", "TREND_H", "TREND_B", "COMPRESSION", "EXPANSION"]


def er(c, n=ER_N):
    """Efficacite directionnelle : |net| / somme(|pas|) sur n barres."""
    net = np.abs(c - np.roll(c, n))
    pas = np.abs(np.diff(c, prepend=c[:1]))
    som = pd.Series(pas).rolling(n).sum().values
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(som > 0, net / som, np.nan)


def etats(D):
    """Label d'etat par barre M30. Retour (labels, metriques)."""
    c, h, l, a = D["c"], D["h"], D["l"], D["a"]
    n = len(c)
    e = er(c, ER_N)
    don_w = pd.Series(h).rolling(DON_N).max().values - \
        pd.Series(l).rolling(DON_N).min().values
    don_w = don_w / a
    atr_p = pd.Series(a).rolling(ATR_PCT_N).rank(pct=True).values
    # direction des plus-hauts/bas progressifs
    hh = pd.Series(h).rolling(ER_N).max().values
    dirup = (hh > np.roll(hh, ER_N // 2)).astype(float)
    lab = np.full(n, "RANGE", dtype=object)
    lab = np.where((e > ER_TREND) & (c > np.roll(c, ER_N // 2)),
                   "TREND_H", lab)
    lab = np.where((e > ER_TREND) & (c < np.roll(c, ER_N // 2)),
                   "TREND_B", lab)
    lab = np.where((atr_p < ATR_LO) & ~((e > ER_TREND)),
                   "COMPRESSION", lab)
    lab = np.where((atr_p > ATR_HI) & (np.abs(e) < ER_TREND),
                   "EXPANSION", lab)
    # les 3 premieres barres sans ATR -> RANGE par defaut neutre
    lab = np.where(np.isfinite(a), lab, "RANGE")
    return lab, dict(er=e, don_w=don_w, atr_p=atr_p)


def agrege(D, k):
    """Agregation k barres M30 -> trame superieure (H4 = 8, D1 = 48)."""
    o, h, l, c, a, idx = D["o"], D["h"], D["l"], D["c"], D["a"], D["idx"]
    n = (len(c) // k) * k
    O = o[:n].reshape(-1, k)[:, 0]
    H = h[:n].reshape(-1, k).max(1)
    L = l[:n].reshape(-1, k).min(1)
    C = c[:n].reshape(-1, k)[:, -1]
    idx2 = idx[:n].reshape(-1, k)[:, 0]
    tr = np.maximum(H - L, np.maximum(np.abs(H - np.roll(C, 1)),
                                      np.abs(L - np.roll(C, 1))))
    atr = pd.Series(tr).rolling(14).mean().values
    return dict(idx=idx2, o=O, h=H, l=L, c=C, a=atr, cout=D["cout"])


def repartition(lab):
    v = {e: float(np.mean(lab == e)) * 100.0 for e in ETATS}
    return v


def transition(lab):
    """Matrice de persistance : P(etat suivant = etat courant)."""
    cnt = defaultdict(int)
    tot = 0
    for i in range(1, len(lab)):
        cnt[(lab[i - 1], lab[i])] += 1
        tot += 1
    return {k: v / tot for k, v in cnt.items()}, tot


def h4_d1(lab):
    """Etat dominant des dernieres 8 (H4) / 48 (D1) barres M30."""
    n = len(lab)
    h4 = np.empty(n, dtype=object)
    d1 = np.empty(n, dtype=object)
    # vote majoritaire glissant
    s = pd.Series(lab.astype(str))
    h4[:] = s.rolling(8).apply(lambda w: w.mode().iloc[0],
                               raw=False).values
    d1[:] = s.rolling(48).apply(lambda w: w.mode().iloc[0],
                                raw=False).values
    return h4, d1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--crosstab", action="store_true")
    a = ap.parse_args()

    print("DICTIONNAIRE DES ETATS | ER>%0.2f = tendance | ATR pct <%0.2f = "
          "compression, >%0.2f = expansion" % (ER_TREND, ATR_LO, ATR_HI))
    agg = defaultdict(lambda: defaultdict(int))
    tot = 0
    for p in JAMBES:
        D = NM.charge(p, "m1_pos")
        if D is None:
            print("  %-8s : corpus absent" % p)
            continue
        lab, met = etats(D)
        rep = repartition(lab)
        print("  %-8s " % p + "  ".join("%s %4.1f%%" % (e[:5], rep[e])
                                        for e in ETATS))
        for e in ETATS:
            agg[e][p] += float(np.sum(lab == e))
        tot += len(lab)
    if tot:
        print("\nREPARTITION GLOBALE :")
        for e in ETATS:
            print("  %-11s %5.1f%%" % (e, 100.0 * sum(agg[e].values()) / tot))
    if not a.crosstab:
        return
    # --- cross-tab etat x declencheur --------------------------------------
    # declencheurs reconstruits dans le moteur honnete : SR97S (vente sommet),
    # SR97L (achat plancher), le fade KELT (retour mediane), et la casse BB.
    print("\nCROSS-TAB etat x declencheur (mu R/tx par case, temoin = "
          "meme-etat direction aleatoire) :")
    import vpc_sr97 as VPC   # moteur de barrieres deja valide
    trig_name = "SR97"       # le portefeuille tient son reservoir ici
    for p in JAMBES[:6]:
        D = NM.charge(p, "m1_pos")
        if D is None:
            continue
        lab, _ = etats(D)
        # signaux SR97 (deja implante dans vpc_sr97.signaux)
        sig = VPC.signaux(D)
        sig = sig[(sig >= 60) & (sig < len(D["c"]) - VPC.HOLD - 3)]
        if len(sig) < 30:
            continue
        ent = sig + 1
        e, st = D["o"][ent], D["a"][sig[:len(ent)]]
        sp = D["cout"]
        tp, sl = e - (VPC.TPR + sp) * st, e + max(VPC.SL - sp, 0.1) * st
        off = np.arange(1, VPC.HOLD + 1)
        Hh, Ll = D["h"][ent[:, None] + off], D["l"][ent[:, None] + off]
        hsl = Hh >= sl[:, None]
        htp = Ll <= tp[:, None]
        it = np.where(htp.any(1), htp.argmax(1), 10 ** 6)
        isl = np.where(hsl.any(1), hsl.argmax(1), 10 ** 6)
        kind = np.where(htp.any(1) & (~hsl.any(1) | (it < isl)), 0,
                        np.where(hsl.any(1), 1, 2))
        fin = (e - D["c"][ent + VPC.HOLD]) / st
        R = np.where(kind == 0, VPC.TPR,
                     np.where(kind == 1, -1.0, fin - sp))
        garde, fin_bloc = [], None
        for k, i in enumerate(ent):
            t = D["idx"][i]
            if fin_bloc is not None and t < fin_bloc:
                continue
            garde.append(k)
            fin_bloc = t + pd.Timedelta(minutes=30 * VPC.HOLD)
        g = np.array(garde, dtype=int)
        ok = np.isfinite(R[g])
        g = g[ok]
        R = R[g]
        et = lab[ent[g]]
        print("  %-8s (VPC/SR97 vente, n=%d)" % (p, len(R)))
        for etat in ETATS:
            m = et == etat
            if m.sum() >= 10:
                print("      %-11s n=%4d mu=%+.3f" % (etat, m.sum(),
                                                      float(np.mean(R[m]))))


if __name__ == "__main__":
    main()
