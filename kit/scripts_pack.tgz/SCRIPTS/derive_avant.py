"""derive_avant.py — ROUND 67 : LA DERIVE PREDIT-ELLE HORS ECHANTILLON ?

Le round 66 a trouve le predicteur le plus fort jamais mesure ici : la derive de
l'annee (log cloture_fin / cloture_debut) correle a +0,557 avec le plafond net,
mieux que eff_range (+0,469) et mieux que tout ce qu'on a teste.

MAIS cette correlation est IN-SAMPLE et probablement tautologique : le plafond
MFE/MAE et la derive sont mesures sur la MEME annee, et une annee qui monte de
15 % a mecaniquement un MFE long superieur a son MAE long. C'est peut-etre la
meme grandeur vue deux fois.

LE SEUL TEST QUI COMPTE. Est-ce que la derive de 2020-2023 predit le plafond de
2024-2026 ? Si oui, on tient enfin une variable simple, forte ET hors
echantillon. Si non, la ligne est close comme les autres.

Unite d'observation : le couple (paire, trame). Chaque couple a UNE derive en
epoque A et UN plafond en epoque B. Les couples sont independants entre eux, la
correlation porte donc sur ~48 a 64 points.
"""
import glob, json, os, sys

import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
B = r"C:\EAFarm\HISTORY - Copy\research"
M1 = os.path.join(B, "m1_pos")
PAIRES = [os.path.basename(f).replace("_M1.csv", "")
          for f in glob.glob(os.path.join(M1, "*_M1.csv"))]
TRAMES = [("5min", "M5"), ("15min", "M15"), ("30min", "M30")]
A = (2020, 2021, 2022, 2023)
Bp = (2024, 2025, 2026)

net = {}
for line in open(os.path.join(B, "ENVELOPPE.jsonl"), encoding="utf-8", errors="replace"):
    if not line.strip().startswith("{"):
        continue
    d = json.loads(line)
    if d.get("net") is not None:
        net[(d.get("paire"), d.get("trame"), str(d.get("regime")))] = float(d["net"])

lignes = []
for p in PAIRES:
    f = os.path.join(M1, "%s_M1.csv" % p)
    d = pd.read_csv(f, usecols=["time", "close"])
    d["t"] = pd.to_datetime(d["time"], unit="s", utc=True)
    for regle, nom in TRAMES:
        b = d.set_index("t").resample(regle).agg(close=("close", "last")).dropna()
        if len(b) < 3000:
            continue
        der, ne = {}, {}
        for an in range(2020, 2026):
            bb = b[b.index.year == an]
            if len(bb) < 3000:
                continue
            c0, c1 = float(bb.close.iloc[0]), float(bb.close.iloc[-1])
            if c0 > 0 and c1 > 0:
                der[an] = float(np.log(c1 / c0))
            n = net.get((p, nom, str(an)))
            if n is not None:
                ne[an] = n
        da = [v for k, v in der.items() if k in A]
        db = [v for k, v in der.items() if k in Bp]
        na = [v for k, v in ne.items() if k in A]
        nb = [v for k, v in ne.items() if k in Bp]
        if not (da and db and na and nb):
            continue
        lignes.append(dict(p=p, tf=nom,
                           derA=float(np.mean(da)), derB=float(np.mean(db)),
                           netA=float(np.mean(na)), netB=float(np.mean(nb)),
                           signe=1 if np.mean(da) > 0 else -1))
d = pd.DataFrame(lignes)
print("couples (paire, trame) mesurables : %d" % len(d))
if len(d) < 8:
    sys.exit(0)


def cor(x, y):
    return float(np.corrcoef(x, y)[0, 1]), float(pd.Series(x).corr(pd.Series(y), method="spearman"))


print("\n=== REFERENCE : la meme correlation IN-SAMPLE (celle du round 66) ===")
r, s = cor(d.derA.values, d.netA.values)
print("   derive A -> plafond A : Pearson %+.3f | Spearman %+.3f" % (r, s))

print("\n=== LE TEST QUI COMPTE : HORS ECHANTILLON ===")
r, s = cor(d.derA.values, d.netB.values)
print("   derive A -> plafond B : Pearson %+.3f | Spearman %+.3f" % (r, s))
print("   (si c'est du meme ordre que l'in-sample, la derive informe vraiment ;")
print("    si ca tombe a zero, l'in-sample n'etait que la meme grandeur vue deux fois)")

print("\n=== CONTROLE : la persistance de la derive elle-meme ===")
r, s = cor(d.derA.values, d.derB.values)
print("   derive A -> derive B  : Pearson %+.3f | Spearman %+.3f" % (r, s))

print("\n=== ET PAR GROUPE : la derive de A separe-t-elle le plafond de B ? ===")
haut = d[d.derA > d.derA.median()]
bas = d[d.derA <= d.derA.median()]
for nom, g in (("derive A forte (moitie haute)", haut), ("derive A faible", bas)):
    print("   %-30s n=%2d | plafond B moyen %.3f | au-dessus de 1 : %d/%d"
          % (nom, len(g), g.netB.mean(), int((g.netB > 1).sum()), len(g)))
r, s = cor(d.derA.values, d.netB.values)
print("\n   VERDICT : %s"
      % ("la derive tient hors echantillon" if abs(r) > 0.3 and r > 0
         else "la derive NE tient PAS hors echantillon -- l'in-sample etait bien la "
              "meme grandeur vue deux fois"))
