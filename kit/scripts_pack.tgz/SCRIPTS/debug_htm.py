"""Diagnostic final : le rapport .htm est-il généré par run ?
Si oui, c'est LA source fiable (le log est un sac de nœuds multi-runs).
Relance un run propre et vérifie le .htm."""
import sys, json
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner as m

# run propre avec rapport explicite
r = m.run_backtest("PTRAIL_LONG", "USDJPY", "M30", "2024.01.01", "2025.01.01", 10000,
                   report_path=r"C:\EAFarm\MT5\Farm\Tester\test_repro.htm")
print("résultat:", json.dumps(r, default=str))
from pathlib import Path
rep = Path(r"C:\EAFarm\MT5\Farm\Tester\test_repro.htm")
print(f"\nrapport: existe={rep.exists()} taille={rep.stat().st_size if rep.exists() else 0}")
if rep.exists():
    h = rep.read_text("utf-8", errors="replace")
    import re
    for pat in ["Net Profit", "Total Trades", "Profit Factor"]:
        m_ = re.search(rf"{pat}[^<]*<[^>]*>([^<]+)", h)
        print(f"  {pat}: {m_.group(1).strip() if m_ else '?'}")
