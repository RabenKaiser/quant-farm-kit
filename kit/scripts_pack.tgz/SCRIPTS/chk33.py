﻿import pickle
d = pickle.load(open(r"C:\EAFarm\HISTORY - Copy\research\pos_cache\AUDNZD.pkl","rb"))
for k,v in d.items():
    if v.get("trig")=="at_PP":
        print(f"  cle   : {k}")
        print(f"  filt  : {v['filt']}")
        break
