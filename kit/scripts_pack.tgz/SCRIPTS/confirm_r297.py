# -*- coding: utf-8 -*-
"""confirm_r297.py — CONFIRMATION CROISEE python vs MT5 sur la MEME periode.

MT5 (Farm, model=1, depot 100k, 0.1 lot, XAUUSD):
  F1 2021-2025 : solde 100000 -> 109112.48 = +9112.48 $, 4094 deals
  F2 2021-2023 : solde 100000 -> 102485.85 = +2485.85 $, 2438 deals
Risque par trade (0.1 lot) = buf_atr * ATR15 * 10 oz
  ATR15 median reel = 2.3740 -> buf 1.0 => 23.74 $ par trade

On calcule le python EXACTEMENT sur les memes fenetres, avec le meme protocole,
et on convertit en $ pour comparer directement au solde MT5.
"""
import sys, json
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import real_m1
import c13v2_py_v3 as F
import c13v2_engine as ENG
import pandas as pd, numpy as np

M1 = real_m1.load_real("XAUUSD")
BASE = {"imp_atr": 0.7, "imp_vol": 1.0, "imp_look": 6, "ob_age": 32,
        "rej_wick": 0.4, "rej_vol": 1.0, "close_zone": 0.15,
        "bias": "vwap", "excl_hours": [], "lookahead": False, "vwap_len": 96,
        "tp_r": 99, "min_stop": 0.00025, "buf_atr": 1.0, "bias_src": "m5_asof"}
FR = {}
def frames(y0, y1):
    k = (y0, y1)
    if k in FR: return FR[k]
    s = pd.Timestamp(f"{y0}-01-01", tz="UTC"); e = pd.Timestamp(f"{y1+1}-01-01", tz="UTC")
    w = M1.loc[s - pd.Timedelta(days=260):e]
    m5 = F.resample(w, "5min").loc[s:e]
    m15 = F.resample(w, "15min"); h4 = F.resample(w, "4h")
    a15 = ENG.SW.F.atr_s(m15, 14)
    a15i = a15.reindex(a15.index.union(m5.index)).ffill().reindex(m5.index)
    FR[k] = (m5, m15, h4, a15i.to_numpy())
    return FR[k]

def bt(y0, y1, buf=1.0, ext=6.0, sp=14.0, slip=1.0, **over):
    m5, m15, h4, a15 = frames(y0, y1)
    cf = dict(BASE); cf["buf_atr"] = buf; cf.update(over)
    return ENG.run_exit(m5, m15, h4, cf, exit_mode="extend", ext_atr=ext, tp_r=99,
                        spread_pips=sp, point_size=0.01, atr_ref=a15,
                        ext_fill="close", slip_points=slip)

# risque moyen reel par trade (varie avec l ATR au moment de l entree)
def risk_usd(r):
    """Risque moyen en $ pour 0.1 lot, reconstitue depuis les trades.
    On ne stocke que R, donc on approxime avec l ATR15 median."""
    return None

print("=" * 104)
print("R297 — CONFIRMATION CROISEE python (vraies M1) vs MT5 (Farm)")
print("=" * 104)

ATR15_MED = 2.3740
RISK_USD = 1.0 * ATR15_MED * 10.0     # 0.1 lot = 10 oz
print(f"Risque par trade pour 0.1 lot : {RISK_USD:.2f} $ (buf 1.0 x ATR15 {ATR15_MED:.4f} x 10 oz)")

CASES = [
    ("2021-2025 (5 ans)", 2021, 2025, 9112.48, 4094),
    ("2021-2023 (3 ans)", 2021, 2023, 2485.85, 2438),
]
print(f"\n{'fenetre':20s} | {'PY n':>5s} {'PY R':>8s} {'PY $':>10s} | "
      f"{'MT5 deals':>9s} {'MT5 $':>10s} | ratio $")
for lab, y0, y1, mt5_usd, mt5_deals in CASES:
    r = bt(y0, y1)
    py_usd = r["R"] * RISK_USD
    ratio = py_usd / mt5_usd if mt5_usd else 0
    print(f"{lab:20s} | {r['n']:5d} {r['R']:+8.1f} {py_usd:+10.0f} | "
          f"{mt5_deals//2:9d} {mt5_usd:+10.0f} | {ratio:.2f}")

print("\n" + "=" * 104)
print("DETAIL python 2021-2025")
print("=" * 104)
r = bt(2021, 2025)
print(f"  n={r['n']} R={r['R']:+.1f} pf={r['pf']:.3f} wr={r['wr']:.1f}% dd={r['dd']:.1f}")
print(f"  MT5: ~{4094//2} trades, +9112.48 $ = {9112.48/RISK_USD:.0f} R")
print(f"  ecart de R : {r['R'] - 9112.48/RISK_USD:+.1f} R "
      f"({(r['R']/(9112.48/RISK_USD)-1)*100:+.1f} %)")

print("\n" + "=" * 104)
print("VALIDATION FINALE DE LA CONFIG (vraies M1, 2020-2025)")
print("=" * 104)
f = bt(2020, 2025)
print(f"  buf1.0/ext6 : n={f['n']} R={f['R']:+.1f} pf={f['pf']:.3f} wr={f['wr']:.1f}% dd={f['dd']:.1f}")
print(f"  en $ (0.1 lot, risque {RISK_USD:.2f}$/trade) : {f['R']*RISK_USD:+,.0f} $")
tot = 0
for y in range(2020, 2026):
    a = bt(y, y)
    tot += a["R"]
    print(f"    {y}: n={a['n']:4d} R={a['R']:+7.1f} ${a['R']*RISK_USD:+8,.0f} pf={a['pf']:.2f} "
          f"wr={a['wr']:.1f}%")

json.dump({"py_2021_2025": r["R"], "mt5_usd": 9112.48, "risk_usd": RISK_USD},
          open(r"C:\EAFarm\HISTORY - Copy\research\RESULTS_C13V2\r297_confirm.json", "w"),
          indent=1, default=str)
print("\nFIN", flush=True)
