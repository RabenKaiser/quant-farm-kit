﻿import os, re
LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
best=None; bestn=-1
for f in os.listdir(LOGD):
    if ".log" not in f: continue
    p=os.path.join(LOGD,f)
    if os.path.getsize(p)<500: continue
    raw=open(p,"rb").read(4)
    enc="utf-16" if raw[:2] in (b"\xff\xfe",b"\xfe\xff") else "utf-8"
    try: txt=open(p,encoding=enc,errors="replace").read()
    except Exception: continue
    n = txt.count("ORION OPEN EURAUD")
    if n>bestn: best, bestn, bt = p, n, txt
if best:
    print(f"log : {os.path.basename(best)}")
    print(f"  ORION OPEN EURAUD  : {bt.count('ORION OPEN EURAUD')}")
    print(f"  ORION CLOSE        : {bt.count('ORION CLOSE')}")
    print(f"  ORION REJET        : {bt.count('ORION REJET')}")
    # combien de deals de fermeture ?
    print(f"  'deal performed'   : {bt.count('deal performed')}")
    # duree entre premier OPEN et dernier OPEN
    op = re.findall(r"(\d{4}\.\d\d\.\d\d \d\d:\d\d:\d\d)\s+ORION OPEN EURAUD", bt)
    cl = re.findall(r"(\d{4}\.\d\d\.\d\d \d\d:\d\d:\d\d)\s+ORION CLOSE", bt)
    print(f"  premier OPEN : {op[0] if op else '-'}")
    print(f"  dernier OPEN : {op[-1] if op else '-'}")
    if cl: print(f"  premier/dernier CLOSE : {cl[0]} / {cl[-1]}")
