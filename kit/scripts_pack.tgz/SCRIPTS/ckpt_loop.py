# -*- coding: utf-8 -*-
"""ckpt_loop.py — CHECKPOINTS PERIODIQUES automatiques.

Lance checkpoint.py toutes les PERIODE_S secondes, indefiniment. Comme ca un
checkpoint existe TOUJOURS, meme si personne ne pense a le demander.

Usage : python ckpt_loop.py [periode_secondes]   (defaut 1800 = 30 min)
"""
import subprocess, sys, time, os, datetime as dt

SCRIPTS = r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS"
PERIODE = int(sys.argv[1]) if len(sys.argv) > 1 else 1800

print(f"ckpt_loop demarre : checkpoint toutes les {PERIODE} s", flush=True)
while True:
    t = dt.datetime.now().strftime("%H:%M:%S")
    try:
        r = subprocess.run([sys.executable, "-u", "checkpoint.py", "--quiet"],
                           cwd=SCRIPTS, timeout=1200, capture_output=True)
        ok = "OK" if r.returncode == 0 else f"code {r.returncode}"
    except Exception as e:
        ok = f"erreur {e}"
    print(f"[{t}] checkpoint : {ok}", flush=True)
    time.sleep(PERIODE)
