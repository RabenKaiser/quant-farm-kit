# -*- coding: utf-8 -*-
import polars as pl
p = r'C:\EAFarm\HISTORY - Copy\research\stack_engine_out\engine_results.parquet'
df = pl.read_parquet(p)
lines = []
lines.append('cols: ' + str(df.columns))
lines.append('rows: ' + str(df.height))
lines.append(str(df.head(3)))
for e in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]:
    row = []
    for x in [1, 2, 3, 4]:
        sub = df.filter((pl.col('E') == e) & (pl.col('F') == 1) & (pl.col('X') == x))
        if sub.height:
            pos = sub.filter(pl.col('R') > 0).height
            tot = sub.select(pl.col('R').sum()).item()
            row.append('E%dF1X%d:%d/%d R=%.0f' % (e, x, pos, sub.height, tot))
    if row:
        lines.append(' | '.join(row))
out = r'C:\EAFarm\HISTORY - Copy\research\engine_query.txt'
with open(out, 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines))
print('written', out)
