"""Build M1 bars from per-month tick chunks.

For each symbol and month:
  - aggregates ticks -> M1 bars (bid & ask OHLC, volumes, spread stats)
  - writes research parquet:  research/<SYM>_M1.parquet (append by month)
  - writes ST5-layout parquet: st5data/<SYM>/Bars/M1/YYYYMM.parquet
                              (time, open, high, low, close, tick_volume, spread, real_volume)

Causality: bar t aggregates ticks with timestamp in [t, t+60s). Bar open time = floor to minute.
Spread stored in ST5 files is in POINTS (ask = close + spread*point).
"""
import polars as pl
import sys, time
from pathlib import Path

HISTORY = Path(r"C:\EAFarm\HISTORY")
CHUNKS = HISTORY / "chunks"
RESEARCH = HISTORY / "research" / "bars"
ST5DATA = HISTORY / "research" / "st5data"

POINT = {
    "EURUSD": 0.00001,
    "USDJPY": 0.001,
    "EURCAD": 0.00001,
    "USATECHIDXUSD": 0.001,
}

# spread cap in PRICE units: 300 points, except US100 index where real
# spreads are 1.4-3.5 index points -> allow 5000 points
SPREAD_CAP = {s: 300 * p for s, p in POINT.items()}
SPREAD_CAP["USATECHIDXUSD"] = 5000 * POINT["USATECHIDXUSD"]

def process_month(sym: str, ym: str) -> None:
    src = CHUNKS / f"{sym}_{ym}.csv"
    if not src.exists():
        return None
    pt = POINT[sym]
    lf = pl.scan_csv(
        src,
        schema_overrides={
            "Timestamp": pl.Utf8,
            "Bid price": pl.Float64,
            "Ask price": pl.Float64,
            "Bid volume": pl.Float64,
            "Ask volume": pl.Float64,
        },
        low_memory=True,
    )
    df = (
        lf.with_columns(
            pl.col("Timestamp").str.replace(r":(\d{3})$", r".$1").str.to_datetime("%Y%m%d %H:%M:%S%.f").alias("ts"),
        )
        .drop_nulls("ts")
        # sanity filters: positive prices, sane spread (<= 300 pts), volumes >= 0
        .filter(
            (pl.col("Bid price") > 0) & (pl.col("Ask price") > 0)
            & (pl.col("Ask price") >= pl.col("Bid price"))
            & ((pl.col("Ask price") - pl.col("Bid price")) <= SPREAD_CAP[sym])
            & (pl.col("Bid volume") >= 0) & (pl.col("Ask volume") >= 0)
        )
        .with_columns(
            pl.col("ts").dt.truncate("1m").dt.epoch("s").alias("time"),
            (pl.col("Ask price") - pl.col("Bid price")).alias("spread_px"),
        )
        .group_by("time")
        .agg(
            pl.col("Bid price").first().alias("bid_o"),
            pl.col("Bid price").max().alias("bid_h"),
            pl.col("Bid price").min().alias("bid_l"),
            pl.col("Bid price").last().alias("bid_c"),
            pl.col("Ask price").first().alias("ask_o"),
            pl.col("Ask price").max().alias("ask_h"),
            pl.col("Ask price").min().alias("ask_l"),
            pl.col("Ask price").last().alias("ask_c"),
            pl.col("Bid volume").sum().alias("bid_vol"),
            pl.col("Ask volume").sum().alias("ask_vol"),
            pl.len().alias("n_ticks"),
            pl.col("spread_px").median().alias("spread_med"),
            pl.col("spread_px").max().alias("spread_max"),
        )
        .sort("time")
        .collect()
    )
    if df.is_empty():
        return None

    # research file (append per month)
    RESEARCH.mkdir(parents=True, exist_ok=True)

    # ST5 layout
    out = (
        df.select(
            pl.col("time"),
            pl.col("bid_o").alias("open"),
            pl.col("bid_h").alias("high"),
            pl.col("bid_l").alias("low"),
            pl.col("bid_c").alias("close"),
            pl.col("n_ticks").alias("tick_volume"),
            (pl.col("spread_med") / pt).round(1).alias("spread"),
            (pl.col("bid_vol") + pl.col("ask_vol")).alias("real_volume"),
        )
        .sort("time")
    )
    d = ST5DATA / sym / "Bars" / "M1"
    d.mkdir(parents=True, exist_ok=True)
    out.write_parquet(d / f"{ym}.parquet")
    return df

if __name__ == "__main__":
    # merge research M1 across months into a single file per symbol
    symbols = sys.argv[1:] or ["EURUSD", "USDJPY", "EURCAD", "USATECHIDXUSD"]
    for sym in symbols:
        months = sorted(p.stem.removeprefix(f"{sym}_") for p in CHUNKS.glob(f"{sym}_*.csv"))
        parts = []
        for ym in months:
            t0 = time.time()
            r = process_month(sym, ym)
            if r is not None:
                parts.append(r)
            print(f"{sym} {ym}: {0 if r is None else len(r)} bars in {time.time()-t0:.1f}s", flush=True)
        if parts:
            full = pl.concat(parts).sort("time")
            RESEARCH.mkdir(parents=True, exist_ok=True)
            full.write_parquet(RESEARCH / f"{sym}_M1.parquet")
            print(f"{sym}: TOTAL {len(full)} M1 bars -> {RESEARCH / (sym + '_M1.parquet')}", flush=True)
