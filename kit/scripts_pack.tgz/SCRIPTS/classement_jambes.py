"""classement_jambes : quelles jambes garder, decide par le rapport edge/variance.

Round 311. Le portefeuille a 5 jambes decorrelees a echoue a TOUS les niveaux de risque testes,
alors que la theorie du round 310 disait que le rendement croit avec le nombre de transactions et
que le drawdown en R ne croit que comme son logarithme. L'erreur de raisonnement est maintenant
claire : **la theorie ne vaut que si chaque jambe ajoutee a un rapport edge/variance comparable.**

Le drawdown maximal attendu d'une suite de N transactions de moyenne mu et d'ecart-type sigma vaut

    E[DD_max] ~ (sigma^2 / (2 mu)) * ln(N)

Il depend donc du rapport **mu / sigma^2**, et non du nombre de transactions en soi. Une jambe a
mu = +0,023 et sigma = 1,3 degrade le rapport global (elle ajoute ln(N) au drawdown tout en tirant
la moyenne vers le bas) ; une jambe a mu = +0,12 et sigma = 1,3 l'ameliore. C'est ce classement, et
non le R/tx seul, qui doit decider de la composition du portefeuille.

Ce script lit les transactions datees d'un portefeuille candidat, calcule pour chaque paire mu,
sigma, N et mu/sigma^2, puis simule la regle prop sur les meilleures jambes, de 2 a 6, a risque
fixe, et affiche le rendement mensuel et le drawdown de chaque taille de portefeuille.
"""
import csv
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import prop_jambes as PJ

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
CSV = Path(os.environ.get("CSV", str(B / "JAMBES_MULTI.csv")))
RISQUE = float(os.environ.get("RISQUE", "0.20"))
OUT = Path(os.environ.get("SORTIE", str(B / "CLASSEMENT_JAMBES.md")))


def charge():
    par_paire = defaultdict(list)
    with CSV.open(encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            par_paire[r["paire"]].append((r["date"], float(r["R"])))
    for p in par_paire:
        par_paire[p].sort()
    return par_paire


def main():
    if not CSV.exists():
        print("CSV absent : %s" % CSV)
        return 1
    pp = charge()
    stats = []
    for p, tr in pp.items():
        R = np.array([x[1] for x in tr])
        mu, sd = float(np.mean(R)), float(np.std(R))
        st = dict(paire=p, n=len(R), mu=mu, sd=sd,
                  ratio=(mu / (sd * sd) if sd > 0 else 0.0),
                  dd_theo=(sd * sd / (2 * mu) * np.log(len(R)) if mu > 0 else 999.0))
        stats.append(st)
    stats.sort(key=lambda x: -x["ratio"])
    # UNE JAMBE PAR PAIRE : deux couples de la meme paire ne sont pas deux paris, c'est le meme
    # augmenté -- et la contrainte "pas de couverture sur une paire" interdit de les tenir ensemble.
    # On garde donc, par paire, le couple au meilleur rapport edge/variance.
    vues, uniques = set(), []
    for s in stats:
        if s["paire"] in vues:
            continue
        vues.add(s["paire"])
        uniques.append(s)
    doublons = len(stats) - len(uniques)
    print("=== RAPPORT EDGE/VARIANCE PAR JAMBE (%d couples, %s) ===" % (len(stats), CSV.name))
    print("  %-9s %6s %8s %7s %9s %12s %s" % ("paire", "N", "mu (R)", "sigma", "mu/sigma2",
                                              "DD theo (R)", "note"))
    for s in stats:
        print("  %-9s %6d %+8.4f %7.3f %9.4f %12.1f %s"
              % (s["paire"], s["n"], s["mu"], s["sd"], s["ratio"], s["dd_theo"],
                 "RETENUE" if s in uniques else "meme paire"))
    print("  (%d couples -> %d paires distinctes : une seule jambe par paire est retenue)"
          % (len(stats), len(uniques)))
    lignes = ["# CLASSEMENT DES JAMBES PAR RAPPORT EDGE/VARIANCE", "",
              "Le drawdown maximal attendu vaut (sigma^2 / 2 mu) x ln(N) : il depend du rapport "
              "**mu / sigma^2**, pas du nombre de transactions. Une jambe n'ameliore le "
              "portefeuille que si son rapport est au moins comparable a celui des jambes deja "
              "retenues. Une seule jambe par paire est retenue (le meilleur rapport), car deux "
              "couples de la meme paire ne sont pas deux paris.", "",
              "| paire | N | mu (R) | sigma | mu/sigma2 | DD theorique (R) | note |",
              "|---|---|---|---|---|---|---|"]
    for s in stats:
        lignes.append("| %s | %d | %+.4f | %.3f | %.4f | %.1f | %s |"
                      % (s["paire"], s["n"], s["mu"], s["sd"], s["ratio"], s["dd_theo"],
                         "RETENUE" if s in uniques else "meme paire"))

    # --- simulation par taille de portefeuille, jambes prises dans l'ordre du classement ----
    tous = []
    for p, tr in pp.items():
        for d, v in tr:
            tous.append((d, p, v))
    print("\n=== SIMULATION PROP A %.2f %% PAR TRANSACTION, PAR TAILLE ===" % RISQUE)
    lignes += ["", "## Simulation de la regle prop (%.2f %% de risque par transaction)" % RISQUE,
               "", "| jambes | composition | rendement | mois moyens | pire mois | DD max | coupe |",
               "|---|---|---|---|---|---|---|"]
    for k in range(2, min(9, len(uniques) + 1)):
        gardees = {s["paire"] for s in uniques[:k]}
        sous = [(PJ.datetime.strptime(d, "%Y-%m-%d %H:%M"), p, v)
                for d, p, v in tous if p in gardees]
        sous.sort()
        s = PJ.simule(sous, RISQUE)
        ret = 100.0 * (s["eq"] - PJ.CAPITAL) / PJ.CAPITAL
        print("  %d jambes | %+.0f %% | mois moyens %+.2f %% | pire mois %+.2f %% | DD %.2f %% | "
              "coupe %s" % (k, ret, s["moy_mois"], s["pire_mois"], s["dd"], s["coupe"] or "aucune"),
              flush=True)
        lignes.append("| %d | %s | %+.0f %% | %+.2f %% | %+.2f %% | %.2f %% | %s |"
                      % (k, ", ".join(sorted(gardees)), ret, s["moy_mois"], s["pire_mois"],
                         s["dd"], s["coupe"] or "aucune"))
    lignes += ["", "Lecture : la bonne taille de portefeuille est celle qui maximise le rendement "
              "mensuel SANS declencher la coupe. Au-dela, chaque jambe ajoutee degrade le rapport "
              "edge/variance global et rapproche la coupe."]
    OUT.write_text("\n".join(lignes), encoding="utf-8")
    print("\necrit %s" % OUT.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
