"""chaine_finale : enchaine TOUT ce qui reste, sans surveillance humaine.

Round 407. Les rounds precedents ont tourne en boucle a verifier « la campagne a-t-elle fini ? » sans
pouvoir rien lancer, parce que le profil farm est occupe et que la regle du projet est UNE SEULE
campagne par profil (c'est le croisement de deux campagnes qui avait fausse une mesure au round 322).
Ce script transforme cette attente en travail : il attend la fin de la campagne en cours, puis enchaine
automatiquement

    1. la mesure qui manque : XAUUSD L r=20 (SR97W20L, stop 3 ATR / cible 6 ATR), la seule jambe LONGUE
       candidate de la table ;
    2. la reprise des fenetres en echec des campagnes deja lancees (`--resume`, qui ne rejoue que ce
       qui manque) : AUDCAD r=50 (2024Q2), range 100 (2022/2023), EURCAD long r=50 (2021, 2023) ;
    3. la remesure complete : `reel_empile.py` (R/tx reels empiles) puis `ecart_corpus_reel.py`
       (recalibration de l'offset corpus/reel).

Chaque etape est journalisee dans `chaine_finale.log` avec l'heure, et chaque echec est ECRIT au lieu
d'etre avale. Le script est idempotent : relance, il refait les `--resume` (qui sautent ce qui est
deja fait) et remesure.

Usage : python SCRIPTS\\chaine_finale.py
"""
import subprocess
import sys
import time
from pathlib import Path

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
S = B / "SCRIPTS"
LOG = B / "chaine_finale.log"
ATTENTE_MAX_H = 4.0          # au-dela, on considere que la campagne en cours est bloquee
FIN = "termine"              # marqueur ecrit par lab_parallel a la fin d'une campagne


def log(msg):
    ligne = "[%s] %s" % (time.strftime("%H:%M:%S"), msg)
    print(ligne, flush=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(ligne + "\n")


def campagne_en_cours():
    """Vrai si une campagne tourne encore : les journaux de campagne les plus recents n'ont pas tous
    leur marqueur de fin."""
    for f in B.glob("camp_*.log"):
        try:
            t = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if not t.strip():
            continue
        # un journal sans marqueur de fin ET ecrit il y a moins de 10 minutes = campagne vivante
        # ROUND 421 : test PUREMENT TEMPOREL. Un lanceur en cours ecrit une ligne toutes les 35 a 60
        # secondes ; un journal non modifie depuis 3 minutes appartient a une campagne finie. Les deux
        # tests par marqueur ont echoue : le journal se termine par une ligne vide (donc
        # `splitlines()[-1]` valait "") et, meme corrige, le marqueur ne suffit pas -- l'automatisation a
        # attendu de 03:50 a 04:00 une campagne terminee. Le temps est le seul signal qui ne se
        # confonde pas avec autre chose.
        if (time.time() - f.stat().st_mtime) < 180:
            return f.name
    return None


def attendre():
    debut = time.time()
    while time.time() - debut < ATTENTE_MAX_H * 3600:
        vivante = campagne_en_cours()
        if vivante is None:
            log("profil farm libre (aucune campagne active)")
            return True
        log("attente : %s tourne encore" % vivante)
        time.sleep(120)
    log("ATTENTE ABANDONNEE apres %.1f h : la campagne en cours ne rend pas le profil" % ATTENTE_MAX_H)
    return False


def lance(tag, setfile, syms, resume=False):
    """Lance une campagne sur le profil farm, en avalant la sortie dans son propre journal."""
    cmd = [sys.executable, str(S / "lab_parallel.py"), "--only", "farm", "--annuel",
           "--setfile", setfile, "--tag", tag, "--holdout", "autorisation",
           "--syms", syms, "--tf", "M30", "--sl-atr", "3", "--tp-r", "2", "--hold-bars", "64"]
    if resume:
        cmd.append("--resume")
    log("lancement %s (%s) : %s" % (tag, syms, " ".join(cmd[-1:] if resume else [])))
    try:
        # ROUND 424 : la sortie va dans le journal DE LA CAMPAGNE, pas dans un tube. Avec
        # `capture_output=True`, la campagne tournait sans rien ecrire dans `camp_<tag>.log` : on ne
        # pouvait plus distinguer « avance » de « bloquee » (constate au round 423). Ici on ecrit dans
        # le fichier, puis on le relit -- meme information, mais lisible en direct.
        dest = B / ("camp_%s.log" % tag)
        with open(dest, "w", encoding="utf-8") as fh:
            r = subprocess.run(cmd, cwd=str(S), timeout=4 * 3600, stdout=fh,
                               stderr=subprocess.STDOUT)
        try:
            texte = dest.read_text(encoding="utf-8", errors="replace")
        except OSError:
            texte = ""
        fin = [l for l in texte.splitlines() if "TERMINE" in l or "ECHEC" in l]
        log("  %s : code %d, %d lignes de bilan/echec, derniere : %s"
            % (tag, r.returncode, len(fin), fin[-1] if fin else "(aucune)"))
    except subprocess.TimeoutExpired:
        log("  %s : INTERROMPU apres 4 h" % tag)


def mesure(script, env=None):
    log("mesure : %s" % script)
    try:
        r = subprocess.run([sys.executable, str(S / script)], cwd=str(S), timeout=2 * 3600,
                           capture_output=True, text=True, env=env)
        lignes = [l for l in (r.stdout or "").splitlines() if l.strip()]
        for l in lignes[-8:]:
            log("  | %s" % l[:200])
    except subprocess.TimeoutExpired:
        log("  %s : INTERROMPU apres 2 h" % script)


def main():
    log("=== CHAINE FINALE ===")
    if not attendre():
        return 1
    # 1. la mesure qui manque : la seule jambe LONGUE candidate
    lance("long_r20_xauusd", "g_l20.txt", "XAUUSD")
    # 2. reprise des fenetres en echec des campagnes deja connues
    for tag, setfile, syms in (("audcad3atr_b", "g_crest.txt", "AUDCAD"),
                               ("r100_audcad_usd", "g_crest100.txt", "AUDCAD,AUDUSD"),
                               ("long_r50_eurcad", "g_l50.txt", "EURCAD"),
                               ("r20_nzd_aud", "g_c20.txt", "NZDUSD,AUDCAD,AUDUSD"),
                               # ROUND 417 : les deux jambes INDEPENDANTES designees par le crible
                               # mu/sigma2 du round 416 (ni AUD ni NZD), qui sont le seul chemin
                               # restant vers « drawdown sous 5 % ET pire annee positive » :
                               # GBPCAD L r=100 (mu/sigma2 0,152, 5/5 annees positives, attendu
                               # +0,083) et XAUUSD L r=50 (0,147, 5/6, attendu +0,060). La variante
                               # SR97W100L existe dans l'EA depuis le round 316 : rien a recompiler.
                               ("long_r100_gbpcad", "g_l100.txt", "GBPCAD"),
                               ("long_r50_xauusd", "g_l100.txt", "XAUUSD")):
        if (B / ("par_farm_%s.jsonl" % tag)).exists() or (B / ("camp_%s.log" % tag)).exists():
            lance(tag, setfile, syms, resume=True)
        else:
            # ROUND 417 : une campagne NOUVELLE (jambe jamais testee) se lance sans --resume, sinon
            # lab_parallel la saute en croyant qu'elle est deja faite.
            log("  %s : nouvelle campagne, lancement complet" % tag)
            lance(tag, setfile, syms, resume=False)
    # 3. remesure
    mesure("reel_empile.py")
    mesure("ecart_corpus_reel.py")
    log("=== CHAINE FINALE TERMINEE ===")
    return 0


if __name__ == "__main__":
    sys.exit(main())
