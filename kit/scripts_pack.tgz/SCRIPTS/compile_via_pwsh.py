# -*- coding: utf-8 -*-
"""compile_via_pwsh.py — compile via PowerShell (le seul qui marche).
Test : subprocess.run direct retourne 1 ; PowerShell & marche (18:30, 18:48).
"""
import subprocess, time, sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
mq5 = Path(sys.argv[1]).resolve()
ex5 = mq5.with_suffix(".ex5")
if ex5.exists():
    ex5.unlink()
cmd = '& "%s" /compile:"%s" /s' % (r"C:\MT5\MetaEditor64.exe", mq5)
r = subprocess.run(["powershell", "-NoProfile", "-Command", cmd],
                   capture_output=True, timeout=120)
time.sleep(4)
if ex5.exists() and ex5.stat().st_size > 5000:
    print(f"OK {mq5.name} ({ex5.stat().st_size}b)", flush=True)
    sys.exit(0)
print(f"FAIL {mq5.name} rc={r.returncode}", flush=True)
sys.exit(1)
