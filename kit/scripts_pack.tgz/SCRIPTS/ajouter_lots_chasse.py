"""ajouter_lots_chasse.py -- mettre les candidats de la chasse dans la file de la MEAULE.

Pourquoi la meule et pas la ferme de burst : le compte demo de l'instance ne tient plus ses
sessions (round 105), alors que la meule continue de tester en ordres reels depuis son cache.
C'est donc la seule voie disponible pour CONFIRMER les candidats traduits du round 108.

Prudence sur le volume : la meule fait ~2,4 campagnes par heure. On n'ajoute donc que le
HAUT de la liste (12 lots, 2 fenetres chacun = 24 campagnes, ~10 heures) et on garde une
sauvegarde de la file. Les autres candidats resteront dans HUNT_EA.sql pour la ferme de
burst quand son compte demo remarchra.

Usage : python ajouter_lots_chasse.py [nombre_de_lots]
"""
import csv
import json
import shutil
import sys
from pathlib import Path

B = Path(__file__).resolve().parent.parent
FILE = B / "LOTS_V6.json"
CSV = B / "HUNT_EA.csv"
NB = int(sys.argv[1]) if len(sys.argv) > 1 else 12
# ROUND 112 : PAS DE CHAMP FENETRES. Cause exacte trouvee dans le code : `boucle_nuit.py`
# pose LARGE=1, et `lab_parallel.py` fait alors `periodes = list(PERIODE_LARGE)`, soit UNE
# seule periode nommee « 2020-2025.03 » (elle s'arrete AVANT le holdout). Le champ FENETRES
# sert de FILTRE sur les noms de periodes : avec « 2022Q1,2022Q3 » aucun nom ne
# correspondait, le filtre vidait la liste et la campagne tournait a ZERO periode, en
# silence. On n'ecrit donc plus ce champ : la fenetre vient du mode LARGE.
FENETRES = None

lots = json.loads(FILE.read_text(encoding="utf-8"))
print("lots existants :", len(lots))

lignes = list(csv.DictReader(open(CSV, encoding="utf-8")))
print("candidats dans HUNT_EA.csv :", len(lignes))

# on dedoublonne par (marche, etiquette, sens) et on prend le meilleur score
vus, choisis = set(), []
for r in sorted(lignes, key=lambda x: -float(x.get("score") or 0)):
    cle = (r["sym"], r["ea"], r["sens"])
    if cle in vus:
        continue
    vus.add(cle)
    choisis.append(r)
    if len(choisis) >= NB:
        break

print("lots retenus :", len(choisis))
ajoutes = 0
for r in choisis:
    tag = "hunt_%s_%s" % (r["ea"].lower()[:18], r["sym"].lower().replace(".", ""))
    if any(l.get("tag") == tag for l in lots):
        print("   deja present :", tag)
        continue
    lots.append({
        "tag": tag,
        "setfile": "hunt_%s_%s.txt" % (r["ea"].lower(), r["sym"].lower().replace(".", "")),
        "syms": r["sym"],
        "tp_r": 2,
        "hold": 128,
        "tf": int(r["tf"]) if str(r["tf"]).isdigit() else 30,
        "rearm": 0,
        "SLR": "6",
        "lignes": [{"ligne": r["ea"], "plage": 0, "sens": r["sens"], "theta": 0.0, "attendu": 0.0}],
        "note": ("CHASSE 15 (round 108/109) : signal %s traduit en etiquette EA %s. "
                 "Walk-forward : n=%s, R=%s, train=%s, valid=%s, annees+=%s, flux=%s, score=%s. "
                 "Source : HUNT_EA.csv (chasse_15.py + traduire_chasse.py).") % (
            r["signal"], r["ea"], r["n"], r["R"], r["train"], r["valid"], r["annees"], r["flux"], r["score"]),
    })
    ajoutes += 1

if ajoutes:
    shutil.copy(FILE, FILE.with_suffix(".json.bak_avant_chasse"))
    FILE.write_text(json.dumps(lots, indent=1, ensure_ascii=False), encoding="utf-8")
    print("sauvegarde :", FILE.with_suffix(".json.bak_avant_chasse").name)

print("lots ajoutes :", ajoutes, "| total :", len(lots))
# ROUND 620 : `FENETRES` vaut None depuis le correctif (pas de champ = fenetre LARGE unique), donc
# `FENETRES.split(",")` levait AttributeError EN FIN DE SCRIPT -- apres l'ecriture du fichier, ce qui
# rendait la panne invisible. On compte desormais les fenetres reellement demandees.
print("campagnes a venir sur la meule :",
      ajoutes * (1 if not FENETRES else len(FENETRES.split(","))))
for l in lots[-ajoutes:]:
    print("   %-40s %-10s %s %s" % (l["tag"], l["syms"], l["lignes"][0]["ligne"], l["lignes"][0]["sens"]))
