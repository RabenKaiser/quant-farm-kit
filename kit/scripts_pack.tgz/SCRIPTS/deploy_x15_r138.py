# -*- coding: utf-8 -*-
"""deploy_x15_r138.py — verif deploy x1.5 avec lots EXACTS arrondis."""
import os
import pandas as pd
import numpy as np

TEAM = r"C:\EAFarm\HISTORY - Copy\research\prop_team\equities"
ACCT = 50000.0
LEGS = {"EURUSD": ("equity_UPC-V3INT-EURUSD.csv", 2.85),
        "GBPJPY": ("equity_UPC-V3INT-GBPJPY.csv", 3.6),
        "NZDJPY": ("equity_UPC-V3INT-NZDJPY.csv", 1.65),
        "AUDUSD": ("equity_UPC-V3INT-AUDUSD.csv", 3.45),
        "NZDUSD": ("equity_UPC-V3INT-NZDUSD.csv", 3.6),
        "CROSS-EURGBP": ("equity_UPC-CROSS-EURGBP.csv", 7.5),
        "GBPUSD-620": ("equity_UPC-GBPUSD-620.csv", 1.65),
        "DOW": ("equity_UPC-DOW.csv", 0.52),
        "SPX": ("equity_UPC-SPX.csv", 1.65),
        "FRCEUR": ("equity_UPC-FRCEUR.csv", 1.8),
        "VWAPF-XAU": ("equity_UPC-VWAPF-XAU.csv", 0.15),
        "VWAPT-XAU": ("equity_UPC-VWAPT-XAU.csv", 0.09)}
ser = {}
for tag, (f, lots) in LEGS.items():
    p = os.path.join(TEAM, f)
    s = pd.read_csv(p, index_col=0, parse_dates=True).iloc[:, 0]
    ser[tag] = s * (lots / 0.10)
a = pd.concat([s.rename(t) for t, s in ser.items()], axis=1,
              join="outer").fillna(0.0)
a = a.reindex(pd.bdate_range("2026-01-02", "2026-09-01")).fillna(0.0)
comb = a.sum(axis=1)
dr = comb / ACCT
print("=== DEPLOY x1.5 (lots presets EXACTS arrondis) ===")
print(f"sigma/j {dr.std()*100:.2f}% | mean/j {dr.mean()*100:+.3f}% | "
      f"pire {dr.min()*100:+.2f}% | meilleur {dr.max()*100:+.1f}%")
print("\npar leg (lots exacts):")
for tag in LEGS:
    s = a[tag]
    print(f"  {tag:14s} lots {LEGS[tag][1]:>5} | sum {s.sum():+9.0f}$ | "
          f"min/j {s.min():+8.0f} ({s.min()/ACCT*100:+.2f}%) | "
          f"max/j {s.max():+8.0f}")
eq, cd, ds = ACCT, None, ACCT
floor = ACCT * 0.95
kills = 0
stopped = False
eqs = []
for ts, p in comb.items():
    d = ts.date()
    if cd != d:
        cd = d
        ds = eq
    if stopped:
        eqs.append(eq)
        continue
    ne = eq + p
    if ne <= ds * 0.96 and p < 0:
        ne = ds * 0.96
        kills += 1
    eq = ne
    if eq <= floor:
        stopped = True
    eqs.append(eq)
c = pd.Series(eqs, index=comb.index)
mo = c.resample("ME").last().pct_change()
mo.iloc[0] = c.resample("ME").last().iloc[0] / ACCT - 1.0
mo = mo[mo.index < "2026-09-01"]
print(f"\nkills -4%: {kills} | stop -5%: {stopped}")
print(f"moy/mois: {mo.mean()*100:+.2f}% | net 8 mois: {c.iloc[-1]-ACCT:+,.0f}$")
for p, v in mo.items():
    print(f"  {p.strftime('%Y-%m')}: {v*100:+5.2f}%")
worst = comb.sort_values().head(4)
print("\npires jours:")
for d, v in worst.items():
    top = a.loc[d].abs().sort_values(ascending=False)
    det = " | ".join(f"{k}:{a.loc[d,k]:+.0f}" for k in top.index[:3]
                     if abs(a.loc[d, k]) > 5)
    print(f"  {d.date()} {v:+8.0f}$  [{det}]")
print("FIN", flush=True)
