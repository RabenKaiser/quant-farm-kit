﻿import subprocess, time, glob, os, re
from pathlib import Path
FARM = Path(r"C:\EAFarm\MT5\Farm"); TM = FARM/"terminal64.exe"
COMMON = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\Common\Files")
LOGD = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs")
CFG = FARM/"Config"/"config_exp_test.ini"
sym="GBPUSD"; frm="2019.01.01"; to="2019.12.31"
cfg = (f"[Tester]\nExpert=eepeek\\EXPORT_M1.ex5\nSymbol={sym}\nPeriod=M1\n"
       f"Model=0\nOptimization=0\nFromDate={frm}\nToDate={to}\nDeposit=10000\n"
       f"Currency=USD\nLeverage=100\nReplaceReport=1\nShutdownTerminal=1\n"
       f"[TesterInputs]\nInpSymbol={sym}\nInpFrom={frm}\nInpTo={to}\n")
CFG.write_text(cfg)
src = COMMON/f"{sym}_M1.csv"
if src.exists(): src.unlink()
p=subprocess.Popen([str(TM),"/config:"+str(CFG)],cwd=str(FARM),
                   creationflags=0x08000000,
                   stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
w=0; prev=-1; stable=0
while w<600:
    time.sleep(5); w+=5
    cur = src.stat().st_size if src.exists() else 0
    alive = "terminal64" in subprocess.run(["tasklist","/FI",f"PID eq {p.pid}"],
             capture_output=True,text=True).stdout
    stable = stable+1 if (cur>0 and cur==prev) else 0
    prev=cur
    if not alive: break
    if stable>=5 and cur>1000: break
subprocess.run(["taskkill","/F","/IM","terminal64.exe"],capture_output=True)
time.sleep(3)
if src.exists():
    print(f"FICHIER : {src.stat().st_size/1e6:.1f} Mo")
    n = sum(1 for _ in open(src, encoding="utf-8", errors="replace")) - 1
    print(f"lignes  : {n:,} barres M1")
    with open(src, encoding="utf-8", errors="replace") as f:
        next(f); first=f.readline().split(",")[0]; last=None
    for line in open(src, encoding="utf-8", errors="replace"):
        if line.strip(): last=line.split(",")[0]
    from datetime import datetime, timezone
    print("debut :", datetime.fromtimestamp(int(first), tz=timezone.utc))
    print("fin   :", datetime.fromtimestamp(int(last), tz=timezone.utc))
else:
    print("PAS DE FICHIER")
