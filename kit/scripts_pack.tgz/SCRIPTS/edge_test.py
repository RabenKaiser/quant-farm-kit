# -*- coding: utf-8 -*-
"""edge_test.py — TEST APPROFONDI des structures du portefeuille 7 jambes.

LA QUESTION
-----------
Le portefeuille a 7 jambes montre :
  s1 R/DD  6.65  ->  s2 28.86  ->  s3 101.71   (progression x15)
  2024-2025 : 22/22 mois positifs, pire mois +2.189

Cette progression est suspecte. Deux explications possibles :

  (A) EDGE REEL : les structures (FVG baissier + heures calmes) capturent un
      mecanisme de marche qui s'est renforce.
  (B) UN SEUL PARI DEGUISE : les 7 jambes partagent la meme condition
      (fvg_dn_20 x 5, h_quiet/vol_lo, bb_low). Si CE regime a ete favorable en
      2024-25, les 7 gagnent ensemble -> on croit a 7 sources, il y en a 1.

COMMENT TRANCHER — 4 TESTS
--------------------------
  T1. DECOMPOSITION : chaque structure prise SEULE, sur les 3 segments.
      Si elles progressent toutes de la meme facon -> un seul facteur commun.
  T2. CORRELATION CROISEE : les 7 jambes montent-elles et descendent-elles
      ENSEMBLE ? Si oui, ce n'est pas un portefeuille.
  T3. NOMBRE EFFECTIF DE PARIS : via les valeurs propres de la matrice de
      correlation -> combien de paris independants y a-t-il vraiment ?
  T4. CONTROLE PAR MARCHE : la meme structure sur 15 marches. Si elle marche
      sur 12-14 marches, c'est structurel. Si seulement sur ces 7, c'est du
      choix.

Sortie : edge_test.json
"""
import os, sys, json, glob, pickle, gc
import numpy as np
import pandas as pd

SCRIPT_DIR = r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS"
sys.path.insert(0, SCRIPT_DIR)
BASE = r"C:\EAFarm\HISTORY - Copy\research"
SL, TP, HOLD = 1.0, 20.0, 192

import giga_lib as G, deep_lib as D, multi_lab as ML

# ---------------------------------------------------------------- T1 + T2
S = pickle.load(open(os.path.join(BASE, "final7_series.pkl"), "rb"))
series = S["series"]; meta = S["meta"]
ALL = pd.DataFrame(series).sort_index()
n = len(ALL); third = n // 3
x = ALL.fillna(0.0).mean(axis=1)

print("=" * 86)
print("T1. DECOMPOSITION — chaque jambe SEULE, par segment")
print("=" * 86)
print(f"{'jambe':<40}{'s1':>8}{'s2':>8}{'s3':>8}{'prog':>8}")
t1 = {}
for k in ALL.columns:
    v = ALL[k].dropna()
    segs = []
    for a, b in ((0, third), (third, 2*third), (2*third, n)):
        s = v.iloc[a:b]
        if len(s) == 0:
            segs.append(0.0); continue
        eq = np.cumsum(s); dd = float((np.maximum.accumulate(eq)-eq).max())
        segs.append(float(s.sum())/dd if dd > 0 else 0.0)
    prog = segs[2]/segs[0] if segs[0] > 0 else float('inf')
    t1[k] = segs
    short = k.split("|")[0] + " " + k.split("|")[1]
    print(f"{short[:39]:<40}{segs[0]:>8.2f}{segs[1]:>8.2f}{segs[2]:>8.2f}"
          f"{prog:>8.1f}")

print("\n" + "=" * 86)
print("T2. CORRELATION CROISEE des 7 jambes (obs communes)")
print("=" * 86)
C = ALL.corr(min_periods=30)
cols = list(C.columns)
print(f"     " + "".join(f"{i:>7d}" for i in range(len(cols))))
for i, a in enumerate(cols):
    row = "".join(f"{C.iloc[i, j]:>7.2f}" for j in range(len(cols)))
    print(f"  {i}  {row}")
off = C.where(~np.eye(len(C), dtype=bool))
mx = float(off.max().max()); mn = float(off.min().min())
mean_off = float(off.stack().mean())
print(f"\n  correlation moyenne : {mean_off:+.3f}")
print(f"  max : {mx:+.3f}   min : {mn:+.3f}")
print(f"  paires |rho| > 0.5 : {int((off.abs() > 0.5).sum().sum() // 2)}")

print("\n" + "=" * 86)
print("T3. NOMBRE EFFECTIF DE PARIS (valeurs propres)")
print("=" * 86)
Cf = C.fillna(0.0).to_numpy()
ev = np.linalg.eigvalsh(Cf)
ev = np.sort(ev)[::-1]
ev_pos = ev[ev > 0]
# nombre effectif = (somme)^2 / somme(^2)  (indice de participations)
neff = float(ev_pos.sum()**2 / (ev_pos**2).sum()) if len(ev_pos) else 0
print(f"  {len(cols)} jambes nominales")
print(f"  valeurs propres : " + " ".join(f"{v:.2f}" for v in ev_pos[:10]))
print(f"  part de la 1re valeur propre : {100*ev_pos[0]/ev_pos.sum():.1f} %")
print(f"  NOMBRE EFFECTIF DE PARIS : {neff:.2f}")
print(f"  -> un vrai portefeuille de 7 jambes devrait donner ~5-7")
print(f"     si c'est proche de 1-2, c'est UN SEUL pari repete")

# ---------------------------------------------------------------- T4
print("\n" + "=" * 86)
print("T4. LA STRUCTURE PRINCIPALE SUR TOUS LES MARCHES")
print("=" * 86)
# on prend les 3 structures dominantes et on les teste sur les 15 marches
TESTS = [
    ("fvg_dn_20", "h_quiet", "FVG baissier + heures calmes"),
    ("fvg_dn_20", "vol_lo", "FVG baissier + volume faible"),
    ("bb_low", "h_quiet", "exces baissier + heures calmes"),
    ("fvg_dn_20", "", "FVG baissier seul"),
]
syms = sorted(os.path.basename(p)[:-4]
              for p in glob.glob(os.path.join(BASE, "pos_cache", "*.pkl")))
res = {}
for dn, filt, label in TESTS:
    print(f"\n  --- {label}  ({dn}" + (f" + {filt})" if filt else ")"))
    print(f"  {'marche':<9}{'signaux':>9}{'trades':>8}{'R':>9}"
          f"{'rdd_s1':>9}{'rdd_s2':>9}{'rdd_s3':>9}  stable")
    row = {}
    for sym in syms:
        G._cache.clear(); gc.collect()
        try:
            F = G.get_frames(sym)
        except Exception:
            continue
        m5 = F["m5"]
        M, atr = ML.build_all(m5, F["m1"], F)
        if dn not in M or not isinstance(M[dn], np.ndarray) or M[dn].dtype != bool:
            continue
        mask = M[dn]
        if filt:
            if filt not in M or not isinstance(M[filt], np.ndarray) or M[filt].dtype != bool:
                continue
            mask = mask & M[filt]
        nsig = int(mask.sum())
        if nsig < 50:
            continue
        s = np.where(mask, 1.0, 0.0)
        T0, T3_ = m5.index[0], m5.index[-1]
        try:
            st = D.run_ex(sym, s, SL, TP, HOLD, trail_atr=None,
                          t0=T0, t1=T3_, use_m1=False, collect=True)
        except Exception:
            continue
        if not st.get("tse"):
            continue
        ts = pd.to_datetime(st["tse"], unit="s", utc=True).normalize()
        ser = pd.Series(st["rets"], index=ts).groupby(level=0).sum()
        v = ser.reindex(ALL.index).fillna(0.0)
        rr = []
        for a, b in ((0, third), (third, 2*third), (2*third, n)):
            sp = v.iloc[a:b]
            eq = np.cumsum(sp); dd = float((np.maximum.accumulate(eq)-eq).max())
            rr.append(float(sp.sum())/dd if dd > 0 else 0.0)
        stab = all(r > 0 for r in rr)
        row[sym] = dict(nsig=nsig, n=st.get("n", 0), R=st.get("R", 0.0),
                        r1=rr[0], r2=rr[1], r3=rr[2], stable=stab)
        print(f"  {sym:<9}{nsig:>9}{st.get('n',0):>8}{st.get('R',0):>9.1f}"
              f"{rr[0]:>9.2f}{rr[1]:>9.2f}{rr[2]:>9.2f}  "
              f"{'OUI' if stab else '-'}")
    nst = sum(1 for v in row.values() if v["stable"])
    npos = sum(1 for v in row.values() if v["r3"] > 0)
    print(f"  => {len(row)} marches | positifs s3 : {npos} | "
          f"STABLES (3 tiers) : {nst}")
    res[label] = dict(row=row, n_mk=len(row), n_pos=npos, n_stable=nst)

json.dump(dict(t1=t1, corr_mean=mean_off, n_pairs=len(cols),
               eigen=[float(v) for v in ev_pos], n_eff=neff,
               t4=res),
          open(os.path.join(BASE, "edge_test.json"), "w"), indent=1, default=str)
print("\n-> edge_test.json")
