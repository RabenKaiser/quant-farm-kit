# -*- coding: utf-8 -*-
"""choch_test.py — LE CUMUL DE FACTEURS BAT-IL LES STRUCTURES ISOLEES ?

IDEE DE L'UTILISATEUR
---------------------
"Les cross VWAP, c'est bien avec un CHoCH, peut-etre sans wick et un FVG.
 La on a une cumulation de facteurs."

Donc on ne teste plus 17 structures isolees, mais des COMBINAISONS :
   1. FVGDN10 seul                    (reference isolee)
   2. VWAPXDN seul                    (reference isolee)
   3. NOWICKDN seul                   (reference isolee)
   4. CHOCHBULL seul                  (nouveau, isole)
   5. VWAPCHOCHDN                     (VWAP + CHoCH)
   6. VWAPCHOCHEMB                    (VWAP + CHoCH + sans meche)  <-- le cumul

MESURE : every tick (Model=4), 3 mois, memes marches, memes sorties.
Le juge : le nombre de trades ET le pnl. Un cumul doit donner MOINS de
trades mais un MEILLEUR taux de reussite.
"""
import os, sys, json, time, glob, subprocess, re
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
FARM = Path(r"C:\EAFarm\MT5\Farm")
TM = FARM / "terminal64.exe"
DATA = (Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")
        / "CF0B997454318B475CF01419AFE2BBF3")
LOGD = DATA / "Tester" / "logs"
COMM = (Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal")
        / "Common" / "Files")
CFGD = FARM / "Config"
OUT = BASE / "choch_test.json"

# les 6 variantes a comparer, du plus simple au plus cumule
VARIANTES = [
    ("1. FVGDN10 seul",        "FVGDN10",     "VOLLO"),
    ("2. VWAPXDN seul",        "VWAPXDN",     "VOLLO"),
    ("3. NOWICKDN seul",       "NOWICKDN",    "HQUIET"),
    ("4. CHOCHBULL seul",      "CHOCHBULL",   ""),
    ("5. VWAP + CHoCH",        "VWAPCHOCHDN", "VOLLO"),
    ("6. VWAP+CHoCH+noWICK",   "VWAPCHOCHEMB", "VOLLO"),
    ("7. CHoCH seul (bear)",   "CHOCHBEAR",   ""),
]

SYMS = ["CADJPY", "EURUSD", "GBPJPY", "AUDUSD", "USDCHF", "EURJPY",
        "NZDUSD", "USDCAD", "EURGBP", "AUDJPY"]

PERIODS = {
    "DISC": ("2024.01.01", "2024.04.01"),
    "VAL":  ("2024.07.01", "2024.10.01"),
}
MODEL = 4
SL, TP, HOLD = 2.0, 1.5, 48


def kill_duka():
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='terminal64.exe'\" | "
          "Where-Object { $_.ExecutablePath -like 'C:\\EAFarm\\MT5\\Farm\\*' } | "
          "ForEach-Object { Stop-Process -Id $_.ProcessId -Force "
          "-ErrorAction SilentlyContinue }")
    subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def run(sym, trig, filt, p0, p1, wait=900):
    fn = f"CH_{sym}_{trig}.csv"
    (COMM / fn).write_text("%s,1,%s,%.3f,%.1f,%.3f,%d,%d\n"
                           % (trig, filt, SL, TP, 0.0, HOLD, 995000),
                           encoding="ascii")
    cfg = CFGD / "choch.ini"
    cfg.write_text(
        "[Tester]\nExpert=eepeek\\ORION_ROBOT.ex5\nSymbol=%s\nPeriod=M5\n"
        "Model=%d\nOptimization=0\nFromDate=%s\nToDate=%s\nDeposit=100000\n"
        "Currency=USD\nLeverage=100\nReplaceReport=1\nShutdownTerminal=1\n"
        "[TesterInputs]\nInpLots=0.10\nInpMaxPos=1\nInpMaxPerSide=1\n"
        "InpLegsFile=%s\nInpMaxSpreadMult=0\nInpMaxSpreadAtr=0.6\n"
        "InpSessStart=0\nInpSessEnd=24\n"
        "InpDayStopPct=0\nInpMaxDDStopPct=0\n"
        "InpVerbose=true\nInpTrace=false\nInpNoHedge=true\n"
        % (sym, MODEL, p0, p1, fn))
    kill_duka(); time.sleep(2)
    for lf in glob.glob(str(LOGD / "*log*")):
        try:
            os.rename(lf, lf + ".old")
        except Exception:
            pass
    p = subprocess.Popen([str(TM), "/config:" + str(cfg)], cwd=str(FARM),
                         creationflags=0x08000000,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    w = 0
    while w < wait:
        time.sleep(2); w += 2
        rr = subprocess.run(["tasklist", "/FI", "PID eq %d" % p.pid],
                            capture_output=True, text=True)
        if "terminal64" not in rr.stdout:
            break
    kill_duka(); time.sleep(2)
    best, bt = None, 0
    for lf in glob.glob(str(LOGD / "*log*")):
        try:
            if os.path.getsize(lf) < 300:
                continue
            t = os.path.getmtime(lf)
        except OSError:
            continue
        if t > bt:
            best, bt = lf, t
    if not best:
        return None
    raw = open(best, "rb").read()
    txt = (raw.decode("utf-16") if raw[:2] in (b"\xff\xfe", b"\xfe\xff")
           else raw.decode("utf-8", errors="replace"))
    mb = re.search(r"ORION BILAN %s sorties=(\d+) SL=(\d+) TP=(\d+) "
                   r"MAXHOLD=(\d+) autres=(\d+) gagnantes=(\d+) "
                   r"win=([\d.]+)%% pnl=(-?[\d.]+)" % sym, txt)
    if not mb:
        return None
    g = mb.groups()
    return dict(n=int(g[0]), sl=int(g[1]), tp=int(g[2]), mx=int(g[3]),
                win_n=int(g[5]), win=float(g[6]), pnl=float(g[7]))


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "DISC"
    p0, p1 = PERIODS[which]
    res = json.load(open(OUT, encoding="utf-8")) if OUT.exists() else {}
    res.setdefault(which, {})
    print("=" * 100)
    print(f"CUMUL DE FACTEURS — {which} ({p0} -> {p1}) — every tick (Model=4)")
    print("=" * 100)
    for lab, trig, filt in VARIANTES:
        res[which].setdefault(lab, {})
        print(f"\n### {lab}  [{trig} + {filt or '-'}] ###", flush=True)
        for sym in SYMS:
            if sym in res[which][lab]:
                continue
            r = run(sym, trig, filt, p0, p1)
            res[which][lab][sym] = r
            json.dump(res, open(OUT, "w"), indent=1)
            if r and r["n"] >= 3:
                print(f"  {sym:<8} n={r['n']:>3} SL={100*r['sl']/r['n']:>3.0f}% "
                      f"TP={100*r['tp']/r['n']:>3.0f}% win={r['win']:>5.1f}% "
                      f"pnl={r['pnl']:>8.2f}", flush=True)
    print()
    print("=" * 100)
    print(f"SYNTHESE {which} — le cumul bat-il l'isole ?")
    print("=" * 100)
    print(f"{'variante':<24}{'n':>7}{'SL%':>7}{'TP%':>7}{'win%':>8}"
          f"{'pnl':>11}{'pos/tot':>9}")
    print("-" * 100)
    for lab, trig, filt in VARIANTES:
        d = res[which].get(lab, {})
        rs = [v for v in d.values() if v]
        if not rs:
            continue
        n = sum(r["n"] for r in rs)
        if n == 0:
            print(f"{lab:<24}{'0 trade':>40}")
            continue
        sl = sum(r["sl"] for r in rs); tp = sum(r["tp"] for r in rs)
        wn = sum(r["win_n"] for r in rs); pn = sum(r["pnl"] for r in rs)
        pos = sum(1 for r in rs if r["pnl"] > 0)
        print(f"{lab:<24}{n:>7}{100*sl/n:>6.0f}%{100*tp/n:>6.0f}%"
              f"{100*wn/n:>7.1f}%{pn:>11.2f}{pos:>5}/{len(rs)}")
    print(f"\n-> {OUT}")
