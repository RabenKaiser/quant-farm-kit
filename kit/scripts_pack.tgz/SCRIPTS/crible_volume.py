"""crible_volume : combien de transactions et quel mu/sigma2 le corpus peut-il fournir ?

Objectif (round 466, goal 800 rounds) : 4 a 5 %/mois avec >= 70 % de chances de passer le prop. Le
simulateur de passage (passe_prop.py) a chiffre le besoin : environ HUIT FOIS le volume de transactions
du panier actuel a mu/sigma2 egal (41,5 % a x1, 78,9 % a x8), soit ~100 transactions par mois au lieu
de 13. Ce script repond a la question suivante, qui commande tout le programme : **ce volume existe-t-il
dans le corpus, et a quelle qualite ?**

Methode. On balaye les 26 paires x 3 plages x 2 sens a la geometrie cible serree (stop 3 ATR, cible
1 ATR, 64 barres -- la seule qui ait fait monter mu/sigma2 sur les ordres reels), on deduit de chaque
couple le cout honnete de SA paire (spread median / ATR median / 3), et on garde comme apport reel
`attendu = R/tx - cout`. Le volume utile d'un couple n'est ni son R/tx ni son mu/sigma2 seul, c'est
**attendu x n** : c'est lui qui alimente le chemin, et mu/sigma2 x n qui commande la probabilite.

Sortie : CRIBLE_TPR1.csv (toutes les lignes) + un etat des lieux chiffre du volume disponible.
Env : SLR=3 TPR=1 HOLD=64 CORPUS=m1_pos
"""
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import barrieres_m1 as BM  # noqa: E402
import table_honnete as TH  # noqa: E402

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
CORPUS = os.environ.get("CORPUS", "m1_pos")
SORTIE = B / os.environ.get("SORTIE", "CRIBLE_TPR1.csv")
LIGNES = {(50, "S"): "SR97S", (20, "S"): "SR97W20S", (100, "S"): "SR97W100S",
          (50, "L"): "SR97L", (20, "L"): "SR97W20L", (100, "L"): "SR97W100L"}
# Volume du panier reel actuel (round 463-464) : la reference du facteur de densite.
N_PANIER, MOIS_PANIER = 921, 72.0
# Couples DEJA mesures en ordres reels (reel_empile.COMPOS) : ils ne sont pas a valider.
DEJA = {("AUDCAD", 50, "S"), ("AUDCAD", 20, "S"), ("AUDCAD", 100, "S"), ("NZDUSD", 20, "S"),
        ("AUDUSD", 20, "S"), ("AUDUSD", 100, "S"), ("EURCHF", 50, "S"), ("EURGBP", 50, "S"),
        ("EURCAD", 50, "L"), ("XAUUSD", 20, "L"), ("GBPCAD", 100, "L"), ("XAUUSD", 50, "L")}


def main():
    TH.SLR = float(os.environ.get("SLR", "3"))
    TH.TPR = float(os.environ.get("TPR", "1"))
    paires = TH.paires(CORPUS)
    print("crible %s : %d paires, stop %.1f ATR, cible %.1f ATR" % (CORPUS, len(paires), TH.SLR, TH.TPR))
    cache = {}
    lignes = []
    for p in paires:
        if p not in cache:
            cache[p] = BM.charge_m30(p, CORPUS)
        if cache[p] is None:
            continue
        for sens in ("S", "L"):
            for r in (20, 50, 100):
                try:
                    m = TH.mesure(p, CORPUS, r, sens=sens, M=cache[p])
                except Exception as e:                                    # noqa: BLE001
                    print("   %s %s r=%d : %s" % (p, sens, r, e))
                    continue
                if m is None or m["n"] < 30:
                    continue
                sd = float(m.get("sd") or 0.0)
                if sd <= 0:
                    continue
                cout = float(m.get("cout") or 0.0)
                att = m["R"] - cout
                lignes.append(dict(paire=p, sens=sens, range=r, ligne=LIGNES[(r, sens)],
                                   n=int(m["n"]), R=float(m["R"]), cout=cout, attendu=att,
                                   sigma=sd, mus2=m["R"] / sd ** 2, att_s2=att / sd ** 2,
                                   volume=att * m["n"], npos=int(m["n_pos"]), nan=int(m["n_an"]),
                                   deja=(p, r, sens) in DEJA))
        print("   %-8s fait" % p, flush=True)

    with SORTIE.open("w", encoding="utf-8") as f:
        f.write("paire,sens,range,ligne,n,R,tx_cout,attendu,sigma,mus2,att_s2,volume,npos,nan,deja\n")
        for x in sorted(lignes, key=lambda z: -z["volume"]):
            f.write("%(paire)s,%(sens)s,%(range)d,%(ligne)s,%(n)d,%(R).4f,%(cout).4f,%(attendu).4f,"
                    "%(sigma).4f,%(mus2).4f,%(att_s2).4f,%(volume).2f,%(npos)d,%(nan)d,%(deja)s\n" % x)

    pos = [x for x in lignes if x["attendu"] > 0]
    utiles = [x for x in lignes if x["attendu"] > 0.02 and x["npos"] >= 2 * x["nan"] / 3.0]
    neufs = [x for x in utiles if not x["deja"]]
    print("\n=== VOLUME DISPONIBLE DANS LE CORPUS ===")
    print("  %d couples mesures | %d a attendu > 0 | %d a attendu > 0,02 ET >= 2/3 annees positives"
          % (len(lignes), len(pos), len(utiles)))
    print("  dont %d pas encore mesures en ordres reels" % len(neufs))
    vol_neuf = sum(x["n"] for x in neufs)
    print("  transactions disponibles (couples neufs) : %d sur %.0f mois = %.1f tx/mois"
          % (vol_neuf, MOIS_PANIER, vol_neuf / MOIS_PANIER))
    print("  panier reel actuel : %d tx sur %.0f mois = %.1f tx/mois"
          % (N_PANIER, MOIS_PANIER, N_PANIER / MOIS_PANIER))
    print("  -> densite atteignable si TOUT est ajoute : x%.1f"
          % ((vol_neuf + N_PANIER) / N_PANIER))

    print("\n  meilleurs apports de VOLUME (attendu x n) :")
    print("  %-8s %-11s %s %5s %9s %8s %8s %9s" %
          ("paire", "ligne", "s", "n", "attendu", "sigma", "att/s2", "volume"))
    for x in sorted(neufs, key=lambda z: -z["volume"])[:25]:
        print("  %-8s %-11s %s %5d %+9.4f %8.2f %8.3f %9.1f"
              % (x["paire"], x["ligne"], x["sens"], x["n"], x["attendu"], x["sigma"],
                 x["att_s2"], x["volume"]))

    print("\n  meilleurs apports de QUALITE (attendu/sigma2), a attendu > 0,02 :")
    for x in sorted(neufs, key=lambda z: -z["att_s2"])[:15]:
        print("  %-8s %-11s %s n=%3d | attendu %+.4f | sigma %.2f | att/s2 %.3f | volume %6.1f"
              % (x["paire"], x["ligne"], x["sens"], x["n"], x["attendu"], x["sigma"],
                 x["att_s2"], x["volume"]))

    # Facteur de densite apporte par les N meilleurs couples par volume, sous l'hypothese -- A DIRE --
    # que leur qualite est celle du panier : c'est une projection, pas une mesure.
    print("\n  facteur de densite cumule (projection, qualite supposee egale au panier) :")
    cum, n_cum = 0.0, 0
    for k, x in enumerate(sorted(neufs, key=lambda z: -z["volume"]), 1):
        cum += x["n"]
        n_cum = k
        if k in (5, 10, 15, 20, 30, 40) or k == len(neufs):
            print("    %2d couples -> %.0f tx/mois, densite x%.1f (qualite non compte ici)"
                  % (k, (cum + N_PANIER) / MOIS_PANIER, (cum + N_PANIER) / N_PANIER))
        if n_cum >= len(neufs):
            break
    print("\n  -> %s" % SORTIE.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
