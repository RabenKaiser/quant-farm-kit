# -*- coding: utf-8 -*-
"""Comparaison configs VWAP_MOMENTUM en MT5 ticks : P5/SL3/RR2 vs P8/SL2/RR1.5.
3 paires × 2024-2026. La config qui tient en ticks gagne."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner as m

for ea in ["VWAP_MOMENTUM", "VWAP_MOMENTUM_P8"]:
    print(f"\n=== {ea} ===")
    for sym in ["GBPUSD", "EURUSD", "USDJPY"]:
        r = m.run_backtest(ea, sym, "H1", "2024.01.01", "2026.01.01", 10000, max_wait=300)
        if r:
            print(f"  {sym}: profit=${r.get('profit')} n={r.get('trades')} wr={r.get('wr')} pf={r.get('pf')}")
        else:
            print(f"  {sym}: None")
