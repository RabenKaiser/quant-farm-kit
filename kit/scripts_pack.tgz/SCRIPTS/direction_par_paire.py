"""direction_par_paire : tester l'INGREDIENT actif du panier, isolement.

Constat du round 139 : le panier qui passait les cinq seuils de gel ne se
reproduit pas quand on fige le motif ET le sens ; en revanche il se reproduit
quand chaque paire choisit son SENS par stabilite. Hypothese : l'ingredient
actif est le CHOIX DE DIRECTION PAR PAIRE, pas le motif.

Test isole, motif fige a SR n=50, stop 1 ATR, objectif 1 R (donc une seule
direction par paire, conforme a la contrainte prop) :
  A. sens choisi par stabilite sur l'avant-2023      <- l'hypothese
  B. tout COURT (controle)
  C. tout LONG (controle)
  D. 500 tirages aleatoires de sens par paire (controle statistique)

Mesure : les cinq seuils de gel sur les mois >= 2023-01, et le percentile de A
parmi les tirages D.
"""
import random
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import portefeuille_large as PL

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
OUT = B / "direction_par_paire.md"
COUPE = "2023-01"
HOSTILE = (("2024-01", "2024-06"), ("2025-04", "2025-12"))
INDICES = ("SPXUSD", "NSXUSD", "UDXUSD")
TIRAGES = 500


def mois(t):
    return "%04d-%02d" % (t.year, t.month)


def bilan(ms, s):
    eq = pic = dd = 0.0
    for x in s:
        eq += x
        pic = max(pic, eq)
        dd = max(dd, pic - eq)
    h = [x for m, x in zip(ms, s) if any(a <= m <= b for a, b in HOSTILE)]
    ann = sum(1 for m in ms if int(m[:4]) <= 2023)
    rdd = eq / dd if dd > 1e-9 else None
    return dict(R=eq, pire=min(s) if s else 0.0, RDD=rdd,
                host=float(np.mean(h)) if h else 0.0, n=len(ms), ann=ann,
                pos=sum(1 for x in s if x > 0))


def main():
    random.seed(17)
    PL.STOP, PL.RR = 1.0, 1.0
    donnees = {}
    for p, b, cout in PL.charge_tout():
        if p in INDICES:
            continue
        sg = PL.motifs(b)
        par_sens = {}
        for sens in (1, -1):
            idx = sg.get(("SR n=50", sens))
            if idx is None:
                continue
            idx = idx[idx < len(b) - 34]
            R, T = PL.r_par_trade(b, idx, sens, cout)
            if R is None:
                continue
            mm = np.array([mois(t) for t in T])
            per = defaultdict(list)
            for m, x in zip(mm, R):
                per[m].append(x)
            v = {m: float(np.mean(x)) for m, x in per.items() if len(x) >= 10}
            par_sens[sens] = (v, float(np.mean(R)))
        if len(par_sens) == 2:
            donnees[p] = par_sens
    print("paires avec les deux sens : %d" % len(donnees), flush=True)

    def serie(choix):
        par_mois = defaultdict(list)
        for p, sens in choix.items():
            v = donnees[p][sens][0]
            for m, x in v.items():
                if m >= COUPE:
                    par_mois[m].append(x)
        ms = sorted(par_mois)
        s = [float(np.mean(par_mois[m])) for m in ms]
        rt = float(np.mean([donnees[p][sens][1] for p, sens in choix.items()]))
        return ms, s, rt

    # A. sens par stabilite sur l'avant-2023
    choix_stab = {}
    for p, ps in donnees.items():
        best, bs = None, -9e18
        for sens, (v, _) in ps.items():
            av = [x for m, x in v.items() if m < COUPE]
            if len(av) < 6:
                continue
            sc = float(np.mean([1.0 if x > 0 else 0.0 for x in av]))
            if sc > bs:
                bs, best = sc, sens
        if best:
            choix_stab[p] = best
    ms, s, rt = serie(choix_stab)
    bA = bilan(ms, s)
    ctrlB = bilan(*serie({p: -1 for p in donnees})[:2],
                  *[serie({p: -1 for p in donnees})[2]]) if False else None
    msB, sB, rtB = serie({p: -1 for p in donnees})
    bB = bilan(msB, sB)
    msC, sC, rtC = serie({p: 1 for p in donnees})
    bC = bilan(msC, sC)
    tirage = []
    for _ in range(TIRAGES):
        ch = {p: random.choice([1, -1]) for p in donnees}
        tirage.append(bilan(*serie(ch)[:2])["R"])
    tirage.sort()
    pct = 100.0 * sum(1 for x in tirage if x < bA["R"]) / len(tirage)

    out = ["# L'ingredient actif : le CHOIX DE DIRECTION par paire", "",
           "Motif fige : SR n=50, stop 1 ATR, objectif 1 R, une seule direction par paire.",
           "Coupure %s | penalite de sens : %% de paires dont le sens d'avant-2023 est "
           "le bon sens apres" % COUPE, "",
           "| variante | R/tx | R total | pire mois | hostile | R/DD | mois + |",
           "|---|---|---|---|---|---|---|"]
    lignes = (("A. sens par stabilite avant 2023", rt, bA),
              ("B. tout COURT", rtB, bB),
              ("C. tout LONG", rtC, bC))
    for nom, rt_, b in lignes:
        out.append("| %s | %+.4f | %+.4f | %+.4f | %+.4f | %s | %d/%d |"
                   % (nom, rt_, b["R"], b["pire"], b["host"],
                      "%.2f" % b["RDD"] if b["RDD"] else "inf", b["pos"], b["n"]))
    bons = sum(1 for p, sens in choix_stab.items()
               if donnees[p][sens][0] and
               np.mean([x for m, x in donnees[p][sens][0].items() if m >= COUPE] or [0]) > 0)
    out += ["", "Percentile de A face a %d tirages aleatoires de sens : **%.1f** "
            "(R median des tirages %+.4f)" % (TIRAGES, pct, tirage[len(tirage) // 2]),
            "", "Sens retenus (et si le sens tient apres la coupure) :"]
    for p, sens in sorted(choix_stab.items()):
        ap = [x for m, x in donnees[p][sens][0].items() if m >= COUPE]
        tient = "tient" if ap and np.mean(ap) > 0 else "ne tient PAS"
        out.append("- %s : %s d'avant-2023 -> apres : %s (%+.4f)"
                   % (p, "LONG" if sens > 0 else "COURT", tient,
                      float(np.mean(ap)) if ap else 0.0))
    OUT.write_text("\n".join(out), encoding="utf-8")
    print("\n".join(out[:12]), flush=True)
    print("percentile A : %.1f | paires ou le sens tient : %d/%d"
          % (pct, bons, len(choix_stab)), flush=True)
    print("ecrit %s" % OUT, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
