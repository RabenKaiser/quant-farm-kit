"""diag_vwap_famille : combien de signaux la famille VWAP produit-elle, et quel filtre mange tout ?

Le premier essai honnete sur M30 a donne 14 transactions pour six ans sur EURCHF et AUCUNE sur AUDCAD,
alors que l'ancienne mesure (moteur non honnete, M15) annoncait 7 358 transactions sur le corpus. Avant
de conclure que la famille n'a pas de volume, il faut savoir OU les signaux disparaissent : on mesure le
filtre, on ne le suppose pas. (Le fichier `diag_vwap.py` deja present dans le dossier est un vestige d'une
autre epoque -- un EA VWAP_TRAIL_FX -- et n'a rien a voir.)

Usage : python SCRIPTS\\diag_vwap_famille.py [PAIRE ...]
"""
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import barrieres_m1 as BM  # noqa: E402

CORPUS = os.environ.get("CORPUS", "m1_pos")


def compte(M, seuil, fenetre_sd, volmax):
    c, h, l = M["c"], M["h"], M["l"]
    tp = (h + l + c) / 3.0
    g = pd.Series(M["idx"].date).values
    cum = pd.Series(tp).groupby(g).cumsum().values
    cnt = pd.Series(tp).groupby(g).cumcount().values + 1.0
    dev = c - cum / cnt
    sd = pd.Series(dev).rolling(fenetre_sd, min_periods=50).std().values
    z = dev / np.where(sd > 0, sd, np.nan)
    tr = np.maximum(h - l, np.maximum(np.abs(h - np.roll(c, 1)), np.abs(l - np.roll(c, 1))))
    atr = pd.Series(tr).rolling(14, min_periods=5).mean().values
    amed = pd.Series(atr).rolling(500, min_periods=50).median().values
    calme = np.isfinite(amed) & (amed > 0) & (atr < volmax * amed)
    zz = np.nan_to_num(z, nan=0.0)
    return dict(z2=int((zz >= seuil).sum()), z15=int((zz >= 1.5).sum()), calme=int(calme.sum()),
                b2=int(((zz >= seuil) & calme).sum()), b15=int(((zz >= 1.5) & calme).sum()),
                p99=float(np.nanpercentile(np.abs(z), 99)))


def main():
    paires = sys.argv[1:] or ["EURCHF", "AUDCAD", "NZDUSD", "GBPUSD", "XAUUSD"]
    print("%-8s %6s | %-30s | %-30s" % ("paire", "barres", "sd sur 200 barres M30", "sd sur 100 barres M30"))
    print("%-8s %6s | %s | %s" % ("", "", "z>=2  z>=1.5  calme  les2(2)", "z>=2  z>=1.5  calme  les2(2)"))
    for p in paires:
        M = BM.charge_m30(p, CORPUS)
        if M is None:
            print("  %-8s absent" % p)
            continue
        a = compte(M, 2.0, 200, 0.7)
        b = compte(M, 2.0, 100, 0.7)
        print("%-8s %6d | %5d %6d %6d %8d | %5d %6d %6d %8d   (|z| p99 sd200 = %.2f)"
              % (p, len(M["c"]), a["z2"], a["z15"], a["calme"], a["b2"],
                 b["z2"], b["z15"], b["calme"], b["b2"], a["p99"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
