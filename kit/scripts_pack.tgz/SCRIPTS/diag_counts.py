﻿"""Diagnose trade-count divergence: engine vs ST5 for H1 momentum."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import polars as pl
import numpy as np
from pathlib import Path

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
from edge_correct import load_m1, to_tf, seg_of, backtest_m1, POINT
from edge_tf import make_signals_tf

sym = "EURUSD"
m1 = load_m1(sym)
tf = to_tf(m1, 3600)
df = seg_of(tf)
m1s = seg_of(m1)
cfg = {"lookback": 20, "thr": 0.5, "sl_atr": 3.0, "rr": 2.0, "session": None, "slippage_pts": 0.5}

for sname in ["IS-1", "IS-2", "OOS"]:
    seg = df.filter(pl.col("seg") == sname)
    m1seg = m1s.filter(pl.col("seg") == sname)
    f = make_signals_tf(seg, "momentum", cfg)
    sigs = f["sig"].to_numpy()
    n_sig = int((sigs != 0).sum())
    n_buy = int((sigs == 1).sum())
    n_sell = int((sigs == -1).sum())
    # count streaks
    streaks = 0
    prev = 0
    for s in sigs:
        if s != 0 and prev == 0:
            streaks += 1
        prev = s
    trades = backtest_m1(m1seg, seg, f, sym, cfg)
    print(f"{sname}: bars={len(seg)} sig_bars={n_sig} (buy={n_buy} sell={n_sell}) streaks={streaks} trades={len(trades)}")
