"""crible_vwap : LA DEUXIEME FAMILLE. Le crible du corpus a montre que le creneau SR97 en cible serree
ne peut fournir que x2,1 a x2,8 le volume du panier actuel (9 couples a attendu positif sur 156, dont
2 neufs sous la convention calibree) -- alors que l'objectif demande x8 pour 79 % de chances de passer.
Le volume manquant ne viendra donc PAS du meme signal : il faut une autre famille.

La deuxieme famille de la session est l'ecart a la VWAP de session (prop_ecart.py) : prix a +2 sigmas
au-dessus de la VWAP, volatilite BASSE, VENTE, stop 1 ATR, objectif 1 R. Elle avait ete mesuree avec
l'ANCIEN moteur (bid + spread median), celui qui annoncait 38,8 % de gagnantes la ou le reel en donnait
30,7 % : son resultat n'est pas utilisable tel quel. On la remesure ici avec le moteur HONNETE, a la
minute, sortie a l'ask, horizon compte en barres, et avec le cout deduit des donnees -- exactement la
chaine de mesure du creneau SR97 (table_honnete.mesure), pour que les deux familles soient comparables.

Trame : le corpus est en M1 et l'infrastructure honnete travaille sur la grille M30 (charge_m30). Les
filtres de la famille sont donc evalues sur M30 : VWAP de session (moyenne cumulee du prix typique par
jour), ecart a la VWAP en sigmas (ecart-type roulant 200 barres), filtre de regime ATR(14) < 0,7 x
mediane roulante 500. La geometrie de la famille est conservee : stop 1 ATR, objectif 1 ATR, detention
HOLD_BARRES barres (12 = les 24 barres M15 d'origine).

Sortie : CRIBLE_VWAP.csv (memes colonnes que CRIBLE_TPR1.csv, pour roadmap_volume.py).
Env : CORPUS=m1_pos HOLD_BARRES=12 SEUIL_VWAP=2.0 VOLMAX=0.7 SIG_MIN=30
"""
import csv
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import barrieres_m1 as BM  # noqa: E402
import spread_barrieres as SB  # noqa: E402

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
CORPUS = os.environ.get("CORPUS", "m1_pos")
SORTIE = B / os.environ.get("SORTIE", "CRIBLE_VWAP.csv")
SEUIL_VWAP = float(os.environ.get("SEUIL_VWAP", "2.0"))
VOLMAX = float(os.environ.get("VOLMAX", "0.7"))
HOLD_BARRES = int(os.environ.get("HOLD_BARRES", "12"))   # barres M30 de detention
SIG_MIN = int(os.environ.get("SIG_MIN", "30"))
SLR = 1.0                                                # stop 1 ATR (geometrie de la famille)
TPR = 1.0                                                # objectif 1 R
LIGNES = {("S", 1.0): "VWAP2S", ("L", 1.0): "VWAP2L"}
DEJA = set()


def signaux_vwap(M, sens, seuil=SEUIL_VWAP, volmax=VOLMAX):
    """Ecart de la VWAP de session + filtre de volatilite basse, sur la grille M30.

    ROUND 466 : le filtre de volatilite basse et le seuil d'ecart sont PRESQUE INCOMPATIBLES sur la
    grille M30 -- mesure faite (diag_vwap_famille.py) : z >= 2 arrive ~3 000 fois par paire sur six ans,
    le filtre « ATR < 0,7 x mediane » laisse passer ~13 000 barres, et leur INTERSECTION ne fait plus
    que 10 a 60 occurrences. Etre a 2 sigmas de la VWAP de session, c'est justement un regime agite.
    VOLMAX=0 desactive le filtre et rend la famille mesurable ; c'est le seul moyen de savoir si
    l'ecart a la VWAP vaut quelque chose en ordres reels.
    """
    c, h, l, a = M["c"], M["h"], M["l"], M["a"]
    idx = M["idx"]
    tp = (h + l + c) / 3.0
    jour = pd.Series(idx.date, index=range(len(idx)))
    cum = pd.Series(tp).groupby(jour.values).cumsum().values
    cnt = pd.Series(tp).groupby(jour.values).cumcount().values + 1.0
    vwap = cum / cnt
    dev = c - vwap
    sd = pd.Series(dev).rolling(200, min_periods=50).std().values
    z = dev / np.where(sd > 0, sd, np.nan)
    zz = np.nan_to_num(z, nan=0.0)
    sig = np.flatnonzero(zz >= seuil) if sens == "S" else np.flatnonzero(zz <= -seuil)
    if volmax > 0:
        tr = np.maximum(h - l, np.maximum(np.abs(h - np.roll(c, 1)), np.abs(l - np.roll(c, 1))))
        atr = pd.Series(tr).rolling(14, min_periods=5).mean().values
        amed = pd.Series(atr).rolling(500, min_periods=50).median().values
        calme = np.isfinite(amed) & (amed > 0) & (atr < volmax * amed)
        sig = sig[calme[sig]]
    sig = sig[(sig >= 210) & (sig < len(c) - HOLD_BARRES - 2)]
    sig = sig[np.isfinite(a[sig]) & (a[sig] > 0)]
    # UNE POSITION A LA FOIS : on applique l'espacement AVANT la resolution des barrieres, ce qui est
    # strictement equivalent (la garde garde le premier signal de chaque grappe) et evite d'appeler le
    # moteur a la minute sur des signaux qui seront jetes -- 3 000 signaux par paire au lieu de 300.
    garde, dernier = [], -10 ** 9
    for i in sig:
        if i - dernier >= HOLD_BARRES:
            garde.append(i)
            dernier = i
    return np.array(garde, dtype=int) if garde else np.array([], dtype=int)


def mesure(paire, M, sens):
    sig = signaux_vwap(M, sens)
    if len(sig) < 12:
        return None
    o, a, idx = M["o"], M["a"], M["idx"]
    ent = sig + 1
    ent = ent[ent < len(idx) - HOLD_BARRES - 2]
    res = []
    for k in ent:
        st = float(a[k - 1])
        if not np.isfinite(st) or st <= 0:
            continue
        r = BM.issue(M["m1"], int(pd.Timestamp(idx[k]).timestamp()), float(o[k]),
                     st, TPR, SLR, HOLD_BARRES * 30, sens, par_barres=True)
        if r is not None:
            res.append((k, r))
    if len(res) < 12:
        return None
    ent = np.array([k for k, _ in res])
    kind = np.array([r[0] for _, r in res])
    R = np.array([r[1] for _, r in res])
    garde = SB.bloque(idx, ent, R, kind)
    if len(garde) < 12:
        return None
    R, kind = R[garde], kind[garde]
    ans = defaultdict(list)
    for k, r_ in zip(garde, R):
        ans[idx[ent[k]].year].append(r_)
    a_ok = a[np.isfinite(a) & (a > 0)]
    cout = float(np.median(M["spr"][np.isfinite(M["spr"])]) / np.median(a_ok)) if len(a_ok) else np.nan
    return dict(n=len(R), R=float(np.mean(R)), sd=float(np.std(R, ddof=1)),
                gagn=100.0 * float(np.mean(kind == 0)), cout=cout,
                n_an=len(ans), n_pos=sum(1 for v in ans.values() if np.mean(v) > 0),
                ans={y: round(float(np.mean(v)), 4) for y, v in sorted(ans.items())},
                ans_n={y: len(v) for y, v in sorted(ans.items())})


def main():
    # Meme enumeration que le crible du creneau SR97 : les couples sont les fichiers <PAIRE>_M1.csv.
    paires = sorted(p.name[:-7] for p in (B / CORPUS).glob("*_M1.csv"))
    print("crible VWAP sur %s : %d paires | seuil %.1f sigma | ATR < %.2f x mediane | detention %d barres"
          % (CORPUS, len(paires), SEUIL_VWAP, VOLMAX, HOLD_BARRES))
    lignes = []
    for p in paires:
        M = BM.charge_m30(p, CORPUS)
        if M is None:
            print("   %-8s : corpus absent" % p, flush=True)
            continue
        for sens in ("S", "L"):
            m = mesure(p, M, sens)
            if m is None or m["n"] < SIG_MIN or m["sd"] <= 0:
                print("   %-8s %s : %s" % (p, sens, "trop peu" if m is None else "%d tx" % m["n"]),
                      flush=True)
                continue
            cout = m["cout"]
            att = m["R"] - cout
            x = dict(paire=p, sens=sens, range=0, ligne=LIGNES[(sens, SLR)], n=m["n"], R=m["R"],
                     cout=cout, attendu=att, sigma=m["sd"], mus2=m["R"] / m["sd"] ** 2,
                     att_s2=att / m["sd"] ** 2, volume=att * m["n"], npos=m["n_pos"],
                     nan=m["n_an"], deja=False)
            lignes.append(x)
            print("   %-8s %s n=%4d | R/tx %+.4f | gagnantes %.1f %% | sigma %.2f | cout %.3f | "
                  "attendu %+.4f | mu/s2 %.3f | an. pos %d/%d"
                  % (p, sens, m["n"], m["R"], m["gagn"], m["sd"], cout, att,
                     x["mus2"], m["n_pos"], m["n_an"]), flush=True)
            print("        annees : %s" % " ".join("%d %+.3f" % (y, v) for y, v in m["ans"].items()))

    if not lignes:
        print("  aucune mesure")
        return 1
    with SORTIE.open("w", encoding="utf-8") as f:
        f.write("paire,sens,range,ligne,n,R,tx_cout,attendu,sigma,mus2,att_s2,volume,npos,nan,deja\n")
        for x in sorted(lignes, key=lambda z: -z["volume"]):
            f.write("%(paire)s,%(sens)s,%(range)d,%(ligne)s,%(n)d,%(R).4f,%(cout).4f,%(attendu).4f,"
                    "%(sigma).4f,%(mus2).4f,%(att_s2).4f,%(volume).2f,%(npos)d,%(nan)d,%(deja)s\n" % x)

    pos = [x for x in lignes if x["attendu"] > 0]
    ok = [x for x in pos if x["npos"] >= 2 * x["nan"] / 3.0]
    print("\n=== FAMILLE VWAP : %d couples mesures | %d a attendu > 0 | %d avec >= 2/3 annees positives"
          % (len(lignes), len(pos), len(ok)))
    if ok:
        tx = sum(x["n"] for x in ok)
        print("  volume : %d transactions (%.1f tx/mois) | densite ajoutee x%.1f sur le panier de 921"
              % (tx, tx / 72.0, (tx + 921) / 921.0))
        print("  attendu moyen %.4f | sigma moyen %.2f | annees positives moyennes %.1f/%.1f"
              % (np.mean([x["attendu"] for x in ok]), np.mean([x["sigma"] for x in ok]),
                 np.mean([x["npos"] for x in ok]), np.mean([x["nan"] for x in ok])))
    print("\n  -> %s" % SORTIE.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
