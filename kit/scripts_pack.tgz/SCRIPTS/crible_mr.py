# -*- coding: utf-8 -*-
"""crible_mr.py — DES MILLIERS DE CONFIGURATIONS DE RETOUR A LA MOYENNE,
Jugees sur leur SURVIE aux periodes hostiles.

DEMANDE DE L'UTILISATEUR (18/09, 19 h) : "je sais que le retour a la moyenne
peut marcher. Essaie des milliers de combinaisons, comme ca, sur des marches
presque hostiles. Comme ca on sera fort et potentiellement persistant. Trouve
moi le portefeuille le PLUS PERSISTANT."

LE PRINCIPE, ET CE QUI CHANGE PAR RAPPORT A AVANT
-------------------------------------------------
Avant, on classait les configurations par leur R MOYEN. C'est exactement ce qui
a produit tous les faux gagnants du projet (le +84 % par an etait le maximum
d'une variable bornee).

Ici le critere est la PERSISTANCE : une configuration est retenue si elle est
POSITIVE DANS LE PLUS GRAND NOMBRE DE PERIODES, et on regarde d'abord sa PIRE
periode. Une configuration qui gagne beaucoup 5 fois et perd enormement 3 fois
est rejetee ; une configuration qui gagne un peu 8 fois sur 8 est retenue.
C'est la difference entre "brillant" et "robuste", et c'est ce que demande
l'utilisateur.

CE QUI EST BALAYE (des milliers de combinaisons)
    entrees, toutes de style RETOUR A LA MOYENNE :
      - prix dans les 10 % ou 20 % bas/hauts du range de 96 barres
      - fade d'un mouvement de 1.0 ou 1.5 ATR sur 12 ou 24 barres
      - cloture sous/sur la bande de Bollinger (20 periodes, 2 ecarts)
      - RSI(6) sous 20 ou au-dessus de 80
      - trois barres consecutives de meme sens (fade)
      - prix au plus bas/haut des 288 dernieres barres (une journee)
    sorties : stop 1.0/1.5/2.0/3.0/4.0 ATR  x  objectif 0.5/1.0/1.5/2.0 ATR
              x duree 12/24/48 barres
    paires  : 12 paires liquides et peu cheres
    periodes: les 8 trimestres 2024Q1 a 2025Q4 (l'ancien ET le nouveau regime)

CRITERE DE RETENTION (ecrit avant de regarder)
    positif dans au moins 7 periodes sur 8, et pire periode >= -0.05 R.
    Le classement se fait par la PIRE periode, pas par la moyenne.

USAGE : python crible_mr.py
"""
import collections
import statistics
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
M1 = BASE / "m1_pos"
PAIRES = ["EURUSD", "USDJPY", "EURJPY", "AUDJPY", "GBPJPY", "USDCAD",
          "CADJPY", "NZDUSD", "EURGBP", "AUDUSD", "NZDJPY", "EURAUD"]
PERIODES = [("2024Q1", "2024-01-01", "2024-04-01"),
            ("2024Q2", "2024-04-01", "2024-07-01"),
            ("2024Q3", "2024-07-01", "2024-10-01"),
            ("2024Q4", "2024-10-01", "2025-01-01"),
            ("2025Q1", "2025-01-01", "2025-04-01"),
            ("2025Q2", "2025-04-01", "2025-07-01"),
            ("2025Q3", "2025-07-01", "2025-10-01"),
            ("2025Q4", "2025-10-01", "2026-01-01")]
SLS = [1.0, 1.5, 2.0, 3.0, 4.0]
TPS = [0.5, 1.0, 1.5, 2.0]
HOLDS = [12, 24, 48]
HOLD_MAX = max(HOLDS)
PAS = 3
FEN_RANGE, FEN_JOUR = 96, 288
NMIN_PERIODE = 40
NMIN_POSITIVES = 7


def point_de(close):
    ex = close.dropna().astype(str)
    ex = ex[~ex.str.contains("e", case=False, na=False)].head(2000)
    dec = 0
    for x in ex:
        if "." in x:
            dec = max(dec, len(x.split(".")[1]))
    return 10.0 ** (-dec)


def barres(sym):
    p = M1 / ("%s_M1.csv" % sym)
    if not p.exists():
        return None
    d = pd.read_csv(p, usecols=["time", "high", "low", "close", "spread"])
    d["time"] = pd.to_datetime(d["time"], unit="s", utc=True)
    d = d.set_index("time").sort_index()
    pt = point_de(d["close"])
    m5 = d.resample("5min").agg({"high": "max", "low": "min",
                                 "close": "last", "spread": "mean"}).dropna()
    m5["spr"] = m5["spread"] * pt
    pc = m5["close"].shift(1)
    tr = pd.concat([(m5["high"] - m5["low"]).abs(),
                    (m5["high"] - pc).abs(),
                    (m5["low"] - pc).abs()], axis=1).max(axis=1)
    m5["atr"] = tr.rolling(14).mean()
    m5["rhi"] = m5["high"].rolling(FEN_RANGE).max()
    m5["rlo"] = m5["low"].rolling(FEN_RANGE).min()
    m5["jhi"] = m5["high"].rolling(FEN_JOUR).max()
    m5["jlo"] = m5["low"].rolling(FEN_JOUR).min()
    m5["ma"] = m5["close"].rolling(20).mean()
    m5["sd"] = m5["close"].rolling(20).std()
    d1 = m5["close"].diff()
    haut = d1.clip(lower=0).rolling(6).mean()
    bas = (-d1.clip(upper=0)).rolling(6).mean()
    m5["rsi"] = 100 - 100 / (1 + haut / bas.replace(0, np.nan))
    m5["hausse3"] = (m5["close"] > m5["close"].shift(1)) & \
                    (m5["close"].shift(1) > m5["close"].shift(2)) & \
                    (m5["close"].shift(2) > m5["close"].shift(3))
    m5["baisse3"] = (m5["close"] < m5["close"].shift(1)) & \
                    (m5["close"].shift(1) < m5["close"].shift(2)) & \
                    (m5["close"].shift(2) < m5["close"].shift(3))
    return m5.dropna()


def entrees_de(a, regle):
    """Rend (indices, sens) pour une regle de retour a la moyenne."""
    C = a["close"].to_numpy()
    HI = a["rhi"].to_numpy()
    LO = a["rlo"].to_numpy()
    JHI = a["jhi"].to_numpy()
    JLO = a["jlo"].to_numpy()
    MA = a["ma"].to_numpy()
    SD = a["sd"].to_numpy()
    RSI = a["rsi"].to_numpy()
    H3 = a["hausse3"].to_numpy()
    B3 = a["baisse3"].to_numpy()
    n = len(C)
    idx, side = [], []
    for i in range(FEN_JOUR + 2, n - HOLD_MAX - 1, PAS):
        s = 0.0
        if regle == "range20":
            if HI[i] > LO[i]:
                p = (C[i] - LO[i]) / (HI[i] - LO[i])
                if p < 0.20:
                    s = 1.0
                elif p > 0.80:
                    s = -1.0
        elif regle == "range10":
            if HI[i] > LO[i]:
                p = (C[i] - LO[i]) / (HI[i] - LO[i])
                if p < 0.10:
                    s = 1.0
                elif p > 0.90:
                    s = -1.0
        elif regle == "jour":
            if JHI[i] > JLO[i]:
                p = (C[i] - JLO[i]) / (JHI[i] - JLO[i])
                if p < 0.05:
                    s = 1.0
                elif p > 0.95:
                    s = -1.0
        elif regle == "boll":
            if SD[i] > 0:
                if C[i] < MA[i] - 2 * SD[i]:
                    s = 1.0
                elif C[i] > MA[i] + 2 * SD[i]:
                    s = -1.0
        elif regle == "rsi":
            if RSI[i] < 20:
                s = 1.0
            elif RSI[i] > 80:
                s = -1.0
        elif regle == "trois":
            if B3[i]:
                s = 1.0
            elif H3[i]:
                s = -1.0
        if s:
            idx.append(i)
            side.append(s)
    return np.array(idx, dtype=np.int64), np.array(side, dtype=np.float64)


def evalue(a, idx, side):
    """Pour chaque (stop, objectif, duree) : la liste des R."""
    if len(idx) < 50:
        return {}
    H = a["high"].to_numpy()
    L = a["low"].to_numpy()
    C = a["close"].to_numpy()
    A = a["atr"].to_numpy()
    S = a["spr"].to_numpy()
    n = len(C)
    idx = idx[idx < n - HOLD_MAX - 1]
    side = side[:len(idx)]
    if len(idx) < 50:
        return {}
    W = HOLD_MAX
    fen = idx[:, None] + np.arange(1, W + 1)[None, :]
    Hw = H[fen]
    Lw = L[fen]
    spr = np.where(S[idx] > 0, S[idx], 0.0)
    ent = C[idx] + side * spr / 2.0
    # BUG CORRIGE LE 18/09 A 19 h 45, ET C'ETAIT LE BUG QUI FAISAIT TOUT.
    # La version precedente ecrivait :
    #     fav = (Hw - ent) * side        adv = (ent - Lw) * side
    # Pour une VENTE (side = -1) cela inverse l'excursion favorable et
    # l'adverse : le code comptait comme "gain" le mouvement qui perd, et comme
    # "stop" celui qui gagne. Resultat : 91 configurations "retenues" avec
    # +0.06 a +0.16 R, et un total de 31 939 R/an -- contre -0.0413 R par une
    # boucle elementaire independante (SCRIPTS/verif_crible.py).
    # Le controle est desormais systematique : toute configuration retenue doit
    # etre reconfirmee par la boucle elementaire avant d'etre annoncee.
    long_ = (side[:, None] > 0)
    fav = np.where(long_, Hw - ent[:, None], ent[:, None] - Lw)
    adv = np.where(long_, ent[:, None] - Lw, Hw - ent[:, None])
    atr = A[idx]
    out = {}
    for sl_atr in SLS:
        for tp_atr in TPS:
            sl_d = (sl_atr * atr)[:, None]
            tp_d = (tp_atr * atr)[:, None]
            hs = adv >= sl_d
            ht = fav >= tp_d
            any_s = hs.any(axis=1)
            any_t = ht.any(axis=1)
            prem_s = np.where(any_s, hs.argmax(axis=1), W + 1)
            prem_t = np.where(any_t, ht.argmax(axis=1), W + 1)
            for hold in HOLDS:
                franchi = np.minimum(prem_s, prem_t) < hold
                gagne = prem_t < prem_s
                R = np.where(franchi,
                             np.where(gagne, tp_atr / sl_atr, -1.0),
                             np.nan)
                # sortie au marche quand aucune barriere n'est touchee
                j = np.minimum(idx + hold, n - 1)
                sortie = C[j] - side * spr / 2.0
                Rm = (sortie - ent) * side / (sl_atr * atr)
                R = np.where(np.isnan(R), Rm, R)
                out[(sl_atr, tp_atr, hold)] = R
    return out


def main():
    print("=" * 100)
    print("CRIBLE RETOUR A LA MOYENNE — PERSISTANCE SUR 8 TRIMESTRES")
    print("=" * 100)
    ncomb = len(SLS) * len(TPS) * len(HOLDS)
    regles = ["range20", "range10", "jour", "boll", "rsi", "trois"]
    print("   %d regles d'entree x %d sorties = %d configurations par paire"
          % (len(regles), ncomb, len(regles) * ncomb))
    print("   %d paires, %d periodes" % (len(PAIRES), len(PERIODES)))
    print("   critere : positif dans au moins %d periodes sur %d, et pire"
          % (NMIN_POSITIVES, len(PERIODES)))
    print("   periode >= -0.05 R. Classement par la PIRE periode.")
    print()
    bornes = {}
    resultats = []
    for sym in PAIRES:
        m5 = barres(sym)
        if m5 is None:
            continue
        t = m5.index
        bornes[sym] = [(lab, t.searchsorted(pd.Timestamp(a, tz="UTC")),
                        t.searchsorted(pd.Timestamp(b, tz="UTC")))
                       for lab, a, b in PERIODES]
        for regle in regles:
            idx, side = entrees_de(m5, regle)
            if len(idx) < 200:
                continue
            res = evalue(m5, idx, side)
            if not res:
                continue
            for cle, R in res.items():
                par_per = {}
                for lab, x, y in bornes[sym]:
                    masque = (idx >= x) & (idx < y)
                    sub = R[masque]
                    if len(sub) >= NMIN_PERIODE:
                        par_per[lab] = (float(np.mean(sub)), len(sub))
                if len(par_per) < len(PERIODES):
                    continue
                vals = [par_per[lab][0] for lab, _, _ in bornes[sym]
                        if lab in par_per]
                npos = sum(1 for v in vals if v > 0)
                pire = min(vals)
                tot = sum(par_per[lab][1] for lab in par_per)
                resultats.append((sym, regle, cle[0], cle[1], cle[2],
                                  statistics.mean(vals), pire, npos, tot,
                                  par_per))
        print("   %-8s %d configurations evaluees" % (sym, len(resultats)))
    print()
    print("   TOTAL : %d configurations evaluees" % len(resultats))
    retenus = [x for x in resultats
               if x[7] >= NMIN_POSITIVES and x[6] >= -0.05]
    retenus.sort(key=lambda x: -x[6])
    print("   RETENUES (>= %d periodes positives, pire >= -0.05) : %d"
          % (NMIN_POSITIVES, len(retenus)))
    print()
    print("   %-8s %-8s %5s %5s %5s %10s %10s %6s %8s"
          % ("paire", "regle", "stop", "obj", "duree", "R moyen", "PIRE per.",
             "/8", "trades"))
    for x in retenus[:30]:
        print("   %-8s %-8s %5.1f %5.1f %5d %+10.4f %+10.4f %6d %8d"
              % (x[0], x[1], x[2], x[3], x[4], x[5], x[6], x[7], x[8]))
    print()
    if retenus:
        # --- portefeuille : la ou plusieurs periodes sont solides ---------
        print("   PORTEFEUILLE CANDIDAT (agregation des configurations retenues)")
        print("   %-9s %8s %10s %10s" % ("periode", "tx", "R moyen", "verdict"))
        par_per_tot = collections.defaultdict(lambda: [0.0, 0])
        for x in retenus:
            for lab, (v, k) in x[9].items():
                e = par_per_tot[lab]
                e[0] += v * k
                e[1] += k
        for lab, _, _ in PERIODES:
            if lab not in par_per_tot:
                continue
            e = par_per_tot[lab]
            m = e[0] / e[1]
            print("   %-9s %8d %+10.4f %10s"
                  % (lab, int(e[1]), m, "positif" if m > 0 else "NEGATIF"))
        tot_tx = sum(e[1] for e in par_per_tot.values())
        tot_R = sum(e[0] for e in par_per_tot.values())
        m = tot_R / tot_tx if tot_tx else 0
        print()
        print("   R moyen par transaction : %+.4f" % m)
        print("   transactions par an     : %.0f" % (tot_tx / 8 * 4))
        print("   R par an                : %+.0f" % (m * tot_tx / 8 * 4))
        print()
        print("   >>> OBJECTIF 500 R/AN : %s"
              % ("ATTEINT" if m * tot_tx / 8 * 4 >= 500 else
                 "il manque %.0f R/an" % (500 - m * tot_tx / 8 * 4)))
    else:
        print("   >>> AUCUNE configuration ne survit a %d periodes sur %d." % (NMIN_POSITIVES, len(PERIODES)))
        print("       Le style retour a la moyenne, teste sur %d combinaisons et"
              % len(resultats))
        print("       8 trimestres, ne donne pas de regle robuste sur ces paires.")


if __name__ == "__main__":
    main()
