# -*- coding: utf-8 -*-
"""deploy_test_reel.py — GUIDE de déploiement du test réel sur Farm.
Le déploiement manuel MT5 (charts) ne peut pas être entièrement automatisé
(headless), mais ce script :
1. Vérifie que tout est prêt (EAs, configs, terminal)
2. Génère un fichier de contrôle avec les inputs exacts par chart
3. Journalise le lancement
Usage: python deploy_test_reel.py"""
import sys, os, json, time
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

DATA = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3"
PACK = r"C:\EAFarm\SHARED\EA_PACK_V10"
SHARED = r"C:\EAFarm\SHARED"

CONFIGS = {
    "EURUSD Dc25": {"ea": "V45G_EA", "sym": "EURUSD", "tf": "M15",
        "inputs": {"InpDcDelta": 25, "InpMaxTradesDay": 4, "InpFvgMinPts": 12, "InpRetestBars": 192, "InpLadderMax": 6, "InpStartHour": 7, "InpEndHour": 15}},
    "EURUSD Dc35": {"ea": "V45G_EA", "sym": "EURUSD", "tf": "M15",
        "inputs": {"InpDcDelta": 35, "InpMaxTradesDay": 2, "InpFvgMinPts": 12, "InpRetestBars": 192, "InpLadderMax": 6, "InpStartHour": 7, "InpEndHour": 15}},
    "USDJPY Dc40": {"ea": "V45G_EA", "sym": "USDJPY", "tf": "M15",
        "inputs": {"InpDcDelta": 40, "InpMaxTradesDay": 4, "InpFvgMinPts": 14, "InpRetestBars": 384, "InpLadderMax": 6, "InpStartHour": 7, "InpEndHour": 15}},
    "NZDUSD Dc30": {"ea": "V45G_EA", "sym": "NZDUSD", "tf": "M15",
        "inputs": {"InpDcDelta": 30, "InpMaxTradesDay": 4, "InpFvgMinPts": 6, "InpRetestBars": 192, "InpLadderMax": 4, "InpStartHour": 7, "InpEndHour": 15}},
    "GBPUSD Dc25": {"ea": "V45G_EA", "sym": "GBPUSD", "tf": "M15",
        "inputs": {"InpDcDelta": 25, "InpMaxTradesDay": 4, "InpFvgMinPts": 6, "InpRetestBars": 480, "InpLadderMax": 10, "InpStartHour": 7, "InpEndHour": 15}},
}

def main():
    print(f"=== DÉPLOIEMENT TEST RÉEL — {time.strftime('%Y-%m-%d %H:%M:%S')} ===")
    # 1) Vérif EA
    ea_ok = os.path.exists(os.path.join(DATA, "MQL5", "Experts", "eepeek", "V45G_EA.ex5"))
    print(f"1. V45G_EA.ex5 dans eepeek : {'OK' if ea_ok else 'MANQUANT !'}")
    # 2) Vérif terminal exe
    term = os.path.exists(r"C:\EAFarm\MT5\Farm\terminal64.exe")
    print(f"2. terminal64.exe : {'OK' if term else 'MANQUANT !'}")
    # 3) Afficher les 5 configs (pour saisie manuelle)
    print("\n3. CONFIGS À APPLIQUER (5 charts M15) :")
    for name, c in CONFIGS.items():
        inp = ", ".join(f"{k}={v}" for k, v in c["inputs"].items())
        print(f"   [{name}] {c['sym']} M15 : {inp}")
    # 4) Journal
    journal = os.path.join(SHARED, "JOURNAL_TEST_REEL.md")
    print(f"\n4. Journal : {journal} (à compléter au déploiement)")
    print("\n⚠️ Les défauts EA sont M2/R288 — RENSEIGNER les inputs ci-dessus.")

if __name__ == "__main__":
    main()
