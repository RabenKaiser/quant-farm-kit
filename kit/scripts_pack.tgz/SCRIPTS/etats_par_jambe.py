# -*- coding: utf-8 -*-
r"""etats_par_jambe.py -- DANS QUEL ETAT DE MARCHE CHAQUE JAMBE GAGNE-T-ELLE ?

ANGLE NOUVEAU (15/10). On a beaucoup mesure les jambes et les etats separement.
Ici on les CROISE : chaque transaction REELLE d'une jambe est rangee dans l'etat
de marche du moment de son entree (les lettres E/C/T/R du dictionnaire,
triage_filtres.lettres), puis on mesure le mu par etat.

Deux usages :
  1) SAVOIR ce qu'on detient : une jambe peut n'etre vivante que dans UN etat.
     Un portefeuille dont toutes les jambes vivent dans le meme etat n'est pas
     diversifie, meme avec 15 symboles differents.
  2) DECIDER une porte par jambe : si une jambe perd dans un etat donne, on peut
     l'y eteindre (porte du dictionnaire) au lieu de la retirer entierement.

Alignement : l'heure d'entree des transactions reelles (heure serveur de la
ferme) est reportee sur la grille M30 du corpus ; on lit la lettre de la
DERNIERE barre CLOTUREE avant l'entree (aucune anticipation).
"""
import os
import sys
from datetime import datetime
from collections import defaultdict
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE / "SCRIPTS"))
os.environ.setdefault("CORPUS", "m1_ext")
import crible_fib as CF
import triage_filtres as TFM
import charge_propre as CH

D0 = datetime(2024, 1, 2)
JAMBES = ["g3_kelt16h_xauusd", "g3_sr100_usa30idx_4", "g3_kelt32deu_slr6",
          "g3_kelt32jpn_slr6", "g3_scr_keltbrk_ej", "g3_struct_ej_cont"]
LETTRES = ("E", "C", "T", "R")
NOMS = {"E": "expansion", "C": "compression", "T": "tendance", "R": "range"}


def grille_lettres(sym, corpus):
    CF.CORPUS = corpus
    M = CF.grille(sym)
    if M is None:
        return None, None
    atr = CF.atr_serie(M)
    let = TFM.lettres(M, atr)
    return M, let


def etat_entree(M, let, t_in):
    """Lettre de la derniere barre M30 CLOTUREE avant l'entree."""
    idx = np.asarray(M["idx"], dtype="datetime64[ns]")
    t = np.datetime64(t_in.replace(tzinfo=None), "ns")
    k = int(np.searchsorted(idx, t, side="right")) - 1
    if k < 0 or k >= len(let):
        return None
    return str(let[k])


def main():
    corpus_par_sym = {}
    print("%-24s %-10s %6s %s" % ("jambe", "etat", "tx", "mu(R) / total"))
    for tag in JAMBES:
        syms = CH.symboles_du_tag(tag) or CH.symbole_du_tag(tag)
        if not syms:
            continue
        sym = syms[0]
        corpus = "m1_ext" if sym.endswith(".IDX") else "m1_pos"
        if sym not in corpus_par_sym:
            corpus_par_sym[sym] = grille_lettres(sym, corpus)
        M, let = corpus_par_sym[sym]
        tx = [x for x in CH.transactions_propres(tag) if x["t_in"] >= D0]
        if not tx or M is None:
            continue
        par_etat = defaultdict(list)
        for x in tx:
            e = etat_entree(M, let, x["t_in"])
            if e in LETTRES:
                par_etat[e].append(x["R"])
        if not par_etat:
            continue
        for e in LETTRES:
            v = np.array(par_etat.get(e, []), dtype=float)
            if len(v) == 0:
                continue
            print("%-24s %-10s %6d %+8.4f / %+8.1f%s"
                  % (tag[:24], "%s (%s)" % (e, NOMS[e][:5]), len(v), v.mean(), v.sum(),
                     "   <-- perd" if v.mean() < 0 and len(v) >= 20 else ""))
        tous = np.array([x["R"] for x in tx], dtype=float)
        print("%-24s %-10s %6d %+8.4f / %+8.1f" % ("", "TOTAL", len(tous), tous.mean(), tous.sum()))
        print()


if __name__ == "__main__":
    main()