# -*- coding: utf-8 -*-
"""corr_extend_r221.py — corr entre les 3 equities extend 2ATR (dedupe memes
dates) + sauvegarde CSV des R par jour."""
import sys, time
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import c13v2_py_v3 as F
import c13v2_engine as ENG
import pandas as pd
import numpy as np

BASE = {"imp_atr": 0.9, "imp_vol": 1.0, "imp_look": 6, "ob_age": 16,
        "rej_wick": 0.8, "rej_vol": 1.0, "close_zone": 0.15,
        "bias": "vwap", "excl_hours": [6, 7, 12, 15, 19, 23],
        "min_stop": 0.00025, "buf_atr": 0.25, "lookahead": False,
        "vwap_len": 96}
TEAM = r"C:\EAFarm\HISTORY - Copy\research\prop_team\equities"
series = {}
for sym in ["EURUSD", "AUDUSD", "NZDUSD"]:
    m1 = F.load_m1(sym)
    start = pd.Timestamp("2023-01-01", tz="UTC")
    end = pd.Timestamp("2026-01-01", tz="UTC")
    wu = start - pd.Timedelta(days=260)
    m5 = F.resample(m1.loc[wu:end], "5min").loc[start:end]
    m15 = F.resample(m1.loc[wu:end], "15min")
    h4 = F.resample(m1.loc[wu:end], "4h")
    r = ENG.run_exit(m5, m15, h4, dict(BASE), exit_mode="extend",
                     ext_atr=2.0, tp_r=99)
    trades = [(t[0], pd.Timestamp(t[1]).tz_localize(None)) for t in r["trades"]]
    df = pd.DataFrame(trades, columns=["r", "t"]).set_index("t")
    # R par jour
    daily = df["r"].resample("D").sum()
    idx = pd.date_range(pd.Timestamp("2023-01-01"), pd.Timestamp("2025-12-31"), freq="D")
    daily = daily.reindex(idx).fillna(0.0)
    series[sym] = daily
    daily.to_csv(f"{TEAM}\\equity_C13V2X-{sym}-extend2a.csv", header=["R_day"])
    print(f"{sym}: R={df['r'].sum():+.0f} trades={len(df)}", flush=True)

A = pd.DataFrame(series)
A = A[A.index >= "2023-01-02"]
print("\nCORRELATIONS (R par jour, extend 2ATR):")
print(A.corr().round(2))
# combine simple sum
comb = A.sum(axis=1)
eq = comb.cumsum()
dd = float((eq.cummax() - eq).max())
print(f"\nPortefeuille 3 legs (sum R/jour): total {comb.sum():+.0f}R | "
      f"jours {len(comb)} | maxDD {dd:.1f}R")
pos_days = (comb > 0).sum()
neg_days = (comb < 0).sum()
print(f"jours +: {pos_days} | jours -: {neg_days} | pire jour {comb.min():+.2f}")
print("FIN", flush=True)
