"""crible_vwap_mtf : la famille VWAP en MULTI-TRAME -- une trame donne le biais, l'autre donne l'instant.

Round 470 (objectif : « la famille VWAP doit etre remesuree sur plusieurs trames ET en multi-trame »).

Ce qui a ete mesure jusqu'ici : la famille VWAP sur M5, M15 et M30 avec une geometrie fixe. Le cote VENTE
est positif en M15/M30 (+0,045 et +0,041 R/tx) et negatif en M5, le cote ACHAT est mort partout. Mais
chaque mesure etait MONO-TRAME : le signal d'entree et son contexte venaient de la meme trame.

Or la construction classique de cette famille est multi-trame : la trame LENTE dit dans quel sens on a le
droit de travailler, la trame RAPIDE dit quand entrer. Quatre biais sont testes ici, et chacun est evalue
par le moteur honnete (sortie a la minute, premier toucher, egalite = stop, horizon en barres, cout deduit
des donnees de la paire ET de la trame) :

  aucun    : pas de filtre -- la reference mono-trame ;
  tendance : VENTE seulement si la trame lente est sous sa moyenne (ACHAT au-dessus) ;
  z        : VENTE seulement si la trame lente est elle aussi etiree du meme cote de sa VWAP ;
  range    : VENTE seulement si la trame lente est dans le HAUT de son range Donchian (0,8).

Le filtre est applique sur la derniere barre FERMEE de la trame lente (searchsorted), donc sans
anticipation : c'est la regle de mesure du projet.

Env : TRAMES=5,15,30 FACTEUR=4 SEUIL_VWAP=2.0 SEUIL_FILTRE=1.0 SLR=1.5 RATIO=1.0 HOLD_BARRES=24
      MODES=aucun,tendance,z,range PAIRES=EURCHF,... CORPUS=m1_pos
Sortie : CRIBLE_VWAP_MTF.csv
"""
import csv
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import barrieres_m1 as BM  # noqa: E402

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
CORPUS = os.environ.get("CORPUS", "m1_pos")
SORTIE = B / os.environ.get("SORTIE", "CRIBLE_VWAP_MTF.csv")
TRAMES = [int(x) for x in os.environ.get("TRAMES", "5,15,30").split(",")]
FACTEUR = float(os.environ.get("FACTEUR", "4"))
SEUIL_VWAP = float(os.environ.get("SEUIL_VWAP", "2.0"))
SEUIL_FILTRE = float(os.environ.get("SEUIL_FILTRE", "1.0"))
SLR = float(os.environ.get("SLR", "1.5"))
RATIO = float(os.environ.get("RATIO", "1.0"))
HOLD_BARRES = int(os.environ.get("HOLD_BARRES", "24"))
MODES = os.environ.get("MODES", "aucun,tendance,z,range").split(",")
PAIRES = [x for x in os.environ.get("PAIRES", "").split(",") if x]
CLASSE = {"XAUUSD": "OR", "XAGUSD": "OR", "SPXUSD": "INDICE", "NSXUSD": "INDICE", "UDXUSD": "INDICE"}
OFFSETS = {"FX": (0.0602, 0.1360), "OR": (0.0, 0.0), "INDICE": (0.0, 0.0)}


def dev_vwap(M):
    """Ecart a la VWAP de session (remise a zero chaque jour) en sigmas, sur la trame de M."""
    c, h, l, idx = M["c"], M["h"], M["l"], M["idx"]
    tp = (h + l + c) / 3.0
    jour = pd.Series(idx.date).values
    cum = pd.Series(tp).groupby(jour).cumsum().values
    cnt = pd.Series(tp).groupby(jour).cumcount().values + 1.0
    dev = c - cum / cnt
    sd = pd.Series(dev).rolling(200, min_periods=50).std().values
    return np.nan_to_num(dev / np.where(sd > 0, sd, np.nan), nan=0.0)


def contexte(Mf, mode):
    """Condition de biais sur la trame lente, evaluee barre par barre."""
    if mode == "aucun":
        return None
    c = Mf["c"]
    if mode == "tendance":
        ema = pd.Series(c).ewm(span=50, min_periods=20).mean().values
        return np.where(c > ema, 1, -1)          # +1 = haussier, -1 = baissier
    if mode == "z":
        z = dev_vwap(Mf)
        return np.where(z >= SEUIL_FILTRE, 1, (np.where(z <= -SEUIL_FILTRE, -1, 0)))
    if mode == "range":
        df = pd.DataFrame({"h": Mf["h"], "l": Mf["l"], "c": c})
        hi = df.h.rolling(50).max().values
        lo = df.l.rolling(50).min().values
        pos = (c - lo) / np.where(hi - lo > 0, hi - lo, np.nan)
        return np.where(pos >= 0.8, 1, (np.where(pos <= 0.2, -1, 0)))
    raise ValueError("mode inconnu : %s" % mode)


def signaux(M, sens, ctx=None, Mf=None, mode="aucun", minutes=30, minutes_filtre=None):
    z = dev_vwap(M)
    sig = np.flatnonzero(z >= SEUIL_VWAP) if sens == "S" else np.flatnonzero(z <= -SEUIL_VWAP)
    if mode != "aucun" and ctx is not None:
        # ROUND 470 : LA BARRE LENTE DOIT ETRE FERMEE, SINON C'EST DE L'ANTICIPATION. Mon premier essai
        # prenait la barre lente qui CONTIENT l'instant du signal (`searchsorted(side="right") - 1`) :
        # sa cloture tombe 45 minutes APRES celle de la barre rapide en M15/H1, donc le filtre lisait un
        # prix futur -- et il rendait des taux de gagnantes de 84 a 88 % a 1 R, ce qui n'existe pas. On
        # prend desormais la derniere barre lente dont la CLOTURE precede la cloture de la barre rapide.
        t_base_close = M["idx"].values[sig] + np.timedelta64(minutes, "m")
        # Les instants de CLOTURE de la trame lente sont tries : la derniere barre lente cloturee est
        # donc directement `searchsorted(clotures, t, side="right") - 1`.
        clos_f = Mf["idx"].values + np.timedelta64(int(minutes_filtre or (FACTEUR * minutes)), "m")
        pos = np.searchsorted(clos_f, t_base_close, side="right") - 1
        ok = pos >= 0
        garde = np.zeros(len(sig), dtype=bool)
        garde[ok] = ctx[pos[ok]] == (-1 if sens == "S" else 1)
        sig = sig[garde]
    sig = sig[(sig >= 210) & (sig < len(M["c"]) - HOLD_BARRES - 2)]
    garde, dernier = [], -10 ** 9
    for i in sig:
        if i - dernier >= HOLD_BARRES:
            garde.append(i)
            dernier = i
    return np.array(garde, dtype=int) if garde else np.array([], dtype=int)


def mesure(M, sig, sens, minutes):
    if len(sig) < 12:
        return None
    idx, o, a = M["idx"], M["o"], M["a"]
    ent = sig + 1
    ent = ent[ent < len(idx) - HOLD_BARRES - 2]
    res = []
    for k in ent:
        st = float(a[k - 1])
        if not np.isfinite(st) or st <= 0:
            continue
        r = BM.issue(M["m1"], int(pd.Timestamp(idx[k]).timestamp()), float(o[k]),
                     st, RATIO * SLR, SLR, HOLD_BARRES * minutes, sens, par_barres=True)
        if r is not None:
            res.append((k, r))
    if len(res) < 12:
        return None
    ent = np.array([k for k, _ in res])
    kind = np.array([r[0] for _, r in res])
    R = np.array([r[1] for _, r in res])
    ans = defaultdict(list)
    for k, r_ in zip(ent, R):
        ans[idx[k].year].append(r_)
    aok = a[np.isfinite(a) & (a > 0)]
    cout = float(np.median(M["spr"][np.isfinite(M["spr"])]) / np.median(aok)) / SLR if len(aok) else np.nan
    return dict(n=len(R), R=float(np.mean(R)), sd=float(np.std(R, ddof=1)),
                gagn=100.0 * float(np.mean(kind == 0)), cout=cout,
                n_an=len(ans), n_pos=sum(1 for v in ans.values() if np.mean(v) > 0),
                ans={y: round(float(np.mean(v)), 4) for y, v in sorted(ans.items())})


def main():
    pairs = PAIRES or sorted(p.name[:-7] for p in (B / CORPUS).glob("*_M1.csv"))
    print("%d paires | trames %s | facteur %.0f | seuil %.1f sigma | stop %.2f ATR | cible %.1f R | "
          "detention %d barres" % (len(pairs), TRAMES, FACTEUR, SEUIL_VWAP, SLR, RATIO, HOLD_BARRES))
    print("%-8s %4s %4s %-8s %3s | %5s %8s %8s %7s %8s %8s | %9s %6s" %
          ("paire", "base", "filt", "mode", "s", "n", "R/tx", "sigma", "gagn%", "coutR", "mu/s2",
           "attendu", "an.pos"))
    lignes = []
    for p in pairs:
        cls = CLASSE.get(p, "FX")
        for minutes in TRAMES:
            M = BM.charge_tf(p, CORPUS, minutes=minutes)
            if M is None:
                continue
            tm = int(round(minutes * FACTEUR))
            Mf = BM.charge_tf(p, CORPUS, minutes=tm)
            if Mf is None:
                Mf = M
                tm = minutes
            for mode in MODES:
                ctx = contexte(Mf, mode)
                for sens in ("S", "L"):
                    sig = signaux(M, sens, ctx, Mf, mode, minutes=minutes,
                                  minutes_filtre=(tm if Mf is not M else minutes))
                    m = mesure(M, sig, sens, minutes)
                    if m is None or m["sd"] <= 0:
                        print("  %-8s %4d %4d %-8s %s | %s" % (p, minutes, tm, mode, sens,
                                                               "trop peu" if m is None else "plat"),
                              flush=True)
                        continue
                    att = m["R"] - OFFSETS[cls][0 if sens == "S" else 1]
                    print("  %-8s %4d %4d %-8s %s | %5d %+8.4f %8.2f %6.1f %8.3f %8.3f | %+9.4f %3d/%d"
                          % (p, minutes, tm, mode, sens, m["n"], m["R"], m["sd"], m["gagn"],
                             m["cout"], m["R"] / m["sd"] ** 2, att, m["n_pos"], m["n_an"]), flush=True)
                    lignes.append(dict(paire=p, trame=minutes, filtre=tm, mode=mode, sens=sens,
                                       n=m["n"], R=m["R"], sigma=m["sd"], gagn=m["gagn"],
                                       cout=m["cout"], mus2=m["R"] / m["sd"] ** 2, attendu=att,
                                       npos=m["n_pos"], nan=m["n_an"],
                                       annees=" ".join("%d %+.2f" % (y, v) for y, v in m["ans"].items())))
            del M, Mf
    if not lignes:
        print("  aucune mesure")
        return 1
    with SORTIE.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(lignes[0].keys()))
        w.writeheader()
        w.writerows(lignes)
    bon = [x for x in lignes if x["attendu"] > 0 and x["npos"] >= 2 * x["nan"] / 3.0]
    print("\n=== %d mesures | %d RETENUES (attendu > 0 ET >= 2/3 annees positives) ===" % (len(lignes), len(bon)))
    for x in sorted(bon, key=lambda z: -z["attendu"] * z["n"])[:15]:
        print("    %-8s base %3d filtre %3d %-8s %s n=%4d attendu %+.4f mu/s2 %6.3f gagn %4.1f %% %d/%d"
              % (x["paire"], x["trame"], x["filtre"], x["mode"], x["sens"], x["n"], x["attendu"],
                 x["mus2"], x["gagn"], x["npos"], x["nan"]))
    print("\n  EFFET DU FILTRE (attendu moyen par mode, cote VENTE) :")
    for mode in MODES:
        g = [x for x in lignes if x["mode"] == mode and x["sens"] == "S"]
        if g:
            print("    %-8s : %2d mesures | attendu moyen %+.4f | dont positifs %d"
                  % (mode, len(g), np.mean([x["attendu"] for x in g]),
                     sum(1 for x in g if x["attendu"] > 0)))
    print("\n  -> %s" % SORTIE.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
