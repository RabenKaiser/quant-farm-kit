# -*- coding: utf-8 -*-
"""BACKTEST CONJOINT FINAL v2 — portefeuilles séparés + chevauchement.
(a) Portfolio FX (COPY, 33 mois) : PTRAIL 3 jambes — stats complètes
(b) Portfolio indices (HISTORY, 11 mois) : short_sess+vwap_us100+vwap_xau
(c) Corrélation sur le chevauchement (2025-10 → 2025-12, 3 mois + jan-mar 2026)
(d) Portfolio 10 paires COMBINÉ sur la fenêtre commune"""
import csv, json
import numpy as np

R2USD = 50.0   # 1R = 0.5% de 10k

hist = {}
with open(r"C:\EAFarm\SHARED\history_monthly_curves.csv") as f:
    for row in csv.DictReader(f):
        hist.setdefault(row["jambe"], {})[row["mois"]] = float(row["R"])

pc = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\night_results\ptrail_curve.json"))
ptrail = {}
for ym, p, e, d in pc["curve"]:
    ptrail[f"{ym[0]}-{ym[1].split('.')[1]}"] = p

hist_usd = {j: {m: r * R2USD for m, r in d.items()} for j, d in hist.items()}

def stats(name, d, base=10000):
    keys = sorted(d)
    eq, peak, maxdd = 0, 0, 0
    for k in keys:
        eq += d[k]; peak = max(peak, eq); maxdd = max(maxdd, peak - eq)
    tot = sum(d.values())
    n = len(keys)
    print(f"{name}: {n} mois, total {tot:+,.0f}$ ({tot/base*100:+.0f}%), "
          f"moy {tot/max(n,1):+.0f}$/mois ({tot/max(n,1)/base*100:+.2f}%), "
          f"DD {maxdd:+,.0f}$ ({maxdd/base*100:.1f}%), R/DD {tot/maxdd:.2f}" if maxdd else
          f"{name}: {n} mois, total {tot:+,.0f}$")
    return {"n": n, "total": tot, "maxdd": maxdd}

print("=" * 72)
print("(a) PORTFOLIO FX (COPY) — PTRAIL 3 jambes, 33 mois réels")
print("=" * 72)
stats("FX seul", ptrail)

print("\n" + "=" * 72)
print("(b) PORTFOLIO INDICES (HISTORY) — fenêtre 2025-10→2026-08")
print("=" * 72)
indices = {}
for m in sorted(set(hist_usd["short_sess"]) | set(hist_usd["vwap_us100"]) | set(hist_usd["vwap_xau"])):
    if "2025-10" <= m <= "2026-08":
        indices[m] = (hist_usd["short_sess"].get(m, 0) * 0.5 +
                      hist_usd["vwap_us100"].get(m, 0) * 0.5 +
                      hist_usd["vwap_xau"].get(m, 0) * 0.5)
stats("Indices seul (sess*0.5+us100*0.5+xau*0.5)", indices)

print("\n" + "=" * 72)
print("(c) CORRÉLATION sur le CHEVAUCHEMENT (mois communs FX/indices)")
print("=" * 72)
common = sorted(set(ptrail) & set(indices))
print(f"mois communs: {common}")
if len(common) >= 3:
    a = np.array([ptrail[m] for m in common]); b = np.array([indices[m] for m in common])
    if a.std() > 0 and b.std() > 0:
        print(f"corrélation PTRAIL vs INDICES: r={np.corrcoef(a,b)[0,1]:+.2f}")
    else:
        print("std nul — corrélation indéfinie")

print("\n" + "=" * 72)
print("(d) PORTFOLIO 10 PAIRES COMBINÉ (fenêtre commune)")
print("=" * 72)
combo = {}
for m in common:
    combo[m] = ptrail[m] + indices[m]
stats("10 paires combiné", combo)

print("\n" + "=" * 72)
print("DIMENSIONNEMENT PROP — 10 paires combiné")
print("=" * 72)
if combo:
    tot = sum(combo.values()); maxdd = max([0] + [0])
    eq, peak, dd = 0, 0, 0
    for m in sorted(combo):
        eq += combo[m]; peak = max(peak, eq); dd = max(dd, peak - eq)
    avg = tot / len(combo)
    print(f"DD max: {dd:+,.0f}$ ({dd/10000*100:.1f}%) | moyenne {avg:+,.0f}$ ({avg/10000*100:.2f}%/mois)")
    for dd_lim in [5, 8, 10]:
        factor = (dd_lim * 0.7) / (dd / 10000 * 100)
        mavg = avg / 10000 * 100 * factor
        print(f"  Prop {dd_lim}%: scale {factor:.2f}x -> {mavg:+.2f}%/mois, +8% en {8/mavg:.0f} mois")

json.dump({"fx": ptrail, "indices": indices, "combo": combo},
          open(r"C:\EAFarm\HISTORY - Copy\research\night_results\portfolio_10p_final.json", "w"), indent=1)
print("\nsauvé: portfolio_10p_final.json")
