# -*- coding: utf-8 -*-
"""DECOUPE DES CAMPAGNES MULTI-SYMBOLES EN LOTS PAR SYMBOLE.

MESURE DU 24/09 A 20 h 06 : la campagne de divergence RSI a quatre symboles (HKG, DEU, USA30, CHI)
tournait depuis 26 minutes sur sa PREMIERE fenetre, avec 247 entrees reelles deja passees -- le stop
serre genere beaucoup plus d'operations que les campagnes precedentes, et le testeur avance au rythme
des ordres. A ce rythme, quatre symboles fois dix fenetres demandent plus de seize heures : le lanceur
interrompt une campagne au bout de six heures, donc elle ne finirait JAMAIS et la mesure ne verrait
jamais un lot complet. On decoupe donc : un lot par symbole, environ deux heures chacun, et la chaine
de mesure peut travailler sur des lots termines.
"""
import json
from pathlib import Path

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
CHEMIN = B / "LOTS_V6.json"
NOTE = (" DECOUPE PAR SYMBOLE : la mesure du 24/09 a montre qu'une fenetre de divergence RSI au stop "
        "de 1,5 ATR prend environ 25 minutes (247 entrees reelles sur la seule fenetre 2020) ; une "
        "campagne a quatre symboles depassait donc le delai de six heures du lanceur et n'etait jamais "
        "terminee. Un lot par symbole finit en deux heures et la mesure peut tourner dessus.")


def main():
    lots = json.loads(CHEMIN.read_text(encoding="utf-8"))
    par = {l["tag"]: l for l in lots}

    def copie(base, tag, syms):
        if base not in par:
            return None
        l = dict(par[base])
        l["tag"] = tag
        l["syms"] = syms
        l["note"] = l.get("note", "") + NOTE
        return l

    nouveaux = []
    for base, couples in (("g3_rsidiv_idx_s15_2", (("HKG.IDX", "g3_rsidiv_hkg_s15_2"),
                                                  ("USA30.IDX", "g3_rsidiv_usa30_s15_2"),
                                                  ("DEU.IDX", "g3_rsidiv_deu_s15_2"))),
                          ("g3_rsidiv_idx_2", (("HKG.IDX", "g3_rsidiv_hkg_3"),)),
                          ("g3_keltbrk_idx_m30_2", (("USA30.IDX", "g3_keltbrk_usa30_m30_2"),))):
        for sym, tag in couples:
            l = copie(base, tag, sym)
            if l:
                nouveaux.append(l)
    remplaces = ("g3_rsidiv_idx_s15_2", "g3_rsidiv_idx_2", "g3_keltbrk_idx_m30_2")
    garde = [l for l in lots if l["tag"] not in remplaces]
    final = nouveaux + garde
    CHEMIN.write_text(json.dumps(final, ensure_ascii=False, indent=1), encoding="utf-8")
    print("LOTS_V6 : %d lots" % len(final))
    for i, l in enumerate(final, 1):
        print("  %2d. %-26s %-22s tf=%-3s SLR=%s" % (i, l["tag"], l["syms"][:22], l.get("tf"), l.get("SLR", "3")))


if __name__ == "__main__":
    main()
