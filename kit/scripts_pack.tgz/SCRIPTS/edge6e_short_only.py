# -*- coding: utf-8 -*-
"""edge_6E SHORT-ONLY : fade de la branche HAUTE (range >1.80x, cassure
haussière -> short). Objectif : trouver le short complémentaire qui rapporte
quand PTRAIL long perd (2024 H1, 2025.01-02, 2025.05, 2025.08)."""
import sys, numpy as np, pandas as pd
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\edge_6E")
from strategie import signal, executer, preparer
from protocole import porte2_concordance

# charge M15 réel (2022-2026)
m15 = pd.read_csv(r"C:\EAFarm\HISTORY - Copy\research\edge_6E\donnees_m15.csv",
                  parse_dates=['dt']).set_index('dt').sort_index()

def signal_short_only(df, fenetres=(8, 10, 12), mediane=100, seuil_bas=0.60,
                      seuil_haut=1.80, votes_min=2, fin_asie=7, heures_bannies=(23, 0, 1)):
    C, H, L = df.c.values, df.h.values, df.l.values
    heures = df.index.hour.values
    bannies = np.isin(heures, list(heures_bannies))
    asie = heures < fin_asie
    votes = np.zeros((len(fenetres), len(C)))
    for k, Lw in enumerate(fenetres):
        haut = pd.Series(H).rolling(Lw).max().shift(1).values
        bas = pd.Series(L).rolling(Lw).min().shift(1).values
        rng = haut - bas
        ref = pd.Series(rng).rolling(mediane).median().shift(1).values
        ratio = rng / ref
        casse = np.where(C > haut, 1, np.where(C < bas, -1, 0))
        # SHORT-ONLY : fade UNIQUEMENT la cassure HAUSSIÈRE d'un range LARGE (hors Asie)
        extreme_haut = (ratio > seuil_haut) & ~asie
        retenu = np.isfinite(ratio) & (casse == 1) & extreme_haut
        votes[k] = np.where(retenu, -1, 0)
    somme = votes.sum(0)
    nb = (votes != 0).sum(0)
    accord = (nb >= votes_min) & (np.abs(somme) == nb)
    return np.where(accord & ~bannies, -1.0, 0.0)

# test par année
for y0, y1 in [("2023-01-01", "2024-01-01"), ("2024-01-01", "2025-01-01"),
               ("2025-01-01", "2026-01-01")]:
    m1w = m15[(m15.index >= y0) & (m15.index < y1)]
    m30 = preparer(m1w, '30min')
    sig = signal_short_only(m30)
    tr = executer(m30, m1w, sig, segment=None)
    tr = tr[tr.seg != 'x']
    if len(tr):
        net = tr.net.mean()
        t = net / (tr.net.std() / np.sqrt(len(tr)))
        print(f"edge_6E SHORT-ONLY {y0[:4]}: n={len(tr)} net={net:+.4f}R t={t:+.2f} "
              f"somme={tr.net.sum():+.1f}R wins={int((tr.net>0).sum())}")
    else:
        print(f"edge_6E SHORT-ONLY {y0[:4]}: 0 trades")
