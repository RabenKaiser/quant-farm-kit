﻿"""Edge research v2 â€” signed order-flow imbalance + session + reversal families.

Uses M1_signed bars (mid-price tick classification). Testable hypotheses:
  A) Flow imbalance (continuation): buy when vol_up >> vol_down over window
  B) Flow imbalance extreme reversal: buy when sellers exhausted
  C) Session effects (hour-of-day forward returns)
  D) Volatility/range regime filters
Protocol: IS-1 / IS-2 / OOS same-sign rule, cost = spread + slippage, entry next bar.
"""
import polars as pl
import numpy as np
import sys, json
from pathlib import Path

RESEARCH = Path(r"C:\EAFarm\HISTORY - Copy\research")
BARS = RESEARCH / "bars"
POINT = {"EURUSD": 0.00001, "USDJPY": 0.001, "EURCAD": 0.00001, "USATECHIDXUSD": 0.001}

def load_m1(sym):
    p = BARS / f"{sym}_M1_signed.parquet"
    if not p.exists():
        p = BARS / f"{sym}_M1.parquet"
    return pl.read_parquet(p).sort("time")

def to_tf(m1, tf_sec):
    return (
        m1.with_columns((pl.col("time") // tf_sec * tf_sec).alias("t"))
        .group_by("t")
        .agg(
            pl.col("bid_o").first().alias("bid_o"),
            pl.col("bid_h").max().alias("bid_h"),
            pl.col("bid_l").min().alias("bid_l"),
            pl.col("bid_c").last().alias("bid_c"),
            pl.col("ask_o").first().alias("ask_o"),
            pl.col("ask_c").last().alias("ask_c"),
            pl.col("mid_o").first().alias("mid_o"),
            pl.col("mid_c").last().alias("mid_c"),
            pl.col("bid_vol").sum().alias("bid_vol"),
            pl.col("ask_vol").sum().alias("ask_vol"),
            pl.col("vol_up").sum().alias("vol_up"),
            pl.col("vol_down").sum().alias("vol_down"),
            pl.col("n_ticks").sum().alias("n_ticks"),
            pl.col("spread_med").median().alias("spread_med"),
        )
        .rename({"t": "time"})
        .sort("time")
    )

def features(tf, w):
    """Causal features computed on bar history (shifted by 1 bar)."""
    return (
        tf.with_columns(
            ((pl.col("vol_up") - pl.col("vol_down")) / (pl.col("vol_up") + pl.col("vol_down"))).alias("sfi_bar"),
            (pl.col("bid_c") - pl.col("bid_o")).alias("range_dir"),
            (pl.col("bid_h") - pl.col("bid_l")).alias("rng"),
        )
        .with_columns(
            pl.col("sfi_bar").rolling_mean(w).shift(1).alias("sfi_w"),
            pl.col("vol_up").rolling_sum(w).shift(1).alias("vu_w"),
            pl.col("vol_down").rolling_sum(w).shift(1).alias("vd_w"),
            pl.col("rng").rolling_mean(14).shift(1).alias("atr"),
            pl.col("bid_c").rolling_mean(20).shift(1).alias("sma20"),
        )
        .with_columns(
            pl.col("time").cast(pl.Int64).alias("ts"),
            ((pl.col("time") % 86400) // 3600).cast(pl.Int64).alias("hr"),
        )
    )

def seg_of(df):
    tmin = df["time"].min()
    tmax = df["time"].max()
    span = tmax - tmin
    if span > 550 * 86400:  # ~18+ months: 3-way split
        b1, b2 = tmin + span / 3, tmin + 2 * span / 3
        return df.with_columns(pl.col("time").cast(pl.Int64).alias("ts")).with_columns(
            pl.when(pl.col("ts") < b1).then(pl.lit("IS-1"))
            .when(pl.col("ts") < b2).then(pl.lit("IS-2"))
            .otherwise(pl.lit("OOS")).alias("seg")
        )
    # short instrument: two halves (IS-1 vs OOS)
    b1 = tmin + span / 2
    return df.with_columns(pl.col("time").cast(pl.Int64).alias("ts")).with_columns(
        pl.when(pl.col("ts") < b1).then(pl.lit("IS-1")).otherwise(pl.lit("OOS")).alias("seg")
    )

def run_signal(df, sym, kind, cfg):
    """Returns list of trade dicts."""
    pt = POINT[sym]
    w = cfg.get("w", 6)
    f = features(df, w)
    if cfg.get("session"):
        f = f.filter((pl.col("hr") >= cfg["session"][0]) & (pl.col("hr") <= cfg["session"][1]))
    if cfg.get("spread_max_pts"):
        f = f.filter(pl.col("spread_med") / pt <= cfg["spread_max_pts"])

    thr = cfg.get("thr", 0.2)
    if kind == "ofi_cont":
        sig = (f["sfi_w"] > thr).cast(pl.Int8) - (f["sfi_w"] < -thr).cast(pl.Int8)
    elif kind == "ofi_rev":
        sig = (f["sfi_w"] < -thr).cast(pl.Int8) - (f["sfi_w"] > thr).cast(pl.Int8)
    elif kind == "vol_ratio":
        # vol_up/vol_down ratio continuation
        ratio = f["vu_w"] / (f["vd_w"] + 1e-9)
        sig = (ratio > cfg.get("ratio", 1.3)).cast(pl.Int8) - (ratio < 1 / cfg.get("ratio", 1.3)).cast(pl.Int8)
    else:
        raise ValueError(kind)
    f = f.with_columns(pl.Series("sig", sig)).with_columns(pl.col("sig").fill_null(0))

    bid_o_n = f["bid_o"].shift(-1).to_numpy()
    ask_o_n = f["ask_o"].shift(-1).to_numpy()
    bid_c = f["bid_c"].to_numpy()
    bid_h = f["bid_h"].to_numpy()
    bid_l = f["bid_l"].to_numpy()
    atr = f["atr"].to_numpy()
    sigs = f["sig"].to_numpy()
    ts_arr = f["ts"].to_numpy()
    spread_arr = (f["spread_med"] / pt).to_numpy()

    sl_atr = cfg.get("sl_atr", 2.0)
    rr = cfg.get("rr", 2.0)
    n = len(f)
    trades = []
    for i in range(n - 1):
        s = int(sigs[i])
        if s == 0 or np.isnan(atr[i]) or atr[i] <= 0:
            continue
        sl_pts = sl_atr * atr[i] / pt
        tp_pts = rr * sl_pts
        entry = ask_o_n[i] if s == 1 else bid_o_n[i]
        if np.isnan(entry):
            continue
        hb, lb = bid_h[i + 1], bid_l[i + 1]
        if s == 1:
            sl_px, tp_px = entry - sl_pts * pt, entry + tp_pts * pt
            r = -1.0 if lb <= sl_px else (rr if hb >= tp_px else (bid_c[i + 1] - entry) / (sl_pts * pt))
        else:
            sl_px, tp_px = entry + sl_pts * pt, entry - tp_pts * pt
            r = -1.0 if hb >= sl_px else (rr if lb <= tp_px else (entry - bid_c[i + 1]) / (sl_pts * pt))
        cost_pts = spread_arr[i] + cfg.get("slippage_pts", 0.5)
        trades.append({"ts": int(ts_arr[i + 1]), "r": r, "cost_r": cost_pts / sl_pts, "sl": sl_pts})

    if not trades:
        return {"n": 0}
    res = pl.DataFrame(trades).with_columns((pl.col("r") - pl.col("cost_r")).alias("net"))
    n_t = len(res)
    gross = float(res["r"].mean())
    net = float(res["net"].mean())
    wr = float((res["r"] > 0).mean()) * 100
    std = float(res["net"].std()) if res["net"].std() is not None else 0.0
    t = net / (std / np.sqrt(n_t)) if std and std > 0 else 0.0
    return {
        "n": n_t, "gross": round(gross, 4), "net": round(net, 4),
        "wr": round(wr, 1), "t": round(t, 2),
        "sl": round(float(res["sl"].median()), 1),
        "spread": round(float(res["sl"].count()) and float((spread_arr > 0).mean() * 100), 1),
    }

def grid(sym, kinds=("ofi_cont", "ofi_rev", "vol_ratio")):
    m1 = load_m1(sym)
    tf = to_tf(m1, 300)
    df = seg_of(tf)
    seg_names = [s for s in ["IS-1", "IS-2", "OOS"] if s in set(df["seg"].to_list())]
    segs = {s: df.filter(pl.col("seg") == s) for s in seg_names}

    results = []
    configs = []
    for kind in kinds:
        for w in [4, 6, 12]:
            for thr in [0.15, 0.25, 0.35]:
                for sl_atr in [1.5, 2.5, 4.0]:
                    for rr in [1.5, 2.5, 4.0]:
                        for sess in [(7, 19), None]:
                            configs.append({"kind": kind, "w": w, "thr": thr, "sl_atr": sl_atr,
                                            "rr": rr, "session": sess, "slippage_pts": 0.5})
    for cfg in configs:
        row = {"cfg": cfg}
        for sname, seg in segs.items():
            r = run_signal(seg, sym, cfg["kind"], cfg)
            row[sname] = r
        seg_names = list(segs.keys())
        if all(row[s]["n"] >= 20 for s in seg_names):
            evs = [row[s]["net"] for s in seg_names]
            if all(e > 0 for e in evs) or all(e < 0 for e in evs):
                row["_sign"] = "ALL+" if evs[0] > 0 else "ALL-"
                row["_mean"] = round(sum(evs) / len(evs), 4)
                row["_total_n"] = sum(row[s]["n"] for s in seg_names)
                results.append(row)
    results.sort(key=lambda r: r.get("_mean", -9), reverse=True)
    return results

if __name__ == "__main__":
    sym = sys.argv[1] if len(sys.argv) > 1 else "EURUSD"
    m1 = load_m1(sym)
    tf = to_tf(m1, 300)
    df = seg_of(tf)
    seg_names = [s for s in ["IS-1", "IS-2", "OOS"] if s in set(df["seg"].to_list())]
    segs = {s: df.filter(pl.col("seg") == s) for s in seg_names}
    print(f"{sym}: M1={len(m1)} M5={len(tf)} segs=" + str({s: len(segs[s]) for s in seg_names}))
    res = grid(sym)
    print(f"\n=== {sym}: same-sign configs (n>=20 per segment) ===")
    for r in res[:20]:
        c = r["cfg"]
        print(f"  {c['kind']:10s} w={c['w']} thr={c['thr']} sl={c['sl_atr']} rr={c['rr']} sess={c['session']} "
              f"sign={r.get('_sign')} mean={r.get('_mean')} totalN={r.get('_total_n')}")
        for s in seg_names:
            x = r[s]
            print(f"    {s}: n={x['n']} gross={x['gross']} net={x['net']} wr={x['wr']}% t={x['t']} sl={x['sl']}pt")
    out = RESEARCH / f"grid2_{sym}.json"
    out.write_text(json.dumps(res, indent=1, default=str))
    print(f"saved -> {out}")
