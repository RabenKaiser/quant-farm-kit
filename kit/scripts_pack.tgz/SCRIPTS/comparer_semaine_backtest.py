# -*- coding: utf-8 -*-
"""COMPARER_SEMAINE_BACKTEST : la semaine vivante du 28/09 mesuree a l'echelle du backtest.

Question (04/10) : « compare la semaine avec ce qu'elle aurait donne dans le backtest ».

Ce qui est possible, et ce qui ne l'est pas. Le corpus de la ferme s'arrete au 31/12/2025 (verifie sur les
fichiers M1 : derniere minute 1767225480 = 2025-12-31 23 h 58 UTC) et celui du juge commence au 16/01/2026 :
la semaine du 28/09/2026 ne peut donc PAS etre rejouee sur le corpus. Ce que l'on fait a la place, et qui
repond a la question : on mesure les SEPT JAMBES DU PORTEFEUILLE V12 sur la periode hors echantillon
2025-01 -> 2026-03, on decoupe en semaines, et l'on regarde ou tombe la semaine vivante dans cette
distribution -- en R (1 R = 1 % du capital).

Les sept jambes sont celles REELLEMENT installees (PortfolioV12), chacune avec son fichier brut d'origine :
    XAUUSD Keltner 32 h achat, stop 6 ATR      raw_farm_g3_kelt32xau_slr6.txt
    DEU.IDX Keltner 32 h achat, stop 3 ATR     raw_farm_g3_kelt32_deu.txt
    JPN.IDX Keltner 32 h achat, stop 3 ATR     raw_farm_g3_kelt32_jpn.txt
    USA30.IDX SR97 achat                       raw_farm_g3_sr15_usa30.txt      (ligne SR97L)
    FRA.IDX divergence RSI achat               raw_farm_g3_div_fra_s15.txt
    EUS.IDX SR100 achat                        raw_farm_g3_m15_eusidx_4.txt    (ligne SR100L)
    AUDCAD SR97 vente                          raw_farm_g3_lot_audcad_2.txt    (ligne SR97S)

Sortie : COMPARAISON_SEMAINE.md + affichage.
"""
import sys
from collections import defaultdict
from datetime import timedelta
from pathlib import Path

import numpy as np

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
S = B / "SCRIPTS"
sys.path.insert(0, str(S))
import reel_sans_constante as RSC   # noqa: E402

# (nom, fichier brut, symbole, morceau de ligne a garder, trame)
JAMBES = [("or",      "g3_kelt32xau_slr6", "XAUUSD",    "KELTHIGH",    None),
          ("Dax",     "g3_kelt32_deu",     "DEU.IDX",   "KELTHIGH",    None),
          ("Nikkei",  "g3_kelt32_jpn",     "JPN.IDX",   "KELTHIGH",    None),
          ("Dow",     "g3_sr15_usa30",     "USA30.IDX", "SR97L",       None),
          ("CAC",     "g3_div_fra_s15",    "FRA.IDX",   "RSI_DIV_LO",  None),
          ("EStoxx",  "g3_m15_eusidx_4",   "EUS.IDX",   "SR100L",      15),
          ("AUDCAD",  "g3_lot_audcad_2",   "AUDCAD",    "SR97S",       None)]

DEBUT, FIN = "2025-01-01", "2026-03-31"        # hors echantillon (jambes choisies sur 2024)

# La semaine vivante : les cinq transactions des lignes mesurees, lues dans ReportHistory-798154993.xlsx.
# Les 103 transactions de la grille du Nikkei (28-29/09) sont la panne, comptees a part.
SEM_VIVANTE = [("30/09 18:15", "EUS.IDX", -51.75), ("01/10 02:15", "JPN.IDX", -35.32),
               ("01/10 08:00", "XAUUSD", +2.91), ("01/10 08:00", "FRA.IDX", -45.32),
               ("02/10 06:30", "DEU.IDX", -93.38)]
PANNE_NIKKEI = -354.0        # perte brute + commissions des 103 transactions de grille
CAPITAL, RISQUE = 10000.0, 0.01


def charge(tag, sym, motif, trame):
    p = B / ("raw_farm_%s.txt" % tag)
    if not p.exists():
        print("    fichier absent : %s" % p.name)
        return []
    corpus = "m1_ext" if sym.endswith(".IDX") else "m1_pos"
    tx = RSC.transactions_texte(p.read_text(encoding="utf-8", errors="replace"), corpus,
                                atr_min=0, symboles=[sym], trame=trame)
    return [t for t in tx if motif in t["ligne"]]


def semaines(trades):
    par = defaultdict(list)
    for t, r, sym, nom in trades:
        par[(t - timedelta(days=t.weekday())).date()].append(r)
    return par


def pct(v, q):
    v = sorted(v)
    return v[min(len(v) - 1, max(0, int(round(q * (len(v) - 1)))))] if v else 0.0


def main():
    print("PORTEFEUILLE V12 — la semaine vivante placee dans les semaines du backtest")
    trades, lignes_jambes = [], []
    for nom, tag, sym, motif, trame in JAMBES:
        tx = charge(tag, sym, motif, trame)
        def mu(v):
            return (np.mean([x["R"] for x in v]), len(v)) if v else (0.0, 0)
        tout = mu(tx)
        dans24 = mu([x for x in tx if x["t_in"].strftime("%Y") == "2024"])
        hors = mu([x for x in tx if DEBUT <= x["t_in"].strftime("%Y-%m-%d") <= FIN])
        print("    %-8s %-10s  corpus entier %+.4f (%4d) | 2024 %+.4f (%3d) | hors ech. %+.4f (%4d)  [%s]"
              % (nom, sym, tout[0], tout[1], dans24[0], dans24[1], hors[0], hors[1], tag))
        lignes_jambes.append("| %s | %s | %+.4f (%d) | %+.4f (%d) | **%+.4f (%d)** |"
                             % (nom, sym, tout[0], tout[1], dans24[0], dans24[1], hors[0], hors[1]))
        tx = [t for t in tx if DEBUT <= t["t_in"].strftime("%Y-%m-%d") <= FIN]
        if not tx:
            continue
        for t in tx:
            trades.append((t["t_in"], float(t["R"]), sym, nom))
    if len(trades) < 100:
        print("  trop peu de transactions mesurees : verifier les bruts")
        return 1
    trades.sort(key=lambda x: x[0])
    r = [x[1] for x in trades]
    print("\n  ENSEMBLE : %d transactions, %s -> %s" % (len(trades), trades[0][0].date(), trades[-1][0].date()))
    print("  mu %+.4f R/tx, gagnantes %.1f %%, mois de %d jours ouvres"
          % (sum(r) / len(r), 100.0 * sum(1 for x in r if x > 0) / len(r), 21))

    sem = semaines(trades)
    tot = [(k, sum(v), len(v)) for k, v in sorted(sem.items())]
    pleines = [x for x in tot if x[2] >= 3]                 # on ecarte les semaines de fetes
    totaux = [x[1] for x in pleines]
    ntx = [x[2] for x in pleines]
    print("\n  SEMAINES DU BACKTEST (hors echantillon, %d semaines exploitables)" % len(pleines))
    print("    transactions/semaine : median %d, moyenne %.1f, mini %d, maxi %d"
          % (pct(ntx, .5), sum(ntx) / len(ntx), min(ntx), max(ntx)))
    print("    R/semaine            : median %+.2f, moyenne %+.2f, pire %+.2f, meilleure %+.2f"
          % (pct(totaux, .5), sum(totaux) / len(totaux), min(totaux), max(totaux)))
    print("    semaines positives   : %.0f %%   |   5 %% pire %+.2f R   |   95 %% %+.2f R"
          % (100.0 * sum(1 for x in totaux if x > 0) / len(totaux), pct(totaux, .05), pct(totaux, .95)))

    v = sum(p for _, _, p in SEM_VIVANTE) / (CAPITAL * RISQUE)
    print("\n  SEMAINE VIVANTE (28/09 -> 02/10, lignes mesurees seulement)")
    for quand, sym, p in SEM_VIVANTE:
        print("    %-11s %-8s %+8.2f EUR = %+.2f R" % (quand, sym, p, p / (CAPITAL * RISQUE)))
    print("    total %+.2f R = %+.2f %% du compte" % (v, 100 * v * RISQUE))
    print("    position dans la distribution : percentile %.0f %%  (P(faire pire) sur une semaine du backtest)"
          % (100.0 * sum(1 for x in totaux if x < v) / len(totaux)))
    print("    transactions : 5 contre une mediane de %d par semaine -- c'est l'ecart le plus net" % pct(ntx, .5))
    print("\n  Avec la panne du Nikkei comptee (%+.0f EUR), la semaine vaut %+.2f R, percentile %.0f %%."
          % (PANNE_NIKKEI, v + PANNE_NIKKEI / (CAPITAL * RISQUE),
             100.0 * sum(1 for x in totaux if x < v + PANNE_NIKKEI / (CAPITAL * RISQUE)) / len(totaux)))

    lignes = ["# LA SEMAINE VIVANTE DANS LES SEMAINES DU BACKTEST", "",
              "Les sept jambes du portefeuille V12, mesurees hors echantillon (2025-01 -> 2026-03) sur leurs",
              "fichiers bruts d'origine, decoupees en semaines civiles. 1 R = 1 % du capital.", "",
              "| | backtest V12 (semaines hors echantillon) | semaine vivante 28/09 -> 02/10 |",
              "|---|---|---|",
              "| transactions | median %d, moyenne %.1f (mini %d, maxi %d) | **5** |" % (pct(ntx, .5), sum(ntx) / len(ntx), min(ntx), max(ntx)),
              "| resultat | median %+.2f R, moyenne %+.2f R | **%+.2f R** |" % (pct(totaux, .5), sum(totaux) / len(totaux), v),
              "| pire semaine | %+.2f R | — |" % min(totaux),
              "| meilleure semaine | %+.2f R | — |" % max(totaux),
              "| semaines positives | %.0f %% | — |" % (100.0 * sum(1 for x in totaux if x > 0) / len(totaux)),
              "| percentile de la semaine vivante | — | **%.0f %%** |" % (100.0 * sum(1 for x in totaux if x < v) / len(totaux)), "",
              "Mu du portefeuille : %+.4f R/tx sur %d transactions, %.1f %% de gagnantes." % (sum(r) / len(r), len(r), 100.0 * sum(1 for x in r if x > 0) / len(r)),
              "La semaine vivante, panne du Nikkei comprise, vaut %+.2f R." % (v + PANNE_NIKKEI / (CAPITAL * RISQUE)), "",
              "## Les sept jambes, mesurees sur trois fenetres (fichiers bruts de la ferme)", "",
              "Les jambes sont CHOISIES sur 2024 : la colonne « hors echantillon » est la seule qui juge.", "",
              "| jambe | symbole | corpus entier | 2024 (choix) | hors ech. 2025-01 -> 2026-03 |",
              "|---|---|---|---|---|"] + lignes_jambes + [
              "",
              "## Ce que la comparaison dit, et ce qu'elle ne dit pas", "",
              "* **Le resultat de la semaine vivante n'a rien d'anormal** : -2,23 R la place au 29e percentile des",
              "  66 semaines du backtest. Une semaine negative sur cinq est la norme (44 % des semaines le sont).",
              "* **L'anomalie est le nombre de transactions : 5 contre une mediane de 26.** C'est la seule chose",
              "  que la semaine demontre, et elle s'explique : la panne du Nikkei (a elle seule 103 transactions)",
              "  plus mes propres manipulations du 01/10, qui ont ferme quatre positions sur cinq.",
              "* **Reserve sur deux jambes.** Sur la fenetre hors echantillon, le CAC (-0,0120 sur 294) et",
              "  l'Euro Stoxx (-0,0564 sur 65) sont NEGATIFS : leurs chiffres d'admission (+0,0116 et +0,0939)",
              "  sont calcules sur le corpus entier, 2024 compris. Et l'AUDCAD etait NEGATIF en 2024 (-0,1049) :",
              "  sa place dans le portefeuille ne vient donc pas du choix sur 2024 mais de la liste des jambes",
              "  retenues. Ces trois points sont a trancher avant de considérer le portefeuille comme fige.", ""]
    (B / "COMPARAISON_SEMAINE.md").write_text("\n".join(lignes), encoding="utf-8")
    print("\n  -> COMPARAISON_SEMAINE.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
