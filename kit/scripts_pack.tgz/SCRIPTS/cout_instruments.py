"""LE COUT PAR INSTRUMENT, EN R — pour ne chasser des jambes que la ou les frais le permettent.

POURQUOI (27/09, 22 h). L'utilisateur demande de concentrer la recherche de jambes sur les **devises et les
indices a frais faibles**. C'est un filtre economique de premiere importance : le projet a deja mesure des
couts medians de 0,04 a 0,11 R par transaction, et aucun edge de +0,05 R/tx ne survit a 0,10 R de frais.

Ce script calcule, instrument par instrument et sur les donnees reelles :
  * le **spread median en points et en prix** (moyenne des spreads de chaque minute) ;
  * l'**ATR14** de la trame de trading utilisee par l'EA (le M15 : c'est lui qui fixe le stop, quelle que
    soit la trame des signaux -- verifie le 27/09 sur l'or et le Dax) ;
  * le **cout en R** = spread / (SLR x ATR), pour SLR = 1,5 / 3 / 6.

Un instrument dont le cout depasse 0,05 R a 6 ATR ne peut pas porter un edge de +0,10 R/tx : il est
ecarte AVANT toute campagne. Ce filtre economise le banc, qui est la ressource rare.
"""
import sys
import pathlib
from collections import defaultdict

import numpy as np
import pandas as pd

B = pathlib.Path(r"C:\EAFarm\HISTORY - Copy\research")
# Corpus ferme : devises (m1_pos) et indices (m1_ext). Corpus du juge : m1_upcomers.
SOURCES = {"m1_pos": "ferme (devises)", "m1_ext": "ferme (indices)", "m1_upcomers": "juge"}


def charge(f, source):
    try:
        d = pd.read_csv(f)
    except (OSError, ValueError):
        return None
    col = "time" if "time" in d.columns else d.columns[0]
    t = d[col]
    if t.dtype == object:
        t = pd.to_datetime(t, utc=True, errors="coerce").astype("int64") // 10 ** 9
    t = t.astype("int64").values
    if not {"high", "low", "close", "spread"} <= set(d.columns):
        return None
    c = d["close"].values.astype(float)
    diff = np.abs(np.diff(c))
    nz = diff[diff > 0]
    if not len(nz) or len(t) < 5000:
        return None
    pt = float(np.min(nz))
    return {"t": t, "h": d["high"].values.astype(float), "l": d["low"].values.astype(float),
            "c": c, "spr": d["spread"].values.astype(float) * pt, "pt": pt}


def cout(D):
    df = pd.DataFrame({"t": pd.to_datetime(D["t"], unit="s"), "h": D["h"], "l": D["l"], "c": D["c"]}).set_index("t")
    m15 = pd.DataFrame({"h": df["h"].resample("15min").max(), "l": df["l"].resample("15min").min(),
                        "c": df["c"].resample("15min").last()}).dropna()
    pc = m15["c"].shift(1)
    tr = pd.concat([m15["h"] - m15["l"], (m15["h"] - pc).abs(), (m15["l"] - pc).abs()], axis=1).max(axis=1)
    atr = float(tr.ewm(alpha=1 / 14.0, adjust=False).mean().median())
    spr = float(np.median(D["spr"][D["spr"] > 0])) if (D["spr"] > 0).any() else float(np.median(D["spr"]))
    return atr, spr


def main():
    lignes = ["# LE COUT PAR INSTRUMENT, EN R (devises et indices)", "",
              "Spread médian et ATR14 M15 (l'unité de stop de l'EA) mesurés sur les données réelles. Le coût",
              "en R vaut spread / (SLR × ATR) : plus il est élevé, plus l'instrument est cher à traiter.", ""]
    for source, quoi in SOURCES.items():
        res = []
        for f in sorted((B / source).glob("*_M1.csv")):
            D = charge(f, source)
            if D is None:
                continue
            atr, spr = cout(D)
            if atr <= 0:
                continue
            sym = f.stem.replace("_M1", "")
            res.append((sym, atr, spr, spr / (6 * atr), spr / (3 * atr), spr / (1.5 * atr)))
        if not res:
            continue
        res.sort(key=lambda z: z[3])
        print("\n=== %s (%s) — %d instruments" % (source, quoi, len(res)))
        print("  %-14s %10s %10s %9s %9s %9s" % ("instrument", "ATR M15", "spread", "cout 6ATR", "3ATR", "1,5ATR"))
        for sym, atr, spr, c6, c3, c15 in res:
            print("  %-14s %10.4f %10.5f %9.3f %9.3f %9.3f" % (sym, atr, spr, c6, c3, c15))
        lignes.append("\n## %s — %s" % (source, quoi))
        lignes.append("\n| instrument | ATR M15 | spread (prix) | coût en R à 6 ATR | à 3 ATR | à 1,5 ATR |")
        lignes.append("|---|---|---|---|---|---|")
        for sym, atr, spr, c6, c3, c15 in res:
            lignes.append("| %s | %.4f | %.5f | **%.3f** | %.3f | %.3f |" % (sym, atr, spr, c6, c3, c15))
        bons = [z for z in res if z[3] <= 0.05]
        lignes.append("\n**Instruments à 6 ATR sous 0,05 R de frais (%d sur %d)** : %s"
                      % (len(bons), len(res), ", ".join(z[0] for z in bons) or "aucun"))
    lignes.append("\n## Comment s'en servir")
    lignes.append("\nUn edge mesuré à +0,05 R/tx ne vaut rien si les frais en coûtent 0,08 : ces instruments "
                  "sont écartés avant campagne. La chasse aux jambes se concentre donc sur les premiers du "
                  "tableau, qui sont aussi, sans surprise, les devises majeures et les quatre grands indices.")
    (B / "COUT_INSTRUMENTS.md").write_text("\n".join(lignes) + "\n", encoding="utf-8")
    print("\n  rapport ecrit dans COUT_INSTRUMENTS.md")


if __name__ == "__main__":
    main()
