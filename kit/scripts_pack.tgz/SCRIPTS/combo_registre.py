"""combo_registre : effet REEL des combinaisons (declencheur x biais x filtre)
sur le corpus REGISTRE (mesures labo + ordres reels).

Question : ajouter un biais ou un filtre a un declencheur ameliore-t-il la
persistance, ou seulement le nombre de mesures ? Comparaison APPARIEE :
meme (paire, declencheur, sens, sl, tp) avec et sans biais/filtre.
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
REG = B / "REGISTRE.jsonl"
OUT = B / "combo_registre.md"


def charge():
    ent = {}
    with REG.open(encoding="utf-8", errors="replace") as f:
        for ln in f:
            if '"cle"' not in ln:
                continue
            try:
                d = json.loads(ln)
            except Exception:
                continue
            cle = d.get("cle")
            if not cle:
                continue
            p = cle.split("|")
            if len(p) != 6:
                continue
            d["trig"], d["bias"], d["filt"], d["sens"] = p[0], p[1], p[2], p[3]
            try:
                d["slr"], d["tpr"] = int(p[4]), int(p[5])
            except ValueError:
                continue
            ent[cle] = d
    return ent


def paires(ent, avec_reel=False):
    """index (sym,trig,sens,sl,tp) -> {cle: d}"""
    ix = defaultdict(dict)
    for cle, d in ent.items():
        if avec_reel and not (d.get("reel") or {}):
            continue
        ix[(d["sym"], d["trig"], d["sens"], d["slr"], d["tpr"])][cle] = d
    return ix


def reel_agg(d):
    """r_tx moyen pondere et hostile sur tous les tags reels."""
    tot = sum(v.get("tx", 0) for v in (d.get("reel") or {}).values())
    if not tot:
        return None
    r = sum(v.get("r_tx", 0) * v.get("tx", 0) for v in (d["reel"]).values()) / tot
    h = sum(v.get("hostile", 0) * v.get("tx", 0) for v in (d["reel"]).values()) / tot
    return r, h, tot


def main():
    ent = charge()
    print("entrees uniques : %d" % len(ent), flush=True)
    vd = defaultdict(int)
    for d in ent.values():
        vd[d.get("verdict")] += 1
    print("verdicts :", dict(sorted(vd.items(), key=lambda kv: -kv[1])[:10]), flush=True)

    lignes = []
    # ---------- A. effet reel des combinaisons, mesure labo, apparie ----
    for nom, champ in (("biais", "bias"), ("filtre", "filt")):
        delta_lab, delta_host, delta_reel = [], [], []
        par_val = defaultdict(list)
        for (sym, trig, sens, sl, tp), g in paires(ent).items():
            base = g.get("%s|NONE|NONE|%s|%d|%d" % (trig, sens, sl, tp))
            if base is None:
                continue
            b_h = base.get("lab_hostile")
            b_m = base.get("lab_moy")
            br = reel_agg(base)
            for cle, d in g.items():
                if d[champ] == "NONE":
                    continue
                if d.get("tx_lab", 0) < 8 or base.get("tx_lab", 0) < 8:
                    continue
                if b_h is not None and d.get("lab_hostile") is not None:
                    delta_lab.append(d["lab_hostile"] - b_h)
                    par_val[d[champ]].append(d["lab_hostile"] - b_h)
                if b_m is not None and d.get("lab_moy") is not None:
                    delta_host.append(d["lab_moy"] - b_m)
                dr = reel_agg(d)
                if br and dr:
                    delta_reel.append((dr[0] - br[0], dr[1] - br[1], dr[2], cle))
        n = len(delta_lab)
        if n:
            pos = sum(1 for x in delta_lab if x > 0)
            lignes.append("### %s : +%s" % (nom, champ))
            lignes.append("mesures appariees %d | delta lab_hostile moyen %+.4f "
                          "| median %+.4f | %d%% ameliore"
                          % (n, sum(delta_lab) / n,
                             sorted(delta_lab)[n // 2], int(100 * pos / n)))
            if delta_host:
                m = len(delta_host)
                lignes.append("delta lab_moyen (toutes fenetres) moyen %+.4f sur %d"
                              % (sum(delta_host) / m, m))
            if delta_reel:
                k = len(delta_reel)
                p2 = sum(1 for x in delta_reel if x[0] > 0)
                lignes.append("ORDRE REEL apparie : %d mesures | delta r_tx moyen %+.4f "
                              "| %d%% ameliore | delta hostile moyen %+.4f"
                              % (k, sum(x[0] for x in delta_reel) / k, int(100 * p2 / k),
                                 sum(x[1] for x in delta_reel) / k))
            for v, xs in sorted(par_val.items(), key=lambda kv: -len(kv[1]))[:8]:
                if len(xs) >= 10:
                    lignes.append("  %-14s n=%5d delta host %+.4f" % (v, len(xs),
                                                                      sum(xs) / len(xs)))
        else:
            lignes.append("### %s : aucune mesure appariee" % nom)

    # ---------- B. reel : combinaisons positives ET hostiles positives ----
    bons = []
    for cle, d in ent.items():
        ra = reel_agg(d)
        if not ra:
            continue
        r, h, tx = ra
        if r > 0 and h > 0 and tx >= 500:
            bons.append((r, h, tx, cle))
    bons.sort(key=lambda x: -(x[1]))
    lignes.append("\n### reel : r_tx>0 ET hostile>0 avec >=500 tx : %d" % len(bons))
    for r, h, tx, cle in bons[:25]:
        ligne = "%-46s r_tx %+.4f hostile %+.4f tx %d" % (cle, r, h, tx)
        lignes.append(ligne)
        print(ligne, flush=True)

    # ---------- C. labo : persistance des combinaisons ----------
    top = []
    vus = set()
    for cle, d in ent.items():
        if d["slr"] <= 0:
            continue
        ratio = d["tpr"] / d["slr"]
        if ratio < 1.0 or ratio > 6.0:      # bande prop 1:1 .. 1:6
            continue
        lab = d.get("lab") or {}
        if len(lab) < 4 or d.get("tx_lab", 0) < 60:
            continue
        vals = [v[0] for v in lab.values() if v[1] >= 5]
        if len(vals) < 4:
            continue
        sig = (tuple(round(v, 3) for v in vals), round(ratio, 2))
        if sig in vus:                       # meme vecteur labo = meme essai reel
            continue
        vus.add(sig)
        top.append((min(vals), sum(vals) / len(vals), len(vals),
                    sum(1 for v in vals if v > 0), cle, sorted(vals),
                    d.get("verdict"), reel_agg(d)))
    top.sort(key=lambda x: -x[0])
    lignes.append("\n### labo IN-BAND (1:1..1:6) : pire fenetre la plus haute")
    for mn, mo, k, pos, cle, vals, vd, ra in top[:30]:
        r = ("reel r_tx %+.4f hostile %+.4f tx %d" % ra) if ra else "aucun essai reel"
        lignes.append("%-46s pire %+.3f moy %+.3f %d/%d | %s | %s | %s"
                      % (cle, mn, mo, pos, k, [round(v, 2) for v in vals], vd, r))
    lignes.append("\n### combien de ces meilleurs ont un biais ou un filtre : %d/%d"
                  % (sum(1 for t in top[:200] if "|NONE|NONE|" not in t[4]), min(200, len(top))))

    OUT.write_text("\n".join(lignes), encoding="utf-8")
    print("ecrit %s" % OUT, flush=True)


if __name__ == "__main__":
    sys.exit(main())
