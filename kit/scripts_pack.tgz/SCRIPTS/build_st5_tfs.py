﻿"""Build ST5-layout parquet bars for M5/M15/M30/H1 from M1 for all symbols."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import polars as pl
from pathlib import Path

RESEARCH = Path(r"C:\EAFarm\HISTORY - Copy\research")
ST5DATA = RESEARCH / "st5data"
POINT = {"EURUSD": 0.00001, "USDJPY": 0.001, "EURCAD": 0.00001, "USATECHIDXUSD": 0.001}
TFS = {"M5": 300, "M15": 900, "M30": 1800, "H1": 3600}

def build_tf(sym, tf_str, sec):
    m1_files = sorted((ST5DATA / sym / "Bars" / "M1").glob("*.parquet"))
    if not m1_files:
        print(f"{sym}: no M1 files")
        return
    for f in m1_files:
        m1 = pl.read_parquet(f)
        out = (
            m1.with_columns((pl.col("time") // sec * sec).alias("t"))
            .group_by("t")
            .agg(
                pl.col("open").first().alias("open"),
                pl.col("high").max().alias("high"),
                pl.col("low").min().alias("low"),
                pl.col("close").last().alias("close"),
                pl.col("tick_volume").sum().alias("tick_volume"),
                pl.col("spread").median().alias("spread"),
                pl.col("real_volume").sum().alias("real_volume"),
            )
            .rename({"t": "time"})
            .sort("time")
            .select(["time", "open", "high", "low", "close", "tick_volume", "spread", "real_volume"])
        )
        d = ST5DATA / sym / "Bars" / tf_str
        d.mkdir(parents=True, exist_ok=True)
        out.write_parquet(d / f.name)
    # merge info
    parts = sorted((ST5DATA / sym / "Bars" / tf_str).glob("*.parquet"))
    full = pl.concat([pl.read_parquet(p) for p in parts]).sort("time")
    full.write_parquet(ST5DATA / f"{sym}_{tf_str}.parquet")
    print(f"{sym} {tf_str}: {len(full)} bars")

if __name__ == "__main__":
    syms = sys.argv[1:] or ["EURUSD", "USDJPY", "EURCAD", "USATECHIDXUSD"]
    for sym in syms:
        for tf_str, sec in TFS.items():
            build_tf(sym, tf_str, sec)
    print("DONE")
