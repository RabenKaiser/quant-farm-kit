"""Distribution des PnL ptrail par run — tail vs stable.
Parse les 3 runs (2023/2024/2025) depuis le log, groupe par run, calcule la
concentration des gains."""
import re
from pathlib import Path

CF = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3")
raw = (CF / "Tester" / "logs" / "20260823.log").read_text("utf-16", errors="replace")
lines = raw.splitlines()

# découper par run ("testing of Experts\eepeek\USDJPY_M30_PTRAIL.ex5 from ...")
runs = []
cur = None
for l in lines:
    m = re.search(r"USDJPY_M30_PTRAIL\.ex5 from (\d{4}\.\d{2}\.\d{2})", l)
    if m:
        cur = {"year": m.group(1)[:4], "lines": []}
        runs.append(cur)
    elif cur is not None and "final balance" in l:
        cur["final"] = l
    if cur is not None:
        cur["lines"].append(l)

print(f"runs détectés: {len(runs)}")
for r in runs:
    year = r["year"]
    lines = r["lines"]
    # deals avec volumes et prix : "market buy 1.23 USDJPY sl: ... tp: ... (price...)"
    ents = [l for l in lines if "market " in l and "sl:" in l]
    sls = [l for l in lines if "stop loss triggered" in l]
    # PnL estimé : on ne peut pas tout extraire du log, mais on peut compter les
    # positions (1 entrée = 1 position ptrail, les adds sont des "market" aussi)
    buys = len([l for l in ents if "market buy" in l])
    sells = len([l for l in ents if "market sell" in l])
    print(f"  {year}: entrées={len(ents)} (buy={buys} sell={sells}) SL={len(sls)}")
