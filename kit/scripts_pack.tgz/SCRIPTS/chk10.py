﻿import sys, importlib
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G
importlib.reload(G)
for s in ("GBPUSD","EURUSD","XAGUSD","XAUUSD"):
    try:
        m1, ps, sp = G.load(s)
        print(f"  {s:<8} n={len(m1):>9,}  ps={ps}  sp_units={sp:.2f}  "
              f"{m1.index[0].date()} -> {m1.index[-1].date()}")
    except Exception as e:
        print(f"  {s:<8} ERREUR {e}")
