"""Debug : les timestamps USDJPY M1 couvrent-ils 2024 ?
Vérifie la plage réelle et le filtre."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
import polars as pl
import datetime as dt
import edge_correct as ec

m1 = ec.load_m1("USDJPY")
print(f"USDJPY M1: {len(m1)} barres")
print(f"  time min: {m1['time'].min()} = {dt.datetime.utcfromtimestamp(m1['time'].min())}")
print(f"  time max: {m1['time'].max()} = {dt.datetime.utcfromtimestamp(m1['time'].max())}")

E = lambda s: int(dt.datetime.strptime(s, "%Y-%m-%d").timestamp())
a, b = E("2024-01-01"), E("2025-01-01")
print(f"  filtre 2024: [{a}, {b})")
sub = m1.filter((pl.col("time") >= a) & (pl.col("time") < b))
print(f"  barres M1 2024: {len(sub)}")

# échantillon des times autour de début 2024
import numpy as np
t = m1["time"].to_numpy()
idx = np.searchsorted(t, a)
print(f"  time à a: {t[max(0,idx-2):idx+2]}")
