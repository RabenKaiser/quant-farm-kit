﻿import json
d = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\pos_selection.json", encoding="utf-8"))
for L in d["legs"]:
    if L["sym"]=="AUDJPY":
        print(f"  {L['trig']:<12} filt={L.get('filt')} ex={L.get('ex')}")
        print(f"     n3={L['n3']} R3={L['R3']:+.1f}  key={L['k'][:60]}")
