# -*- coding: utf-8 -*-
"""candidat_final.py — LE CANDIDAT A TESTER SUR LE HOLDOUT, GELE.

CE QU'IL CONTIENT, ET POURQUOI RIEN D'AUTRE
------------------------------------------
Tout ce qui a ete mesure en 24 heures converge vers trois choses, et vers elles
seulement :

 1. LE COUT. C'est le seul indicateur qui sort en tete des DEUX axes
    independants (resilience.py : +0.056 puis +0.011). Troisieme confirmation
    de la meme loi (labo -0.736, vrais ordres -0.71/-0.79).
 2. LES PAIRES LES MOINS CHERES. EURUSD et EURJPY sont positives sur les trois
    periodes dans l'analyse de medecine legale (forensique.py : +0.021/+0.041/
    +0.006 et +0.028/+0.020/+0.010). USDJPY est la moins chere de toutes mais
    n'a pas d'historique exploitable en 2020-2021.
 3. UNE FAMILLE DE DECLENCHEURS, la seule positive sur les TROIS periodes :
    NEST3_C (+0.0507 / +0.0134 / +0.0176). Aucune autre famille n'est coherente
    sur les trois.

Ce qui n'entre PAS dans le candidat, et c'est deliberé :
  - aucun classement par performance passee (aucune statistique ne transfere) ;
  - pas de "top du top" (la sortie SL 12 / TP 1 a un plafond : 2 103 couples sur
    24 871 y sont exactement, et l'ancien portefeuille s'y asseyait sur 24
    lignes sur 24) ;
  - pas de critere supplementaire ajoute apres avoir vu les resultats.

REGLE PRE-ENREGISTREE ET GELEE
    paires  : EURUSD, EURJPY          (positives 3/3, cout 6.3 % et 13.9 %)
    declencheur : NEST3_C
    filtres : tous, les deux cotes
    selection : mediane des R (r_x54) sur 2024Q1+Q2+Q3 >= 0, n cumule >= 15 ;
                si plus de 8 lignes, on garde les 8 de mediane la plus haute
    sortie  : r_x54 = SL 12 x ATR / TP 24 x ATR (le reglage du reel)
    jugement de reference : 2024Q4 + 2025Q1 (jamais utilisees pour choisir)
    test final : 2025Q2 a 2026 sur MT5, en ordres reels, quelques fenetres
                 -- HOLDOUT, tire UNE SEULE FOIS

USAGE : python candidat_final.py
"""
import collections
import hashlib
import json
import statistics
import time
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
LIVE = BASE / "lab_results.jsonl"
COMMON = (Path.home() / "AppData/Roaming/MetaQuotes/Terminal/Common/Files")
QA = ["2024Q1", "2024Q2", "2024Q3"]
QB = ["2024Q4", "2025Q1"]
V = ["2020.01", "2020.07", "2021.01", "2021.07"]
PAIRES = ["EURUSD", "EURJPY"]
DECL = "NEST3_C"
NTOP = 8
NMIN = 15


def main():
    g = collections.defaultdict(dict)
    with open(LIVE, encoding="utf-8") as fh:
        for line in fh:
            if '"r_x54"' not in line:
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            if str(r.get("period", "")) in QA + QB + V and r["n"] >= 3:
                g[(r["id"], r["sym"])][str(r.get("period"))] = r

    cand = collections.defaultdict(list)
    for (cid, sym), d in g.items():
        if sym not in PAIRES or not cid.startswith(DECL + "|"):
            continue
        va = [d[q]["r_x54"] for q in QA if q in d]
        if len(va) < 3:
            continue
        na = sum(d[q]["n"] for q in QA if q in d)
        if na < NMIN:
            continue
        med = statistics.median(va)
        if med < 0:
            continue
        cand[sym].append((cid, med, statistics.mean(va), na))

    print("=" * 100)
    print("CANDIDAT FINAL — declencheur %s sur %s" % (DECL, " et ".join(PAIRES)))
    print("=" * 100)
    retenus = []
    for s in sorted(cand):
        lst = sorted(cand[s], key=lambda x: -x[1])
        retenus += [(s, cid, med, mo, n) for cid, med, mo, n in lst[:NTOP]]
        print("   %-8s %3d candidats (mediane >= 0)   %d retenus"
              % (s, len(cand[s]), min(len(lst), NTOP)))
    if not retenus:
        print("   AUCUN candidat : la famille %s n'a pas de ligne a mediane" % DECL)
        print("   positive sur ces deux paires. Rien a tester.")
        return

    def R(quarts):
        tot = n = 0.0
        for sym, cid, *_ in retenus:
            d = g[(cid, sym)]
            for q in quarts:
                if q in d:
                    tot += d[q]["r_x54"] * d[q]["n"]
                    n += d[q]["n"]
        return (tot / n if n else 0.0), int(n)

    ra, na = R(QA)
    rb, nb = R(QB)
    rv, nv = R(V)
    print()
    print("   %-32s %12s %12s %12s" % ("", "A = choix", "B = JUGEMENT",
                                       "V = 2020-21"))
    print("   %-32s %+12.4f %+12.4f %+12.4f" % ("R par transaction", ra, rb, rv))
    print("   %-32s %12d %12d %12d" % ("transactions", na, nb, nv))
    print()
    print("   %-8s %-34s %8s %6s %8s %8s %8s"
          % ("paire", "combinaison", "mediane", "n", "R(A)", "R(B)", "R(V)"))
    for sym, cid, med, mo, n in sorted(retenus, key=lambda x: (x[0], -x[2])):
        d = g[(cid, sym)]
        def m(qs):
            v = [d[q]["r_x54"] for q in qs if q in d]
            return statistics.mean(v) if v else 0.0
        print("   %-8s %-34s %+8.3f %6d %+8.3f %+8.3f %+8.3f"
              % (sym, cid[:34], med, n, m(QA), m(QB), m(V)))

    txt = "\n".join(cid for _, cid, *_ in sorted(retenus)) + "\n"
    h = hashlib.sha256(txt.encode()).hexdigest()
    (BASE / "CANDIDAT_FINAL.txt").write_text(txt, encoding="utf-8")
    ids = sorted({cid for _, cid, *_ in retenus})
    (COMMON / "candidat_set.txt").write_text("\n".join(ids) + "\n",
                                             encoding="ascii")
    (BASE / "CANDIDAT_FINAL_couples.txt").write_text(
        "\n".join("%s|%s" % (cid, sym) for sym, cid, *_ in sorted(retenus)) + "\n",
        encoding="utf-8")
    print()
    print("   GELE le %s — empreinte %s" % (time.strftime("%d/%m/%Y %H:%M"),
                                             h[:32]))
    print("   %d combinaisons uniques, %d couples" % (len(ids), len(retenus)))
    print("   -> CANDIDAT_FINAL.txt, CANDIDAT_FINAL_couples.txt,")
    print("      et candidat_set.txt dans les fichiers communs MT5")
    print()
    etat = "TIENT" if (rb > 0 and rv > 0) else ("TIENT A MOITIE" if rb > 0 or rv > 0
                                                else "NE TIENT PAS")
    print("   ETAT SUR LES PERIODES DE REFERENCE : %s" % etat)
    print("   (B %+.4f et V %+.4f ; pour memoire, aleatoire -0.0293 et -0.0177)"
          % (rb, rv))
    if rb > 0 and rv > 0:
        print()
        print("   >>> LE CANDIDAT TIENT SUR LES DEUX PERIODES NON UTILISEES POUR")
        print("       LE CHOIX. C'est la condition que l'utilisateur a posee pour")
        print("       tirer le holdout. Test 2025-2026 a lancer.")
    else:
        print()
        print("   >>> le candidat ne tient pas sur les deux. NE PAS tirer le")
        print("       holdout pour lui : on le garderait pour rien.")


if __name__ == "__main__":
    main()
