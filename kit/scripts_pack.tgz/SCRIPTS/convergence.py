﻿"""Convergence check: my engine (intrabar M1) vs ST5 (M1 close-only).

Adds a close-resolution mode to the backtest engine to isolate the
modeling difference vs ST5's 1-minute OHLC (which only sees closes).
"""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import polars as pl
import numpy as np
from pathlib import Path

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
from edge_correct import load_m1, to_tf, seg_of, summarize, POINT, make_signals as make_signals_base

def backtest_m1_close(m1, tf, f, sym, cfg, max_hold_bars=480):
    """Like backtest_m1 but SL/TP only trigger on M1 CLOSE (ST5 1-min OHLC model)."""
    pt = POINT[sym]
    sigs = f["sig"].to_numpy()
    ts_tf = f["ts"].to_numpy()
    atr_tf = f["atr"].to_numpy()
    sl_atr = cfg.get("sl_atr", 2.0)
    rr = cfg.get("rr", 2.0)
    slip = cfg.get("slippage_pts", 0.5)

    t_m1 = m1["time"].to_numpy()
    bid_c = m1["bid_c"].to_numpy()
    ask_o = m1["ask_o"].to_numpy()
    bid_o = m1["bid_o"].to_numpy()

    m1_idx = np.searchsorted(t_m1, ts_tf, side="left")
    trades = []
    n_tf = len(f)
    last_exit_idx = -1
    for i in range(n_tf - 1):
        s = int(sigs[i])
        if s == 0 or np.isnan(atr_tf[i]) or atr_tf[i] <= 0:
            continue
        sl_pts = sl_atr * atr_tf[i] / pt
        tp_pts = rr * sl_pts
        j0 = m1_idx[i + 1]
        if j0 >= len(t_m1) or j0 <= last_exit_idx:
            continue
        entry = ask_o[j0] + slip * pt if s == 1 else bid_o[j0] - slip * pt
        if np.isnan(entry) or entry <= 0:
            continue
        cost_r = slip / sl_pts
        sl_px = entry - sl_pts * pt if s == 1 else entry + sl_pts * pt
        tp_px = entry + tp_pts * pt if s == 1 else entry - tp_pts * pt
        r = None
        k_exit = None
        for k in range(j0 + 1, min(j0 + 1 + max_hold_bars, len(t_m1))):
            close_px = bid_c[k]
            if s == 1:
                hit_sl = close_px <= sl_px
                hit_tp = close_px >= tp_px
            else:
                hit_sl = close_px >= sl_px
                hit_tp = close_px <= tp_px
            if hit_sl:
                r = -1.0; k_exit = k; break
            if hit_tp:
                r = rr; k_exit = k; break
        if r is None:
            k = min(j0 + max_hold_bars, len(t_m1) - 1)
            if s == 1:
                r = (bid_c[k] - slip * pt - entry) / (sl_pts * pt)
            else:
                r = (entry - (bid_c[k] + slip * pt)) / (sl_pts * pt)
            k_exit = k
        last_exit_idx = k_exit
        trades.append({"ts": int(t_m1[k_exit]), "r": float(r), "cost_r": float(cost_r),
                       "sl": float(sl_pts), "bars": int(k_exit - j0)})
    return trades

if __name__ == "__main__":
    sym = "EURUSD"
    m1 = load_m1(sym)
    # ---- range_fade M15 (lb=40, sl=1.5, rr=1.5) ----
    for tf_sec, cfg, kind in [
        (900, {"lookback": 40, "w": 6, "thr": 0.2, "sl_atr": 1.5, "rr": 1.5, "session": None, "slippage_pts": 0.5}, "range_fade"),
        (3600, {"lookback": 20, "thr": 0.5, "sl_atr": 3.0, "rr": 2.0, "session": None, "slippage_pts": 0.5}, "momentum"),
    ]:
        tf = to_tf(m1, tf_sec)
        df = seg_of(tf)
        m1s = seg_of(m1)
        print(f"\n=== {sym} M{tf_sec//60} {kind} {cfg} ===")
        for sname in ["IS-1", "IS-2", "OOS"]:
            seg = df.filter(pl.col("seg") == sname)
            m1seg = m1s.filter(pl.col("seg") == sname)
            if kind == "momentum":
                from edge_tf import make_signals_tf
                f = make_signals_tf(seg, kind, cfg)
            else:
                f = make_signals_base(seg, kind, cfg)
            tr_intra = summarize(backtest_m1_close(m1seg, seg, f, sym, cfg, max_hold_bars=200000))
            # intrabar version from edge_correct
            from edge_correct import backtest_m1
            tr_full = summarize(backtest_m1(m1seg, seg, f, sym, cfg, max_hold_bars=200000))
            print(f"  {sname}: intrabar n={tr_full['n']} net={tr_full['net']} | close-only n={tr_intra['n']} net={tr_intra['net']}")
