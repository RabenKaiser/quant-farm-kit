"""Comparaison moteur vs MT5 pour le ptrail : counts et net/trade.
Si l'EA MT5 trade 3-4x plus que le moteur, la réplication est fausse et les
étages 4 (ptrail, MFR) sont invalides -> il faut corriger les EAs."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
import polars as pl
import numpy as np
import datetime as dt
import edge_correct as ec
import deep_signals as DS

E = lambda s: int(dt.datetime.strptime(s, "%Y-%m-%d").timestamp())
a, b = E("2024-01-01"), E("2025-01-01")

# MOTEUR : ptrail (htf_nest + pyramiding + trail) sur USDJPY M30
# = la famille htf_nest avec les params ptrail du leader
m1 = ec.load_m1("USDJPY")
tf = ec.to_tf(m1, 1800)
tfseg = tf.filter((pl.col("time") >= a) & (pl.col("time") < b))
m1seg = m1.filter((pl.col("time") >= a) & (pl.col("time") < b))

# config ptrail leader : lookback 40, sl 1.5 ATR, pyr 1.5R max 2, trail 3.5/1.0
cfg = dict(htf_sec=14400, lookback=40, sl_atr=1.5, rr=99, pyramid_max=2,
           pyramid_trigger_r=1.5, trail_atr_mult=3.5, trail_trigger_r=1.0,
           commission_rt=4.0, tick_value_per_pt=0.67)
f = DS.htf_nest(tfseg, cfg)
tr = ec.backtest_m1_ptrail(m1seg, tfseg, f, "USDJPY", cfg)
nets = np.array([t["r"] - t["cost_r"] for t in tr]) if tr else np.array([])
print(f"MOTEUR ptrail USDJPY 2024: n={len(nets)} net/trade={nets.mean():+.3f}" if len(nets) else "0 trades")
print(f"  (MT5 EA : n=262, profit +$8797 sur 2024)")
print(f"  écart de count: {262/max(1,len(nets)):.1f}x")

# aussi MFR moteur vs MT5 pour rappel
print("\nRappel MFR M15 : moteur ~200/an vs MT5 ~2200/an = 10x")
print("=> PATTERN : les EAs MT5 tradent 3-10x plus que le moteur")
print("=> soit les EAs sont trop permissifs (filtres manquants), soit le")
print("   moteur est trop restrictif (filtres en trop)")
