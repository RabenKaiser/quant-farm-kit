﻿import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G
# les CSV m1_real viennent d'un EXPORT EA, pas de l'API
import os
p = G.M1R / "XAUUSD_M1.csv"
print("source python :", p)
print("existe :", p.exists(), "| %.1f Mo" % (p.stat().st_size/1e6))
# plage
import pandas as pd
df = pd.read_csv(p, nrows=3)
print("colonnes :", list(df.columns))
df2 = pd.read_csv(p, usecols=["time"] if "time" in df.columns else None)
