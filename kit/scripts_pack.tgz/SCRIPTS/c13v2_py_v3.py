# -*- coding: utf-8 -*-
"""c13v2_py_v3.py — version vectorisee PROPRE. OB par detection retrograde
simple; propagation par boucle unique sur M15 (pas de while complexe)."""
import sys
import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
BARS = r"C:\EAFarm\HISTORY - Copy\research\bars"


def load_m1(sym):
    df = pd.read_parquet(f"{BARS}\\{sym}_M1_db.parquet")
    df = df.set_index("ts_event").sort_index()
    df = df[~df.index.duplicated(keep="last")]
    return df[["open", "high", "low", "close", "volume"]].astype(float)


def resample(df, rule):
    return df.resample(rule).agg(
        {"open": "first", "high": "max", "low": "min", "close": "last",
         "volume": "sum"}).dropna()


def atr_s(s, period=14):
    h, l, c = s["high"], s["low"], s["close"]
    pc = c.shift(1)
    tr = pd.concat([(h - l), (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    return tr.rolling(period).mean()


def detect_ob(m15, cfg, lookahead):
    """Detecte OB bull/bear avec impulsion dans jj+1..jj+L.
    lookahead=True: utilisable immediatement (mode python boss, optimiste).
    lookahead=False: utilisable seulement apres confirmation (honnete)."""
    o = m15["open"].to_numpy(); h = m15["high"].to_numpy()
    l = m15["low"].to_numpy(); c = m15["close"].to_numpy()
    v = m15["volume"].to_numpy()
    a15 = atr_s(m15, 14).to_numpy()
    av = pd.Series(v).rolling(cfg.get("vol_look", 50)).mean().to_numpy()
    n = len(m15)
    body = np.abs(c - o)
    is_bull = c > o
    is_bear = c < o
    L = cfg.get("imp_look", 5)
    imp_mult = cfg.get("imp_atr", 0.9)
    vol_mult = cfg.get("imp_vol", 1.0)

    bull = {}   # jj -> (dispo_idx, zl, zh)
    bear = {}
    for jj in range(n):
        if not np.isfinite(a15[jj]) or a15[jj] <= 0:
            continue
        thr = a15[jj] * imp_mult
        dispo = jj if lookahead else None
        if is_bear[jj]:
            for k in range(1, L + 1):
                kk = jj + k
                if kk >= n:
                    break
                vok = (not np.isfinite(av[kk])) or v[kk] >= av[kk] * vol_mult
                if is_bull[kk] and body[kk] >= thr and c[kk] > h[jj] and vok:
                    bull[jj] = (kk if not lookahead else jj, l[jj], o[jj])
                    break
        if is_bull[jj]:
            for k in range(1, L + 1):
                kk = jj + k
                if kk >= n:
                    break
                vok = (not np.isfinite(av[kk])) or v[kk] >= av[kk] * vol_mult
                if is_bear[kk] and body[kk] >= thr and c[kk] < l[jj] and vok:
                    bear[jj] = (kk if not lookahead else jj, o[jj], h[jj])
                    break
    return bull, bear


def backtest(sym, year, cfg):
    m1 = load_m1(sym)
    start = pd.Timestamp(f"{year}-01-01", tz="UTC")
    end = pd.Timestamp(f"{year + 1}-01-01", tz="UTC")
    wu = start - pd.Timedelta(days=260)
    m5 = resample(m1.loc[wu:end], "5min").loc[start:end]
    m15 = resample(m1.loc[wu:end], "15min")
    h4 = resample(m1.loc[wu:end], "4h")
    lookahead = cfg.get("lookahead", False)

    if cfg.get("bias", "ema") == "vwap":
        tv = (h4["high"] + h4["low"] + h4["close"]) / 3
        vwap = (tv * h4["volume"]).rolling(cfg.get("vwap_len", 96)).sum() / \
               h4["volume"].rolling(cfg.get("vwap_len", 96)).sum()
    else:
        vwap = h4["close"].ewm(span=cfg.get("ema", 200), adjust=False).mean()

    bull, bear = detect_ob(m15, cfg, lookahead)
    n15 = len(m15)
    max_age = cfg.get("ob_age", 100000)

    # pre-calcul par index m15: dernier OB dispo (par liste triee + pointeur)
    bull_items = sorted(bull.items())
    bear_items = sorted(bear.items())
    lastB = {}  # i15 -> (zl, zh, jj)
    lastS = {}
    bi = 0
    si = 0
    curB = None
    curS = None
    for i15 in range(n15):
        while bi < len(bull_items) and bull_items[bi][0] <= i15:
            jj, (dispo, zl, zh) = bull_items[bi]
            if dispo <= i15:
                curB = (zl, zh, jj)
                bi += 1  # consomme seulement si dispo
            else:
                break   # pas encore dispo: garde pour plus tard
        while si < len(bear_items) and bear_items[si][0] <= i15:
            jj, (dispo, zl, zh) = bear_items[si]
            if dispo <= i15:
                curS = (zl, zh, jj)
                si += 1
            else:
                break
        lastB[i15] = curB
        lastS[i15] = curS

    # M5
    m15_t = m15.index.values.astype("datetime64[ns]")
    m5_t = m5.index.values.astype("datetime64[ns]")
    idx15 = np.clip(np.searchsorted(m15_t, m5_t, side="right") - 1, 0, n15 - 1)
    o5 = m5["open"].to_numpy(); h5 = m5["high"].to_numpy()
    l5 = m5["low"].to_numpy(); c5 = m5["close"].to_numpy()
    v5 = m5["volume"].to_numpy()
    av5 = pd.Series(v5).rolling(cfg.get("vol_look", 50)).mean().to_numpy()
    pip = 0.0001
    body5 = np.abs(c5 - o5)
    rej_wick = cfg.get("rej_wick", 1.0)
    close_in = cfg.get("close_zone", 0.15)

    signals = []  # (i, dirn, zl, zh)
    for i in range(len(m5)):
        i15 = idx15[i]
        # BUY
        b = lastB.get(i15)
        if b is not None and i15 - b[2] <= max_age:
            zl, zh = min(b[0], b[1]), max(b[0], b[1])
            zoneH = max(zh - zl, pip * 0.5)
            lowerW = min(o5[i], c5[i]) - l5[i]
            if (body5[i] >= pip * 0.5 and l5[i] <= zh and
                c5[i] >= zl + zoneH * close_in and c5[i] <= zh and
                c5[i] > o5[i] and body5[i] > 0 and
                (lowerW / body5[i]) >= rej_wick):
                signals.append((i, 1, zl, zh))
        s_ = lastS.get(i15)
        if s_ is not None and i15 - s_[2] <= max_age:
            zl, zh = min(s_[0], s_[1]), max(s_[0], s_[1])
            zoneH = max(zh - zl, pip * 0.5)
            upperW = h5[i] - max(o5[i], c5[i])
            if (body5[i] >= pip * 0.5 and h5[i] >= zl and
                c5[i] <= zh - zoneH * close_in and c5[i] >= zl and
                c5[i] < o5[i] and body5[i] > 0 and
                (upperW / body5[i]) >= rej_wick):
                signals.append((i, -1, zl, zh))

    # simulation (bias sur close precedente)
    hour = m5.index.hour.to_numpy()
    excl = set(cfg.get("excl_hours", []))
    min_stop = cfg.get("min_stop", 0.00025)
    tp_r = cfg.get("tp_r", 2.5)
    buf = cfg.get("buf_atr", 0.25)
    a15v = atr_s(m15, 14).to_numpy()

    pos = None
    trades = []
    sig_map = {i: s for s in signals for i in [s[0]]}
    for i in range(1, len(m5)):
        if pos is not None:
            dirn = pos["dir"]
            sl = pos["sl"]; tp0 = pos["tp"]; entry = pos["entry"]
            hit_sl = (l5[i] <= sl) if dirn == 1 else (h5[i] >= sl)
            hit_tp = (h5[i] >= tp0) if dirn == 1 else (l5[i] <= tp0)
            if hit_sl or hit_tp:
                exit_px = tp0 if (hit_tp and not hit_sl) else sl
                r = (exit_px - entry) / pos["risk"] if dirn == 1 \
                    else (entry - exit_px) / pos["risk"]
                trades.append(r)
                pos = None
        if pos is None and i in sig_map and hour[i] not in excl:
            bv = vwap.asof(m5.index[i - 1]) if len(vwap.dropna()) else np.nan
            if np.isnan(bv):
                continue
            bias = 1 if c5[i - 1] > bv else -1
            dirn = sig_map[i][1]
            if (dirn == 1 and bias != 1) or (dirn == -1 and bias != -1):
                continue
            entry = c5[i]
            zl, zh = sig_map[i][2], sig_map[i][3]
            atrv = a15v[idx15[i]]
            if dirn == 1:
                sl = zl - (buf * atrv if np.isfinite(atrv) else pip * 5)
                if (entry - sl) < min_stop:
                    sl = entry - min_stop
                risk = entry - sl
                tp = entry + risk * tp_r
            else:
                sl = zh + (buf * atrv if np.isfinite(atrv) else pip * 5)
                if (sl - entry) < min_stop:
                    sl = entry + min_stop
                risk = sl - entry
                tp = entry - risk * tp_r
            if risk > 0:
                pos = {"dir": dirn, "entry": float(entry), "sl": float(sl),
                       "tp": float(tp), "risk": float(risk)}
    if not trades:
        return {"n": 0, "R": 0.0, "wr": 0, "pf": 0, "dd": 0}
    arr = np.array(trades)
    wins = arr[arr > 0]; losses = arr[arr < 0]
    gw = wins.sum(); gl = -losses.sum()
    eq = np.cumsum(arr)
    dd = float((np.maximum.accumulate(eq) - eq).max())
    return {"n": len(arr), "R": float(arr.sum()),
            "wr": float(len(wins) / len(arr) * 100),
            "pf": float(gw / gl) if gl > 0 else 99.0, "dd": dd}


if __name__ == "__main__":
    sym = sys.argv[1] if len(sys.argv) > 1 else "EURUSD"
    year = int(sys.argv[2]) if len(sys.argv) > 2 else 2024
    look = "--look" in sys.argv
    cfg = {"imp_atr": 0.9, "imp_vol": 1.0, "imp_look": 6, "ob_age": 100000,
           "rej_wick": 1.0, "rej_vol": 1.0, "close_zone": 0.15, "tp_r": 2.5,
           "bias": "ema", "excl_hours": [6, 7, 12, 15, 19, 23],
           "min_stop": 0.00025, "buf_atr": 0.25, "lookahead": look}
    import time
    t0 = time.time()
    res = backtest(sym, year, cfg)
    print(sym, year, "look=", look, res, f"{time.time()-t0:.1f}s")
