﻿import MetaTrader5 as mt5
mt5.initialize(path=r"C:\EAFarm\MT5\Farm\terminal64.exe")
i = mt5.symbol_info("EURAUD")
print(f"  trade_stops_level = {i.trade_stops_level} points")
print(f"  trade_freeze_level = {i.trade_freeze_level} points")
print(f"  point = {i.point}")
print(f"  => distance min SL = {i.trade_stops_level*i.point:.5f}")
mt5.shutdown()
