"""ANALYSE ACTIVE : les CSVs du moteur reproduisent-ils Alpari ?
Compare les barres M30 GBPUSD du moteur (CSVs) aux barres M30 Alpari réelles
(teste via MT5) sur une même fenêtre. Si elles diffèrent structurellement,
TOUT le screening moteur sur GBPUSD/AUDCAD est faussé -> il faut re-tester sur
Alpari. C'est le test qui décide si nos ~100 rejets sont réels ou artefact."""
import sys, json
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner as m

# 1) run MT5 rapide GBPUSD M30 2023-01 -> 2023-02 pour obtenir les barres Alpari
# (le log du testeur contient les ticks/barres générées)
r = m.run_backtest("EURUSD_H1_COMBO", "GBPUSD", "M30", "2023.01.01", "2023.02.01", 10000)
print("run MT5 GBPUSD M30:", r.get("profit"), "trades:", r.get("trades"))

# 2) le log agent contient les prix des deals -> comparer aux CSVs
import re
from pathlib import Path
CF = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3")
agent = CF / "Tester" / "logs" / "20260823.log"
if agent.exists():
    raw = agent.read_text("utf-16", errors="replace")
    # prix GBPUSD du run
    prices = re.findall(r"GBPUSD at ([\d.]+)", raw)
    print(f"prix GBPUSD Alpari dans le log: {len(prices)} échantillons")
    if prices:
        ps = sorted(set(float(p) for p in prices))
        print(f"  range Alpari: {ps[0]:.5f} -> {ps[-1]:.5f} (n={len(ps)})")
