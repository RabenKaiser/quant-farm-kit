# -*- coding: utf-8 -*-
"""deploy_final_r43.py — SIM DEPLOY FINAL 12 legs Upcomers, lots EXACTS des
presets (lus du terminal), equities TOUTES rescalees au balance reel des logs.
Regles Upcomers: daily -4% (jour local), floor -5%, kill interieur EA -3%."""
import os
import pandas as pd
import numpy as np

TEAM = r"C:\EAFarm\HISTORY - Copy\research\prop_team\equities"
ACCT = 50000.0
# leg -> (fichier equity 0.1 lot, lots preset Upcomers actuel)
LEGS = {"EURUSD": ("equity_UPC-V3INT-EURUSD.csv", 1.9),
        "GBPJPY": ("equity_UPC-V3INT-GBPJPY.csv", 2.4),
        "NZDJPY": ("equity_UPC-V3INT-NZDJPY.csv", 1.1),
        "AUDUSD": ("equity_UPC-V3INT-AUDUSD.csv", 2.3),
        "NZDUSD": ("equity_UPC-V3INT-NZDUSD.csv", 2.4),
        "CROSS-EURGBP": ("equity_UPC-CROSS-EURGBP.csv", 20.0),
        "GBPUSD-620": ("equity_UPC-GBPUSD-620.csv", 1.6),
        "DOW": ("equity_UPC-DOW.csv", 0.5),
        "SPX": ("equity_UPC-SPX.csv", 1.4),
        "FRCEUR": ("equity_UPC-FRCEUR.csv", 1.7),
        "VWAPF-XAU": ("equity_UPC-VWAPF-XAU.csv", 0.1),
        "VWAPT-XAU": ("equity_UPC-VWAPT-XAU.csv", 0.1)}
ser = {}
for tag, (f, lots) in LEGS.items():
    p = os.path.join(TEAM, f)
    if os.path.exists(p):
        s = pd.read_csv(p, index_col=0, parse_dates=True).iloc[:, 0]
        ser[tag] = s * (lots / 0.10)  # pnl $ au lots preset (equity = base 0.1)
    else:
        print("MANQUE", tag)
a = pd.concat([s.rename(t) for t, s in ser.items()], axis=1,
              join="outer").fillna(0.0)
a = a.reindex(pd.bdate_range("2026-01-02", "2026-09-01")).fillna(0.0)
comb = a.sum(axis=1)
dr = comb / ACCT
print(f"=== DEPLOY FINAL (lots presets EXACTS) — Upcomers 2026, equities reel ===")
print(f"jours n={len(dr)} | sigma/j {dr.std()*100:.2f}% | mean/j "
      f"{dr.mean()*100:+.3f}% | meilleur {dr.max()*100:+.1f}% | pire "
      f"{dr.min()*100:+.1f}%")

# pnl/jour par leg aux lots presets (diagnostique)
print("\npar leg aux lots presets:")
for tag in LEGS:
    lots = LEGS[tag][1]
    s = a[tag]
    print(f"  {tag:14s} lots {lots:>5} | sum {s.sum():+10.0f}$ | min/j "
          f"{s.min():+9.0f} | max/j {s.max():+9.0f}", flush=True)

# sim regles Upcomers (kill firme -4% jour, floor -5%)
eq, cd, ds = ACCT, None, ACCT
floor = ACCT * 0.95
kills = 0
stopped = False
eqs = []
for ts, p in comb.items():
    d = ts.date()
    if cd != d:
        cd = d
        ds = eq
    if stopped:
        eqs.append(eq)
        continue
    ne = eq + p
    if ne <= ds * 0.96 and p < 0:
        ne = ds * 0.96
        kills += 1
    eq = ne
    if eq <= floor:
        stopped = True
    eqs.append(eq)
c = pd.Series(eqs, index=comb.index)
mo = c.resample("ME").last().pct_change()
mo.iloc[0] = c.resample("ME").last().iloc[0] / ACCT - 1.0
mo = mo[mo.index < "2026-09-01"]
print(f"\njours kill -4%: {kills} | stop overall -5%: {stopped}")
print(f"moy/mois: {mo.mean()*100:+.2f}% | net 8 mois: {c.iloc[-1]-ACCT:+,.0f}$")
for p, v in mo.items():
    print(f"  {p.strftime('%Y-%m')}: {v*100:+5.2f}%")
# risque par trade estime (worst-trade-based)
print("\nrisque/trade approx = pire perte journaliere moyenne / 2 trades max")
print(f"  pire jour total {dr.min()*100:+.1f}% (~{comb.min():+.0f}$)")
print("FIN", flush=True)
