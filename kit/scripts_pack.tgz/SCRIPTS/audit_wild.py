﻿import sys, datetime as _dt
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
import numpy as np
import polars as pl
from edge_correct import load_m1, to_tf, backtest_m1, backtest_m1_pyr, COMMISSION_RT, TICK_VALUE_PER_PT
import deep_signals as DS

def E(d):
    return int(_dt.datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=_dt.timezone.utc).timestamp())

OOS = (E("2023-01-01"), E("2024-01-01"))

LEADERS = [
    ("pyr  (lb40 sl1.5 rr4 +1 add@2R)", "htf_nest",
     {"slippage_pts": 0.5, "htf_sec": 14400, "lookback": 40, "sl_atr": 1.5, "rr": 4,
      "pyramid_max": 1, "pyramid_trigger_r": 2.0}, True),
    ("wide (lb40 sl1.0 rr6)", "htf_nest",
     {"slippage_pts": 0.5, "htf_sec": 14400, "lookback": 40, "sl_atr": 1.0, "rr": 6}, False),
]

def audit(sym, tf_sec, family, cfg, use_pyr):
    m1 = load_m1(sym)
    tf = to_tf(m1, tf_sec)
    c = dict(cfg, commission_rt=COMMISSION_RT[sym], tick_value_per_pt=TICK_VALUE_PER_PT[sym])
    m1o = m1.filter((pl.col("time") >= OOS[0]) & (pl.col("time") < OOS[1]))
    tfo = tf.filter((pl.col("time") >= OOS[0]) & (pl.col("time") < OOS[1]))
    f = DS.REGISTRY[family](tfo, c)
    bt = backtest_m1_pyr if use_pyr else backtest_m1
    tr = bt(m1o, tfo, f, sym, c)
    if not tr:
        return None
    res = pl.DataFrame(tr).with_columns((pl.col("r") - pl.col("cost_r")).alias("net"))
    net = res["net"].to_numpy()
    gross = res["r"].to_numpy()
    n = len(res)
    top5 = np.sort(net)[-5:]
    net_no5 = (net.sum() - top5.sum()) / (n - 5) if n > 5 else 0.0
    cum = np.cumsum(net)
    maxdd = float((cum - np.maximum.accumulate(cum)).min())
    res = res.with_columns((pl.col("entry_ts") // 86400 * 86400 * 1000).cast(pl.Datetime("ms")).dt.strftime("%Y-%m").alias("ym"))
    g = res.group_by("ym").agg(pl.col("net").sum().alias("R")).sort("ym")
    months = [(r["ym"], round(float(r["R"]), 1)) for r in g.to_dicts()]
    pos = sum(1 for _, r in months if r > 0)
    pf = float(gross[gross > 0].sum() / abs(gross[gross < 0].sum())) if (gross < 0).any() else 99.0
    return dict(n=n, net=net.mean(), no5=net_no5, pf=pf, dd=maxdd, pos=pos, tot=len(months), months=months)

for name, fam, cfg, pyr in LEADERS:
    print(f"=== {name} | USDJPY OOS 2023 | same config all TF ===")
    for tf in [3600, 1800, 900, 300]:
        r = audit("USDJPY", tf, fam, cfg, pyr)
        if r is None:
            print(f"  M{tf//60:2d}: no trades")
            continue
        print(f"  M{tf//60:2d}: n={r['n']:3d} netR/tr={r['net']:+.3f} top5-out={r['no5']:+.3f} "
              f"PF={r['pf']:.2f} maxDD={r['dd']:.1f}R pos={r['pos']}/{r['tot']}")
        print(f"        {r['months']}")
