"""boucle_nuit : huit heures autonomes -- campagnes restantes, puis mesures et composition.

Round 451. Objectif demande par l'utilisateur : « automate the night loop for 8h ». Ce script enchaine
sans intervention, en cycles :

  1. si le profil farm est LIBRE (aucun journal de campagne modifie depuis 3 minutes -- le seul test qui
     ne se confonde pas avec autre chose, cf. round 421), lancer la prochaine campagne de la file via
     `lance_campagne.ps1`, donc EN POWERSHELL : les lancements pilotes par un sous-processus Python
     echouent (rounds 422-428) ;
  2. puis remesurer : `reel_empile.py` (R/tx reels par couple, avec controle de couverture des annees),
     `combi_reel.py` sur FENETRE DECLAREE (round 421 : un classement de composition n'a de sens qu'avec
     sa duree) et `prop_reel.py` sur les meilleures jambes (la regle de decision : drawdown sous 5 % ET
     pire annee positive) ;
  3. journaliser l'essentiel dans `NUIT.md` et dans `boucle_nuit.log`, en une ligne par cycle.

La file de campagnes traite d'abord ce qui manque aux jambes validees (finir XAUUSD L r=50 et reprendre
les fenetres en echec), parce que c'est ce qui peut encore changer une conclusion. Les campagnes deja
completes ne sont PAS relancees : le script ne rejoue que ce qui a echoue ou ce qui n'a jamais tourne.

Usage : python SCRIPTS\\boucle_nuit.py      (env HEURES=8)
"""
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

# ROUND 452 : « pwsh » n'est pas resolu par nom dans cet environnement -- le premier lancement a echoue
# avec [WinError 2] The system cannot find the file specified, alors que la detection du profil libre,
# elle, avait parfaitement fonctionne. On resout le chemin une fois, avec repli sur powershell.exe.
SHELL = shutil.which("pwsh") or shutil.which("pwsh.exe") or shutil.which("powershell") or "powershell"

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
S = B / "SCRIPTS"
LOG = B / "boucle_nuit.log"
JOURNAL = B / "NUIT.md"
HEURES = float(os.environ.get("HEURES", "8"))
# ROUND 455 : la cible, exprimee en multiples du STOP (--tp-r du lanceur). 1 = cible serree, le reglage
# que l'utilisateur a propose et que le crible mu/sigma2 du round 454 a valide (facteur 4).
TP_R = os.environ.get("TP_R", "1")
# 3 minutes sans ecriture = campagne finie (un lanceur ecrit une ligne toutes les 35 a 60 s).
FRAICHEUR_S = 180

# File des campagnes, dans l'ordre de valeur.
# ROUND 455 : GEOMETRIE A CIBLE SERREE. L'utilisateur a propose de retrecir la cible sous un stop large ;
# la mesure du round 454 le confirme avec un facteur 4. Les campagnes ci-dessous portent des etiquettes
# NEUVES (prefixe g3_) pour que leurs resultats ne se melangent pas a ceux de l'ancienne geometrie
# (cible 2 x stop) : deux geometries differentes ne doivent jamais partager un fichier de resultats.
# La geometrie employee est celle de TP_R (variable d'environnement, 1 par defaut ici).
FILE = [
    # ROUND 464 : resume=True PARTOUT. La reprise existe deja (« ne pas refaire un test deja fait ») :
    # sans elle, une deuxieme boucle relance la meme campagne depuis zero et refait 4 h de tests deja
    # faits -- c'est exactement ce qui se serait produit a 19 h avec la chaine posee au round 464.
    ("g3_eurchf_s20", "g_c20.txt", "EURCHF", True),      # mu/sigma2 0,658 -- 6/6 annees positives
    ("g3_eurchf_s50", "g_crest.txt", "EURCHF", True),    # 0,383 -- comparaison directe avec -0,0558
    ("g3_audcad_s50", "g_crest.txt", "AUDCAD", True),    # 0,414 -- jambe de reference deja validee
    ("g3_eurchf_l100", "g_l100.txt", "EURCHF", True),    # 0,449 (achat)
    ("g3_audcad_s100", "g_crest100.txt", "AUDCAD", True),  # 0,340
    ("g3_gbpcad_l50", "g_l50.txt", "GBPCAD", True),      # 0,217 (achat)
    ("g3_nzdusd_aud", "g_c20.txt", "NZDUSD,AUDUSD", True),  # references range 20 deja validees
    # ROUND 464 : LE PROGRAMME DE VOLUME. La probabilite de passer le prop (passe_prop.py) exige environ
    # huit fois le volume de transactions du panier actuel a mu/sigma2 egal : 41,5 % de chances a x1,
    # 78,9 % a x8. Les cinq campagnes ci-dessous ajoutent les couples les mieux classes du crible qui ne
    # sont pas encore mesures en ordres reels. Rien ne change dans la geometrie -- TP = 1 ATR pour un
    # stop de 3 ATR (TP_R=1), la seule qui ait fait monter mu/sigma2 sur les ordres reels.
    ("g3_nzdjpy_s50", "g_crest.txt", "NZDJPY", True),       # 0,204 | n=313
    ("g3_usdchf_s100", "g_crest100.txt", "USDCHF", True),   # 0,212 | cout 0,063
    ("g3_gbp_bloc", "g_crest100.txt", "GBPUSD", True),      # 0,151 | cout 0,033 -- le moins cher
    ("g3_usdcad_l50", "g_l50.txt", "USDCAD", True),         # 0,140 (achat)
    ("g3_jpy_c20", "g_c20.txt", "NZDJPY,AUDJPY", True),     # 0,203 et 0,134 | 5/5 annees
]
# ROUND 464 : LES CAMPAGNES A FENETRE LARGE. Le cout du banc se paie par TEST, pas par annee testee :
# une seule fenetre de 5,25 ans donne les memes transactions que dix fenetres annuelles et trimestrielles,
# pour un dixieme des synchronisations d'environnement. Ces campagnes sont placees EN FIN DE FILE : les
# campagnes a fenetres courtes, dont la chaine de mesure est eprouvee, passent d'abord ; celle-ci valide
# le mode large sans mettre la nuit en peril. Les statistiques par annee restent calculables, les lignes
# JRN et DEAL portant la date de chaque transaction.
# ROUND 467 : LE BLOC INDICE PASSE EN TETE. Le crible par classe d'instrument fait des indices le plus
# gros apport de volume disponible (1 068 transactions neuves a offset nul, decorrelees du FX), et le
# feed Dukascopy du farm porte bien USA500.IDX et USATECH.IDX avec un historique 2014-2026.
# ATTENTION (verifie le 23/09) : DOLLAR.IDX n'a d'historique QUE depuis 2025 -- les jambes UDXUSD du
# corpus (195, 247, 147 transactions) ne sont donc PAS validables sur 2020-2024, et le nom du symbole
# n'est pas USDIDX.IDX. Le dollard index est retire de la file jusqu'a ce que son historique existe.
FILE_LARGE = [("g3_idx_aus4", "g_crest.txt", "AUS.IDX", True, {"LARGE": "1", "TP_R": "4"}),
              ("g3_idx_aus2", "g_crest.txt", "AUS.IDX", True, {"LARGE": "1", "TP_R": "2"}),
              ("g3_idx_gbr_l2", "g_l20.txt", "GBR.IDX", True, {"LARGE": "1", "TP_R": "2"}),
              ("g3_idx_deu_l2", "g_l20.txt", "DEU.IDX", True, {"LARGE": "1", "TP_R": "2"}),
              ("g3_idx_us30_l2", "g_l20.txt", "USA30.IDX", True, {"LARGE": "1", "TP_R": "2"}),
              ("g3_idx_deu4", "g_crest.txt", "DEU.IDX", True, {"LARGE": "1", "TP_R": "4"}),
              ("g3_idx_aus_l2", "g_l20.txt", "AUS.IDX", True, {"LARGE": "1", "TP_R": "2"}),
              ("g3_chfjpy_s2", "g_c20.txt", "CHFJPY", True, {"LARGE": "1", "TP_R": "2"}),
              ("g3_idx_chi4", "g_c20.txt", "CHI.IDX", True, {"LARGE": "1", "TP_R": "4"}),
              ("g3_idx_ussc_l4", "g_l20.txt", "USSC2000.IDX", True, {"LARGE": "1", "TP_R": "4"}),
              ("g3_idx_jpn_l2", "g_l20.txt", "JPN.IDX", True, {"LARGE": "1", "TP_R": "2"}),
              ("g3_idx_eus4", "g_crest.txt", "EUS.IDX", True, {"LARGE": "1", "TP_R": "4"}),
              ("g3_idx_us500s2", "g_crest.txt", "USA500.IDX", True, {"LARGE": "1", "TP_R": "2"}),
              ("g3_idx_us500_l4", "g_l50.txt", "USA500.IDX", True, {"LARGE": "1", "TP_R": "4"}),
              ("g3_pt_audcad4", "g_crest.txt", "AUDCAD", True, {"LARGE": "1", "TP_R": "4"}),
              ("g3_pt_xauusd4", "g_l20.txt", "XAUUSD", True, {"LARGE": "1", "TP_R": "4"}),
              ("g3_idx_usatech_l1", "g_l20.txt", "USATECH.IDX", True, {"LARGE": "1"}),
              ("g3_large_us500b", "g_l100.txt", "USA500.IDX", True, {"LARGE": "1"}),
              ("g3_pt_audcad2", "g_crest.txt", "AUDCAD", True, {"LARGE": "1", "TP_R": "2"}),
              ("g3_pt_xauusd2", "g_l20.txt", "XAUUSD", True, {"LARGE": "1", "TP_R": "2"}),
              ("g3_large_chf", "g_crest100.txt", "EURCHF", True, {"LARGE": "1"}),
              ("g3_large_usdchf", "g_crest100.txt", "USDCHF", True, {"LARGE": "1"}),
              ("g3_large_jpy", "g_crest.txt", "NZDJPY", True, {"LARGE": "1"}),
              ("g3_large_gbp", "g_crest100.txt", "GBPUSD", True, {"LARGE": "1"})]


def log(msg):
    ligne = "[%s] %s" % (time.strftime("%H:%M:%S"), msg)
    print(ligne, flush=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(ligne + "\n")


def profil_libre():
    """Vrai si AUCUN lanceur ne tourne ET aucun journal n'a ete ecrit recemment.

    ROUND 456 : la fraicheur des journaux NE SUFFIT PAS. Une campagne qui ECHOUE n'ecrit plus de ligne
    pendant ses tentatives ratees ; la boucle la croyait donc finie, lançait une deuxieme campagne, et le
    nouveau lanceur tue le terminal du profil -- ce qui faisait echouer la premiere. C'etait un
    inter-blocage fabrique par mon propre test : observe a 12:35 avec DEUX couples de processus
    `lab_parallel` vivants (PID 6820/13892 et 2256/14548). Le seul test fiable est la presence d'un
    processus lanceur : s'il y en a un, le profil est occupe, quoi qu'ecrivent les journaux.
    """
    try:
        import subprocess as _sp
        # ROUND 531 (25/09, 13 h) : ON NE COMPTE QUE LES LANCEURS DU FARM. Le test comptait TOUS les
        # `lab_parallel.py`, y compris ceux de la voie Upcomers : des que le juge travaillait (ce qui est
        # le cas depuis 12 h), la boucle du farm se croyait le profil occupe et attendait... indefiniment.
        # Les deux profils ont deux fichiers de configuration et deux terminaux : ils DOIVENT pouvoir
        # tourner en parallele, c'est tout l'interet de la seconde ferme. On filtre sur `--only farm`
        # (ou l'absence de `--only mt5`).
        out = _sp.run([SHELL, "-NoProfile", "-Command",
                       "(Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
                       "Where-Object { $_.CommandLine -like '*lab_parallel.py*' -and "
                       "$_.CommandLine -notlike '*--only mt5*' }).Count"],
                      capture_output=True, text=True, timeout=60).stdout.strip()
        if out.isdigit() and int(out) > 0:
            return False, "%d lanceur(s) farm actif(s)" % int(out)
    except (OSError, Exception):
        pass  # si le test echoue, on retombe sur la fraicheur des journaux ci-dessous
    for f in B.glob("camp_*.log"):
        try:
            # ROUND 515 : LES JOURNAUX DE L'AUTRE TERMINAL NE DISENT RIEN DU FARM. La voie Upcomers
            # ecrit `camp_up_*.log` toutes les deux minutes ; la boucle du farm les prenait pour les
            # siens et se croyait le profil occupe -- mesure du 24/09 a 19 h 07 : « profil occupe par
            # camp_up_g3_fx100_audcad_4.log, attente », alors que le terminal du farm etait libre et
            # qu'aucun lanceur ne tournait. Deux profils, deux fichiers de configuration, deux
            # terminaux : la fraicheur des journaux doit se lire par profil.
            if f.name.startswith("camp_up_"):
                continue
            if (time.time() - f.stat().st_mtime) < FRAICHEUR_S:
                return False, f.name
        except OSError:
            continue
    return True, None


def lancer(tag, setfile, syms, resume, env=None):
    """Lance une campagne en POWERSHELL, sous forme de COMMANDE EN LIGNE.

    ROUND 452 : le premier essai passait par un fichier .ps1 et a echoue au parse (aucun journal ecrit,
    processus mort en quelques secondes). Plutot que de deboguer un script intermediaire, on utilise
    exactement la forme qui a produit toutes les campagnes valides de la session : une commande
    PowerShell en ligne avec `Tee-Object`, lancee avec `-NoProfile -Command`.
    """
    parts = ["cd '%s'" % S,
             "python lab_parallel.py --only farm --annuel --setfile %s --tag %s --holdout autorisation "
             "--syms %s --tf M30 --sl-atr 3 --tp-r 2 --hold-bars 64%s"
             % (setfile, tag, syms, " --resume" if resume else ""),
             "Tee-Object -FilePath '%s'" % (B / ("camp_%s.log" % tag))]
    # la redirection 2>&1 doit preceder le Tee : on compose la ligne dans l'ordre du shell
    # ROUND 463 : ANNEES=1 -- les fenetres trimestrielles 2024Q1..2025Q1 coutaient QUATRE tests de 27
    # minutes pour couvrir une seule annee civile. Le banc a ete mesure ce jour : 27 min par test quand
    # la machine est chargee (8,6 min de synchronisation + 18 min de ticks), donc 13 tests = 5,9 h par
    # campagne -- au-dela du delai de 3 h de ce lanceur, donc campagne JAMAIS terminee. Avec ANNEES=1 le
    # travailleur ne fait plus que les six annees 2020-2025 : meme couverture, 2,7 h.
    # ROUND 469 : LE RAPPORT RISQUE/RENDEMENT DEVIENT UN PARAMETRE PAR CAMPAGNE. Le crible des gros
    # objectifs (crible_payoff.py) montre que la meme famille paie beaucoup plus a 4 R qu'a 1 R sur
    # certains couples (AUDCAD S : +0,048 a 1 R, +0,155 a 4 R, 5/5 annees positives). TP_R reste la
    # valeur par defaut, mais une campagne peut demander la sienne.
    extra = "".join("$env:%s='%s'; " % (k, v) for k, v in (env or {}).items()
                    if k not in ("TP_R", "HOLD", "TF", "SLR", "ANNUEL"))
    # ROUND 498 : LA FENETRE LARGE NE MARCHE PAS POUR LES INDICES. Mesure du 23/09 : HKG.IDX en M15 sur la
    # fenetre 2020-2025.03 rend « 0 tick, 0 barre » (le testeur n'a pas d'historique aussi ancien pour ces
    # symboles sur ce feed), alors que les MEMES symboles en fenetres ANNUELLES rendent des transactions
    # (HKG.IDX 2024 : 297 transactions ; 2025Q1 : 61). Un symbole .IDX passe donc en mode ANNEES, et le
    # reste en fenetre large. Bonus mesure : un test M15 annuel prend 15 a 35 SECONDES (environnement en
    # cache), contre 1 h 45 pour une campagne large -- dix fois plus rapide.
    idx_sym = syms.split(",")[0].endswith(".IDX")
    if idx_sym:
        extra = extra.replace("$env:LARGE='1'; ", "")
        extra += "$env:LARGE='0'; $env:ANNEES='1'; "
        # ROUND 499 : NE PAS restreindre les fenetres. J'avais d'abord ajoute un filtre pour sauter 2020 a
        # 2023, en supposant que l'historique des indices commencait en 2024 : c'etait FAUX, et la campagne
        # en cours l'a montre en negotiant HKG.IDX des fevrier 2020 (le journal de l'agent porte l'entree
        # « ENT HKG.IDX SR100L entree=26078.97200 »). Ce qui echoue, c'est la FENETRE LARGE (5,25 ans en
        # M15, sans doute au-dela de ce que le testeur accepte pour ces symboles), pas les annees anciennes.
    tpr = (env or {}).get("TP_R", TP_R)
    tenue = (env or {}).get("HOLD", "64")
    trame = (env or {}).get("TF", "M30")
    # ROUND 512 : LE STOP DEVIENT UN PARAMETRE PAR LOT. Le crible des geometries (round 508) montre que
    # la divergence RSI sur HKG.IDX rend +0,3126 R/tx au stop de 3 ATR mais +0,4961 au stop de 1,5 ATR
    # sur les memes 391 transactions : le stop etait fige a 3 ATR dans le lanceur, donc la meilleure
    # geometrie mesuree ne pouvait pas etre mise au banc. Un lot peut desormais demander son propre stop.
    slr = (env or {}).get("SLR", "3")
    # ROUND 522 : LA TAILLE DE LA FENETRE DECIDE DE LA PLACE DISQUE EXIGEE. Le testeur genere les ticks
    # de TOUTE la fenetre avant de commencer : une fenetre annuelle d'indice reclame plus de vingt
    # gigaoctets libres et echoue en une minute trente avec « no disk space in ticks generating
    # function » des que la machine descend sous ce seuil -- meme avec quinze gigaoctets disponibles.
    # Une fenetre TRIMESTRIELLE demande environ quatre fois moins, pour un total de tests comparable, et
    # les resultats restent agregeables par annee. Un lot peut donc demander ANNUEL=0.
    annuel = (env or {}).get("ANNUEL", "1") == "1"
    ligne = ("$env:PYTHONIOENCODING='utf-8'; $env:REARM='64'; $env:ANNEES='1'; " + extra + "cd '%s'; "
             "python lab_parallel.py --only farm%s --setfile %s --tag %s "
             "--holdout autorisation --syms %s --tf %s --sl-atr %s --tp-r %s --hold-bars %s%s "
             "2>&1 | Tee-Object -FilePath '%s'"
             % (S, " --annuel" if annuel else "", setfile, tag, syms, trame, slr, tpr, tenue,
                " --resume" if resume else "", B / ("camp_%s.log" % tag)))
    del parts
    log("campagne %s (%s) resume=%s" % (tag, syms, resume))
    try:
        r = subprocess.run([SHELL, "-NoProfile", "-Command", ligne], timeout=6 * 3600,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        log("  %s terminee, code %d" % (tag, r.returncode))
    except subprocess.TimeoutExpired:
        log("  %s INTERROMPUE apres 6 h" % tag)
    except OSError as e:
        log("  %s : lancement impossible (%s)" % (tag, e))


def mesurer():
    """Remesure apres campagne.

    ROUND 531 (25/09, 15 h) : LA MESURE NE DOIT PLUS MANGER LE BANC. La chaine d'origine
    (reel_empile + combi_reel + prop_reel) prend 25 a 30 minutes par passage -- elle relit des journaux
    d'agents de 20 Mo -- et pendant ce temps AUCUNE campagne ne tourne. Elle tournait un cycle sur deux :
    la moitie du banc partait en mesure. `mesurer_lots_profil.py` fait le meme travail (R/tx par lot, par
    annee, plus la QUEUE de perte et un drapeau de validite quand le rapprochement ENT/JRN est mauvais)
    en quelques secondes, et c'est lui qui fait autorite depuis le 25/09. La chaine lourde reste
    disponible a la demande (MESURE_LOURDE=1), pas dans la boucle.
    """
    resume = []
    e = dict(os.environ)
    e["PYTHONIOENCODING"] = "utf-8"
    e["PROFIL"] = "farm"
    e["CORPUS"] = "m1_ext"
    e["N_MIN"] = "30"
    e.pop("UPCOMERS_2026", None)
    try:
        r = subprocess.run([sys.executable, str(S / "mesurer_lots_profil.py")], cwd=str(S), env=e,
                           timeout=900, capture_output=True, text=True)
        lignes = [l.strip() for l in (r.stdout or "").splitlines() if l.strip()]
        for l in [x for x in lignes if "LOTS RETENUS" in x or x.startswith("up_") or "n " in x][-6:]:
            log("  mesure | %s" % l[:170])
            resume.append(("mesurer_lots_profil", l))
        for l in [x for x in lignes if "NON VALIDE" in x][:4]:
            log("  mesure (invalidite) | %s" % l[:170])
    except (subprocess.TimeoutExpired, OSError) as ex:
        log("  mesure : echec (%s)" % ex)
    if os.environ.get("MESURE_LOURDE") == "1":
        resume += _mesurer_lourde()
    return resume


def _mesurer_lourde():
    resume = []
    for script, env in (("reel_empile.py", {}),
                        ("combi_reel.py", {"FENETRE": "2024-01,2025-12"}),
                        ("prop_reel.py", {"JAMBES": "AUDCAD,NZDUSD,XAUUSD"})):
        e = dict(os.environ)
        e.update(env)
        e["PYTHONIOENCODING"] = "utf-8"
        try:
            r = subprocess.run([sys.executable, str(S / script)], cwd=str(S), env=e,
                               timeout=2 * 3600, capture_output=True, text=True)
            lignes = [l.strip() for l in (r.stdout or "").splitlines() if l.strip()]
            cle = [l for l in lignes if ("EMPILE" in l or "moyenne par paire" in l
                                         or "MEILLEURE COMBINAISON" in l or "0.25 %" in l
                                         or "ATTENTION couverture" in l)]
            for l in cle[-4:]:
                log("  %s | %s" % (script, l[:170]))
                resume.append((script, l))
        except (subprocess.TimeoutExpired, OSError) as e:
            log("  %s : echec (%s)" % (script, e))
    return resume


def ecrire_journal(cycle, faits, mesures):
    with open(JOURNAL, "a", encoding="utf-8") as f:
        f.write("\n## Cycle %d -- %s\n\n" % (cycle, time.strftime("%H:%M")))
        f.write("Campagnes faites : %s\n\n" % (", ".join(faits) if faits else "aucune"))
        for script, l in mesures:
            f.write("- `%s` : %s\n" % (script, l))
        f.write("")


def main():
    debut = time.time()
    fin = debut + HEURES * 3600
    log("=== BOUCLE DE NUIT, %.1f h ===" % HEURES)
    if not JOURNAL.exists():
        JOURNAL.write_text("# Journal de la boucle de nuit\n", encoding="utf-8")
    cycle, faits_total = 0, []
    while time.time() < fin:
        cycle += 1
        libre, qui = profil_libre()
        if not libre:
            log("cycle %d : profil occupe par %s, attente" % (cycle, qui))
            time.sleep(150)
            continue
        # prochaine campagne non encore faite dans cette boucle
        # ROUND 474 : LA FILE VIENT DES LOTS quand LOTS.json existe (generer_lots.py). Un lot = un fichier
        # de reglages a PLUSIEURS lignes : la meme campagne valide plusieurs jambes de la meme paire a la
        # meme cible, puisque le temps de test ne depend que de la paire et de la fenetre. Les listes
        # ecrites en dur restent en secours si le fichier manque.
        lots = []
        try:
            import json as _json
            # ROUND 489 : L'ORDRE DE LA FILE SUIT LA VALEUR MESUREE. La vague 3 (seuil 0,90, theta 34) doit
            # passer AVANT la vague 4 (FX a 0,90, theta 2,2) : la premiere version les avait inversees, et la
            # nuit aurait consomme trois heures de banc sur les jambes les plus faibles avant d'atteindre les
            # meilleures. Ordre : seuil 0,90 -> vague 1 (0,97) -> horizons courts -> FX a 0,90.
            # ROUND 494 : la vague 5 (trame M15) passe en tete -- theta 74,4 contre 34 en M30.
            for nom_f in ("LOTS_V6.json", "LOTS_V5.json", "LOTS_V3.json", "LOTS.json", "LOTS_V2.json", "LOTS_V4.json"):
                f_lots = B / nom_f
                if not f_lots.exists():
                    continue
                for lot in _json.loads(f_lots.read_text(encoding="utf-8")):
                    env = {"LARGE": "1", "TP_R": str(lot["tp_r"])}
                    if lot.get("hold"):
                        env["HOLD"] = str(lot["hold"])
                    if lot.get("tf"):
                        # ROUND 504 : LA TRAME H1 N'A PAS DE NOM "M60" DANS LE FICHIER DE TEST.
                        # Le fichier de configuration du testeur attend les libelles MT5 (M1, M5,
                        # M15, M30, H1, H4) ; ecrire « M60 » y aurait laisse le terminal sur la
                        # trame par defaut, et la campagne VWAP H1 aurait en realite tourne en M30
                        # sans que rien ne le signale. Les minutes restent dans LOTS_V6.json pour
                        # la mesure Python (TF_MIN).
                        n_tf = int(lot["tf"])
                        env["TF"] = {60: "H1", 240: "H4"}.get(n_tf, "M%d" % n_tf)
                    if lot.get("rearm"):
                        # Meme valeur que le rearmement du crible Python (HOLD_BARRES).
                        env["REARM"] = str(lot["rearm"])
                    if lot.get("SLR"):
                        # ROUND 514 : LE STOP DU LOT DOIT ARRIVER JUSQU'AU LANCEUR. Le champ SLR etait
                        # lu par `lancer()` mais jamais recopie du fichier de lots vers l'environnement :
                        # la campagne de divergence RSI a donc demarre au stop de 3 ATR alors que sa
                        # meilleure geometrie mesuree est 1,5 ATR (+0,4961 contre +0,3126). Verifie sur
                        # la ligne de commande du processus : « --sl-atr 3 » au lieu de « --sl-atr 1.5 ».
                        env["SLR"] = str(lot["SLR"])
                    if lot.get("rollover"):
                        # ROUND 532 : ANTI-ROLLOVER PAR JAMBE. Le champ rollover du lot, format
                        # « HHMM/HHMM » (ex. « 2230/100 » = mise a plat 22:30 serveur, reouverture 01:00),
                        # alimente FLAT_HHMM/OPEN_HHMM que lab_parallel ecrit dans la config testeur
                        # (InpFlatHHMM/InpOpenHHMM). Absent = 0/0 = comportement historique inchange.
                        try:
                            _f, _o = str(lot["rollover"]).split("/", 1)
                            env["FLAT_HHMM"] = str(int(_f))
                            env["OPEN_HHMM"] = str(int(_o))
                        except ValueError:
                            pass
                    if lot.get("FENETRES"):
                        # ROUND 531 (25/09, 14 h) : MEME PIEGE QUE SLR, UN CRAN PLUS LOIN. Le champ
                        # FENETRES (les fenetres reellement testables) etait ecrit dans le fichier de lots
                        # mais JAMAIS recopie ici : la campagne redemandait dix periodes, dont trois qui ne
                        # peuvent rien rendre (« 0 ticks, 0 bars generated » a GBR.IDX).
                        env["FENETRES"] = str(lot["FENETRES"])
                        # ET LARGE=1 ANNULE TOUT FILTRE DE FENETRES (25/09, 20 h). La file pose
                        # `LARGE=1` par defaut, ce qui remplace la liste des periodes par UNE fenetre de
                        # 5,25 ans sans etiquette annuelle ni trimestrielle : le filtre FENETRES ne
                        # trouvait alors AUCUN libelle et la campagne partait avec « 0 periodes »
                        # (observe sur g3_div_euraud_s15 a 19:55:30 : « FILTRE FENETRES : » vide). Les
                        # symboles .IDX etaient proteges par la branche dediee ; les devises, non. Des
                        # qu'un lot demande des fenetres precises, on lui rend le mode annuel.
                        env["LARGE"] = "0"
                    if lot.get("ANNUEL") is not None:
                        # ROUND 522 : meme piege pour la taille de fenetre -- le champ etait dans le
                        # fichier de lots mais jamais recopie, donc ANNUEL=0 restait sans effet et la
                        # campagne continuait a demander des fenetres annuelles qui exigent vingt
                        # gigaoctets de ticks. On recopie explicitement.
                        env["ANNUEL"] = str(lot["ANNUEL"])
                    lots.append((lot["tag"], lot["setfile"], lot["syms"], True, env))
        except Exception:                                                 # noqa: BLE001
            lots = []
        file_complete = lots + list(FILE_LARGE) + [(t, s, y, r, {}) for (t, s, y, r) in FILE]

        # ROUND 497 : NE FAIRE TOURNER QUE LES SYMBOLES QUI ONT DES DONNEES. Controle du 23/09 sur le
        # nouveau compte (camp_ctrl_indices.log) : sur huit indices, quatre rendent des transactions et
        # quatre rendent le resultat degenere « 1 trade, maxpos 0 » -- c'est-a-dire aucune donnee, MT5 ne
        # resolvant pas le symbole dans la selection du compte. La Market Watch du nouveau compte est deux
        # fois plus petite que celle des anciens (15 072 o contre 32 854 o). En attendant que les symboles
        # manquants y soient ajoutes, on met DEVANT les campagnes dont le symbole est confirme.
        SYMBOLES_OK = {"DEU.IDX", "CHI.IDX", "HKG.IDX", "USA30.IDX", "USATECH.IDX",
                       "EURCHF", "XAUUSD", "AUDCAD", "NZDUSD", "AUDUSD", "CHFJPY", "USDCHF",
                       "NZDJPY", "GBPUSD", "USDCAD", "EURGBP", "EURAUD",
                       # ROUND 531 (25/09, 13 h) : LE TEST D'INTERSECTION PASSAIT EN DERNIER. Le tri
                       # ci-dessous met devant les symboles confirmes ; les huit indices du controle
                       # croise juge -> ferme (GBR, CHE, AUS, JPN, EUS, FRA, NLD, ESP) n'y etaient pas,
                       # donc les campagnes qui repondent a la seule question ouverte partaient en fin de
                       # file -- c'est-a-dire jamais, la boucle s'arrete quand la file est finie. Leurs
                       # dossiers d'historique existent bien dans la base Dukascopy du farm (verifie :
                       # bases\Dukascopy-demo-mt5-1\history\<INDICE>), donc ils passent devant.
                       "GBR.IDX", "CHE.IDX", "AUS.IDX", "JPN.IDX", "EUS.IDX", "FRA.IDX",
                       "NLD.IDX", "ESP.IDX", "USA500.IDX", "USSC2000.IDX", "VOL.IDX",
                       # ROUND 531 (25/09, 16 h 15) : les devises du controle croise (vente de divergence)
                       # passent devant aussi -- ce sont les seules jambes d'une AUTRE classe d'actifs, et
                       # c'est la seule facon de faire baisser un drawdown qui reste colle a la limite prop.
                       "AUDJPY", "GBPJPY",
                       # ROUND 553 (08/10) : LES CROISES YEN MULTI-FLUX. La chasse (271 WF, 41
                       # confirmes Dukascopy+Upcomers) a mis EURJPY en tete (BOLL_SQ, KELT_BRK,
                       # KELT_WALK) et EURUSD (KELT_WALK) : sans ces libelles, le tri repoussait
                       # leurs lots en fin de file et la session de 8 h ne les atteignait jamais.
                       "EURJPY", "EURUSD",
                       # ROUND 552 (26/09, 02 h 55) : L'ARGENT PASSAIT EN DERNIER, DONC JAMAIS. Le tri
                       # ci-dessous met devant les symboles confirmes et repousse les autres en fin de
                       # file ; la boucle s'arrete au bout de huit heures, donc les deux lots d'argent
                       # (`g3_sr97_xagusd`, `g3_kelt32_xagusd`) ajoutes cette nuit pour mesurer la seule
                       # famille ou l'argent est deja positif chez le juge (+0,1135) et la meilleure regle
                       # SR ferme (CRESTM) n'auraient pas tourne. L'argent est un instrument du flux
                       # Dukascopy (son M1 existe dans le corpus) : il passe devant.
                       "XAGUSD"}
        file_complete.sort(key=lambda c: 0 if c[2].split(",")[0] in SYMBOLES_OK else 1)
        reste = [c for c in file_complete if c[0] not in faits_total]
        if reste:
            tag, setfile, syms, resume, env = reste[0]
            lancer(tag, setfile, syms, resume, env)
            faits_total.append(tag)
        else:
            log("cycle %d : toutes les campagnes de la file ont ete traitees" % cycle)
        # ROUND 514 : LA MESURE NE BLOQUE PLUS LE BANC UN CYCLE SUR DEUX.
        # Mesure du 24/09 : la chaine de mesure (reel_empile + combi_reel + prop_reel) prend 25 a 30
        # minutes par cycle -- relever tous les lots depuis des journaux d'agents qui atteignent 21 Mo
        # -- pendant lesquelles AUCUNE campagne ne tourne. Sur douze heures et douze lots en file, cela
        # represente la moitie du banc perdue. La mesure tourne donc un cycle sur deux par defaut, et
        # reste forcable par MESURE_TOUS_LES=1.
        tous_les = max(1, int(os.environ.get("MESURE_TOUS_LES", "2")))
        if cycle % tous_les == 0 or tous_les == 1:
            mesures = mesurer()
        else:
            mesures = []
            log("cycle %d : mesure sautee (une sur %d), le banc enchaine" % (cycle, tous_les))
        ecrire_journal(cycle, faits_total[-1:], mesures)
        log("cycle %d termine (%.1f h restantes)" % (cycle, (fin - time.time()) / 3600.0))
        time.sleep(60)
    log("=== BOUCLE DE NUIT TERMINEE (8 h) : %s ===" % ", ".join(faits_total))
    return 0


if __name__ == "__main__":
    sys.exit(main())
