"""LA MEME REGLE, MESUREE HORS LIGNE ET EN ORDRES REELS : OU EST L'ECART ?

POURQUOI (26/09, 04 h). Le crible contre-courant donnait +0,2994 sur le Dax en 2024-2026 (t +7,20) avec le
mouvement de 2 ATR en 180 minutes ; la famille equivalente passee sur les VRAIS ordres de la ferme (bandes
de Bollinger 3 sigma, stop 1,5 ATR, cible 2 R, 64 barres) donne **-0,2450 sur 777 transactions** (t -5,14),
et NEGATIVE sur ses quatre lignes prises separement. Deux mesures aussi opposees ne peuvent pas decrire la
meme chose : il faut donc reproduire la regle de l'EA hors ligne, sur les memes donnees, et voir si l'ecart
vient de la condition (mon crible n'est pas la bande de Bollinger) ou du harnais.

Ce script mesure hors ligne, sur le meme moteur et les memes donnees :
  1. la bande de Bollinger 3 sigma (20 periodes M30) touchee a la cloture -- la regle de l'EA ;
  2. le mouvement de 2 ATR en 180 minutes -- mon crible ;
  3. le hasard, comme temoin.
"""
import sys
import pathlib

import numpy as np
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import barrieres_m1 as BM  # noqa: E402
import crible_contre_courant as C  # noqa: E402

B = pathlib.Path(r"C:\EAFarm\HISTORY - Copy\research")
SYMS = [("m1_ext", "DEU.IDX"), ("m1_ext", "HKG.IDX"), ("m1_real", "XAUUSD")]
PERIODE = ("2024-01-01", "2026-04-01")
MINUTES, SEUIL = 180, 2.0


def cadre(D):
    """Bandes de Bollinger 20 periodes, 3 sigma, calculees sur les cloture M30 CLOTUREES."""
    df = pd.DataFrame({"t": pd.to_datetime(D["t"], unit="s"), "c": D["c"]}).set_index("t")
    m30 = df["c"].resample("30min").last().dropna()
    moy = m30.rolling(20).mean()
    sig = m30.rolling(20).std(ddof=0)
    return (moy - 3 * sig).shift(1), (moy + 3 * sig).shift(1)   # .shift(1) : bande connue AVANT la bougie


def joue(D, mode, t0, t1):
    t, c, atr = D["t"], D["c30"], D["atr"]
    n = len(t)
    pas = max(1, int(MINUTES / 30))
    idx30 = [i for i in range(n) if i % 30 == 29 or (i + 1 < n and t[i + 1] - t[i] > 60)]
    bas, haut = cadre(D)
    bb_bas = bas.reindex(pd.to_datetime(t, unit="s"), method="ffill").values
    bb_haut = haut.reindex(pd.to_datetime(t, unit="s"), method="ffill").values
    rng = np.random.default_rng(20260926)
    out, bloque = [], -1
    for k in range(pas, len(idx30)):
        i, j = idx30[k], idx30[k - pas]
        if not (t0 <= t[i] < t1) or i <= bloque:
            continue
        if not np.isfinite(atr[i]) or atr[i] <= 0:
            continue
        if mode == "bb3":
            if not (np.isfinite(bb_bas[i]) and np.isfinite(bb_haut[i])):
                continue
            if c[i] < bb_bas[i]:
                sens = "L"
            elif c[i] > bb_haut[i]:
                sens = "S"
            else:
                continue
        elif mode == "mouvement":
            if not np.isfinite(c[j]):
                continue
            move = c[i] - c[j]
            if abs(move) < SEUIL * atr[i]:
                continue
            sens = "S" if move > 0 else "L"
        else:
            sens = "L" if rng.random() < 0.5 else "S"
        r = BM.issue(D, int(t[i]), float(c[i]), float(atr[i]), tpr=C.TPR, slr=C.SLR,
                     hold_min=C.HOLD, sens=sens, r_en_risque=True, par_barres=True)
        if r is None:
            continue
        kind, R, _p, t_sortie = r
        out.append((R, kind))
        bloque = int(np.searchsorted(t, t_sortie))
    return out


def resume(R):
    if len(R) < 20:
        return "n=%4d (trop peu)" % len(R)
    a = np.array(R)
    mu = float(a.mean())
    sd = float(a.std(ddof=1)) if len(a) > 1 else 0.0
    return "n=%5d  mu %+.4f  t %+.2f" % (len(a), mu, mu / (sd / np.sqrt(len(a))) if sd > 0 else 0.0)


def main():
    t0 = int(pd.Timestamp(PERIODE[0], tz="UTC").timestamp())
    t1 = int(pd.Timestamp(PERIODE[1], tz="UTC").timestamp())
    print("=" * 118)
    print("BANDE DE BOLLINGER 3 SIGMA CONTRE MOUVEMENT DE 2 ATR — memes donnees, meme moteur (%s a %s)"
          % PERIODE)
    print("=" * 118)
    L = ["# LA MEME REGLE HORS LIGNE ET EN ORDRES REELS", "",
         "Periode %s -> %s (celle que la ferme mesure). Stop 1,5 ATR, cible 2 R, 64 barres," % PERIODE,
         "premier toucher, cout pris dans les donnees.", "",
         "| instrument | Bollinger 3σ (la regle de l'EA) | mouvement 2 ATR en 180 min (mon crible) | hasard |",
         "|---|---|---|---|"]
    for src, sym in SYMS:
        D = C.prepare(sym, src)
        if D is None:
            continue
        res = {}
        for mode in ("bb3", "mouvement", "hasard"):
            tx = joue(D, mode, t0, t1)
            R = [x[0] for x in tx]
            res[mode] = resume(R)
            if mode == "bb3" and tx:
                k = np.array([x[1] for x in tx])
                res[mode] += " (cible %.0f %%, stop %.0f %%)" % (100 * np.mean(k == 0), 100 * np.mean(k == 1))
        print("  %-22s BB3 %s | mouv %s | hasard %s" % (sym, res["bb3"], res["mouvement"], res["hasard"]))
        L.append("| %s (%s) | %s | %s | %s |" % (sym, src, res["bb3"], res["mouvement"], res["hasard"]))
    L.append("\n## Rappel des mesures en ordres reels (ferme)")
    L.append("\nDax, bandes 3σ, 777 transactions : **−0,2450 (t −5,14)**, et ses quatre lignes séparément :")
    L.append("BBLOW3 −0,2364, BBHIGH3 −0,2471, BB3_XLO −0,2193, BB3_XHI −0,2782. Le corpus doit donc")
    L.append("s'accorder avec ces chiffres, sinon c'est le crible qui est en cause, pas la famille.")
    (B / "BB3_OFFLINE_VS_REEEL.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n  rapport ecrit dans BB3_OFFLINE_VS_REEEL.md")


if __name__ == "__main__":
    main()
