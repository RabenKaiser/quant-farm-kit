﻿import json
mt5 = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\mt5_up_results.json", encoding="utf-8"))
base = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\pos_baseline_6y.json", encoding="utf-8"))
print("=== CADJPY ===")
print("  MT5 par declencheur :", mt5["CADJPY"]["triggers"])
print("  Python 6 ans : 466 (total)")
print()
print("  jambes python CADJPY :")
sel = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\pos_selection.json", encoding="utf-8"))
for L in sel["legs"]:
    if L["sym"]=="CADJPY":
        print(f"    {L['trig']:<12} filt={L.get('filt')} n3={L['n3']} R3={L['R3']:+.1f}")
print()
print("  MT5 : ATPDL=1185, SWEEPHI=428, VWAPXUP=397, MACDXUP=84")
print("  => ATPDL domine (1185) alors que la jambe python at_PDL n'a que 54 trades")
print("     sur s3 et ~? sur 6 ans -> SUR-TRADE MASSIF sur ATPDL")
