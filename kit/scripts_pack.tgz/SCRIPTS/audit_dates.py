import collections, glob, json, os, re, sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
B = r"C:\EAFarm\HISTORY - Copy\research"


def bornes(label):
    """Bornes attendues d'une etiquette de fenetre, ou None si inconnue."""
    m = re.fullmatch(r"(\d{4})Q([1-4])", label or "")
    if m:
        a, q = int(m.group(1)), int(m.group(2))
        d0 = "%04d.%02d.01" % (a, 3 * (q - 1) + 1)
        d1 = ("%04d.01.01" % (a + 1)) if q == 4 else "%04d.%02d.01" % (a, 3 * q + 1)
        return d0, d1
    if re.fullmatch(r"\d{4}", label or ""):
        return "%s.01.01" % label, "%d.01.01" % (int(label) + 1)
    return None


blocs = collections.Counter()
sales = collections.Counter()
tous_tx = 0
tous_tx_sales = 0
detail = []
for f in sorted(glob.glob(os.path.join(B, "par_*_deals.jsonl"))):
    jours = collections.defaultdict(list)
    with open(f, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if not line.strip().startswith("{"):
                continue
            try:
                d = json.loads(line)
            except Exception:
                continue
            if d.get("day") and d.get("quarter"):
                jours[d["quarter"]].append(str(d["day"]))
    for lab, ds in jours.items():
        b = bornes(lab)
        if not b:
            continue
        tous_tx += len(ds)
        blocs[lab] += 1
        mn, mx = min(ds), max(ds)
        if mn < b[0] or mx >= b[1]:
            sales[lab] += 1
            tous_tx_sales += len(ds)
            detail.append((os.path.basename(f), lab, len(ds), mn, mx, b))

print("=== AUDIT DATES DE TRANSACTION CONTRE ETIQUETTE DE FENETRE ===")
print("blocs examines : %d | transactions : %d" % (sum(blocs.values()), tous_tx))
print("blocs CONTAMINES (au moins une transaction hors fenetre) : %d (%.1f %%)"
      % (sum(sales.values()), 100.0 * sum(sales.values()) / max(1, sum(blocs.values()))))
print("transactions dans un bloc contamine : %d (%.1f %%)"
      % (tous_tx_sales, 100.0 * tous_tx_sales / max(1, tous_tx)))
print("\nrepartition des blocs contamines par etiquette (les 12 pires) :")
for lab, n in sales.most_common(12):
    print("   %-8s : %d blocs contamines sur %d" % (lab, n, blocs[lab]))

print("\n=== DETAIL DES 20 PREMIERS BLOCS CONTAMINES ===")
print("fichier                              | etiquette | tx   | dates reelles        | attendu")
for f, lab, n, mn, mx, b in detail[:20]:
    print("%-36s | %-9s | %4d | %s -> %s | %s" % (f[:36], lab, n, mn, mx, b[0]))
