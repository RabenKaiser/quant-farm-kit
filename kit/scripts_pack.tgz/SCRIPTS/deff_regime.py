# -*- coding: utf-8 -*-
"""deff_regime.py — L'EFFICACITE DIRECTIONNELLE EXPLIQUE-T-ELLE NOS ECHECS ?

IDEE DE L'UTILISATEUR (16/09, 23 h) : remplacer la volatilite implicite (OTC,
hors de prix) par des estimateurs OHLC efficaces — Garman-Klass, Rogers-
Satchell, Yang-Zhang. Leur interet pour NOUS n'est pas le NIVEAU de volatilite
mais sa DECOMPOSITION :

    DEFF = RS / GK   = efficacite directionnelle
                       proche de 1 -> le prix balaie son range en tendance
                       proche de 0 -> il monte et descend dans le meme range

Le laboratoire a mesure que le marche va PLUS LOIN CONTRE NOUS QUE POUR NOUS
(MAE 9.84 ATR contre MFE 8.25) : pas de direction. Si c'est la cause, alors les
declencheurs doivent mieux marcher dans les regimes a DEFF eleve.

CE SCRIPT TESTE CETTE HYPOTHESE TOUT DE SUITE, hors ligne, sur les CSV M1
(100 Mo par paire) croises avec les performances deja mesurees :
    pour chaque (paire, periode) : DEFF et niveau de volatilite ;
    pour chaque (paire, periode) : le R moyen des combinaisons mesurees ;
    puis la correlation entre les deux.

USAGE : python deff_regime.py [chemin_csv]     (defaut : m1_pos)
"""
import collections
import json
import math
import statistics
import sys
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
PERIODES = {
    "2024Q1": ("2024-01-01", "2024-04-01"),
    "2024Q2": ("2024-04-01", "2024-07-01"),
    "2024Q3": ("2024-07-01", "2024-10-01"),
    "2024Q4": ("2024-10-01", "2025-01-01"),
    "2025Q1": ("2025-01-01", "2025-04-01"),
}


def gk(o, h, l, c):
    if l <= 0 or o <= 0 or c <= 0 or h <= l:
        return None
    x, y = math.log(h / l), math.log(c / o)
    v = 0.5 * x * x - (2 * math.log(2) - 1) * y * y
    return v if v > 0 else None


def rs(o, h, l, c):
    if l <= 0 or o <= 0 or c <= 0:
        return None
    v = math.log(h / c) * math.log(h / o) + math.log(l / c) * math.log(l / o)
    return v if v > 0 else None


def yz(o, h, l, c, pc):
    """Yang-Zhang d'une barre : il faut la cloture precedente pour le gap."""
    if l <= 0 or o <= 0 or c <= 0 or pc <= 0:
        return None
    g = math.log(o / pc)
    d = math.log(c / o)
    r = rs(o, h, l, c)
    if r is None:
        return None
    return g * g, d * d, r


def charge_periodes(csv):
    """Agrege le M1 en barres JOURNALIERES et calcule les estimateurs."""
    try:
        import pandas as pd
    except ImportError:
        return None
    try:
        d = pd.read_csv(csv, usecols=["time", "open", "high", "low", "close"])
    except Exception:
        return None
    d["time"] = pd.to_datetime(d["time"], unit="s", utc=True)
    d = d.set_index("time").sort_index()
    j = d.resample("1D").agg({"open": "first", "high": "max",
                              "low": "min", "close": "last"}).dropna()
    if len(j) < 30:
        return None
    out = collections.defaultdict(lambda: collections.defaultdict(list))
    pc = None
    for t, row in j.iterrows():
        o, h, l, c = row["open"], row["high"], row["low"], row["close"]
        per = None
        for nom, (a, b) in PERIODES.items():
            if a <= t.strftime("%Y-%m-%d") < b:
                per = nom
                break
        if per is None:
            pc = c
            continue
        v_gk, v_rs = gk(o, h, l, c), rs(o, h, l, c)
        v_yz = yz(o, h, l, c, pc) if pc else None
        if v_gk:
            out[per]["gk"].append(v_gk)
        if v_rs:
            out[per]["rs"].append(v_rs)
        if v_yz:
            out[per]["go"].append(v_yz[0])
            out[per]["do"].append(v_yz[1])
            out[per]["ro"].append(v_yz[2])
        pc = c
    res = {}
    for per, v in out.items():
        if len(v["gk"]) < 20:
            continue
        gk_m = statistics.mean(v["gk"])
        rs_m = statistics.mean(v["rs"])
        vo = statistics.mean(v["go"])
        vc = statistics.mean(v["do"])
        vr = statistics.mean(v["ro"])
        k = 0.34 / (1.34 + (len(v["gk"]) + 1) / (len(v["gk"]) - 1))
        yz_m = vo + k * vc + (1 - k) * vr
        res[per] = dict(gk=math.sqrt(gk_m), rs=math.sqrt(rs_m),
                        yz=math.sqrt(yz_m) if yz_m > 0 else 0,
                        deff=math.sqrt(rs_m / gk_m) if gk_m > 0 else 0,
                        gap=math.sqrt(vo) if vo > 0 else 0,
                        n=len(v["gk"]))
    return res


def perf_par_paire_periode():
    """R moyen des combinaisons mesurees, par (paire, periode)."""
    g = collections.defaultdict(list)
    with open(BASE / "lab_results.jsonl", encoding="utf-8") as fh:
        for line in fh:
            if not line.strip():
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            p = str(r.get("period", ""))
            if p not in PERIODES or r["n"] < 3:
                continue
            if "r_x54" in r:
                g[(r["sym"], p)].append(r["r_x54"])
    return {k: statistics.mean(v) for k, v in g.items() if len(v) >= 30}


def spearman(a, b):
    def rank(x):
        s = sorted(range(len(x)), key=lambda i: x[i])
        rk = [0] * len(x)
        for j, i in enumerate(s):
            rk[i] = j
        return rk
    ra, rb = rank(a), rank(b)
    n = len(a)
    ma, mb = statistics.mean(ra), statistics.mean(rb)
    num = sum((ra[i] - ma) * (rb[i] - mb) for i in range(n))
    den = (sum((x - ma) ** 2 for x in ra) * sum((x - mb) ** 2 for x in rb)) ** 0.5
    return num / den if den else 0


def main():
    dossier = Path(sys.argv[1]) if len(sys.argv) > 1 else BASE / "m1_pos"
    perf = perf_par_paire_periode()
    print("cibles (paire, periode) avec performance mesuree :", len(perf))
    lignes = []
    for csv in sorted(dossier.glob("*_M1.csv")):
        sym = csv.name.split("_")[0]
        res = charge_periodes(str(csv))
        if not res:
            print("   %-8s : pas de donnees" % sym)
            continue
        for per, v in res.items():
            if (sym, per) in perf:
                lignes.append(dict(sym=sym, per=per, R=perf[(sym, per)], **v))
        print("   %-8s : %d periodes" % (sym, len(res)))
    if len(lignes) < 25:
        print("trop peu de points (%d)" % len(lignes))
        return
    print("\n=== %d points (paire x periode) ===" % len(lignes))
    print("%-8s %-8s %8s %8s %8s %8s %9s"
          % ("paire", "periode", "R moyen", "DEFF", "GK", "YZ", "gap"))
    for x in sorted(lignes, key=lambda y: -y["deff"])[:14]:
        print("%-8s %-8s %+8.3f %8.3f %8.4f %8.4f %9.4f"
              % (x["sym"], x["per"], x["R"], x["deff"], x["gk"], x["yz"], x["gap"]))
    print("\n=== CORRELATIONS AVEC LE R MESURE (Spearman) ===")
    for nom, cle in (("DEFF (efficacite directionnelle)", "deff"),
                     ("niveau GK (volatilite)", "gk"),
                     ("niveau YZ", "yz"),
                     ("gap overnight", "gap")):
        c = spearman([x[cle] for x in lignes], [x["R"] for x in lignes])
        print("   %-38s : %+.3f" % (nom, c))
    # par tiers de DEFF
    tri = sorted(lignes, key=lambda x: x["deff"])
    t = len(tri) // 3
    print("\n=== R MOYEN PAR TIERS DE DEFF ===")
    for nom, grp in (("DEFF faible (dents de scie)", tri[:t]),
                     ("DEFF moyen", tri[t:2*t]),
                     ("DEFF eleve (directionnel)", tri[2*t:])):
        print("   %-30s DEFF moyen %.3f -> R moyen %+.3f  (%d points)"
              % (nom, statistics.mean([x["deff"] for x in grp]),
                 statistics.mean([x["R"] for x in grp]), len(grp)))


if __name__ == "__main__":
    main()
