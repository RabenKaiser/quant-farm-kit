import collections, glob, json, os, sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
B = r"C:\EAFarm\HISTORY - Copy\research"
HOST = ["2024Q1", "2024Q2", "2025Q2", "2025Q3", "2025Q4"]
UN_R = 2 * 2.77          # valeur par defaut : stop 2 ATR (surchargee par tag)
for f in glob.glob(os.path.join(B, "par_farm_prop_clean*_deals.jsonl")) \
        + glob.glob(os.path.join(B, "par_farm_brkasia*_deals.jsonl")):
    tag = os.path.basename(f).replace("par_farm_", "").replace("_deals.jsonl", "")
    # 1 R depend du STOP du test. Le round precedent prenait 2 partout : les R
    # de brkasia (stop 4) etaient donc sous-estimes d'un facteur 2.
    if "_s12_" in tag:
        UN_R = 12 * 2.77
    elif "_s6_" in tag:
        UN_R = 6 * 2.77
    elif "_s4_" in tag:
        UN_R = 4 * 2.77
    else:
        UN_R = 2 * 2.77
    par_id = collections.defaultdict(lambda: collections.defaultdict(float))
    n_id = collections.defaultdict(lambda: collections.defaultdict(int))
    tx_fen = collections.Counter()
    for line in open(f, encoding="utf-8", errors="replace"):
        if not line.strip().startswith("{"):
            continue
        d = json.loads(line)
        q = str(d.get("quarter"))
        i = d.get("id")
        p = d.get("pnl")
        if i is None or not isinstance(p, (int, float)):
            continue
        par_id[i][q] += float(p)
        n_id[i][q] += 1
        tx_fen[q] += 1
    print("=" * 92)
    print("%s | %d lignes | %d transactions | %d fenetres"
          % (tag, len(par_id), sum(tx_fen.values()), len(tx_fen)))
    print("=" * 92)
    lignes = []
    for i, pqs in par_id.items():
        tot = sum(pqs.values())
        h = sum(v for q, v in pqs.items() if q in HOST)
        lignes.append((h / UN_R, tot / UN_R, sum(n_id[i].values()), i))
    lignes.sort()
    print("   %-46s %10s %10s %6s" % ("ligne", "R hostile", "R total", "tx"))
    for rh, rt, n, i in lignes:
        print("   %-46s %+10.2f %+10.2f %6d" % (i[:46], rh, rt, n))
    neg = [x for x in lignes if x[0] < 0]
    print()
    print("   lignes qui PERDENT en hostile : %d / %d" % (len(neg), len(lignes)))
    print("   R hostile du panier : %+.2f | R total : %+.2f"
          % (sum(x[0] for x in lignes), sum(x[1] for x in lignes)))
    if neg:
        print("   si on RETIRE les lignes hostiles-negatives :")
        pos = [x for x in lignes if x[0] >= 0]
        if pos:
            print("      %d lignes restantes | R hostile %+.2f | R total %+.2f | %d tx"
                  % (len(pos), sum(x[0] for x in pos), sum(x[1] for x in pos),
                     sum(x[2] for x in pos)))
