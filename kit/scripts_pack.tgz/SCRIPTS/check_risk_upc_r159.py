# -*- coding: utf-8 -*-
"""check_risk_upc_r159.py — verifier le pire SL du run RISK1% Upcomers:
chaque perte doit etre ~1% du capital (deposit 100000 -> ~1000$ max)."""
import sys, glob, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
# run RISK1-TP10-SL20: bal ~102074 (p=+2074 sur 100k), n=8
for ea, bal0, tag in [("V3INT_EA_RISK", 102073.66, "RISK1-TP10SL20")]:
    best = None
    for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-30:]:
        try:
            runs = F.parse_stream(lp, ea)
        except Exception:
            continue
        for key, data in runs.items():
            if "GBPJPY" not in key:
                continue
            closed = [t for t in data["trades"].values() if t["close"] is not None]
            if len(closed) != 8:
                continue
            b = data.get("balance") or 0.0
            if best is None or abs(b - bal0) < abs(best.get("d", 1e9)):
                best = {"d": abs(b - bal0), "trades": closed, "bal": b, "lp": lp}
    if best is None:
        print(tag, "pas trouve")
        continue
    print(f"{tag}: bal={best['bal']:.0f}")
    for t in sorted(best["trades"], key=lambda t: F.pnl_usd(t)):
        v = t.get("vol")
        print(f"  {str(t['ts_entry'])[:10]} {str(t.get('side')):4s} "
              f"vol={v} pnl={F.pnl_usd(t):+.0f} "
              f"({F.pnl_usd(t)/best['bal']*100:+.2f}% du capital) "
              f"[{t.get('ctype')}]")
print("FIN", flush=True)
