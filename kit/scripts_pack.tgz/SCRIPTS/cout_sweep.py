"""cout_sweep : le portefeuille par paire tient-il avec des spreads plus eleves ?

Demande de l'utilisateur (20/09) : « arrange-toi pour que le portefeuille tienne
avec des spreads plus eleves, comme sur Upcomers ».

Protocole : on reconstruit le corpus M30 (14 paires) en multipliant le cout
mesure par 1, 1.5, 2 et 3, puis on rejoue EXACTEMENT la selection qui a tenu :
une ligne par paire, critere de stabilite, selection sur la premiere moitie des
fenetres, lecture sur la seconde, controle de 500 tirages. On note aussi, pour
chaque paire, la marge en R a 1x et a 3x (R mesure moins cout multiplie).
"""
import json
import os
import random
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import patterns_lab as P
import portefeuille_large as PL
import un_par_paire as U

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
OUT = B / "cout_sweep.md"
MULT = (1.0, 1.5, 2.0, 3.0)


def corpus(mult, chemin):
    """reconstruit la matrice ligne x fenetre avec le cout multiplie."""
    os.environ["COUT_MULT"] = str(mult)
    lignes = []
    for p, b, cout in PL.charge_tout():
        for (nom, sens), idx in PL.motifs(b).items():
            if len(idx) < 200:
                continue
            R, T = PL.r_par_trade(b, idx, sens, cout)
            if R is None:
                continue
            tr = np.array([PL.trimestre(t) for t in T])
            per = {}
            for q in np.unique(tr):
                x = R[tr == q]
                if len(x) >= 20:
                    per[str(q)] = round(float(np.mean(x)), 5)
            if len(per) >= 8:
                lignes.append(dict(motif=nom, sens=sens, paire=p, per=per))
    chemin.write_text(json.dumps(lignes), encoding="utf-8")
    return lignes


def protocole(lignes, tirage=500):
    pp = {}
    for l in lignes:
        pp.setdefault(l["paire"], []).append(l)
    fen = sorted({q for ls in pp.values() for l in ls for q in l["per"]},
                 key=U.cle)
    coupe = len(fen) // 2
    sel, test = fen[:coupe], fen[coupe:]
    choix = {}
    for p, ls in pp.items():
        best, bs = None, -9e18
        for l in ls:
            s = U.score("stabilite", U.note(l, sel))
            if s > bs:
                bs, best = s, l
        choix[p] = best
    xs = U.portefeuille(choix, test)
    st = U.stat(xs)
    ctrl = []
    for _ in range(tirage):
        c = {p: random.choice(ls) for p, ls in pp.items()}
        ctrl.append(U.stat(U.portefeuille(c, test))["moy"])
    ctrl.sort()
    pct = 100.0 * sum(1 for x in ctrl if x < st["moy"]) / len(ctrl)
    marges = {}
    for p, ls in pp.items():
        l = choix[p]
        marges[p] = l["motif"]
    return st, pct, ctrl[len(ctrl) // 2], len(pp), marges


def main():
    random.seed(9)
    out = ["# Robustesse au cout (le portefeuille tient-il avec un spread plus large ?)", "",
           "Protocole : une ligne par paire, critere de stabilite, selection sur la "
           "premiere moitie des fenetres, lecture sur la seconde, controle 500 tirages.", "",
           "| cout x | paires | moy test | pire fenetre | fen + | DD | R/DD | pct vs hasard | hasard med |",
           "|---|---|---|---|---|---|---|---|---|"]
    for m in MULT:
        chemin = B / ("lignes_large_x%s.json" % str(m).replace(".", ""))
        lignes = corpus(m, chemin)
        st, pct, med, np_, marges = protocole(lignes)
        out.append("| %.1f | %d | %+.4f | %+.4f | %.0f%% | %.2f | %s | %.1f | %+.4f |"
                   % (m, np_, st["moy"], st["pire"], 100 * st["pos"], st["DD"],
                      st["RDD"], pct, med))
        print("cout x%.1f : moy %+.4f pire %+.4f fen+ %.0f%% R/DD %s pct %.1f"
              % (m, st["moy"], st["pire"], 100 * st["pos"], st["RDD"], pct),
              flush=True)
        if m == MULT[-1]:
            out += ["", "## composition retenue a %.1f x le cout" % m]
            for p, motif in sorted(marges.items()):
                out.append("- %s : %s" % (p, motif))
    OUT.write_text("\n".join(out), encoding="utf-8")
    print("ecrit %s" % OUT, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
