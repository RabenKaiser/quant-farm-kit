﻿import sys, numpy as np, gc
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT, deep_lib as D
G._cache.clear(); gc.collect()
F = G.get_frames("EURAUD"); m5,m1=F["m5"],F["m1"]
h1z,hh,ll,a1,gb,gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd,zlo,zhi = MT.project(m5.index,h1z,hh,ll,gb,gr,max_age_h=48)
M = NL.build(m5,F,zd,zlo,zhi); M.update(FE.more(m5,F,m1))
T0,T1=m5.index[0],m5.index[-1]
for trig,filt,sl,tp,hm,tr in (("big_bear",["vol_lo"],1.5,99.0,192,3.5),
                              ("brk_ll20",["in_fvgB_2.0"],1.0,99.0,192,2.5),
                              ("at_PDH",["in_fvgB_1.0","in_fibM"],1.0,99.0,960,3.5),
                              ("stoch_xdn",["kelt_low"],1.5,20.0,192,None)):
    s = NL.sig(M, trig, filt)
    st = D.run_ex("EURAUD", s, sl, tp, hm, trail_atr=tr, t0=T0, t1=T1, use_m1=False)
    print(f"  {trig:<12} python n={st.get('n',0):<6} | MT5 attenDU")
