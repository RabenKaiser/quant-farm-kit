﻿"""BALAYAGE : LA REGLE `SR97L|NONE|CRESTM|L` SUR TOUS LES INSTRUMENTS DEJA MESURES.

POURQUOI (26/09, 02 h 40). La meilleure jambe du projet apres correction du signe est, mesuree ligne par
ligne, la regle **SR97L avec le filtre CRESTM sur l'or** : +0,2072 sur 100 transactions (t +1,79), queue
0 %, cinq annees positives sur six. A elle seule elle ne porte pas un portefeuille (1,4 transaction par
mois), mais si la MEME regle est positive sur beaucoup d'instruments, c'est une famille a mu eleve -- et
c'est exactement ce que la cible reclame (`MANQUE.md` : +0,10 R/tx de plus sur tout le livre).

Or la ferme a deja fait tourner cette regle, avec des cibles de 2 a 12 R, sur une vingtaine
d'instruments (`g3_h32_*`, `g_lot_*`, `g3_w20_fx_2`...). Ces textes bruts sont sur le disque : le
balayage ne consomme aucun terminal. Il distingue la regle AVEC filtre de la regle SANS (le nom de ligne
complet est desormais conserve par le moteur de mesure), parce que les deux n'ont pas les memes
resultats.

REGLE DE LECTURE. Une ligne n'est un candidat que si elle est positive avec au moins 40 transactions,
que sa queue de perte reste sous 10 %, et qu'elle n'est pas portee par une seule annee.
"""
import re
import sys
import pathlib
from collections import defaultdict

import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import reel_sans_constante as RS  # noqa: E402

B = pathlib.Path(r"C:\EAFarm\HISTORY - Copy\research")

# Les lignes d'achat de la famille (le cote vente de SR97 n'a jamais ete positif chez nous, et le cote
# achat est celui dont la queue est vide). On garde la ligne COMPLETE pour separer CRESTM de NONE.
LIGNES = ("SR97L", "SR97W20L", "SR97W100L")


def mesure(tx):
    if len(tx) < 10:
        return None
    R = np.array([x["R"] for x in tx], dtype=float)
    n = len(R)
    mu = float(R.mean())
    sd = float(R.std(ddof=1)) if n > 1 else 0.0
    par_an = defaultdict(list)
    for x in tx:
        par_an[x["t_in"].year].append(float(x["R"]))
    return {"n": n, "mu": mu, "t": mu / (sd / np.sqrt(n)) if sd > 0 else 0.0,
            "queue": float((R < -1.5).mean()), "pire": float(R.min()),
            "ans": {a: (len(v), float(np.mean(v))) for a, v in sorted(par_an.items())}}


def cibles_par_tag():
    """tag de campagne -> cible en R, lue dans les fichiers de lots (le nom du brut porte le tag).

    Le nom du texte brut (`raw_farm_g3_lot_xauusd_5.txt`) ne dit pas la cible : c'est le fichier de lots
    qui la porte (`tp_r`). On la retrouve donc par le tag, sinon la ligne du tableau afficherait Â« ? R Â»
    et l'on ne saurait pas si la mesure vaut pour une cible de 2 R ou de 5 R -- deux strategies differentes.
    """
    import json
    table = {}
    for f in sorted(B.glob("LOTS*.json")):
        try:
            for lot in json.loads(f.read_text(encoding="utf-8")):
                if lot.get("tag"):
                    table.setdefault(lot["tag"], lot.get("tp_r"))
        except (OSError, ValueError):
            continue
    return table


def cible_du_nom(nom, cibles):
    """Cible en R : d'abord par le tag de campagne, sinon par le motif `_Ncible` du nom de fichier."""
    m = re.search(r"_(\d+)cible", nom)
    if m:
        return m.group(1)
    tag = nom.replace("raw_farm_", "").replace(".txt", "")
    v = cibles.get(tag)
    return str(v) if v else "?"


def main():
    L = ["# BALAYAGE DE LA REGLE SR97 ACHAT SUR TOUS LES INSTRUMENTS MESURES", "",
         "Une ligne par (instrument, ligne, filtre, cible) trouvee dans les textes bruts de la ferme. R/tx",
         "en R, signe corrige du 26/09. Candidat = mu > 0, au moins 40 transactions, queue < 10 % et plus",
         "d'une annee positive.", "",
         "DOUBLONS : les campagnes de la ferme se recouvrent (le meme lot d'or apparait dans plusieurs",
         "fichiers bruts, avec exactement les memes transactions). La colonne Â« vu dans Â» compte ces",
         "apparitions : elle sert a NE PAS additionner deux fois le meme flux dans un portefeuille.", "",
         "| instrument | ligne | filtre | cible | n | R/tx | t | queue | pire | annees | vu dans | verdict |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    CIBLES = cibles_par_tag()
    uniques = {}
    for f in sorted(B.glob("raw_farm_*.txt")):
        try:
            txt = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        cible = cible_du_nom(f.name, CIBLES)
        tx = RS.transactions_texte(txt)
        if not tx:
            continue
        par_cle = defaultdict(list)
        for x in tx:
            complet = x.get("ligne_complete", "")
            if complet.split("|")[0] in LIGNES:
                par_cle[(x["sym"], complet)].append(x)
        for (sym, complet), g in par_cle.items():
            st = mesure(g)
            if st is None:
                continue
            cle = (sym, complet, cible, st["n"], round(st["mu"], 6))
            if cle in uniques:
                uniques[cle]["vus"].append(f.name)
                continue
            uniques[cle] = {"st": st, "vus": [f.name]}

    candidats = []
    for (sym, complet, cible, _n, _mu), d in sorted(uniques.items(), key=lambda kv: -kv[1]["st"]["mu"]):
        st = d["st"]
        filtre = complet.split("|")[2] if complet.count("|") >= 2 else "?"
        pos = sum(1 for _, v in st["ans"].items() if v[1] > 0)
        if st["mu"] > 0 and st["n"] >= 40 and st["queue"] < 0.10 and pos >= 2:
            verdict = "**CANDIDAT**"
            candidats.append((sym, complet, filtre, cible, st))
        elif st["n"] < 40:
            verdict = "petit effectif"
        else:
            verdict = "rejete"
        L.append("| %s | %s | %s | %s R | %d | **%+.4f** | %+.2f | %.0f %% | %+.2f | %s | %d | %s |"
                 % (sym, complet.split("|")[0], filtre, cible, st["n"], st["mu"], st["t"],
                    100 * st["queue"], st["pire"],
                    " ".join("%d %+.2f" % (a, v[1]) for a, v in st["ans"].items()),
                    len(d["vus"]), verdict))

    L.append("\n## Les candidats")
    if candidats:
        for sym, complet, filtre, cible, st in sorted(candidats, key=lambda c: -c[4]["mu"]):
            L.append("- **%s** `%s` (filtre %s, cible %s R) : %+.4f sur %d transactions (t %+.2f), queue "
                     "%.0f %%, %d annees dont %d positives."
                     % (sym, complet, filtre, cible, st["mu"], st["n"], st["t"], 100 * st["queue"],
                        len(st["ans"]), sum(1 for _, v in st["ans"].items() if v[1] > 0)))
        mu = float(np.mean([c[4]["mu"] for c in candidats]))
        n = sum(c[4]["n"] for c in candidats)
        L.append("\nMu moyen des candidats : **%+.4f** sur %d transactions cumulees. C'est ce chiffre qu'il "
                 "faut comparer aux +0,19 R/tx que reclame la cible." % (mu, n))
    else:
        L.append("Aucun : la regle n'est porteuse que sur l'or.")
    L.append("\n## Ce que le balayage ne dit pas")
    L.append("Ces mesures sont **toutes de l'etage ferme**. Aucune n'entre au portefeuille avant d'etre "
             "confirmee par le juge (`lane_upcomers.py`) : c'est la regle d'admission, et elle a deja "
             "ecarte ce soir trois familles que la ferme ou le juge seul donnaient gagnantes.")
    (B / "BALAYAGE_SR97.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n".join(L))
    print("\n  rapport ecrit dans BALAYAGE_SR97.md")


if __name__ == "__main__":
    main()

