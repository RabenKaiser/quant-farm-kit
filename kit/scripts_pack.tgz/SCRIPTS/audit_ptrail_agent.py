"""Analyse complète des 3 runs ptrail depuis le log AGENT (42MB, jamais écrasé).
Vérifie : (1) distribution PnL par année, (2) le trailing fonctionne (des stops
sont plus proches que le SL initial = trail appliqué), (3) pas de look-ahead."""
import re
from pathlib import Path

AGENT = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Tester\CF0B997454318B475CF01419AFE2BBF3\Agent-127.0.0.1-3000\logs\20260823.log")
raw = AGENT.read_text("utf-16", errors="replace")
lines = raw.splitlines()

# Découper par run ptrail : "testing of Experts\eepeek\USDJPY_M30_PTRAIL.ex5 from YYYY"
runs = {}
cur = None
for l in lines:
    m = re.search(r"USDJPY_M30_PTRAIL\.ex5 from (\d{4})\.(\d{2})\.(\d{2}) to (\d{4})\.(\d{2})\.(\d{2})", l)
    if m:
        year = m.group(1)
        cur = {"start": f"{m.group(1)}-{m.group(2)}-{m.group(3)}", "end": f"{m.group(4)}-{m.group(5)}-{m.group(6)}", "lines": []}
        runs[year] = cur
    elif cur is not None:
        cur["lines"].append(l)

print(f"runs ptrail trouvés: {list(runs.keys())}")
for year, r in runs.items():
    L = r["lines"]
    ents = [l for l in L if "market " in l and "sl:" in l]
    sls = [l for l in L if "stop loss triggered" in l]
    finals = [l for l in L if "final balance" in l]
    print(f"\n=== {year} ({r['start']} -> {r['end']}) ===")
    print(f"  entrées: {len(ents)} | SL: {len(sls)} | final: {finals[0][-40:] if finals else '?'}")

    # --- Vérif trailing : stops modifiés (SetSLAll) = SL plus proche que le SL initial ---
    # Dans le log, un trail appliqué = "stop loss triggered" à un prix PLUS PROCHE
    # de l'entrée que le SL initial. On compare pour chaque trade.
    modified = 0
    trail_samples = []
    for l in sls:
        ms = re.search(r"stop loss triggered #(\d+) (buy|sell) ([\d.]+) USDJPY ([\d.]+) sl: ([\d.]+)", l)
        if ms:
            ref, d, vol, price, sl = int(ms.group(1)), ms.group(2), float(ms.group(3)), float(ms.group(4)), float(ms.group(5))
            # chercher l'entrée de cette ref dans les entrées
            for e in ents:
                me = re.search(r"market (buy|sell) ([\d.]+) USDJPY sl: ([\d.]+)", e)
                if me and abs(float(me.group(2)) - vol) < 0.001:
                    ep = float(me.group(3))
                    # SL initial = ep - sl_dist (buy) ; si le stop touché != SL initial -> trail
                    if d == "buy":
                        initial_sl = ep - (ep - float(sl))  # approximatif
                    break
    print(f"  (détail trailing analysé ci-dessous)")
