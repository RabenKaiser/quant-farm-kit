﻿import pandas as pd, glob, os, sys
from datetime import datetime, timezone
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G
OUT = r"C:\EAFarm\HISTORY - Copy\research\m1_pos"
MIN = 1_500_000
ok, part = [], []
for f in sorted(glob.glob(os.path.join(OUT,"*_M1.csv"))):
    sym = os.path.basename(f).replace("_M1.csv","")
    try: df = pd.read_csv(f, usecols=["time"])
    except Exception: continue
    n=len(df)
    if n==0: continue
    d0 = datetime.fromtimestamp(int(df['time'].iloc[0]), tz=timezone.utc)
    d1 = datetime.fromtimestamp(int(df['time'].iloc[-1]), tz=timezone.utc)
    (ok if n>=MIN else part).append((sym,n,d0,d1))
print(f"=== VALIDABLES ({len(ok)}) ===")
for s,n,d0,d1 in sorted(ok, key=lambda x:-x[1]):
    print(f"  {s:<8} {n:>10,}  {d0.date()} -> {d1.date()}")
print(f"\n=== PARTIELS ({len(part)}) — ecartes ===")
for s,n,d0,d1 in sorted(part, key=lambda x:-x[1]):
    print(f"  {s:<8} {n:>10,}  {d0.date()} -> {d1.date()}")
# les 5 duka
print(f"\n=== DEJA LA (source duka, 5 marches) ===")
duka = [s for s,(src,ps,sp) in G.MK.items() if src=="duka"]
print(" ", duka)
print(f"\nTOTAL VALIDABLES = {len(ok)} POS + {len(duka)} duka = {len(ok)+len(duka)}")
