﻿import MetaTrader5 as mt5, time
mt5.initialize(path=r"C:\EAFarm\MT5\Farm\terminal64.exe")
for s in ("GBPUSD","EURUSD"):
    mt5.symbol_select(s, True)
    # demande des barres : si l'historique n'est pas la, MT5 declenche un DL
    for attempt in range(6):
        r = mt5.copy_rates_from_pos(s, mt5.TIMEFRAME_M1, 0, 5000)
        n = 0 if r is None else len(r)
        print(f"  {s} tentative {attempt+1} : {n} barres M1")
        if n > 0: break
        time.sleep(3)
# et regarde si un telechargement est en cours
ti = mt5.terminal_info()
print("\nterminal connected :", ti.connected)
mt5.shutdown()
