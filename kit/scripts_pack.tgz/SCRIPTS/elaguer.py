# -*- coding: utf-8 -*-
"""elaguer.py — L'ELAGAGE : ecarter ce qui n'est pas interessant.

DEMANDE DE L'UTILISATEUR (17/09, 14 h) : "j'aimerais pouvoir ecarter des
filtres et des tests s'ils ne sont pas tres interessants. Autant qu'on ait de
bons resultats derriere."

CE QUE CE SCRIPT FAIT
  Il lit les resultats du plan de TRI (2 fenetres d'un mois, 5 paires au cout
  le plus faible), classe TOUTES les combinaisons mesurees, et ecrit dans
  lab_black.txt celles qui sont manifestement mortes.

  Effet double :
    1. le plan LARGE ne mesurera que les survivants -> moins de combinaisons,
       donc moins de trades vivants par tick, donc des blocs BEAUCOUP plus
       rapides (le cout par tick est proportionnel au nombre de trades ouverts);
    2. l'analyse se concentre sur ce qui a une chance.

REGLES D'ELAGAGE (toutes sur le TRI, jamais sur les fenetres de jugement)
  - moins de 8 trades sur les 2 mois                -> ecarte
  - present sur une seule des 2 fenetres            -> ecarte
  - R moyen <= 0 sur les 2 fenetres                 -> ecarte
  - dans le tiers inferieur de sa famille           -> ecarte
  On CONSERVE tout ce qui est incertain : l'elagage doit retirer l'evident,
  pas trancher a la place des fenetres de jugement.

USAGE : python elaguer.py [--simuler]
"""
import collections
import json
import statistics
import sys
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
BLACK = (Path.home() / "AppData/Roaming/MetaQuotes/Terminal/Common/Files"
         / "lab_black.txt")
TRI_PERIODES = {"2024.01", "2024.07"}
OUT = BASE / "ELAGAGE.md"


def charge():
    g = collections.defaultdict(dict)
    with open(BASE / "lab_results.jsonl", encoding="utf-8") as fh:
        for line in fh:
            if not line.strip():
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            if str(r.get("period", "")) not in TRI_PERIODES:
                continue
            g[r["id"]][r["period"]] = r
    return g


def main():
    simuler = "--simuler" in sys.argv
    doux = "--fort" not in sys.argv      # defaut : mode DOUX
    g = charge()
    if not g:
        print("aucune donnee de TRI dans lab_results.jsonl.")
        print("Le plan de tri n'a pas encore tourne (LAB_PLAN=tri).")
        return
    print("=" * 88)
    print("ELAGAGE — %d combinaisons mesurees sur le plan de TRI" % len(g))
    print("=" * 88)

    stats = []
    for cid, d in g.items():
        v = [r["r_x54"] for r in d.values() if "r_x54" in r]
        n = sum(r["n"] for r in d.values())
        if not v:
            continue
        stats.append(dict(id=cid, R=statistics.mean(v), n=n, nf=len(v),
                          pos=sum(1 for x in v if x > 0),
                          fam=cid.split("|")[0]))
    print("combinaisons avec la grille : %d" % len(stats))

    # --- regles d'elagage ------------------------------------------------
    trop_rares = [x for x in stats if x["n"] < 8]
    une_fenetre = [x for x in stats if x["nf"] < 2]
    negatifs = [x for x in stats if x["R"] <= 0 and x["nf"] >= 2]
    # ROUND 102 : LA REGLE DE FAMILLE EST RELATIVE, DONC RISQUEE.
    # Mesure du 17/09 : avec elle, l'elagage ne gardait que 783 combinaisons sur
    # 3 084 (25 %). Or elle elimine des combinaisons qui ne sont mauvaises que
    # PAR COMPARAISON avec leur famille -- pas dans l'absolu. Sur un tri de deux
    # mois, c'est trop peu pour trancher. Le mode doux (defaut) ne garde que les
    # regles ABSOLUES : trop rare, une seule fenetre, negatif partout.
    tiers = []
    if not doux:
        par_fam = collections.defaultdict(list)
        for x in stats:
            par_fam[x["fam"]].append(x)
        for fam, lst in par_fam.items():
            if len(lst) < 20:
                continue
            lst.sort(key=lambda y: y["R"])
            tiers += lst[:len(lst) // 3]

    ecarter = {x["id"] for x in trop_rares} | {x["id"] for x in une_fenetre}
    ecarter |= {x["id"] for x in negatifs} | {x["id"] for x in tiers}
    garder = [x for x in stats if x["id"] not in ecarter]

    print("\n1. POURQUOI ON ECARTE")
    print("   moins de 8 trades sur les 2 mois        : %d" % len(trop_rares))
    print("   present sur une seule fenetre           : %d" % len(une_fenetre))
    print("   R negatif sur les 2 fenetres            : %d" % len(negatifs))
    print("   tiers inferieur de sa famille           : %d" % len(tiers))
    print("   ----------------------------------------------")
    print("   TOTAL ecarte (union)                    : %d" % len(ecarter))
    print("   CONSERVE                                : %d (%.0f %%)"
          % (len(garder), 100.0 * len(garder) / max(len(stats), 1)))

    print("\n2. CE QUI SURVIT, PAR FAMILLE")
    fam = collections.defaultdict(lambda: [0, 0])
    for x in stats:
        fam[x["fam"]][0] += 1
    for x in garder:
        fam[x["fam"]][1] += 1
    for f, (tot, ok) in sorted(fam.items(), key=lambda y: -y[1][1] / max(y[1][0], 1)):
        if tot < 10:
            continue
        print("   %-18s %5d / %-5d = %3.0f %% survivent"
              % (f, ok, tot, 100.0 * ok / tot))

    print("\n3. LES 20 MEILLEURES SURVIVANTES")
    print("   %-40s %8s %8s %6s" % ("combinaison", "R", "trades", "fen. >0"))
    for x in sorted(garder, key=lambda y: -y["R"])[:20]:
        print("   %-40s %+8.3f %8d %4d/%d"
              % (x["id"][:40], x["R"], x["n"], x["pos"], x["nf"]))

    # --- ecriture de la liste noire --------------------------------------
    if simuler:
        print("\n(simulation : lab_black.txt n'a PAS ete modifie)")
        return
    anciens = set()
    if BLACK.exists():
        anciens = {l.strip() for l in BLACK.read_text().splitlines() if l.strip()}
    nouveaux = anciens | ecarter
    BLACK.write_text("\n".join(sorted(nouveaux)) + "\n", encoding="ascii")
    print("\n4. LISTE NOIRE")
    print("   avant : %d exclusions" % len(anciens))
    print("   apres : %d exclusions (+%d)" % (len(nouveaux), len(nouveaux) - len(anciens)))
    print("   -> %s" % BLACK)
    print("\n   La prochaine mesure ne portera que sur les %d survivantes : moins de"
          % len(garder))
    print("   combinaisons = moins de trades vivants par tick = blocs plus rapides.")

    L = ["# ELAGAGE", "",
         "| famille | survivent | total | taux |", "|---|---|---|---|"]
    for f, (tot, ok) in sorted(fam.items()):
        L.append("| %s | %d | %d | %.0f%% |" % (f, ok, tot, 100.0 * ok / tot))
    L += ["", "**%d combinaisons conservees sur %d.**" % (len(garder), len(stats)), ""]
    OUT.write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n-> %s" % OUT)


if __name__ == "__main__":
    main()
