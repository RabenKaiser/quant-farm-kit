﻿"""Diagnose cost in the correct backtest engine."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import polars as pl
import numpy as np
from pathlib import Path

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
from edge_correct import load_m1, to_tf, seg_of, make_signals, backtest_m1

sym = "EURUSD"
m1 = load_m1(sym)
tf = to_tf(m1, 300)
df = seg_of(tf)
segs = {s: df.filter(pl.col("seg") == s) for s in ["IS-1", "IS-2", "OOS"]}
m1_segs = seg_of(m1)
m1_map = {s: m1_segs.filter(pl.col("seg") == s) for s in ["IS-1", "IS-2", "OOS"]}

# spread stats
sp = m1["spread_med"] / 0.00001
print("EURUSD M1 spread pts: median", sp.median(), "mean", round(sp.mean(), 2), "p90", sp.quantile(0.9), "p99", sp.quantile(0.99))

cfg = {"lookback": 20, "w": 6, "thr": 0.2, "wick_atr": 0.3, "sl_atr": 2.0, "rr": 2.5,
       "session": None, "slippage_pts": 0.5}
for sname in ["IS-1", "OOS"]:
    f = make_signals(segs[sname], "ofi_cont", cfg)
    trades = backtest_m1(m1_map[sname], segs[sname], f, sym, cfg)
    t = pl.DataFrame(trades)
    print(f"\n{sname}: n={len(t)}")
    print("  r mean:", round(float(t['r'].mean()), 4), " cost mean:", round(float(t['cost_r'].mean()), 4))
    print("  net mean:", round(float((t['r'] - t['cost_r']).mean()), 4))
    print("  gross pts:", round(float(t['r'].mean() * t['sl'].median()), 1))
    print("  cost pts:", round(float(t['cost_r'].mean() * t['sl'].median()), 1))
    print("  sl median:", t['sl'].median(), "bars median:", t['bars'].median())
    print("  wr:", round(float((t['r'] > 0).mean() * 100), 1))
    print("  exit dist: tp", round(float((t['r'] > 1.0).mean() * 100), 1), "pct, sl", round(float((t['r'] <= -0.99).mean() * 100), 1), "pct, time", round(float(((t['r'] > -0.99) & (t['r'] < 1.0)).mean() * 100), 1), "pct")
