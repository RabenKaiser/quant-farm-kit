# -*- coding: utf-8 -*-
r"""classif_m5.py -- SOUS-ETATS DE CYCLE : ou en est le mouvement ?

Demande de l'utilisateur (10/13) : le M5 est une TRAME SUPPLEMENTAIRE du
dictionnaire (pas des sous-etats M5 exclusifs), et les sous-etats qu'il
veut sont des PHASES DE CYCLE du mouvement :

  TREND_NAISSANT  : la tendance DEMARRE (ER vient de franchir le seuil,
                    ATR monte, ADX-like grimpe depuis le bas)
  TREND_CROISSANT : la tendance SE CONFORT (ER haut, direction persiste,
                    volatilite haute et stable)
  TREND_FINISSANT : la tendance S'ESSOUFFLE (ER decroit, ATR redescend,
                    divergence RSI / dernier poussee sans continuation)
  RANGE_E.tabli   : range stable qui dure (largeur stable, pas de cassure)
  RANGE_MOURE     : range en train de casser (poussee hors couloir)
  COMPRESS_SECHE  : compression qui se resserre (le ressort se charge)
  EXPANSION_VIVE  : expansion franche (corps >> meches)

LES CONFIRMATEURS (ce qui AIDE a identifier les etats, meme demande) :
  - RSI(14) niveau + pente (divergence = finissant)
  - PROXY VOLUME : le corpus M1 n'a pas de volume fiable -> on utilise le
    "tick-density" (nombre de variations de prix par barre M1 aggregee) ET
    l'amplitude relative : un poussee sur GROS volume = barres larges
    frequentes ; le proxy est honnete et documente.
  - "Zhat" : la composante RESIDUELLE standardisee du log-prix autour de
    sa moyenne mobile (z-score) = la surprise locale du prix. |z|>2 =
    evenement hors regime (catalyseur), utile pour EXPANSION_VIVE.

TROIS TRAMES : M30 (moteur), M5 (finition du timing), D1 (regime de fond).
Le label final M30 x M5 = un mot compose du dictionnaire.

USAGE : python SCRIPTS\\classif_m5.py
Sortie : repartition des sous-etats + table sous-etat x SR97 (R/tx).
"""
import os
import sys

import numpy as np
import pandas as pd

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parent))
import nuit_motifs as NM
# NOTE 10/13 17:50 : on N'IMPORTE PAS classif_marche au top-level (sa
# definition contient un rolling.apply(mode()) de 270 s+ sur les trames M5 ;
# on ne prend que ses constantes, en les recopiant ici).
ER_SEUIL = 0.30
CM_ATR_LO, CM_ATR_HI = 0.30, 0.70
CM_ER_TREND = 0.38

JAMBES = [x.strip() for x in os.environ.get(
    "PAIRES", "EURUSD,GBPUSD,USDCHF,AUDUSD,NZDUSD,EURJPY,XAUUSD").split(",")
    if x.strip()]

# seuils fixes (pas de fitting) -- poses AVANT la mesure
ER_SEUIL = 0.30          # efficacite directionnelle 64 barres M30
ER_M5_SEUIL = 0.30       # idem en M5 (fenetre 96 = 8h)
RSI_DIV = 25.0           # |RSI - 50| au-dela duquel on parle d'extreme
ADX_MIN = 20.0           # seuil ADX-like (DI+/DI-)
Z_EXTREME = 2.0          # |z-prix| = surprise
SERR_PENTE = -0.02       # pente largeur Donchian par barre


def er(c, n=64):
    """Efficacite directionnelle |net|/somme des pas (copie de
    classif_marche.er, non importee ici pour eviter son rolling.apply)."""
    net = np.abs(c - np.roll(c, n))
    pas = np.abs(np.diff(c, prepend=c[:1]))
    som = pd.Series(pas).rolling(n).sum().values
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(som > 0, net / som, np.nan)


SSE30 = ["TREND_NAISSANT", "TREND_CROISSANT", "TREND_FINISSANT",
         "RANGE_ETABLI", "RANGE_MOURE", "COMPRESS_SECHE", "EXPANSION_VIVE"]


def adx_like(D, n=14):
    """ADX simplifie (DI+ / DI- / DX lisse) sans dependance TA-lib."""
    h, l, c = D["h"], D["l"], D["c"]
    up = h - np.roll(h, 1)
    dn = np.roll(l, 1) - l
    up[0], dn[0] = 0.0, 0.0
    plus_dm = np.where((up > dn) & (up > 0), up, 0.0)
    minus_dm = np.where((dn > up) & (dn > 0), dn, 0.0)
    tr = np.maximum(h - l, np.maximum(np.abs(h - np.roll(c, 1)),
                                      np.abs(l - np.roll(c, 1))))
    atr = pd.Series(tr).rolling(n).mean().values
    with np.errstate(invalid="ignore", divide="ignore"):
        pdi = 100.0 * pd.Series(plus_dm).rolling(n).sum().values / atr / n * 14
        mdi = 100.0 * pd.Series(minus_dm).rolling(n).sum().values / atr / n * 14
        dx = 100.0 * np.abs(pdi - mdi) / np.where(pdi + mdi > 0, pdi + mdi,
                                                  np.nan)
    adx = pd.Series(np.nan_to_num(dx)).rolling(n).mean().values
    return adx, pdi, mdi


def z_prix(D, n=96):
    """z-score du prix vs sa moyenne mobile (la surprise locale)."""
    c = D["c"]
    mu = pd.Series(c).rolling(n).mean().values
    sd = pd.Series(c).rolling(n).std().values
    with np.errstate(invalid="ignore", divide="ignore"):
        return (c - mu) / sd


def pentes(x, n=8):
    return (x - np.roll(x, n)) / float(n)


def charge_m5(pair):
    f = NM.B / "m1_pos" / ("%s_M1.csv" % pair)
    if not f.exists():
        return None
    d = pd.read_csv(f, usecols=["time", "open", "high", "low", "close",
                                "spread"])
    dcl = d["close"].diff().abs()
    nzc = dcl[dcl > 0]
    if not len(nzc):
        return None
    pt = float(nzc.min())
    s = d["spread"].astype(float)
    nz = s[s > 0]
    if not len(nz):
        return None
    d["t"] = pd.to_datetime(d["time"], unit="s")
    d = d.set_index("t")
    # 10/13 18:05 : le lambda d'aggregation ('close', lambda ...) sur 2.2M
    # lignes M1 coutait des MINUTES par paire. Version vectorisee : colonne
    # 'chg' puis 'sum' — 0.1 s au lieu de minutes.
    d["chg"] = (d["close"].diff().abs() > 0).astype(np.int8)
    b = d.resample("5min").agg(o=("open", "first"), high=("high", "max"),
                               low=("low", "min"), close=("close", "last"),
                               tks=("chg", "sum"),
                               sp=("spread", "median")).dropna()
    if len(b) < 3000:
        return None
    tr = pd.concat([b.high - b.low, (b.high - b.close.shift()).abs(),
                    (b.low - b.close.shift()).abs()], axis=1).max(axis=1)
    atr = tr.rolling(14).mean()
    cout = (float(nz.median()) * pt) / float(atr.median())
    return dict(idx=b.index, o=b.o.values, h=b.high.values, l=b.low.values,
                c=b.close.values, a=atr.values, cout=cout,
                tks=b.tks.values.astype(float))


def etats_m30(D):
    """7 sous-etats de cycle en M30 (ou en M5, la fonction est generique)."""
    c, a = D["c"], D["a"]
    e = er(c, 64)
    e_p = pentes(e, 8)
    atr_p = pd.Series(a).rolling(1000).rank(pct=True).values
    atr_pente = pentes(atr_p, 12)
    adx, pdi, mdi = adx_like(D)
    rsi = NM.rsi(c, 14)
    rsi_ext = np.abs(rsi - 50.0) > RSI_DIV
    dw = pd.Series(D["h"]).rolling(50).max().values - \
        pd.Series(D["l"]).rolling(50).min().values
    dw = dw / a
    dw_p = pentes(dw, 12)
    z = z_prix(D)

    n = len(c)
    lab = np.empty(n, dtype=object)

    tendance = np.nan_to_num(e) > ER_SEUIL
    dirup = c > np.roll(c, 32)
    # 1. naissant : ER vient de franchir + ATR monte + ADX monte
    naissant = tendance & (np.nan_to_num(e_p) > 0.02) & \
        (np.nan_to_num(atr_pente) > 0.0) & (np.nan_to_num(adx) > ADX_MIN)
    # 2. croissant : ER haut stable, ATR haut stable
    croissant = tendance & ~naissant & (np.nan_to_num(atr_p) > CM_ATR_LO) & \
        (np.abs(np.nan_to_num(atr_pente)) <= 0.05)
    # 3. finissant : ER decroit OU divergence RSI (extreme + ER baisse)
    finissant = tendance & ((np.nan_to_num(e_p) < -0.02) |
                            (rsi_ext & (np.nan_to_num(e_p) < 0)))
    lab = np.where(naissant, "TREND_NAISSANT",
                   np.where(finissant, "TREND_FINISSANT",
                            np.where(croissant, "TREND_CROISSANT", "")))
    # 4-5. range : etabli vs mouve (cassure recente hors couloir)
    sur = (D["h"] > pd.Series(D["h"]).rolling(50).max().values) | \
        (D["l"] < pd.Series(D["l"]).rolling(50).min().values)
    moure = np.roll(np.nan_to_num(sur).astype(float), 1).astype(bool)
    est_range = ~tendance & (np.nan_to_num(atr_p) >= CM_ATR_LO)
    lab = np.where((lab == "") & est_range & moure, "RANGE_MOURE", lab)
    lab = np.where((lab == "") & est_range & ~moure, "RANGE_ETABLI", lab)
    # 6. compression seche : ATR bas + largeur qui se resserre
    lab = np.where((lab == "") & (np.nan_to_num(atr_p) < CM_ATR_LO) &
                   (np.nan_to_num(dw_p) < SERR_PENTE), "COMPRESS_SECHE", lab)
    # 7. expansion vive : ATR haut + surprise |z|>=2
    lab = np.where((lab == "") & (np.nan_to_num(atr_p) > CM_ATR_HI) &
                   (np.abs(np.nan_to_num(z)) >= Z_EXTREME),
                   "EXPANSION_VIVE", lab)
    lab = np.where(lab == "", "RANGE_ETABLI", lab)
    return lab, dict(er=e, atr_p=atr_p, adx=adx, rsi=rsi, z=z, dw=dw)


def main():
    print("SOUS-ETATS DE CYCLE (M30 et M5) | ER>%.2f | ADX>%.0f | RSI50+-%.0f"
          " | |z|>%.1f" % (ER_SEUIL, ADX_MIN, RSI_DIV, Z_EXTREME))
    print("confirmateurs : RSI niveau+pente, proxy volume = tick-density M1, "
          "z-prix (surprise), ADX-like, pente de largeur Donchian")
    for trame, fn in (("M30", NM.charge), ("M5", charge_m5)):
        agg = {}
        for p in JAMBES:
            D = fn(p, "m1_pos") if trame == "M30" else charge_m5(p)
            if D is None:
                continue
            lab, met = etats_m30(D)
            rep = {k: 100.0 * float(np.mean(lab == k)) for k in SSE30}
            agg[p] = rep
            print("  [%s] %-8s %s" % (trame, p, "  ".join(
                "%s %4.1f" % (k.replace("TREND_", "T_").replace("_", "")[:8], x)
                for k, x in rep.items())))
        if agg:
            print("  [%s] MOYENNE :" % trame)
            for k in SSE30:
                vals = [r.get(k, 0.0) for r in agg.values()]
                print("      %-16s %5.1f%%" % (k, float(np.mean(vals))))


if __name__ == "__main__":
    main()
