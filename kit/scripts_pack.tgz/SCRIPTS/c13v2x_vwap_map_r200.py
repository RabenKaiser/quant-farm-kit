# -*- coding: utf-8 -*-
"""c13v2x_vwap_map_r200.py — cartographie C13V2X mode VWAP (1) sur 8 paires
x 2023-2025. Le test du boss: un bon edge doit marcher sur PLUS de cellules
que le base (2/24). VWAP a ameliore l'OOS EURUSD -> voir si ca generalise."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\c13v2x_vwap_map_r200.jsonl"


def cfg(mg):
    return dict(InpMagic=mg, InpLots=0.10, InpRiskPct=0.0, InpTpR=2.5,
                InpMagLookbackH4=60, InpTrailAtrMult=1.5, InpTrailAfterR=1.0,
                InpImpulseAtrMult=0.9, InpImpulseLook=6, InpAtrPeriod=14,
                InpHtfEmaPeriod=200, InpPinWickRatio=1.5, InpCloseInZoneMin=0.15,
                InpMinStopPips=2.5, InpBufferAtrFrac=0.25, InpMaxSpreadPts=80,
                InpUseHourFilter=True, InpExcludedHoursCSV="6,7,12,15,19,23",
                InpUseDailyStop=True, InpDailyStopR=3.0, InpMaxTradesDay=0,
                InpUtcOffset=2, InpMixMode=1, InpVwapLookback=96,
                InpChoChSwing=5, InpVerbose=False)


def main():
    mg = 772000
    PAIRS = ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "NZDUSD", "GBPJPY",
             "XAUUSD"]
    YEARS = [(2023, "2023.01.01", "2024.01.01"),
             (2024, "2024.01.01", "2025.01.01"),
             (2025, "2025.01.01", "2026.01.01")]
    with open(OUT, "a", encoding="utf-8") as fo:
        for sym in PAIRS:
            for (yr, frm, to) in YEARS:
                mg += 1
                c = cfg(mg)
                tag = f"{sym}-{yr}"
                print(f"[r200 {tag}] ...", flush=True)
                r = RF.run_backtest("C13V2X_EA", symbol=sym, tf="M5",
                                    from_d=frm, to_d=to, deposit=10000,
                                    max_wait=3600, inputs=c)
                fo.write(json.dumps({"tag": tag, "sym": sym, "year": yr,
                                     "r": r}, default=str) + "\n")
                fo.flush()
                print(f"[{tag}] " + ("null" if r is None else
                      f"p={r.get('profit')} n={r.get('trades')} "
                      f"pf={r.get('pf')} wr={r.get('wr')}"), flush=True)
                time.sleep(1)
    print("FIN r200", flush=True)


if __name__ == "__main__":
    main()
