# -*- coding: utf-8 -*-
"""debug_trades.py — affiche les trades détaillés d'un run précis."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

log = sys.argv[1]
filt = sys.argv[2] if len(sys.argv) > 2 else "V45G"
keymatch = sys.argv[3] if len(sys.argv) > 3 else "2025"
runs = F.parse_stream(log, filt)
for key, data in runs.items():
    if keymatch not in key:
        continue
    print("===", key, "balance=", data["balance"])
    for tid, t in sorted(data["trades"].items()):
        if t["close"] is None:
            continue
        pt = F.PTS.get(t["sym"], 0.0001)
        dpx = (t["close"] - t["entry"]) / pt if t["side"] == "buy" else (t["entry"] - t["close"]) / pt
        if t["sl0"] is not None:
            risk = abs(t["sl0"] - t["entry"]) / pt
        else:
            risk = 0
        netR = dpx / risk if risk > 0 else 0
        print(f"  #{tid} {t['side']} {t['sym']} vol={t['vol']} entry={t['entry']} "
              f"sl0={t['sl0']} close={t['close']} ({t['ctype']}) dpx={dpx:.0f} "
              f"risk={risk:.0f} netR={netR:+.2f}")
    break
