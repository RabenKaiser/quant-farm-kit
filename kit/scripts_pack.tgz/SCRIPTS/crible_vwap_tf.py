"""crible_vwap_tf : la famille VWAP sur PLUSIEURS TRAMES, mesuree par le moteur honnete.

Round 468. La famille avait ete jugee sur la seule trame M30 -- parce que le laboratoire honnete etait
fige en M30 -- et declaree sans edge. C'est insuffisant : la definition d'origine etait M15 (et les
premiers essais M5), et l'ecart a la VWAP de session n'a pas du tout les memes statistiques d'une trame a
l'autre. Le cout en R, lui, vaut spread / (stop x ATR de la TRAME) : un stop de 1 ATR en M5 coute trois
fois plus cher en R qu'un stop de 1 ATR en M15. Un signal peut donc etre un edge en M15 et une taxe en M5.

Ce script balaye une trame (ou plusieurs) et une geometrie, pour chaque paire et chaque sens, avec :
  - la VWAP de session (moyenne cumulee du prix typique, remise a zero chaque jour) ;
  - l'ecart a la VWAP en sigmas (ecart-type roulant 200 barres de la trame) ;
  - un filtre de regime optionnel (ATR(14) < VOLMAX x mediane roulante 500) ;
  - une seule position a la fois (espacement de HOLD barres, applique AVANT la resolution des barrieres) ;
  - sortie a la minute, premier toucher, egalite = stop, horizon compte en barres (`par_barres`) ;
  - cout deduit des donnees de la paire ET DE LA TRAME.

Sortie : une ligne par (paire, trame, sens) et un CSV pour la suite de l'analyse.
Env : TRAMES=5,15,30,60 SEUIL_VWAP=2.0 SLR=1.5 RATIO=1.0 HOLD_BARRES=24 VOLMAX=0
      PAIRES=EURCHF,NZDUSD,... CORPUS=m1_pos SORTIE=CRIBLE_VWAP_TF.csv
"""
import csv
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import barrieres_m1 as BM  # noqa: E402
import spread_barrieres as SB  # noqa: E402

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
CORPUS = os.environ.get("CORPUS", "m1_pos")
SORTIE = B / os.environ.get("SORTIE", "CRIBLE_VWAP_TF.csv")
TRAMES = [int(x) for x in os.environ.get("TRAMES", "5,15,30,60").split(",")]
SEUIL_VWAP = float(os.environ.get("SEUIL_VWAP", "2.0"))
SLR = float(os.environ.get("SLR", "1.5"))        # stop en ATR de la trame
RATIO = float(os.environ.get("RATIO", "1.0"))    # cible en multiples du RISQUE (1.0 = 1 R)
HOLD_BARRES = int(os.environ.get("HOLD_BARRES", "24"))
VOLMAX = float(os.environ.get("VOLMAX", "0"))
SIG_MIN = int(os.environ.get("SIG_MIN", "30"))
PAIRES = [x for x in os.environ.get("PAIRES", "").split(",") if x]
# Offset de realite par CLASSE d'instrument, mesure sur ordres reels (round 467).
CLASSE = {"XAUUSD": "OR", "XAGUSD": "OR", "SPXUSD": "INDICE", "NSXUSD": "INDICE", "UDXUSD": "INDICE",
          "USA500.IDX": "INDICE", "USATECH.IDX": "INDICE", "DOLLAR.IDX": "INDICE"}
OFFSETS = {"FX": (0.0602, 0.1360), "OR": (0.0, 0.0), "INDICE": (0.0, 0.0)}


def signaux_vwap(M, sens, seuil=SEUIL_VWAP, volmax=VOLMAX):
    """Ecart a la VWAP de session sur la trame de M, + filtre de volatilite optionnel."""
    c, h, l, a, idx = M["c"], M["h"], M["l"], M["a"], M["idx"]
    tp = (h + l + c) / 3.0
    jour = pd.Series(idx.date).values
    cum = pd.Series(tp).groupby(jour).cumsum().values
    cnt = pd.Series(tp).groupby(jour).cumcount().values + 1.0
    dev = c - cum / cnt
    sd = pd.Series(dev).rolling(200, min_periods=50).std().values
    z = np.nan_to_num(dev / np.where(sd > 0, sd, np.nan), nan=0.0)
    sig = np.flatnonzero(z >= seuil) if sens == "S" else np.flatnonzero(z <= -seuil)
    if volmax > 0:
        amed = pd.Series(a).rolling(500, min_periods=50).median().values
        calme = np.isfinite(amed) & (amed > 0) & (a < volmax * amed)
        sig = sig[calme[sig]]
    sig = sig[(sig >= 210) & (sig < len(c) - HOLD_BARRES - 2)]
    sig = sig[np.isfinite(a[sig]) & (a[sig] > 0)]
    garde, dernier = [], -10 ** 9
    for i in sig:
        if i - dernier >= HOLD_BARRES:
            garde.append(i)
            dernier = i
    return np.array(garde, dtype=int) if garde else np.array([], dtype=int)


def mesure(M, sens, minutes):
    sig = signaux_vwap(M, sens)
    if len(sig) < 12:
        return None
    o, a, idx = M["o"], M["a"], M["idx"]
    ent = (sig + 1)
    ent = ent[ent < len(idx) - HOLD_BARRES - 2]
    res = []
    for k in ent:
        st = float(a[k - 1])
        if not np.isfinite(st) or st <= 0:
            continue
        r = BM.issue(M["m1"], int(pd.Timestamp(idx[k]).timestamp()), float(o[k]),
                     st, RATIO * SLR, SLR, HOLD_BARRES * minutes, sens, par_barres=True)
        if r is not None:
            res.append((k, r))
    if len(res) < 12:
        return None
    ent = np.array([k for k, _ in res])
    kind = np.array([r[0] for _, r in res])
    R = np.array([r[1] for _, r in res])
    garde = SB.bloque(idx, ent, R, kind)
    if len(garde) < 12:
        return None
    R, kind = R[garde], kind[garde]
    ans = defaultdict(list)
    for k, r_ in zip(garde, R):
        ans[idx[ent[k]].year].append(r_)
    aok = a[np.isfinite(a) & (a > 0)]
    cout = float(np.median(M["spr"][np.isfinite(M["spr"])]) / np.median(aok)) / SLR if len(aok) else np.nan
    return dict(n=len(R), R=float(np.mean(R)), sd=float(np.std(R, ddof=1)),
                gagn=100.0 * float(np.mean(kind == 0)), cout=cout,
                n_an=len(ans), n_pos=sum(1 for v in ans.values() if np.mean(v) > 0),
                ans={y: round(float(np.mean(v)), 4) for y, v in sorted(ans.items())})


def main():
    pairs = PAIRES or sorted(p.name[:-7] for p in (B / CORPUS).glob("*_M1.csv"))
    print("%d paires | trames %s | seuil %.1f sigma | stop %.2f ATR | cible %.1f R | detention %d barres | "
          "filtre vol %s" % (len(pairs), TRAMES, SEUIL_VWAP, SLR, RATIO, HOLD_BARRES,
                             ("< %.2f x mediane" % VOLMAX) if VOLMAX > 0 else "aucun"))
    print("%-8s %4s %3s | %5s %8s %8s %7s %8s %8s | %8s %8s %6s" %
          ("paire", "trame", "s", "n", "R/tx", "sigma", "gagn%", "mu/s2", "cout R", "attendu", "an.pos", "verdict"))
    lignes = []
    for p in pairs:
        for minutes in TRAMES:
            M = BM.charge_tf(p, CORPUS, minutes=minutes)
            if M is None:
                print("  %-8s %4d : corpus absent ou trame trop courte" % (p, minutes))
                continue
            for sens in ("S", "L"):
                m = mesure(M, sens, minutes)
                if m is None or m["n"] < SIG_MIN or m["sd"] <= 0:
                    print("  %-8s %4d %s | %s" % (p, minutes, sens,
                                                  "trop peu" if m is None else "%d tx" % m["n"]), flush=True)
                    continue
                cls = CLASSE.get(p, "FX")
                att = m["R"] - OFFSETS[cls][0 if sens == "S" else 1]
                v = "RETENU" if (att > 0 and m["n_pos"] >= 2 * m["n_an"] / 3.0) else ""
                print("  %-8s %4d %s | %5d %+8.4f %8.2f %6.1f %8.3f %8.3f | %+8.4f %5d/%d %s"
                      % (p, minutes, sens, m["n"], m["R"], m["sd"], m["gagn"], m["R"] / m["sd"] ** 2,
                         m["cout"], att, m["n_pos"], m["n_an"], v), flush=True)
                lignes.append(dict(paire=p, trame=minutes, sens=sens, n=m["n"], R=m["R"], sd=m["sd"],
                                   gagn=m["gagn"], mus2=m["R"] / m["sd"] ** 2, cout=m["cout"],
                                   attendu=att, npos=m["n_pos"], nan=m["n_an"],
                                   annees=json_annees(m["ans"])))
    if lignes:
        with SORTIE.open("w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(lignes[0].keys()))
            w.writeheader()
            w.writerows(lignes)
        print("\n  -> %s (%d lignes)" % (SORTIE.name, len(lignes)))
        bon = [x for x in lignes if x["attendu"] > 0 and x["npos"] >= 2 * x["nan"] / 3.0]
        print("  couples RETENUS : %d" % len(bon))
        for x in sorted(bon, key=lambda z: -z["attendu"] * z["n"])[:12]:
            print("    %-8s trame %3d %s n=%4d attendu %+.4f annees %d/%d"
                  % (x["paire"], x["trame"], x["sens"], x["n"], x["attendu"], x["npos"], x["nan"]))
    return 0


def json_annees(ans):
    return " ".join("%d %+.3f" % (y, v) for y, v in ans.items())


if __name__ == "__main__":
    sys.exit(main())
