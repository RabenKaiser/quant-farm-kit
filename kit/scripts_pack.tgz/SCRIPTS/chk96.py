﻿import os, re
LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
files=sorted([(os.path.getmtime(os.path.join(LOGD,f)), f) for f in os.listdir(LOGD) if ".log" in f], reverse=True)
print("=== VWAPXUP CADJPY dans les 6 derniers logs ===")
for m,f in files[:6]:
    p=os.path.join(LOGD,f)
    if os.path.getsize(p)<500: continue
    raw=open(p,"rb").read(4)
    enc="utf-16" if raw[:2] in (b"\xff\xfe",b"\xfe\xff") else "utf-8"
    try: txt=open(p,encoding=enc,errors="replace").read()
    except Exception: continue
    n = len(re.findall(r"ORION OPEN CADJPY VWAPXUP", txt))
    tot = txt.count("ORION OPEN CADJPY")
    if tot: print(f"  {f[:44]:<46} VWAPXUP={n:<5} total={tot}")
