# -*- coding: utf-8 -*-
"""Backtest conjoint des 3 jambes PTRAIL (GBPUSD/USDJPY/EURUSD, ticks Dukascopy).
Corrélation mensuelle + DD combiné + dimensionnement — le noyau du portfolio FX."""
import sys, json, numpy as np
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_duka as d

RES = {}
for sym in ["GBPUSD", "USDJPY", "EURUSD"]:
    months = {}
    for y0, y1 in [("2023.01.01", "2024.01.01"), ("2024.01.01", "2025.01.01"),
                   ("2025.01.01", "2026.01.01")]:
        r = d.run_backtest("PTRAIL_LONG", sym, "H1", y0, y1, 10000, max_wait=300)
        if r is None or r.get("profit") is None:
            print(f"{sym} {y0[:4]}: PARSE FAIL — réessaie", flush=True)
            import time; time.sleep(5)
            r = d.run_backtest("PTRAIL_LONG", sym, "H1", y0, y1, 10000, max_wait=300)
        v = r.get("profit", 0) if r else 0
        months[y0[:4]] = v
        print(f"{sym} {y0[:4]}: ${v}", flush=True)
    RES[sym] = months

# portefeuille : somme des 3 jambes par année
years = ["2023", "2024", "2025"]
port = {y: sum(RES[s][y] for s in RES) for y in years}
tot = sum(port.values())
print(f"\nPORTEFEUILLE 3 jambes PTRAIL:")
for y in years:
    print(f"  {y}: ${port[y]:+,.0f}")
print(f"  TOTAL 3 ans: ${tot:+,.0f}  ({tot/10000*100:+.0f}% sur 10k$)")

# corrélation des années entre paires
print("\nCorrélation des rendements annuels (3 points, indicatif):")
for a in RES:
    for b in RES:
        if a < b:
            va = np.array([RES[a][y] for y in years])
            vb = np.array([RES[b][y] for y in years])
            c = np.corrcoef(va, vb)[0, 1]
            print(f"  {a} vs {b}: r={c:+.2f}")

# DD combiné mensuel approx (1/12 du profit annuel, linéaire)
monthly = {y: port[y] / 12 for y in years}
eq = []
for y in years:
    eq.extend([monthly[y]] * 12)
eq = np.array(eq)
peak = np.maximum.accumulate(eq)
dd = (eq - peak).min()
print(f"\nDD max combiné (approx mensuel): ${dd:+,.0f}")
print(f"R/DD: {tot / abs(dd):.2f}")
json.dump({"per_pair": RES, "portfolio": port, "total": tot},
          open(r"C:\EAFarm\HISTORY - Copy\research\night_results\ptrail_portfolio.json", "w"), indent=1)
print("sauvé: ptrail_portfolio.json")
