﻿import sys, datetime as _dt
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
import numpy as np
import polars as pl
from edge_correct import load_m1, to_tf, backtest_m1, COMMISSION_RT, TICK_VALUE_PER_PT
import deep_signals as DS

def E(d):
    return int(_dt.datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=_dt.timezone.utc).timestamp())

OOS = (E("2023-01-01"), E("2024-01-01"))
CFG = {"slippage_pts": 0.5, "lookback": 20, "retest_k": 10, "sl_atr": 1.5, "rr": 4.0}


def audit(sym, tf_sec, cfg):
    m1 = load_m1(sym)
    tf = to_tf(m1, tf_sec)
    c = dict(cfg, commission_rt=COMMISSION_RT[sym], tick_value_per_pt=TICK_VALUE_PER_PT[sym])
    m1o = m1.filter((pl.col("time") >= OOS[0]) & (pl.col("time") < OOS[1]))
    tfo = tf.filter((pl.col("time") >= OOS[0]) & (pl.col("time") < OOS[1]))
    f = DS.REGISTRY["retest"](tfo, c)
    tr = backtest_m1(m1o, tfo, f, sym, c)
    res = pl.DataFrame(tr).with_columns((pl.col("r") - pl.col("cost_r")).alias("net"))
    n = len(res)
    net = res["net"].to_numpy()
    gross = res["r"].to_numpy()
    # condition c: retrait top-5 gagnants OOS
    top5 = np.sort(net)[-5:]
    net_no5_mean = (net.sum() - top5.sum()) / (n - 5) if n > 5 else 0.0
    # drawdown cumulÃ© (en R)
    cum = np.cumsum(net)
    peak = np.maximum.accumulate(cum)
    maxdd = float((cum - peak).min())
    # monthly
    res = res.with_columns((pl.col("entry_ts") // 86400 * 86400 * 1000).cast(pl.Datetime("ms")).dt.strftime("%Y-%m").alias("ym"))
    g = res.group_by("ym").agg(pl.col("net").sum().alias("R")).sort("ym")
    months = [(r["ym"], round(float(r["R"]), 2)) for r in g.to_dicts()]
    pos = sum(1 for _, r in months if r > 0)
    pf = float(gross[gross > 0].sum() / abs(gross[gross < 0].sum())) if (gross < 0).any() else 99.0
    print(f"[{sym} M{tf_sec//60:2d}] n={n:3d} netR/tr={net.mean():+.3f} top5-out={net_no5_mean:+.3f} "
          f"wr={100*(res['r']>0).mean():.0f}% PF={pf:.2f} maxDD={maxdd:.1f}R")
    print(f"      months pos={pos}/{len(months)}  {months}")
    return net.mean(), net_no5_mean


print("=== RETEST leader audit OOS 2023 (lb20 k10 sl1.5 rr4) â€” TF reproduction ===")
for tf in [3600, 1800, 900, 300]:
    audit("USDJPY", tf, CFG)
