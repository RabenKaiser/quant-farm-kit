# -*- coding: utf-8 -*-
"""eurgbp_lots_r43.py — calibrer lots EURGBP pour risque ~1%/trade (50k).
SL reel moyen/pire a 0.1 lot: SL_moy ~ -7.3$ (parse -46.3/3 x0.472),
pire SL -9.27$ (16.7 pips). Lots = 1% x 50k / pire_SL_0.1lot x 0.1."""
sl_pire_01 = 9.27   # $ pire SL a 0.1 lot (reel)
sl_moy_01 = 7.30
for target in (0.0075, 0.010, 0.0125):
    lots_pire = target * 50000 / sl_pire_01 * 0.1
    lots_moy = target * 50000 / sl_moy_01 * 0.1
    print(f"target {target*100:.2f}%: lots(pire SL)={lots_pire:.2f} | "
          f"lots(SL moy)={lots_moy:.2f}")
print()
# verif a 5 lots: contribution sum, pire jour, risque
# sum equity reel 0.1 lot = +23.7 sur 8 mois -> a 5 lots (x50) = +1185
# pire jour -9.27 x50 = -463 (0.93%); jour 2 SL (07-31) ~ -6.4-6.2 x50 x2?
print("a 5 lots: sum ~+1185$ | pire SL ~-463$ (0.93%) | "
      "2 SL meme jour ~-900$ (1.8%)")
print("a 4 lots: sum ~+950$ | pire SL ~-371$ (0.74%)")
print("a 6 lots: sum ~+1420$ | pire SL ~-556$ (1.11%)")
print("FIN")
