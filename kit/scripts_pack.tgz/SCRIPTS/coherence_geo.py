# -*- coding: utf-8 -*-
"""coherence_geo.py -- (stop = MAE p50, cible = MFE p50) est-ce coherent ?

L'OBJECTION, ET ELLE EST JUSTE.
MFE et MAE sont des quantiles MARGINAUX, mesures sur toute la detention (192
barres) sans aucune barriere. Les combiner donne une regle qui predit
"50 % stoppes, 50 % au but" -- ce qui est impossible : un trade stoppe a
forcément eu, avant son stop, une excursion favorable non nulle, et le trade
qui atteint la cible est un trade qui a SURVECU.

LE TEST DECISIF.
On prend la geometrie deduite (stop = round(MAE p50), cible = round(MFE p50)),
on la ramene sur la cellule de la grille mesuree, et on compare :
   - l'esperance NAIVE que predit l'arithmetique des marginaux :
         E[R] = 0.5 * (cible/stop) - 0.5
   - le R REELLEMENT mesure par la cellule (r_x) sur les 4 fenetres.
Si le R mesure est tres inferieur au R naif, la logique des marginaux est
refutee et il faut conditionner : c'est mesure, le labo fournit deja le MFE
CONDITIONNEL a la survie d'un stop (mfe_sl8, mfe_sl12, mfe_sl16).
"""
import collections
import json
import statistics
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
LIVE = r"C:\EAFarm\HISTORY - Copy\research\lab_results.jsonl"
PER = ["2024Q1", "2024Q2", "2024Q3", "2024Q4"]
SL = [2, 3, 4, 6, 8, 12]
TP = [1, 2, 3, 4, 6, 8, 12, 24]


def plus_proche(v, lst):
    return min(lst, key=lambda x: abs(x - v))


g = collections.defaultdict(dict)
with open(LIVE, encoding="utf-8", errors="replace") as fh:
    for line in fh:
        if '"r_x7"' not in line:
            continue
        r = json.loads(line)
        if r.get("sym") != "EURUSD" or "|NONE|" in r.get("id", ""):
            continue
        if r.get("period") not in PER or int(r.get("n", 0)) < 3:
            continue
        g[r["id"]][r["period"]] = r

complets = {c: d for c, d in g.items() if all(p in d for p in PER)}
print("=" * 96)
print("COHERENCE DE (stop = MAE p50, cible = MFE p50) -- %d combinaisons completes"
      % len(complets))
print("=" * 96)
print("   %-40s %9s %9s %9s %9s %8s" %
      ("combinaison", "stop der", "cible der", "cellule", "R naif", "R mesure"))
naifs, mesures, ecarts = [], [], []
for c, d in complets.items():
    sl_ = statistics.fmean(float(d[p].get("mae_p50") or 0) for p in PER)
    tp_ = statistics.fmean(float(d[p].get("mfe_p50") or 0) for p in PER)
    if sl_ <= 0:
        continue
    sl, tp = plus_proche(sl_, SL), plus_proche(tp_, TP)
    if tp < sl:
        continue                       # hors regle 1:1
    i, j = SL.index(sl), TP.index(tp)
    rs = [d[p].get("r_x%d" % (7 + i * len(TP) + j)) for p in PER]
    if any(v is None for v in rs):
        continue
    r_mes = statistics.fmean(float(v) for v in rs)
    r_nai = 0.5 * (tp / float(sl)) - 0.5
    naifs.append(r_nai); mesures.append(r_mes); ecarts.append(r_mes - r_nai)
    if len(naifs) <= 14:
        print("   %-40s %9.2f %9.2f %4d/%-4d %+9.4f %+9.4f"
              % (c[:40], sl_, tp_, sl, tp, r_nai, r_mes))
print()
if naifs:
    print("   couples testes            : %d" % len(naifs))
    print("   R NAIF moyen (marginaux)  : %+.4f" % statistics.fmean(naifs))
    print("   R MESURE moyen (cellule)   : %+.4f" % statistics.fmean(mesures))
    print("   ecart moyen (mesure - naif): %+.4f" % statistics.fmean(ecarts))
    print("   combinaisons ou la mesure est MEILLEURE que le naif : %d/%d"
          % (sum(1 for e in ecarts if e > 0), len(ecarts)))
    print()
    if statistics.fmean(ecarts) < 0:
        print("   VERDICT : les deux quantiles sont MARGINAUX et ne peuvent pas")
        print("   etre combines -- le R mesure est loin sous la prediction naive.")
        print("   La geometrie deduite sert donc de BORNE (elle tue les cibles")
        print("   inatteignables), PAS de regle de sortie.")
    else:
        print("   VERDICT : la mesure ne refute pas la deduction par marginaux.")
print()
print("   CE QU'IL FAUT UTILISER A LA PLACE : le MFE CONDITIONNEL a la survie,")
print("   que le labo mesure deja (mfe_sl8, mfe_sl12, mfe_sl16 = MFE des trades")
print("   qui n'ont PAS touche un stop de 8/12/16 ATR). Cible = quantile de ce")
print("   MFE conditionnel : les deux cotes portent alors sur les MEMES trades.")
