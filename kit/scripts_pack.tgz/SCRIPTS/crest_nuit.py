"""crest_nuit : la boucle de nuit de CREST.

CREST (voir SPEC_CREST.md) est la premiere configuration persistante de la session :
motif SR50 court + selectivite (pos >= 0,97, volatilite normale) + BLOCAGE (une position par
paire a la fois) + stop 1 ATR / cible 2 R / 16 h, une jambe par paire.

Cette boucle teste, sans surveillance, les ameliorations de la spec et ecrit une ligne de
tableau de bord par variante, sur les DEUX feeds, avec la regle prop appliquee. Aucune
variante n'est retenue si elle est coupee a -5 %, quel que soit son rendement.
"""
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM
import sweep_256 as SW
import portefeuille_tp2 as P2

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
SCORE = B / "CREST_SCOREBOARD.md"

LEGS3 = "EURCHF:SR50:C,EURGBP:SR100:C,GBPCHF:SR50:C"
LEGS4 = LEGS3 + ",EURUSD:SR100:C"
LEGS5 = LEGS3 + ",NZDJPY:SR50:C,NZDJPY:RSI14:C"


def une_variante(nom, legs, tpr, hold, sla, filtre, blocage, annee_min=0, coupe=-5.0):
    os.environ["FILTRE"] = "1" if filtre else "0"
    os.environ["BLOCAGE"] = "1" if blocage else "0"
    os.environ["SL_ATR"] = str(sla)
    SW.DD_COUPE = coupe          # 264 : -99 % = on regarde la courbe sans coupe interne
    sortie = []
    for source in ("m1_upcomers", "m1_pos"):
        os.environ["SOURCE"] = source
        sous = {}
        for leg in [x for x in legs.split(",") if x]:
            paire, motif, sens = leg.split(":")
            D = NM.charge(paire, source)
            if D is None:
                continue
            tr = P2.trades(D, motif, sens, hold, tpr)
            if annee_min and tr:
                tr = [(t, r) for t, r in tr if t.year >= annee_min]
            if tr and len(tr) >= 40:
                sous[leg] = tr
        if len(sous) < 2:
            print("  %-30s %-11s : moins de 2 jambes exploitables" % (nom, source), flush=True)
            continue
        moy = float(np.mean([np.mean([r for _, r in v]) for v in sous.values()]))
        meilleur = None
        for cap in (1, 2):
            for risk in (0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0):
                r = SW.simule(sous, risk, 6, cap)
                if r["coupe"]:
                    continue
                if meilleur is None or r["mois_moy"] > meilleur[0]:
                    meilleur = (r["mois_moy"], risk, cap, r)
        if meilleur is None:
            print("  %-30s %-11s : TOUTES les configurations coupees" % (nom, source), flush=True)
            continue
        moy_mois, risk, cap, r = meilleur
        print("  %-30s %-11s jambes %d | R/tx jambes %+.4f | pris %+.4f | %.2f %% risque (cap %d) "
              "-> %+.2f %%/mois | pire mois %+.2f %% | DD %.2f %% | %d tx"
              % (nom, source, len(sous), moy, r["r_tx"], risk, cap, r["mois_moy"], r["pire"],
                 r["dd"], r["pris"]), flush=True)
        sortie.append("| %s | %s | %d | %+.4f | %+.4f | %.2f %% | %d | %+.2f %% | %+.2f %% | %d/%d | %.2f %% |"
                      % (nom, source, len(sous), moy, r["r_tx"], risk, cap, r["mois_moy"], r["pire"],
                         r["mois_pos"], r["mois_n"], r["dd"]))
    return sortie


def main():
    if not SCORE.exists():
        SCORE.write_text(
            "# Tableau de bord CREST\n\n"
            "Une ligne par variante testee, sur chaque feed. Reference (SPEC_CREST.md) : motif SR50\n"
            "court + selectivite pos >= 0,97 + blocage une position par paire + stop 1 ATR /\n"
            "cible 2 R / 16 h. Aucune variante n'est retenue si elle est coupee a -5 %.\n\n"
            "| variante | feed | jambes | R/tx jambes | R/tx pris | risque | cap | mois moy | pire mois | mois + | DD max |\n"
            "|---|---|---|---|---|---|---|---|---|---|---|\n", encoding="utf-8")
    variantes = [
        ("reference 3 jambes 2R", LEGS3, 2.0, 32, 1.0, True, True),
        ("3 jambes 1R", LEGS3, 1.0, 32, 1.0, True, True),
        ("3 jambes 3R", LEGS3, 3.0, 32, 1.0, True, True),
        ("3 jambes 2R hold 16", LEGS3, 2.0, 16, 1.0, True, True),
        ("3 jambes 2R hold 64", LEGS3, 2.0, 64, 1.0, True, True),
        ("3 jambes 2R stop 1,5", LEGS3, 2.0, 32, 1.5, True, True),
        ("3 jambes 2R stop 2", LEGS3, 2.0, 32, 2.0, True, True),
        ("3 jambes 2R sans selectivite", LEGS3, 2.0, 32, 1.0, False, True),
        ("3 jambes 2R sans blocage", LEGS3, 2.0, 32, 1.0, True, False),
        ("3 jambes 2R ni l'un ni l'autre", LEGS3, 2.0, 32, 1.0, False, False),
        ("4 jambes 2R", LEGS4, 2.0, 32, 1.0, True, True),
        ("5 jambes 2R", LEGS5, 2.0, 32, 1.0, True, True),
    ]
    lignes = []
    print("CREST : %d variantes x 2 feeds" % len(variantes), flush=True)
    for nom, legs, tpr, hold, sla, filtre, blocage in variantes:
        print("\n=== %s" % nom, flush=True)
        lignes += une_variante(nom, legs, tpr, hold, sla, filtre, blocage)
    with SCORE.open("a", encoding="utf-8") as f:
        f.write("\n".join(lignes) + "\n")
    print("\n%d lignes ajoutees a %s" % (len(lignes), SCORE), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
