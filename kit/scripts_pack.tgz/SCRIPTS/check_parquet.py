﻿import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import polars as pl
from pathlib import Path

p = Path(r"C:\EAFarm\HISTORY - Copy\research\bars\EURUSD_M1.parquet")
df = pl.read_parquet(p).sort("time")
print(df.columns)
print(df.head(5))
print("\nspread_med sample stats:")
print("mean:", df["spread_med"].mean(), "max:", df["spread_med"].max())
print("n==0:", (df["spread_med"] == 0).sum(), "of", len(df))
# find a bar with ticks but spread 0
print("\nsample rows where n_ticks>20:")
print(df.filter(pl.col("n_ticks") > 20).head(3))
# compare with raw month around same time
