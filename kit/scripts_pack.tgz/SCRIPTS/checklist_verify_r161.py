# -*- coding: utf-8 -*-
"""checklist_verify_r161.py — repondre a la checklist deploy:
(1) taille echantillon par leg sur Upcomers 2026 (mois, n)
(2) risque PAR TRADE des runs RISK1% (chaque SL <= 1% ?) sur les CFDs + GBPJPY
(3) trades/mois (frequence reelle)
Lecture des logs par leg: chaque perte en % du capital."""
import sys, glob, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
# (ea, symbole, bal approx, n attendu, tag)
WANT = [("V3INT_EA_RISK", "DJCUSD.c", 103835.74, 16, "DOW-RISK1"),
        ("V3INT_EA_RISK", "SPCUSD.c", 104906.59, 18, "SPX-RISK1"),
        ("V3INT_EA_RISK", "FRCEUR.c", 102044.8, 9, "FR40-RISK1")]
for ea, sym, bal0, n0, tag in WANT:
    best = None
    for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-40:]:
        try:
            runs = F.parse_stream(lp, ea)
        except Exception:
            continue
        for key, data in runs.items():
            s0 = (key.split(" ")[0] or "").split(",")[0]
            if s0.replace(".c", "") != sym.replace(".c", ""):
                continue
            closed = [t for t in data["trades"].values() if t["close"] is not None]
            if len(closed) != n0:
                continue
            b = data.get("balance") or 0.0
            if best is None or abs(b - bal0) < abs(best.get("d", 1e9)):
                best = {"d": abs(b - bal0), "trades": closed, "bal": b, "lp": lp}
    if best is None:
        print(f"{tag}: introuvable")
        continue
    bal = best["bal"]
    losses = [t for t in best["trades"] if F.pnl_usd(t) < 0]
    wins = [t for t in best["trades"] if F.pnl_usd(t) > 0]
    months = sorted({str(t["ts_entry"])[:7] for t in best["trades"]})
    print(f"=== {tag} ({sym}) bal={bal:.0f} n={len(best['trades'])} "
          f"| {len(months)} mois touches | ~{len(best['trades'])/max(1,len(months)):.1f} t/mois ===")
    for t in sorted(losses, key=F.pnl_usd):
        pct = F.pnl_usd(t) / bal * 100
        flag = "  <<< DEPASSE 1%" if pct < -1.0 else ""
        print(f"  SL {str(t['ts_entry'])[:10]} vol={t.get('vol')} "
              f"{F.pnl_usd(t):+.0f}$ ({pct:+.2f}%){flag}")
    for t in sorted(wins, key=F.pnl_usd, reverse=True)[:2]:
        print(f"  TP {str(t['ts_entry'])[:10]} vol={t.get('vol')} "
              f"{F.pnl_usd(t):+.0f}$ ({F.pnl_usd(t)/bal*100:+.2f}%)")
print("FIN", flush=True)
