# -*- coding: utf-8 -*-
"""checkpoint.py — SAUVEGARDE + DOCUMENT DE REPRISE, relancable a volonte.

Cree C:\\EAFarm\\SHARED\\CHECKPOINT_<AAAAMMJJ_HHMM>\\ avec :
  - tous les scripts .py du dossier SCRIPTS (moteurs + campagnes + analyses)
  - les sorties JSON/JSONL importantes (taillees si trop grosses)
  - les EA MT5 (FVGX_EA.mq5, EXPORT_M1.mq5)
  - un document REPRISE_<date>.md REGENERE avec les chiffres du moment
Il tient aussi un index C:\\EAFarm\\SHARED\\CHECKPOINTS.md (liste de tous les points).

Usage : python checkpoint.py [--quiet]
"""
import os, sys, json, shutil, datetime as dt

BASE = r"C:\EAFarm\HISTORY - Copy\research"
SCRIPTS = os.path.join(BASE, "SCRIPTS")
SHARED = r"C:\EAFarm\SHARED"
MAX_MO = 60.0                      # taille max par fichier de sortie copie
KEEP_JSON = [
    "r354_current.json", "r345_rerank.json", "r344_rank.json", "r351_best.json",
    "r352_pass.json", "r353_portfolio.json", "r358_best.json", "r361_sym.json",
    "r340_dsr.json", "r341_mech.json", "r338_harvest.json", "r351_agg.txt",
    "r344_rank.txt", "r345_rerank.txt", "selftest_r344.log", "r352.log",
]
KEEP_JSONL = [
    "r342_pair.jsonl", "r342_up.jsonl", "r342_duka.jsonl", "r348_duka5.jsonl",
    "r350_up35.jsonl", "r359_combo.jsonl", "r358_edge.jsonl", "r337_mega2.jsonl",
]
KEEP_EA = [
    (r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal"
     r"\CF0B997454318B475CF01419AFE2BBF3\MQL5\Experts\eepeek\FVGX_EA.mq5", "FVGX_EA.mq5"),
    (r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal"
     r"\CF0B997454318B475CF01419AFE2BBF3\MQL5\Experts\eepeek\EXPORT_M1.mq5", "EXPORT_M1.mq5"),
]


def jload(p):
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return None


def snapshot_numbers():
    """Lit les sorties du moment pour ecrire des chiffres VERIFIABLES."""
    out = {}
    d = jload(os.path.join(BASE, "r354_current.json"))
    if d and "res15" in d:
        r = d["res15"]
        out["portefeuille_actuel"] = dict(
            R=r.get("metrics", {}).get("net"), dd=r.get("metrics", {}).get("dd"),
            rdd=r.get("metrics", {}).get("rdd"), calmar12=r.get("calmar12"),
            ca_mois=r.get("ca_mois"), neff=r.get("neff"),
            n_legs=len(d.get("chosen", [])))
    s = jload(os.path.join(BASE, "r361_sym.json"))
    if isinstance(s, list) and s:
        out["symetrie_top"] = s[:5]
    for f, key in (("r348_duka5.jsonl", "r348"), ("r350_up35.jsonl", "r350"),
                   ("r359_combo.jsonl", "r359"), ("r342_up.jsonl", "r342_up")):
        p = os.path.join(BASE, f)
        if os.path.exists(p):
            n = sum(1 for _ in open(p, encoding="utf-8", errors="replace"))
            out.setdefault("lignes", {})[key] = n
    return out


def write_reprise(path, tag, nums):
    L = []
    A = L.append
    A(f"# REPRISE {tag} — ETAT DU PROJET (auto-genere par checkpoint.py)")
    A("")
    A("> Genere automatiquement. Les chiffres ci-dessous sont LUS dans les sorties.")
    A("")
    A("## 1. LIRE D'ABORD")
    A("")
    A("### Travail R371 (session du 2026-09-12) — le plus recent")
    A("- `VERIFICATION_R371.md` : **audit independant complet**. Sonde isolee")
    A("  filtre par filtre : 12/13 filtres a moins de 1 point du python.")
    A("- `RESULTAT_FINAL_R371.md` : portefeuille lisse valide (18 jambes,")
    A("  5 marches, trimestres positifs 8/8) + fidelite MT5 **5/5 paires**.")
    A("- `BLOCAGE_15_MARCHES_R371.md` : **pourquoi 10-15 marches est impossible**")
    A("  avec ces donnees (le terminal n'a que des fragments M1 1999/2008).")
    A("- `PIEGES_MT5_R371.md` : 6 pieges MT5 (logs UTF-16, cache pre-filtre...).")
    A("- `PERSISTANCE_R371.md` : 8 mois non validables (+0.155) vs 6 ans (+0.289).")
    A("- `AUDIT_CORRIGE_R371.md` : corrige un audit anterieur errone.")
    A("")
    A("### Historique")
    A("- `REPRISE_R344.md` : etat du projet a R344 (6 bugs corriges).")
    A("- `MANIFESTE.md`, `CORRECTIONS_R320.md`.")
    A("- `METRIQUES.md` : quelles metriques utiliser et pourquoi.")
    A("")
    A("## 2. NON-REGRESSION OBLIGATOIRE")
    A("")
    A("```")
    A("cd C:\\EAFarm\\HISTORY - Copy\\research\\SCRIPTS")
    A("python -u selftest.py            # attendu : 18 OK / 0 ECHECS")
    A("python -u test_metrics3.py       # attendu : OK — metrics3 conforme")
    A("```")
    A("")
    A("## 3. CHIFFRES DU MOMENT")
    A("")
    A("```json")
    A(json.dumps(nums, indent=1, default=str)[:4000])
    A("```")
    A("")
    A("## 4. CE QUI A ETE MESURE (a ne pas oublier)")
    A("")
    A("- **Le portefeuille historique etait 13/15 sur l'OR** : ce n'est pas de la")
    A("  diversification. La loi R/DD_pf ~ sqrt(sum R/DD_i^2) exige des MARCHES differents.")
    A("- **Classer par `s` (edge/trade), jamais par R brut** : `big_bear x h_quiet`")
    A("  = +748 R mais s = 0.079 (jambe de volume, pas d'edge).")
    A("- **R/ES transfere 2x mieux que le R/DD** hors-echantillon (43.31 vs 21.46) ;")
    A("  le Sharpe est le pire (19.75). Mais R/ES croit avec N -> normaliser par sqrt(N).")
    A("- **SYMETRIE** : le miroir negatif ne prouve rien. Un vrai edge gagne DANS LES")
    A("  DEUX SENS. Seule exception : les INDICES (biais long structurel).")
    A("- **`giga_lib.run_trades` n'applique PAS `trail_atr`** : les essais trailing de")
    A("  r337/r338/r348/r350 sont des DOUBLONS sans trailing. Seuls `deep_lib` et")
    A("  `m1_engine` appliquent reellement le trailing.")
    A("- **FIBO IMBRIQUE** : `fibo_nested` = golden pocket mineur (50 barres) dans le")
    A("  majeur (200 barres). Aussi `in_fibM`, `in_fibm`, `in_fibM_deep`.")
    A("")
    A("## 5. CAMPAGNES")
    A("")
    A("| script | role |")
    A("|---|---|")
    A("| `r359_combo.py` | explosion combinatoire (4.9 M cribles, simples+paires+triples) |")
    A("| `r361_sym.py` | post-traitement SYMETRIE des cribles |")
    A("| `r358_edge.py` | sorties fines + TRAILING REEL sur les survivants |")
    A("| `r348_duka5.py` | grille M5 sur 5 marches Dukascopy 6 ANS |")
    A("| `r350_up35.py` | grille M5 sur 34 marches Upcomers (9 mois) |")
    A("| `r342_pair.py` | recherche par paire en M1 |")
    A("| `r354_current.py` | MESURE du portefeuille actuel (base de comparaison) |")
    A("| `r353_portfolio.py` | construction du portefeuille decorrele |")
    A("| `r344_rank.py` / `r351_agg.py` / `r345_rerank.py` | classements par `s` |")
    A("")
    A("## 6. METRIQUES (voir METRIQUES.md)")
    A("")
    A("- Jambe : `s` = min(R/DD_h1,R/DD_h2)/sqrt(N) puis `s_es`, puis `s_sym`.")
    A("- Portefeuille : **Calmar 12 mois MESURE** (fenetres glissantes) et")
    A("  **CA/mois = (R12/12) x (10 %/DD12)**.")
    A("- Ajout d'une jambe : `R_i/DD_i^2 > R_pf/(2*DD_pf^2)` et `|rho| <= rho_max`.")
    A("- Secondaires : ES5/CVaR, CDaR5, Ulcer, Martin, N_eff, IC bootstrap par blocs.")
    A("")
    A("## 7. OUTILS")
    A("")
    A("- `metrics3.py` : metriques canoniques (verifie par `test_metrics3.py`).")
    A("- `pf2.py` / `pf_lib.py` : rapport de portefeuille + simulation prop")
    A("  (day-stop -3 %, trailing -6 %, verrou +10 %).")
    A("- `m1_engine.py`, `deep_lib.py`, `giga_lib.py`, `nested_lib.py`, `feat2.py`,")
    A("  `pa_mtf.py`, `c13v2_engine.py`.")
    A("- `r357_export_api.py` : export M1 par l'API MetaTrader5 (le terminal Farm")
    A("  pointe en realite sur le data_path CF0B, connecte a Dukascopy-demo-mt5-1).")
    A("")
    A("## 8. PIEGES")
    A("")
    A("- `giga_v2.py` s'execute a l'import (pas de garde `__main__`).")
    A("- `Select-Object -First N` tue le process python avant ses ecritures.")
    A("- PowerShell corrompt les guillemets imbriques dans `python -c` -> ecrire un .py.")
    A("- `Start-Process` casse les chemins contenant des espaces.")
    A("- 4 coeurs seulement : ne pas lancer plus de 4-5 jobs python.")
    A("- Le dossier MetaQuotes est enorme : ne pas le lister recursivement (timeout).")
    A("- `C:\\MT5` : NE PAS TOUCHER.")
    A("")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(L))


def safe_copy(src, dst):
    """Copie SANS bloquer les ecrivains.

    ATTENTION : shutil.copy2 utilise CopyFileEx qui ouvre la source avec
    FILE_SHARE_READ seulement -> il REFUSE l'ecriture aux autres process et tue
    les campagnes en cours (PermissionError sur open(OUT,'a')).
    Ici on lit avec open('rb') (partage complet) par blocs.
    """
    with open(src, "rb") as fi, open(dst, "wb") as fo:
        while True:
            b = fi.read(1 << 20)
            if not b:
                break
            fo.write(b)


def safe_tail(src, dst, nbytes=20 << 20):
    sz = os.path.getsize(src)
    with open(src, "rb") as fi:
        if sz > nbytes:
            fi.seek(sz - nbytes)
        with open(dst, "wb") as fo:
            while True:
                b = fi.read(1 << 20)
                if not b:
                    break
                fo.write(b)


def main():
    quiet = "--quiet" in sys.argv
    tag = dt.datetime.now().strftime("%Y%m%d_%H%M")
    dst = os.path.join(SHARED, f"CHECKPOINT_{tag}")
    os.makedirs(dst, exist_ok=True)
    os.makedirs(os.path.join(dst, "SCRIPTS"), exist_ok=True)
    os.makedirs(os.path.join(dst, "OUT"), exist_ok=True)
    npy = njson = mo = 0
    # scripts
    for f in sorted(os.listdir(SCRIPTS)):
        if f.endswith(".py"):
            try:
                shutil.copy2(os.path.join(SCRIPTS, f), os.path.join(dst, "SCRIPTS", f))
                npy += 1
            except Exception:
                pass
    # sorties
    for f in KEEP_JSON + KEEP_JSONL:
        p = os.path.join(BASE, f)
        if not os.path.exists(p):
            continue
        sz = os.path.getsize(p) / 1e6
        try:
            if sz <= MAX_MO:
                safe_copy(p, os.path.join(dst, "OUT", f))
            else:                      # trop gros : on garde la queue (les survivants)
                safe_tail(p, os.path.join(dst, "OUT", f + ".tail"))
            njson += 1; mo += min(sz, MAX_MO)
        except Exception:
            pass
    # EA
    for src, name in KEEP_EA:
        try:
            if os.path.exists(src):
                shutil.copy2(src, os.path.join(dst, name))
        except Exception:
            pass
    # chiffres + document de reprise
    nums = snapshot_numbers()
    json.dump(nums, open(os.path.join(dst, "SNAPSHOT.json"), "w"),
              indent=1, default=str)
    write_reprise(os.path.join(dst, "REPRISE.md"), tag, nums)
    # index
    idx = os.path.join(SHARED, "CHECKPOINTS.md")
    tot = sum(os.path.getsize(os.path.join(r, x))
              for r, _, fs in os.walk(dst) for x in fs)
    line = (f"- `CHECKPOINT_{tag}` — {npy} scripts, {njson} sorties, "
            f"{tot/1e6:.1f} Mo — R/DD actuel "
            f"{nums.get('portefeuille_actuel', {}).get('rdd')}\n")
    if not os.path.exists(idx):
        open(idx, "w", encoding="utf-8").write(
            "# INDEX DES CHECKPOINTS\n\n(le plus recent en haut)\n\n")
    old = open(idx, encoding="utf-8").read().split("\n")
    head, body = old[:4], old[4:]
    open(idx, "w", encoding="utf-8").write(
        "\n".join(head + [line.rstrip()] + body))
    if not quiet:
        print(f"CHECKPOINT {tag} cree : {dst}")
        print(f"  {npy} scripts | {njson} sorties | {tot/1e6:.1f} Mo")
        print(f"  chiffres : {json.dumps(nums.get('portefeuille_actuel', {}), default=str)}")
        print(f"  index    : {idx}")
    return dst


if __name__ == "__main__":
    main()
