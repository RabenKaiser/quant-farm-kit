# -*- coding: utf-8 -*-
"""eq_extract_r175.py — extraire NZDJPY (log actif) + GBPJPY (chercher dans
le log rote juste avant). Lecture ciblee: ne parser QUE le log contenant le
run (les logs actifs/rotes recents)."""
import sys, os, glob
import pandas as pd
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
TEAM = r"C:\EAFarm\HISTORY - Copy\research\prop_team\equities"

def grab(lp, sym, n):
    if not os.path.exists(lp):
        return None
    try:
        runs = F.parse_stream(lp, "V3INT")
    except Exception as e:
        print(lp, "err", e)
        return None
    for key, data in runs.items():
        if sym not in key or "H1" not in key:
            continue
        closed = [t for t in data["trades"].values() if t["close"] is not None]
        if len(closed) != n:
            continue
        b = data.get("balance") or 0
        rows = []
        for t in closed:
            try:
                rows.append((str(t["ts_entry"])[:10], F.pnl_usd(t)))
            except Exception:
                pass
        s = pd.Series([r[1] for r in rows],
                      index=pd.DatetimeIndex([r[0] for r in rows]))
        ds = s.groupby(s.index).sum()
        k = (b - 10000) / ds.sum() if ds.sum() != 0 else 1.0
        ds2 = ds * k
        fn = TEAM + rf"\equity_V3INT-{sym}-H1-duka7y.csv"
        ds2.to_csv(fn, header=["pnl_day"])
        print(f"{sym}: n={len(closed)} bal={b:.0f} k={k:.3f} sum={ds2.sum():+.0f} "
              f"[{os.path.basename(lp)}]")
        return ds2
    return None

active = os.path.join(LOGD, "20260908.log")
grab(active, "NZDJPY", 54)
# GBPJPY n105: le run a tourne avant NZDJPY -> log rote le plus recent
logs = sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime, reverse=True)
for lp in logs[:5]:
    if lp == active:
        continue
    if os.path.getsize(lp) > 800 * 1024 * 1024:
        continue
    if grab(lp, "GBPJPY", 105):
        break
print("FIN", flush=True)
