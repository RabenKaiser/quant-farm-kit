"""edge_sweep : recherche systematique du MEILLEUR portefeuille, pas d'un seul reglage.

Ce que les rounds 261-268 ont etabli :
  - seuls les signaux EXTREMES payent (pos >= 0,97) ;
  - ne pas vendre dans une course deja lancee (MOM 2 ATR / 8 barres) fait passer le R/tx de
    +0,216 a +0,291 et rend les six annees positives ;
  - une position par paire a la fois (blocage) ramene le pire jour de -35 R a -2,2 R ;
  - la cible 2 R vaut mieux que 1 R, et 3 jambes valent mieux que 6.

Ce script balaie maintenant les quatre leviers EN MEME TEMPS, sur le corpus long (le seul qui
couvre 6 ans), et classe les configurations sur deux criteres de ROBUSTESSE :
  - le R/tx de la PIRE annee (un reglage qui ne vit que sur une annee ne vaut rien) ;
  - le rapport edge / drawdown en R (combien de R on gagne par R de drawdown).
Un reglage qui gagne en moyenne mais s'effondre une annee est ecarte, meme s'il a le meilleur
R/tx.
"""
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM
import portefeuille_tp2 as P2

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
LEGS = ["EURCHF:SR50:C", "EURGBP:SR100:C", "GBPCHF:SR50:C"]
MOM_L = (4, 8, 12)
MOM_T = (1.5, 2.0, 2.5, 3.0)
TPR = (2.0, 3.0)
HOLD = (32, 64)
SESSION = ("toutes", "hors 7-16 h")


def base_leg(D, motif, sens, tpr, hold):
    """Sert une fois par (jambe, cible, detention) : signaux filtres, R, barre de sortie."""
    m = NM.motifs(D)
    sig = np.asarray(P2.masque_selectif(D, m[motif][0 if sens < 0 else 1]), dtype=int)
    c, h, l, a = D["c"], D["h"], D["l"], D["a"]
    sig = sig[sig < len(c) - hold - 2]
    sig = sig[np.isfinite(a[sig]) & (a[sig] > 0)]
    e, st = c[sig], a[sig]
    tp, sl = (e - tpr * st, e + st) if sens < 0 else (e + tpr * st, e - st)
    off = np.arange(1, hold + 1)
    Hh, Ll, cl = h[sig[:, None] + off], l[sig[:, None] + off], c[sig + hold]
    htp = (Ll <= tp[:, None]) if sens < 0 else (Hh >= tp[:, None])
    hsl = (Hh >= sl[:, None]) if sens < 0 else (Ll <= sl[:, None])
    it = np.where(htp.any(1), htp.argmax(1), 10 ** 6)
    isl = np.where(hsl.any(1), hsl.argmax(1), 10 ** 6)
    tph, slh = htp.any(1), hsl.any(1)
    kind = np.where(tph & (~slh | (it < isl)), 0, np.where(slh, 1, 2))
    barre = np.where(kind == 0, it + 1, np.where(kind == 1, isl + 1, hold))
    fin = ((e - cl) if sens < 0 else (cl - e)) / st
    R = np.where(kind == 0, tpr, np.where(kind == 1, -1.0, fin)) - D["cout"]
    ok = np.isfinite(R)
    return sig[ok], R[ok], barre[ok]


def bloque(idx, sig, R, barre, hold, saut=1.0):
    garde, fin = [], None
    for k, i in enumerate(sig):
        t = idx[i]
        if fin is not None and t < fin:
            continue
        garde.append(k)
        fin = t + pd.Timedelta(minutes=30 * hold * saut)
    g = np.array(garde, dtype=int)
    return g


def evalue(idx, sig, R, hold, annee_min=0):
    if len(R) < 40:
        return None
    par_an = defaultdict(list)
    for i, v in zip(sig, R):
        par_an[idx[i].year].append(v)
    annees = [y for y in sorted(par_an) if len(par_an[y]) >= 25 and y >= annee_min]
    if not annees:
        return None
    pire = min(float(np.mean(par_an[y])) for y in annees)
    jours = defaultdict(float)
    for i, v in zip(sig, R):
        jours[idx[i].date()] += v
    v = np.array(sorted(jours.values()))
    dd = float(np.min(np.cumsum(v - v.mean())))
    return dict(n=len(R), r=float(np.mean(R)), pire_an=pire, annees=len(annees),
                rdd=float(np.sum(v) / abs(dd)) if dd < 0 else 99.0, pire_jour=float(v.min()),
                par_an=dict((y, float(np.mean(par_an[y]))) for y in annees))


def main():
    os.environ["SOURCE"] = "m1_pos"
    donnees = {}
    for leg in LEGS:
        paire, motif, sens = leg.split(":")
        D = NM.charge(paire, "m1_pos")
        if D is not None:
            donnees[leg] = D
    if len(donnees) < 2:
        print("donnees insuffisantes")
        return 1
    print("%d jambes chargees" % len(donnees), flush=True)
    resultats = []
    for tpr in TPR:
        for hold in HOLD:
            cache = {}
            for leg, D in donnees.items():
                paire, motif, sens = leg.split(":")
                cache[leg] = base_leg(D, motif, -1 if sens == "C" else 1, tpr, hold)
            for L in MOM_L:
                for T in MOM_T:
                    for sess in SESSION:
                        tous_sig, tous_R, par_leg = {}, {}, {}
                        for leg, D in donnees.items():
                            sig, R, barre = cache[leg]
                            c, a = D["c"], D["a"]
                            garde = np.abs(c[sig] - np.roll(c, L)[sig]) <= T * a[sig]
                            if sess == "hors 7-16 h":
                                hr = D["idx"][sig].hour
                                garde &= ~((hr >= 7) & (hr <= 16))
                            if garde.sum() < 40:
                                continue
                            par_leg[leg] = (sig[garde], R[garde], barre[garde], D)
                        if len(par_leg) < 2:
                            continue
                        # blocage par jambe, puis mise en commun pour l'edge/drawdown
                        tous = []
                        for leg, (sig, R, barre, D) in par_leg.items():
                            g = bloque(D["idx"], sig, R, barre, hold)
                            for k in g:
                                tous.append((D["idx"][sig[k]], R[k]))
                        if len(tous) < 60:
                            continue
                        tous.sort(key=lambda x: x[0])
                        idxs = pd.DatetimeIndex([t for t, _ in tous])
                        Rr = np.array([r for _, r in tous])
                        e = evalue(idxs, np.arange(len(Rr)), Rr, hold)
                        if e is None:
                            continue
                        resultats.append((tpr, hold, L, T, sess, e))
                        print("  cible %.1f hold %2d | MOM %4.1f ATR/%2d barres | %-11s : %5d tx R/tx %+.4f | pire an %+.4f (%d ans) | R/DD %5.1f | pire jour %+.1f"
                              % (tpr, hold, T, L, sess, e["n"], e["r"], e["pire_an"], e["annees"], e["rdd"], e["pire_jour"]), flush=True)
    if not resultats:
        print("aucun resultat")
        return 1
    # classement : d'abord la robustesse (pire annee), ensuite l'edge par unite de drawdown
    resultats.sort(key=lambda x: (x[5]["pire_an"], x[5]["rdd"]), reverse=True)
    lignes = ["# Balayage de l'edge du portefeuille - corpus long, jambes CREST", "",
              "Classe par R/tx de la PIRE ANNEE, puis par edge/drawdown en R. Un reglage qui ne",
              "vit que sur une seule annee est ecarte, meme s'il a la meilleure moyenne.", "",
              "| cible | hold | MOM | session | positions | R/tx | pire annee | edge/DD | pire jour |",
              "|---|---|---|---|---|---|---|---|---|"]
    for tpr, hold, L, T, sess, e in resultats[:25]:
        lignes.append("| %.1f R | %d | %.1f ATR / %d barres | %s | %d | %+.4f | %+.4f | %.1f | %+.1f |"
                      % (tpr, hold, T, L, sess, e["n"], e["r"], e["pire_an"], e["rdd"], e["pire_jour"]))
    lignes += ["", "## Detail par annee des 5 meilleurs", ""]
    for tpr, hold, L, T, sess, e in resultats[:5]:
        lignes.append("- cible %.1f R, hold %d, MOM %.1f ATR/%d, %s : %s"
                      % (tpr, hold, T, L, sess,
                         ", ".join("%d %+.3f" % (y, v) for y, v in sorted(e["par_an"].items()))))
    (B / "EDGE_SWEEP.md").write_text("\n".join(lignes), encoding="utf-8")
    print("\nMEILLEUR : cible %.1f R, hold %d, MOM %.1f ATR/%d barres, %s -> R/tx %+.4f, pire annee %+.4f, edge/DD %.1f"
          % (resultats[0][0], resultats[0][1], resultats[0][3], resultats[0][2], resultats[0][4],
             resultats[0][5]["r"], resultats[0][5]["pire_an"], resultats[0][5]["rdd"]), flush=True)
    print("ecrit EDGE_SWEEP.md", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
