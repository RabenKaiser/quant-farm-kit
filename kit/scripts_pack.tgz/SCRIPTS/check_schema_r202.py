# -*- coding: utf-8 -*-
"""check_schema_r202.py — verifier le schema des parquets M1 dispo."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import pandas as pd

P = r"C:\EAFarm\HISTORY - Copy\research\bars\EURUSD_M1_db.parquet"
df = pd.read_parquet(P)
print("colonnes:", list(df.columns))
print("dtypes:", dict(df.dtypes.astype(str)))
print("range:", df.index.min() if not isinstance(df.index, pd.RangeIndex) else df['ts_event'].min() if 'ts_event' in df else '?', "->",
      df.index.max() if not isinstance(df.index, pd.RangeIndex) else df['ts_event'].max() if 'ts_event' in df else '?')
print("rows:", len(df))
print(df.head(3))
print(df.tail(2))
