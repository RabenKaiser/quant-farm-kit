"""combo_lab : test de COMBINAISONS de motifs (ET logique) sur les familles
de patterns. Seuls les motifs deja juges positifs dans LES DEUX epoques dans
patterns_lab.jsonl sont combines. Geometrie de reference : stop 1 ATR / rr 1.
Sortie : research/combo_lab.jsonl (resumable) + tableau classe.
"""
import sys
import json
import argparse
import itertools
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import patterns_lab as P  # noqa: E402

OUT = P.B / "combo_lab.jsonl"
BENCH = P.B / "patterns_lab.jsonl"
GEOS = ("stop1.0,rr1.0", "stop2.0,rr1.0", "stop1.0,rr2.0")


def net(sorties, geo, cout_atr):
    g = sorties.get(geo)
    if g is None:
        return None
    stop = float(geo.split("stop")[1].split(",")[0])
    cA = cout_atr / stop
    return (g[0], g[1], g[0] - cA, g[1] - cA)


def candidats(k, regle="strict"):
    """(paire, sens) -> motifs positifs nets dans les deux epoques.
    strict : geometrie imposee stop1/rr1.  best : meilleure geometrie de la
    bande 1:1..1:6 pour chaque motif (celle ou le pire des deux epochs est max).
    """
    cand = {}
    for ln in BENCH.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            d = json.loads(ln)
        except Exception:
            continue
        if regle == "strict":
            v = net(d["sorties"], "stop1.0,rr1.0", d["cout_atr"])
            if v is None:
                continue
            gA, gB, nA, nB = v
            geo = "stop1.0,rr1.0"
        else:
            nA = nB = None
            geo = None
            for g, val in d["sorties"].items():
                stop = float(g.split("stop")[1].split(",")[0])
                if stop < 1.0 or stop > 6.0:
                    continue
                xA, xB = val[0] - d["cout_atr"] / stop, val[1] - d["cout_atr"] / stop
                if nA is None or min(xA, xB) > min(nA, nB):
                    nA, nB, geo = xA, xB, g
            if geo is None:
                continue
        if nA <= 0 or nB <= 0:
            continue
        cand.setdefault((d["paire"], d["sens"]), []).append(
            dict(motif=d["motif"], famille=d["famille"], nA=nA, nB=nB,
                 geo=geo, n=d["n"], mfe_cond=d.get("mfe_cond")))
    for kk in cand:
        cand[kk].sort(key=lambda d: -min(d["nA"], d["nB"]))
        cand[kk] = cand[kk][:k]
    return cand


def signaux(b):
    sg = {}
    for fam, fn in P.FAMILLES.items():
        for motif, (lo, hi) in fn(b).items():
            sg[motif] = (fam, lo.values, hi.values)
    return sg


def mesure_geo(b, idx, sens, cout_atr):
    if len(idx) < 60:
        return None
    m = P.mesure(b, idx, sens, cout_atr)
    if not m:
        return None
    out = {"n": m["n"], "mfe": m["mfe"], "mae": m["mae"],
           "mfe_cond": m["mfe_cond"]}
    for g in GEOS:
        v = m["lignes"].get(g)
        if v is None:
            continue
        stop = float(g.split("stop")[1].split(",")[0])
        out[g] = [v[0], v[1], v[0] - cout_atr / stop, v[1] - cout_atr / stop]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--paires", default="")
    ap.add_argument("--top", type=int, default=10)
    ap.add_argument("--mono", action="store_true",
                    help="autoriser les combinaisons intra-famille")
    ap.add_argument("--maxpaires", type=int, default=0)
    ap.add_argument("--regle", default="strict", choices=("strict", "best"))
    a = ap.parse_args()

    cand = candidats(a.top, a.regle)
    paires = [p.strip() for p in a.paires.split(",") if p.strip()] or P.TOUTES
    if a.maxpaires:
        paires = paires[:a.maxpaires]

    res = []
    for p in paires:
        cl = cand.get((p, "L"), []) + cand.get((p, "S"), [])
        if len(cl) < 2:
            print("%-8s aucun candidat positif 2 epoques" % p, flush=True)
            continue
        b = P.charge(p)
        if b is None or len(b) < 500:
            print("%-8s pas de donnees" % p, flush=True)
            continue
        cout_atr = float(b.attrs["cout_atr"])
        sg = signaux(b)
        n_ok = 0
        for sens, cle in ((1, "L"), (-1, "S")):
            cs = [c for c in cand.get((p, cle), []) if c["motif"] in sg]
            for c1, c2 in itertools.combinations(cs, 2):
                if not a.mono and c1["famille"] == c2["famille"]:
                    continue
                s1, s2 = sg[c1["motif"]], sg[c2["motif"]]
                m1 = s1[1] if sens > 0 else s1[2]
                m2 = s2[1] if sens > 0 else s2[2]
                ix = np.flatnonzero(m1 & m2)
                ix = ix[ix < len(b) - P.HOLD - 1]
                if len(ix) < 60:
                    continue
                mo = mesure_geo(b, ix, sens, cout_atr)
                if not mo or "stop1.0,rr1.0" not in mo:
                    continue
                g = mo["stop1.0,rr1.0"]
                res.append(dict(paire=p, sens=cle, cout_atr=cout_atr,
                                a=c1["motif"], fa=c1["famille"],
                                b=c2["motif"], fb=c2["famille"],
                                nA_comp=[c1["nA"], c2["nA"]], nB_comp=[c1["nB"], c2["nB"]],
                                socle=min(g[2], g[3]),
                                **{k: v for k, v in mo.items()}))
                n_ok += 1
        print("%-8s %3d combinaisons mesurees" % (p, n_ok), flush=True)

    with OUT.open("a", encoding="utf-8") as f:
        for r in res:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    res = [r for r in res if "stop1.0,rr1.0" in r]
    res.sort(key=lambda r: -r["socle"])
    print("\n=== TOP combinaisons (socle = min(netA,netB) en stop1/rr1) ===")
    print("%-8s %-4s %-6s %-22s %-22s %7s %7s %7s %6s %6s"
          % ("paire", "sens", "n", "motif1", "motif2", "netA", "netB", "socle",
             "mfeC", "mae"))
    for r in res[:30]:
        g = r["stop1.0,rr1.0"]
        print("%-8s %-4s %-6d %-22s %-22s %7.4f %7.4f %7.4f %6.2f %6.2f"
              % (r["paire"], r["sens"], r["n"], r["a"][:22], r["b"][:22],
                 g[2], g[3], r["socle"], r["mfe_cond"] or -99, r["mae"]))
    # familles qui se combinent le mieux
    par_type = {}
    for r in res:
        k = tuple(sorted((r["fa"], r["fb"]))) + (r["sens"],)
        par_type.setdefault(k, []).append(r["socle"])
    print("\n=== types de combinaison (moyenne des socles, >=2 mesures) ===")
    for k, v in sorted(par_type.items(), key=lambda kv: -np.mean(kv[1])):
        if len(v) >= 2:
            print("%-28s %-2s n=%3d moy %+.4f  max %+.4f"
                  % ("+".join(k[:2]), k[2], len(v), float(np.mean(v)),
                     float(np.max(v))))


if __name__ == "__main__":
    main()
