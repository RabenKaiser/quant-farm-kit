# -*- coding: utf-8 -*-
"""BOOTSTRAP PAR BLOCS sur la courbe PTRAIL réelle (33 mois).
Le DD observé (-42%) est UN chemin. Le bootstrap donne la DISTRIBUTION du DD :
médiane, p75, p95. On dimensionne sur p95 (jamais sur l'observé — leçon edge_6E).
Puis : sizing optimisé (risque plus élevé) avec le vrai DD de référence."""
import json
import numpy as np

curve = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\night_results\ptrail_curve.json"))
pnl = np.array([p for ym, p, e, d in curve["curve"]])
months = [f"{ym[0]}-{ym[1].split('.')[1]}" for ym, p, e, d in curve["curve"]]
n = len(pnl)
print(f"courbe : {n} mois, total ${pnl.sum():+,.0f}")

# --- bootstrap par blocs (12 mois, conserve autocorrélation) ---
rng = np.random.default_rng(7)
bloc = 12
nblocs = n // bloc
blocs = [pnl[i*bloc:(i+1)*bloc] for i in range(nblocs)]
print(f"blocs de {bloc} mois : {len(blocs)}")

def max_dd(series):
    eq = np.cumsum(series)
    peak = np.maximum.accumulate(eq)
    return float((eq - peak).min())

dd_obs = max_dd(pnl)
T = 5000
dds = []
totals = []
for _ in range(T):
    # ré-échantillonner les blocs avec remise, même longueur totale
    idx = rng.integers(0, len(blocs), len(blocs))
    samp = np.concatenate([blocs[i] for i in idx])[:n]
    dds.append(max_dd(samp))
    totals.append(samp.sum())
dds = np.array(dds); totals = np.array(totals)

print(f"\n=== DD OBSERVÉ vs DISTRIBUTION BOOTSTRAP ===")
print(f"DD observé (2024 H1)      : {dd_obs:+,.0f}$ ({abs(dd_obs)/10000*100:.1f}%)")
for q, label in [(50, "médiane"), (75, "p75"), (90, "p90"), (95, "p95")]:
    v = np.percentile(dds, q)
    print(f"DD bootstrap {label:8s} : {v:+,.0f}$ ({abs(v)/10000*100:.1f}%)")
print(f"\nP(DD > observé) = {(dds < dd_obs).mean():.2f}  -> l'observé est "
      f"{'PESSIMISTE' if (dds < dd_obs).mean() < 0.5 else 'OPTIMISTE'}")

# total bootstrap
print(f"\nTotal bootstrap médian : {np.median(totals):+,.0f}$")

# --- sizing sur p95 du DD (le bon réflexe) ---
print(f"\n=== SIZING OPTIMISÉ (dimensionner sur p95, pas sur l'observé) ===")
dd_p95 = abs(np.percentile(dds, 95))
dd_obs_abs = abs(dd_obs)
print(f"DD de référence p95 : {dd_p95:.0f}$ ({dd_p95/10000*100:.1f}%)  [au lieu de l'observé {dd_obs_abs/10000*100:.1f}%]")
print(f"Gain de risque possible : x{dd_obs_abs/dd_p95:.2f} par rapport au sizing sur l'observé")

# avec le filtre (DD 42 -> 33%) et la diversification (corr -0.41 -> ~-25%->-20%)
print(f"\n=== SCÉNARIOS (le DD de référence change tout) ===")
scenarios = [
    ("Conservateur (DD obs 42%)", 42, 3.98),
    ("Filtre seul (33%)", 33, 3.94),
    ("Filtre + indices (25%)", 25, 3.5),
    ("Filtre + indices + shorts (20%)", 20, 3.5),
]
for name, dd, ret in scenarios:
    print(f"\n  {name} : DD {dd}%, rendement {ret:.2f}%/mois à risque 0.5%")
    for dd_lim in [5, 8, 10]:
        factor = (dd_lim * 0.7) / dd
        risk = 0.5 * factor
        avg = ret * factor
        print(f"    Prop {dd_lim}% : risque {risk:.3f}% -> {avg:+.2f}%/mois, +8% en {8/avg:.0f} mois, "
              f"+100% en {100/avg:.0f} mois")

json.dump({"dd_obs": dd_obs, "dd_p95": float(np.percentile(dds, 95)),
           "dd_med": float(np.percentile(dds, 50))},
          open(r"C:\EAFarm\HISTORY - Copy\research\night_results\bootstrap_dd.json", "w"))
print("\nsauvé: bootstrap_dd.json")
