# -*- coding: utf-8 -*-
r"""deux_voies.py -- DEUX VOIES DE FRONT, EN PARALLELE (demande utilisateur 10/14).

  VOIE A (ferme, ordres reels) : la boucle de nuit. Elle tient le terminal
      Dukascopy occupe en campagnes WFO. C'est la voie LENTE et CHERE.
  VOIE B (corpus, python) : le triage en echelle (trimestre -> trimestre ->
      annee). Pure lecture de CSV, aucun terminal, aucun conflit avec la voie A.
      C'est la voie RAPIDE : ~90 s par idee.

POURQUOI DEUX VOIES. La voie A met ~17 min par campagne ; la voie B met ~90 s
par idee. Les faire tourner ensemble multiplie le debit de l'atelier : la voie
B tue ou confirme des idees pendant que la voie A paye les ordres reels des
idees DEJA confirmees. Une seule regle : la voie B ne consomme JAMAIS les deux
terminaux ni les fenetres de holdout ; la voie A reste seule maitresse du farm.

Ce superviseur :
  - verifie que la boucle de nuit vit (voie A) et la relance si elle est morte ;
  - enchaine les idees de TRIAGE_IDEES.json non encore triees (voie B) ;
  - tient un journal commun DEUX_VOIES.log et s'arrete proprement.

USAGE :
  python deux_voies.py            -> superviseur (tourne en fond)
  python deux_voies.py --etat     -> etat des deux voies, puis sort
"""
import json
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
SCRIPTS = BASE / "SCRIPTS"
LOG = BASE / "DEUX_VOIES.log"
IDEE_LOG = BASE / "TRIAGE_IDEES_FAITES.json"
BOUCLE = SCRIPTS / "boucle_nuit.py"
TRIAGE = SCRIPTS / "triage.py"
IDEE_JSON = BASE / "TRIAGE_IDEES.json"


def log(msg):
    ligne = "%s %s" % (datetime.now().strftime("%H:%M:%S"), msg)
    print(ligne, flush=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(ligne + "\n")


def boucle_vivante():
    """La voie A vit-elle ? On cherche un python qui execute boucle_nuit.py."""
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
             "Where-Object {$_.CommandLine -like '*boucle_nuit*'} | "
             "Select-Object -ExpandProperty ProcessId"],
            capture_output=True, text=True, timeout=60)
        return bool(out.stdout.strip())
    except Exception as e:
        log("voie A : lecture des processus impossible (%s)" % e)
        return False


def relance_boucle():
    log("voie A : boucle absente -> relance")
    with open(BASE / "boucle_superviseur.log", "ab") as f:
        subprocess.Popen([sys.executable, "-X", "utf8", "-u", str(BOUCLE)],
                         cwd=str(BASE), stdout=f, stderr=subprocess.STDOUT)


def idees_restantes():
    if not IDEE_JSON.exists():
        return []
    d = json.loads(IDEE_JSON.read_text(encoding="utf-8"))
    faites = set()
    if IDEE_LOG.exists():
        try:
            faites = set(json.loads(IDEE_LOG.read_text(encoding="utf-8")))
        except ValueError:
            faites = set()
    return [x["nom"] for x in d.get("idees", []) if x["nom"] not in faites], faites


def marque_faite(nom, faites):
    faites.add(nom)
    IDEE_LOG.write_text(json.dumps(sorted(faites), indent=1), encoding="utf-8")


def voie_b(noms):
    """Une passe de triage (voie B) : ~90 s par idee, aucun terminal."""
    if not noms:
        return
    log("voie B : triage de %d idee(s) : %s" % (len(noms), ", ".join(noms)))
    with open(BASE / "triage_lane.log", "a", encoding="utf-8") as f:
        f.write("\n==== %s ====\n" % datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        f.flush()
        subprocess.run([sys.executable, "-X", "utf8", "-u", str(TRIAGE), ",".join(noms)],
                       cwd=str(BASE), stdout=f, stderr=subprocess.STDOUT)
    log("voie B : passe terminee -> triage_lane.log")


def etat():
    noms, faites = idees_restantes()
    log("=== ETAT DES DEUX VOIES ===")
    log("voie A (farm)     : %s" % ("VIVANTE" if boucle_vivante() else "MORTE"))
    log("voie B (triage)   : %d idee(s) en attente, %d faite(s)" % (len(noms), len(faites)))
    if noms:
        log("   en attente : %s" % ", ".join(noms))


def main():
    if "--etat" in sys.argv:
        etat()
        return
    log("=== DEMARRAGE DU SUPERVISEUR DEUX VOIES ===")
    tours = 0
    while True:
        tours += 1
        if not boucle_vivante():
            relance_boucle()
        noms, faites = idees_restantes()
        if noms:
            voie_b(noms)
            for n in noms:
                marque_faite(n, faites)
        else:
            log("voie B : aucune idee en attente (ajouter dans TRIAGE_IDEES.json)")
        etat()
        # la voie A met 15-20 min par campagne : on repasse toutes les 10 min
        time.sleep(600)


if __name__ == "__main__":
    main()