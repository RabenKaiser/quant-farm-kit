﻿import sys, numpy as np, gc
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT
G._cache.clear(); gc.collect()
F = G.get_frames("CADJPY"); m5,m1=F["m5"],F["m1"]
h1z,hh,ll,a1,gb,gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd,zlo,zhi = MT.project(m5.index,h1z,hh,ll,gb,gr,max_age_h=48)
M = NL.build(m5,F,zd,zlo,zhi); M.update(FE.more(m5,F,m1))
print(f"  python bb_low : {100*np.asarray(M['bb_low']).mean():.2f} %")
print(f"  MQL5   BBLOW  : 5.81 % (mesure precedente sur XAUUSD, a refaire sur CADJPY)")
print()
print("Le produit attendu : 0.0315 * 0.0581 = 0.18 % des barres = ~680 barres")
print("Or python n'a que 208 signaux (0.055 %). Donc les deux conditions sont")
print("FORTEMENT anti-correlees : VWAPXUP et BBLOW ne coincident presque jamais.")
print()
print("MT5, avec les MEMES taux, devrait donner ~680. Il en donne 495 en")
print("ENTREES (pas en barres). L'ecart vient de la duree de detention :")
print("hold=960 barres = 80 h. Python bloque 960 barres apres chaque entree.")
print("Si l'EA ferme plus tot (SL), elle peut re-entrer plus souvent.")
