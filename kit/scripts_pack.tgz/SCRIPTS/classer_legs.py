"""classer_legs : la table unique des candidats, tous cribles confondus.

Round 473. Les cribles se sont multiplies (26 paires d'origine, corpus etendu, plages 20/50/100, cibles
1 a 5 R, trois filtres de contexte). Chacun a son CSV. Ce script les rassemble en UNE seule table classee
par **apport de chemin theta = mu^2 x n / sigma^2 par an**, avec les deux contraintes de l'objectif :

  - attendu > 0 (le corpus moins la decote de la CLASSE d'instrument, mesuree sur ordres reels) ;
  - au moins 2/3 des annees positives (« un reglage qui ne vit que sur une annee est ecarte »).

Il marque aussi les couples deja MESURES en ordres reels (reel_empile.COMPOS) et ceux dont le symbole
n'est pas negociable sur le feed (DOLLAR.IDX sans historique avant 2025) : une table de candidats qui
ignore ces deux faits propose des campagnes impossibles.

Usage : python SCRIPTS\\classer_legs.py
Sortie : CANDIDATS.md
"""
import csv
import os
import re
from pathlib import Path

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
FICHIERS = ["CRIBLE_PAYOFF.csv", "CRIBLE_PAYOFF_EXT.csv",
            "CRIBLE_EXT_R20.csv", "CRIBLE_EXT_R50.csv", "CRIBLE_EXT_R100.csv",
            "CRIBLE_TPR1.csv", "CRIBLE_VWAP_TF.csv", "CRIBLE_VWAP_MTF_SLR3.csv"]
# Symboles NON negociables : historique trop court sur le feed (constate au round 467).
NON_NEGOCIABLES = {"DOLLAR.IDX", "UDXUSD"}
# Noms du courtier et noms de corpus (pour marquer ce qui est deja mesure en reel).
ALIAS = {"USA500.IDX": "SPXUSD", "USATECH.IDX": "NSXUSD", "DOLLAR.IDX": "UDXUSD"}


def deja_mesures():
    """Couples mesures en ordres reels, lus dans reel_empile.COMPOS."""
    src = (B / "SCRIPTS" / "reel_empile.py").read_text(encoding="utf-8", errors="replace")
    bloc = src[src.index("COMPOS = ["):src.index("]", src.index("COMPOS = ["))]
    # groupes : 1 = paire, 2 = plage, 3 = sens (le motif de la ligne de jeu n'est pas capture).
    return {(m.group(1), int(m.group(2)), m.group(3))
            for m in re.finditer(r'\("([A-Z0-9.]+)", "[A-Z0-9]+", (\d+), "([SL])"\)', bloc)}


def charge():
    lignes = []
    for nom in FICHIERS:
        f = B / nom
        if not f.exists():
            continue
        with f.open(encoding="utf-8") as fh:
            r = csv.DictReader(fh)
            for x in r:
                try:
                    n = int(x["n"])
                    att = float(x["attendu"]) if "attendu" in x else float(x["R"]) - float(x["cout"])
                    sig = float(x["sigma"])
                    npos, nan = int(x["npos"]), int(x["nan"])
                except (KeyError, ValueError):
                    continue
                if sig <= 0 or n < 20:
                    continue
                tpr = x.get("tpr") or x.get("TPR") or "?"
                lignes.append(dict(paire=x["paire"], sens=x.get("sens", x.get("s", "?")),
                                   tpr=float(tpr) if tpr not in ("?", "") else float(x.get("range", 3) or 3),
                                   n=n, attendu=att, sigma=sig, mus2=float(x.get("mus2", x.get("R", 0))) if x.get("mus2") else att / sig ** 2,
                                   cout=float(x.get("cout", 0) or 0), npos=npos, nan=nan,
                                   source=nom, famille=x.get("famille", x.get("ligne", "?"))))
    return lignes


def main():
    deja = deja_mesures()
    lignes = charge()
    for x in lignes:
        x["annees_ok"] = x["npos"] >= (2.0 / 3.0) * x["nan"]
        x["theta"] = max(x["attendu"], 0.0) ** 2 * x["n"] / x["sigma"] ** 2 / 6.0
        x["deja"] = (x["paire"], int(x["tpr"]), x["sens"]) in deja or \
                    (ALIAS.get(x["paire"], x["paire"]), int(x["tpr"]), x["sens"]) in deja
        x["negociable"] = x["paire"] not in NON_NEGOCIABLES
        x["R"] = x["tpr"] / 3.0 if x["tpr"] > 1.5 else x["tpr"]

    gardes = [x for x in lignes if x["attendu"] > 0 and x["annees_ok"] and x["negociable"]]
    neufs = [x for x in gardes if not x["deja"]]
    print("%d mesures lues | %d retenues | %d deja mesurees en reel | %d NEUVES negociables"
          % (len(lignes), len(gardes), len(gardes) - len(neufs), len(neufs)))
    print("\n%-10s %-6s %3s %5s %8s %8s %8s %8s  %s" %
          ("paire", "famille", "R", "n", "attendu", "sigma", "theta", "annees", "source"))
    top = sorted(neufs, key=lambda z: -z["theta"])[:28]
    for x in top:
        print("%-10s %-6s %3.1f %5d %+8.4f %8.2f %8.3f %5d/%d  %s"
              % (x["paire"], x["famille"][:6], x["R"], x["n"], x["attendu"], x["sigma"],
                 x["theta"], x["npos"], x["nan"], x["source"].replace("CRIBLE_", "").replace(".csv", "")))
    with (B / "CANDIDATS.md").open("w", encoding="utf-8") as f:
        f.write("# Candidats classes par apport de chemin (theta = mu^2 x n / sigma^2 par an)\n\n")
        f.write("Filtres : attendu > 0 apres decote de la CLASSE d'instrument, au moins 2/3 des annees "
                "positives, symbole negociable sur le feed, et couple pas encore mesure en ordres reels.\n\n")
        f.write("| paire | famille | cible | n | attendu | sigma | theta | annees | source |\n")
        f.write("|---|---|---|---|---|---|---|---|---|\n")
        for x in sorted(neufs, key=lambda z: -z["theta"]):
            f.write("| %s | %s | %.1f R | %d | %+.4f | %.2f | %.3f | %d/%d | %s |\n"
                    % (x["paire"], x["famille"], x["R"], x["n"], x["attendu"], x["sigma"],
                       x["theta"], x["npos"], x["nan"], x["source"]))
        f.write("\n## Total\n\n%d couples neufs, theta cumule %.1f/an\n"
                % (len(neufs), sum(x["theta"] for x in neufs)))
    print("\n  -> CANDIDATS.md (%d couples, theta cumule %.1f/an)" % (len(neufs), sum(x["theta"] for x in neufs)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
