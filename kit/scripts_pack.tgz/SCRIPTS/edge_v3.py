﻿"""Edge research v3 â€” additional families at M15 + US100 deeper.

Families:
  range_break: close breaks N-bar range high/low (continuation)
  range_fade:  fade N-bar range extreme (mean reversion)
  mom:         momentum: |ret over N bars| > thr, follow direction
  mom_rev:     fade momentum extremes
  ofi at M15:  ofi_cont/ofi_rev on M15 bars
Same protocol: entry next bar open, SL/TP atr-based, cost=spread+slippage,
same-sign across segments.
"""
import polars as pl
import numpy as np
import sys, json
from pathlib import Path

RESEARCH = Path(r"C:\EAFarm\HISTORY - Copy\research")
BARS = RESEARCH / "bars"
POINT = {"EURUSD": 0.00001, "USDJPY": 0.001, "EURCAD": 0.00001, "USATECHIDXUSD": 0.001}

def load_m1(sym):
    p = BARS / f"{sym}_M1_signed.parquet"
    if not p.exists():
        p = BARS / f"{sym}_M1.parquet"
    return pl.read_parquet(p).sort("time")

def to_tf(m1, tf_sec):
    return (
        m1.with_columns((pl.col("time") // tf_sec * tf_sec).alias("t"))
        .group_by("t")
        .agg(
            pl.col("bid_o").first().alias("bid_o"),
            pl.col("bid_h").max().alias("bid_h"),
            pl.col("bid_l").min().alias("bid_l"),
            pl.col("bid_c").last().alias("bid_c"),
            pl.col("ask_o").first().alias("ask_o"),
            pl.col("vol_up").sum().alias("vol_up"),
            pl.col("vol_down").sum().alias("vol_down"),
            pl.col("n_ticks").sum().alias("n_ticks"),
            pl.col("spread_med").median().alias("spread_med"),
        )
        .rename({"t": "time"})
        .sort("time")
    )

def seg_of(df):
    tmin = df["time"].min()
    tmax = df["time"].max()
    span = tmax - tmin
    if span > 550 * 86400:
        b1, b2 = tmin + span / 3, tmin + 2 * span / 3
    else:
        b1, b2 = tmin + span / 2, None
    out = df.with_columns(pl.col("time").cast(pl.Int64).alias("ts")).with_columns(
        pl.when(pl.col("ts") < b1).then(pl.lit("IS-1"))
        .when((pl.col("ts") < b2) if b2 else pl.lit(True)).then(pl.lit("IS-2"))
        .otherwise(pl.lit("OOS")).alias("seg")
    )
    return out

def features(tf, w, lookback):
    return (
        tf.with_columns(
            ((pl.col("vol_up") - pl.col("vol_down")) / (pl.col("vol_up") + pl.col("vol_down"))).alias("sfi_bar"),
            (pl.col("bid_h") - pl.col("bid_l")).alias("rng"),
            (pl.col("bid_c") - pl.col("bid_c").shift(lookback)).alias("mom"),
        )
        .with_columns(
            pl.col("sfi_bar").rolling_mean(w).shift(1).alias("sfi_w"),
            pl.col("rng").rolling_mean(14).shift(1).alias("atr"),
            pl.col("bid_h").rolling_max(lookback).shift(1).alias("hh"),
            pl.col("bid_l").rolling_min(lookback).shift(1).alias("ll"),
        )
        .with_columns(
            pl.col("time").cast(pl.Int64).alias("ts"),
            ((pl.col("time") % 86400) // 3600).cast(pl.Int64).alias("hr"),
        )
    )

def run_signal(df, sym, kind, cfg):
    pt = POINT[sym]
    w = cfg.get("w", 6)
    lb = cfg.get("lookback", 20)
    f = features(df, w, lb)
    if cfg.get("session"):
        f = f.filter((pl.col("hr") >= cfg["session"][0]) & (pl.col("hr") <= cfg["session"][1]))
    if cfg.get("spread_max_pts"):
        f = f.filter(pl.col("spread_med") / pt <= cfg["spread_max_pts"])

    thr = cfg.get("thr", 0.2)
    if kind == "ofi_cont":
        sig = (f["sfi_w"] > thr).cast(pl.Int8) - (f["sfi_w"] < -thr).cast(pl.Int8)
    elif kind == "ofi_rev":
        sig = (f["sfi_w"] < -thr).cast(pl.Int8) - (f["sfi_w"] > thr).cast(pl.Int8)
    elif kind == "range_break":
        sig = (f["bid_c"] > f["hh"]).cast(pl.Int8) - (f["bid_c"] < f["ll"]).cast(pl.Int8)
    elif kind == "range_fade":
        sig = (f["bid_c"] < f["ll"]).cast(pl.Int8) - (f["bid_c"] > f["hh"]).cast(pl.Int8)
    elif kind == "mom":
        sig = (f["mom"] > 0).cast(pl.Int8) - (f["mom"] < 0).cast(pl.Int8)
        # strength filter: only strong momentum
        atr0 = f["atr"]
        sig = ((f["mom"] > thr * atr0).cast(pl.Int8) - (f["mom"] < -thr * atr0).cast(pl.Int8))
    elif kind == "mom_rev":
        sig = ((f["mom"] < -thr * f["atr"]).cast(pl.Int8) - (f["mom"] > thr * f["atr"]).cast(pl.Int8))
    else:
        raise ValueError(kind)
    f = f.with_columns(pl.Series("sig", sig).fill_null(0))

    bid_o_n = f["bid_o"].shift(-1).to_numpy()
    ask_o_n = f["ask_o"].shift(-1).to_numpy()
    bid_c = f["bid_c"].to_numpy()
    bid_h = f["bid_h"].to_numpy()
    bid_l = f["bid_l"].to_numpy()
    atr = f["atr"].to_numpy()
    sigs = f["sig"].to_numpy()
    ts_arr = f["ts"].to_numpy()
    spread_arr = (f["spread_med"] / pt).to_numpy()

    sl_atr = cfg.get("sl_atr", 2.0)
    rr = cfg.get("rr", 2.0)
    n = len(f)
    trades = []
    for i in range(n - 1):
        s = int(sigs[i])
        if s == 0 or np.isnan(atr[i]) or atr[i] <= 0:
            continue
        sl_pts = sl_atr * atr[i] / pt
        tp_pts = rr * sl_pts
        entry = ask_o_n[i] if s == 1 else bid_o_n[i]
        if np.isnan(entry):
            continue
        hb, lb = bid_h[i + 1], bid_l[i + 1]
        if s == 1:
            sl_px, tp_px = entry - sl_pts * pt, entry + tp_pts * pt
            r = -1.0 if lb <= sl_px else (rr if hb >= tp_px else (bid_c[i + 1] - entry) / (sl_pts * pt))
        else:
            sl_px, tp_px = entry + sl_pts * pt, entry - tp_pts * pt
            r = -1.0 if hb >= sl_px else (rr if lb <= tp_px else (entry - bid_c[i + 1]) / (sl_pts * pt))
        cost_pts = spread_arr[i] + cfg.get("slippage_pts", 0.5)
        trades.append({"ts": int(ts_arr[i + 1]), "r": r, "cost_r": cost_pts / sl_pts, "sl": sl_pts})

    if not trades:
        return {"n": 0}
    res = pl.DataFrame(trades).with_columns((pl.col("r") - pl.col("cost_r")).alias("net"))
    n_t = len(res)
    gross = float(res["r"].mean())
    net = float(res["net"].mean())
    wr = float((res["r"] > 0).mean()) * 100
    std = float(res["net"].std()) if res["net"].std() is not None else 0.0
    t = net / (std / np.sqrt(n_t)) if std and std > 0 else 0.0
    return {"n": n_t, "gross": round(gross, 4), "net": round(net, 4),
            "wr": round(wr, 1), "t": round(t, 2), "sl": round(float(res["sl"].median()), 1)}

def grid(sym, tf_sec=900, kinds=("range_break", "range_fade", "mom", "mom_rev", "ofi_cont", "ofi_rev")):
    m1 = load_m1(sym)
    tf = to_tf(m1, tf_sec)
    df = seg_of(tf)
    seg_names = [s for s in ["IS-1", "IS-2", "OOS"] if s in set(df["seg"].to_list())]
    segs = {s: df.filter(pl.col("seg") == s) for s in seg_names}
    print(f"{sym} M{tf_sec//60}: M1={len(m1)} bars={len(tf)} segs=" + str({s: len(segs[s]) for s in seg_names}))

    results = []
    for kind in kinds:
        for w in [6, 12]:
            for lb in [10, 20, 40]:
                for sl_atr in [1.5, 2.5, 4.0]:
                    for rr in [1.5, 2.5, 4.0]:
                        for sess in [(7, 19), None]:
                            cfg = {"w": w, "lookback": lb, "thr": 0.15, "sl_atr": sl_atr,
                                   "rr": rr, "session": sess, "slippage_pts": 0.5}
                            row = {"cfg": cfg}
                            ok = True
                            for sname, seg in segs.items():
                                r = run_signal(seg, sym, kind, cfg)
                                row[sname] = r
                                if r["n"] < 15:
                                    ok = False
                            if not ok:
                                continue
                            evs = [row[s]["net"] for s in seg_names]
                            if all(e > 0 for e in evs) or all(e < 0 for e in evs):
                                row["_sign"] = "ALL+" if evs[0] > 0 else "ALL-"
                                row["_mean"] = round(sum(evs) / len(evs), 4)
                                row["_total_n"] = sum(row[s]["n"] for s in seg_names)
                                row["kind"] = kind
                                results.append(row)
    results.sort(key=lambda r: r.get("_mean", -9), reverse=True)
    return results, seg_names

if __name__ == "__main__":
    sym = sys.argv[1] if len(sys.argv) > 1 else "EURUSD"
    tf = int(sys.argv[2]) if len(sys.argv) > 2 else 900
    res, seg_names = grid(sym, tf_sec=tf)
    print(f"\n=== {sym} M{tf//60}: same-sign configs ===")
    for r in res[:25]:
        c = r["cfg"]
        print(f"  {r.get('kind'):10s} w={c['w']} lb={c['lookback']} sl={c['sl_atr']} rr={c['rr']} sess={c['session']} "
              f"sign={r.get('_sign')} mean={r.get('_mean')} totalN={r.get('_total_n')}")
        for s in seg_names:
            x = r[s]
            print(f"    {s}: n={x['n']} gross={x['gross']} net={x['net']} wr={x['wr']}% t={x['t']} sl={x['sl']}pt")
    out = RESEARCH / f"grid3_{sym}_M{tf//60}.json"
    out.write_text(json.dumps(res, indent=1, default=str))
    print(f"saved -> {out}")
