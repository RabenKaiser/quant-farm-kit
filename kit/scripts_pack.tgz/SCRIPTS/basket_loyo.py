"""basket_loyo : la composition retenue survit-elle a l'annee qu'on lui cache ?

Round 463. Le choix glouton donne six jambes, +0,64 %/mois a drawdown 5 % et pire annee +2,54 %. Mais
ce panier a ete CHOISI sur les memes transactions qui servent a le juger : c'est exactement le piege que
l'objectif interdit (« un reglage qui ne vit que sur une annee est ecarte »). On refait donc la procedure
en aveugle : pour chaque annee Y, on choisit geometrie ET panier sur TOUTES les autres annees, puis on
mesure l'annee Y avec le risque calcule hors Y. La courbe ainsi recoltee est OOS de bout en bout -- c'est
le seul chiffre qui compte pour juger la PROCEDURE de selection.

Usage : python SCRIPTS\\basket_loyo.py
"""
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import choix_basket as CB  # noqa: E402

MIN_N = 40  # minimum de transactions dans l'echantillon d'apprentissage pour oser choisir une jambe.
# ROUND 463 : un plancher de 250 avait ete essaye d'abord -- il ne restait AUCUNE jambe candidate, les
# jambes reelles valant de 67 a 255 transactions sur cinq ans. Le plancher doit etre petit devant la
# taille d'une jambe, pas devant celle du portefeuille.
RISQUE_MAX = float(os.environ.get("RISQUE_MAX", "1.0")) / 100.0
# ROUND 463 : premiere execution SANS plafond de risque -- un pli a retenu UNE seule jambe et lui a
# attribue 6,75 % par transaction (le drawdown d'une jambe unique est minuscule, donc le solveur monte
# le risque jusqu'a l'absurde). Un plafond est une contrainte de la regle prop, pas un confort : on le
# pose avant de juger la procedure.
RISQUE_FIXE = float(os.environ.get("RISQUE_FIXE", "0.4")) / 100.0


def budget_cape(ser, budget=CB.BUDGET):
    """Comme CB.a_budget, mais le risque par transaction ne depasse pas RISQUE_MAX."""
    r, rm, pa, dd, ok = CB.a_budget(ser, budget)
    if r > RISQUE_MAX:
        r = RISQUE_MAX
        dd, rm, pa = CB.courbe(ser, r)
    return r, rm, pa, dd


def annees(cache):
    return sorted({t.year for s in cache.values() for t, _, _ in s})


def candidats(cache, jambes, sans):
    """(geometrie, serie) par jambe, geometrie choisie sur les transactions HORS annee `sans`."""
    out = {}
    for paire, ligne, range_, sens in jambes:
        cds = {}
        for g in CB.GEOM:
            s = cache.get((paire, ligne, range_, sens, g))
            if not s:
                continue
            app = [x for x in s if x[0].year != sans]
            if len(app) >= 20:
                cds[g] = (s, CB.stats(app), app)
        if not cds:
            continue
        ok = {g: v for g, v in cds.items() if v[1]["npos"] >= (2 * v[1]["nan"]) / 3.0 and v[1]["mu"] > 0}
        g = max(ok, key=lambda k: ok[k][1]["mus2"]) if ok else max(cds, key=lambda k: cds[k][1]["mus2"])
        if cds[g][1]["n"] >= MIN_N:
            out[(paire, ligne, range_, sens)] = (g, cds[g][0])
    return out


def glouton(cands, annee_cible):
    """Panier choisi par rendement mensuel a budget de drawdown constant, sur les annees hors `annee_cible`."""
    def compo(noms):
        return [x for n in noms for x in cands[n][1] if x[0].year != annee_cible]

    sel, reste = [], list(cands)
    base = -9.9
    while reste:
        essais = []
        for n in reste:
            s = compo(sel + [n])
            r, rm, pa, dd = budget_cape(s)
            essais.append((rm, n))
        rm, n = max(essais)
        if rm <= base:
            break
        sel.append(n)
        reste.remove(n)
        base = rm
    return sel


def main():
    cache = CB.charge()
    jambes = [(p, l, r, s) for p, l, r, s in CB.JAMBES
              if any((p, l, r, s, g) in cache for g in CB.GEOM)]
    print("=== VALIDATION CROISEE PAR ANNEE (selection et geometrie choisies HORS de l'annee mesuree) ===")
    print("%6s %5s %8s %9s %9s  %s" % ("annee", "tx", "risque", "R annee", "compo", "jambes retenues"))
    oos, gardes = [], []
    for y in annees(cache):
        cands = candidats(cache, jambes, y)
        sel = glouton(cands, y)
        if not sel:
            print("%6d  aucun panier" % y)
            continue
        r, _, _, _, _ = CB.a_budget([x for n in sel for x in cands[n][1] if x[0].year != y])
        an = [x for n in sel for x in cands[n][1] if x[0].year == y]
        if not an:
            print("%6d  aucune transaction sur l'annee" % y)
            continue
        _, rm_an, _ = CB.courbe(an, r)
        oos += [(0.0, r * x, 0) for _, x, _ in an]
        gardes.append((y, r, an, rm_an))
        print("%6d %5d %7.3f %% %+8.2f %% %9s  %s" %
              (y, len(an), 100 * r, 100 * rm_an,
               "%.3f" % 0, ", ".join("%s r=%d %s (cible %g)" % (p, rr, s, cands[(p, l, rr, s)][0])
                                     for p, l, rr, s in sel)), flush=True)
    if not oos:
        print("  aucune annee hors echantillon")
        return 1
    # courbe OOS recollee : chaque annee avec SON panier et SON risque
    cap, pic, dd, mois = 1.0, 1.0, 0.0, defaultdict(float)
    courbe = []
    for y, r, an, _ in gardes:
        s = sorted(an, key=lambda z: z[0])
        for t, x, _ in s:
            g = r * x
            cap *= (1 + g)
            pic = max(pic, cap)
            dd = max(dd, (pic - cap) / pic)
            mois[(t.year, t.month)] += g
            courbe.append((t, cap))
    an = defaultdict(float)
    for y, r, a, _ in gardes:
        for _, x, _ in a:
            an[y] += r * x
    print("\n=== COURBE OOS RECOLLEE (chaque annee avec le panier choisi sans elle) ===")
    print("  %d transactions | R/mois %+.2f %% | drawdown %.2f %% | pire annee %+.2f %%"
          % (sum(len(a) for _, _, a, _ in gardes), 100 * float(np.mean(list(mois.values()))),
             100 * dd, 100 * min(an.values())))
    print("  comparaison : meme mesure EN ECHANTILLON (panier glouton complet) = +0,64 %/mois, pire annee +2,54 %")
    return 0


def mode_fixe():
    """AUCUNE selection : toutes les jambes reelles, risque fixe. Le panier ne peut pas etre surajuste
    puisqu'il n'est pas choisi -- il ne reste que le choix de geometrie, fait hors de l'annee mesuree."""
    cache = CB.charge()
    jambes = [(p, l, r, s) for p, l, r, s in CB.JAMBES
              if any((p, l, r, s, g) in cache for g in CB.GEOM)]
    print("=== AUCUNE SELECTION : toutes les jambes reelles a %.2f %% de risque, geometrie choisie HORS annee ==="
          % (100 * RISQUE_FIXE))
    tot, annee = [], defaultdict(float)
    for y in annees(cache):
        cands = candidats(cache, jambes, y)
        if not cands:
            continue
        an = [x for n in cands for x in cands[n][1] if x[0].year == y]
        if not an:
            continue
        _, rm, pa = CB.courbe(an, RISQUE_FIXE)
        annee[y] = pa
        tot += [(t, RISQUE_FIXE * x, 0) for t, x, _ in an]
        print("  %d : %4d tx | R annee %+7.2f %% | %d jambes actives"
              % (y, len(an), 100 * pa, len({n for n in cands if any(x[0].year == y for x in cands[n][1])})),
              flush=True)
    if not tot:
        print("  aucune annee")
        return 1
    cap, pic, dd, mois = 1.0, 1.0, 0.0, defaultdict(float)
    for t, x, _ in sorted(tot, key=lambda z: z[0]):
        cap *= (1 + x)
        pic = max(pic, cap)
        dd = max(dd, (pic - cap) / pic)
        mois[(t.year, t.month)] += x
    print("  TOUTES ANNEES : %d tx | R/mois %+.2f %% | drawdown %.2f %% | pire annee %+.2f %%"
          % (len(tot), 100 * float(np.mean(list(mois.values()))), 100 * dd, 100 * min(annee.values())))
    return 0


if __name__ == "__main__":
    if "--fixe" in sys.argv:
        sys.exit(mode_fixe())
    sys.exit(main())
