# -*- coding: utf-8 -*-
r"""classif_cause2.py -- DICTIONNAIRE DES TRANSITIONS v2 (10/13 20 h).

Suite de classif_cause.py (le lag ~30 h est prouve) :
  1. Run sur TOUTES les paires (pas seulement EURUSD) ;
  2. Aggregation par transition : lift moyen par variable (le multi-feed
     du dictionnaire : un predicteur qui ne tient que sur une paire n'est
     pas un predicteur) ;
  3. PREDICTEUR COMPOSE : score = somme des (lift-1) signes selon le
     quantile. On mesure son AVANCE de detection : combien de barres avant
     la transition le score passe-t-il son seuil, mediane par transition ;
  4. Verdict : si l'avance >= 8 h (16 barres M30), le predicteur devient
     candidat FILTRE BIAS MQL5.
"""
import os
import sys
from collections import defaultdict

import numpy as np
import pandas as pd

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parent))
import nuit_motifs as NM
from classif_m5 import er, adx_like, z_prix, pentes
import classif_m5_v2 as V2
from classif_cause import variables, transitions, quantile_table

JAMBES = [x.strip() for x in os.environ.get(
    "PAIRES", "EURUSD,GBPUSD,USDCHF,AUDUSD,NZDUSD,EURJPY,XAUUSD").split(",")
    if x.strip()]
FEN = 32          # fenetre de prediction en barres M30
AVANCE_CIBLE = 16  # 8 h


def score_compose(vv, ref_tables, pos_mask=None):
    """score = somme des contributions (lift-1) signees par quantile.
    ref_tables : dict variable -> (edges, lift_par_quantile) aggregates."""
    s = np.zeros(len(vv["er"]))
    for nom, x in vv.items():
        if nom not in ref_tables:
            continue
        edges, lifts = ref_tables[nom]
        q = np.searchsorted(edges, x, side="right") - 1
        q = np.clip(q, 0, len(lifts) - 1)
        contrib = lifts[q] - 1.0
        # on ne signe PAS : le lift du quantile b est deja celui du cote
        # observe. La contribution est ajoutee telle quelle.
        s += np.nan_to_num(contrib)
    return s


def main():
    # ---- passe 1 : collecter les tables par paire --------------------------
    par_trans_paire = defaultdict(list)   # cle -> liste de (paire, dict var->(edges, lifts))
    premier_i_tous = defaultdict(list)    # cle -> liste de (paire, i, nb_barres)
    for p in JAMBES:
        D = NM.charge(p, "m1_pos")
        if D is None:
            print("  %-8s : corpus absent" % p)
            continue
        lab, _ = V2.etats(D)
        vv = variables(D)
        trans = transitions(lab)
        if len(trans) < 20:
            print("  %-8s : %d transitions (insuffisant)" % (p, len(trans)))
            continue
        print("  %-8s : %d transitions stables" % (p, len(trans)))
        # fenetre positive globale de la paire
        pos_all = np.zeros(len(lab), dtype=bool)
        for (i, A, B) in trans:
            pos_all[max(0, i - FEN):i] = True
        par_trans = defaultdict(list)
        for (i, A, B) in trans:
            par_trans["%s->%s" % (A, B)].append(i)
        for cle, idxs in par_trans.items():
            if len(idxs) < 15:
                continue
            pos = np.zeros(len(lab), dtype=bool)
            for i in idxs:
                pos[max(0, i - FEN):i] = True
            tables = {}
            for nom, x in vv.items():
                t = quantile_table(x, pos)
                if t is None:
                    continue
                edges = np.quantile(x[~np.isnan(x)], np.linspace(0, 1, 6))
                lifts = np.array([z[2] for z in t])
                tables[nom] = (edges, lifts)
            par_trans_paire[cle].append((p, tables))
            premier_i_tous[cle].append((p, idxs, len(lab)))
    # ---- passe 2 : aggregation multi-paires -------------------------------
    print("\n=== TABLE AGREGEE (lift moyen par variable, paires qui ont la "
          "transition) ===")
    agg_tables = {}
    for cle, lst in sorted(par_trans_paire.items(), key=lambda x: -len(x[1])):
        if len(lst) < 3:
            continue
        print("\n== %s (%d paires) ==" % (cle, len(lst)))
        noms = sorted({nom for _, t in lst for nom in t})
        scores = []
        for nom in noms:
            lifts = []
            for p, t in lst:
                if nom in t:
                    lifts.append(t[nom][1])
            m = np.mean(lifts, axis=0)
            best = int(np.argmax(m))
            scores.append((float(m[best]), nom, best, float(m.max())))
        scores.sort(reverse=True)
        for lift, nom, q, mx in scores[:8]:
            print("   %-14s q%d  lift moyen=%.2f" % (nom, q, lift))
        agg_tables[cle] = scores
    # ---- passe 3 : avance de detection du predicteur compose ---------------
    print("\n=== AVANCE DE DETECTION du predicteur compose ===")
    for cle, lst in sorted(par_trans_paire.items(), key=lambda x: -len(x[1])):
        if len(lst) < 3:
            continue
        avances = []
        for p, tables in lst:
            D = NM.charge(p, "m1_pos")
            if D is None:
                continue
            lab, _ = V2.etats(D)
            vv = variables(D)
            idxs = None
            for (pp, ilist, nlab) in premier_i_tous[cle]:
                if pp == p:
                    idxs = ilist
                    break
            if not idxs:
                continue
            ref = {nom: t for nom, t in tables.items()}
            s = score_compose(vv, ref)
            seuil = float(np.nanpercentile(s, 80))
            for i in idxs:
                # dernier croisement du seuil avant la transition
                fen = s[max(0, i - 96):i]
                dep = np.flatnonzero(fen >= seuil)
                if len(dep):
                    avances.append(i - (max(0, i - 96) + dep[0]))
        if avances:
            av = np.array(avances)
            ok = np.median(av)
            print("   %-32s n=%3d avance mediane=%3.0f barres (%.0f h) %s"
                  % (cle, len(av), ok, ok * 0.5,
                     "OK BIAS" if ok >= AVANCE_CIBLE else "trop court"))
    return 0


if __name__ == "__main__":
    sys.exit(main())


if __name__ == "__main__":
    main()
