"""Parse correct des deals ptrail 2024 : PnL par position, distribution."""
import re
from pathlib import Path

CF = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3")
raw = (CF / "Tester" / "logs" / "20260823.log").read_text("utf-16", errors="replace")
lines = raw.splitlines()

# Format :
#   market buy 0.22 USDJPY sl: 145.142 (145.467 / ...)      <- ordre d'entrée (ref #2)
#   deal #2 buy 0.22 USDJPY at 145.470 done (based on order #2)
#   stop loss triggered #2 buy 0.22 USDJPY 145.470 sl: 145.142 [#3 sell 0.22 USDJPY at 145.142]
#   deal #3 sell 0.22 USDJPY at 145.142 done (based on order #3)
#
# Stratégie : chaque "market buy/sell VOL" crée une position (ref = #N de l'ordre).
# La sortie est le deal qui referme (même VOL, direction opposée).
# On reconstitue : pour chaque ref d'entrée, trouver la sortie correspondante.

entries = {}   # ref -> (dir, vol, entry_price)
closes = []    # (ref_entrée, sortie_price)  -- on déduit la sortie du "stop loss triggered #ref"
for i, l in enumerate(lines):
    # entrée : "market buy 0.22 USDJPY sl: 145.142 (145.467 / 145.470 / ...)"
    me = re.search(r"market (buy|sell) ([\d.]+) USDJPY sl: ([\d.]+) \(([\d.]+) / ([\d.]+) /", l)
    if me:
        # le # de ref de l'ordre apparait dans la ligne suivante "deal #2 buy ... (based on order #2)"
        for j in range(i, min(i+3, len(lines))):
            mref = re.search(r"deal #(\d+) (buy|sell) ([\d.]+) USDJPY at ([\d.]+) done", lines[j])
            if mref:
                ref = int(mref.group(1))
                entries[ref] = (me.group(1), float(me.group(2)), float(mref.group(4)))
                break
    # sortie SL : "stop loss triggered #2 buy 0.22 USDJPY 145.470 sl: 145.142 [#3 sell ... at 145.142]"
    ms = re.search(r"stop loss triggered #(\d+) (buy|sell) ([\d.]+) USDJPY [\d.]+ sl: [\d.]+ \[#\d+ (buy|sell) [\d.]+ USDJPY at ([\d.]+)\]", l)
    if ms:
        ref = int(ms.group(1))
        closes.append((ref, float(ms.group(5))))

# PnL par position
pnls = []
for ref, (d, vol, ep) in entries.items():
    # trouver la sortie de cette ref
    for r2, sp in closes:
        if r2 == ref:
            if d == "buy":
                pnl = (sp - ep) * vol * 100000
            else:
                pnl = (ep - sp) * vol * 100000
            pnls.append((ref, d, vol, ep, sp, pnl))
            break

pnls.sort(key=lambda x: x[5], reverse=True)
print(f"positions: {len(pnls)} / entrées {len(entries)} / sorties SL {len(closes)}")
if pnls:
    import numpy as np
    a = np.array([p[5] for p in pnls])
    print(f"total: {a.sum():+.0f} | moyenne: {a.mean():+.0f} | médiane: {np.median(a):+.0f}")
    print(f"gagnants: {(a>0).sum()} | perdants: {(a<0).sum()} | WR: {100*(a>0).mean():.0f}%")
    print(f"top5: {[round(p[5]) for p in pnls[:5]]}")
    print(f"top5 % total: {100*a[:5].sum()/a.sum():.0f}%")
    print(f"gains >500: {(a>500).sum()} | >1000: {(a>1000).sum()} | pertes < -500: {(a<-500).sum()}")
    # concentration : top 10% des trades = quel % du PnL ?
    k = max(1, len(a)//10)
    print(f"top10% trades = {100*a[:k].sum()/a.sum():.0f}% du PnL")
