# -*- coding: utf-8 -*-
"""EXPORT_M1_HISTORY.py — Export M1 2016-2026 via l'API MetaTrader5.
Objectif : construire le dataset 10 ans pour le walk-forward ML sérieux.
- CopyRates(M1) : OHLC + tick_volume + spread (dispo 2016-2026 via .hcc)
- Si les ticks réels existent (2025-2026 .tkc) : CopyTicksRange pour
  bid/ask/n_ticks précis.
Sortie : research/bars/<SYM>_M1_full.parquet (time, bid_o..c, ask_o..c,
bid_vol, ask_vol, n_ticks, spread_med, spread_max, tick_volume).
Usage : python EXPORT_M1_HISTORY.py [SYMBOL...]  (défaut EURUSD USDJPY GBPUSD)
"""
import sys, time
from pathlib import Path
import numpy as np
import polars as pl

OUT = Path(r"C:\EAFarm\HISTORY - Copy\research\bars")

def main():
    import MetaTrader5 as mt5
    symbols = sys.argv[1:] or ["EURUSD", "USDJPY", "GBPUSD"]
    if not mt5.initialize(r"C:\EAFarm\MT5\Farm\terminal64.exe"):
        print("MT5 init échoué:", mt5.last_error()); return
    print(f"MT5 connecté: {mt5.account_info().login if mt5.account_info() else '?'}")

    for sym in symbols:
        info = mt5.symbol_info(sym)
        if info is None:
            print(f"{sym}: symbole inconnu"); continue
        # 1) M1 complet via CopyRates (historique .hcc 2016-2026)
        #    CopyRates limite ~ 5M barres par appel ; on boucle par an
        parts = []
        for year in range(2016, 2027):
            from_dt = mt5.symbol_info(sym) and __import__("datetime").datetime(year, 1, 1)
            to_dt = __import__("datetime").datetime(year + 1, 1, 1) if year < 2026 else None
            rates = mt5.copy_rates_range(sym, mt5.TIMEFRAME_M1, from_dt, to_dt) if to_dt else \
                    mt5.copy_rates_from_pos(sym, mt5.TIMEFRAME_M1, 0, 100000)
            if rates is None or len(rates) == 0:
                print(f"  {sym} {year}: vide"); continue
            df = pl.DataFrame(rates)
            df = df.rename({"time": "time_s"})
            df = df.with_columns([
                pl.from_epoch(pl.col("time_s"), time_unit="s").dt.epoch("s").alias("time"),
            ])
            parts.append(df)
            print(f"  {sym} {year}: {len(df)} barres", flush=True)
        if not parts:
            print(f"{sym}: AUCUNE donnée"); continue
        full = pl.concat(parts).unique(subset=["time"]).sort("time")
        full = full.with_columns([
            pl.col("open").alias("bid_o"),
            pl.col("high").alias("bid_h"),
            pl.col("low").alias("bid_l"),
            pl.col("close").alias("bid_c"),
            pl.col("tick_volume").alias("n_ticks_rates"),
            pl.col("spread").alias("spread_rates"),
        ]).select([
            "time", "bid_o", "bid_h", "bid_l", "bid_c",
            "n_ticks_rates", "spread_rates",
        ])
        # 2) enrichir avec ticks réels si dispo (2025-2026)
        ticks = mt5.copy_ticks_range(sym,
                                     __import__("datetime").datetime(2025, 1, 1),
                                     __import__("datetime").datetime(2026, 1, 1),
                                     mt5.COPY_TICKS_ALL)
        if ticks is not None and len(ticks) > 1000:
            tdf = pl.DataFrame(ticks)
            tdf = tdf.with_columns(pl.from_epoch(pl.col("time"), time_unit="s")
                                   .dt.truncate("1m").dt.epoch("s").alias("time"))
            tdf = tdf.with_columns([
                (pl.col("ask") - pl.col("bid")).alias("spread_px"),
            ])
            agg = tdf.group_by("time").agg([
                pl.col("bid").first().alias("bid_o2"),
                pl.col("bid").max().alias("bid_h2"),
                pl.col("bid").min().alias("bid_l2"),
                pl.col("bid").last().alias("bid_c2"),
                pl.col("ask").first().alias("ask_o"),
                pl.col("ask").last().alias("ask_c"),
                pl.len().alias("n_ticks"),
                pl.col("spread_px").median().alias("spread_med"),
                pl.col("spread_px").max().alias("spread_max"),
            ])
            full = full.join(agg, on="time", how="left")
            full = full.with_columns([
                pl.col("bid_o2").fill_null(pl.col("bid_o")).alias("bid_o"),
                pl.col("bid_h2").fill_null(pl.col("bid_h")).alias("bid_h"),
                pl.col("bid_l2").fill_null(pl.col("bid_l")).alias("bid_l"),
                pl.col("bid_c2").fill_null(pl.col("bid_c")).alias("bid_c"),
            ]).drop(["bid_o2", "bid_h2", "bid_l2", "bid_c2"])
            n_ticks_full = full["n_ticks"].fill_null(full["n_ticks_rates"]).alias("n_ticks")
            full = full.with_columns(n_ticks_full)
            full = full.with_columns([
                pl.col("spread_med").fill_null(pl.col("spread_rates") / 1e5).alias("spread_med"),
            ])
        else:
            full = full.with_columns([
                pl.col("n_ticks_rates").alias("n_ticks"),
                (pl.col("spread_rates") / 1e5).alias("spread_med"),
            ])
        full = full.drop(["n_ticks_rates", "spread_rates"])
        # volume bid/ask : non dispo en M1 historique -> n_ticks comme proxy
        full = full.with_columns([
            (pl.col("n_ticks") * 0.5).cast(pl.Float64).alias("bid_vol"),
            (pl.col("n_ticks") * 0.5).cast(pl.Float64).alias("ask_vol"),
        ])
        out = OUT / f"{sym}_M1_full.parquet"
        full.write_parquet(out)
        print(f"\n{sym}: TOTAL {len(full)} barres -> {out}")
        print(f"  plage: {full['time'].min()} -> {full['time'].max()}")
        print(f"  n_ticks médian: {full['n_ticks'].median() if full['n_ticks'].median() else '?'}")

    mt5.shutdown()

if __name__ == "__main__":
    main()
