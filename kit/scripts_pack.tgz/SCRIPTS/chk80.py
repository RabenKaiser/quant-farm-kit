﻿import os, re
LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
files=sorted([(os.path.getmtime(os.path.join(LOGD,f)), f) for f in os.listdir(LOGD) if ".log" in f], reverse=True)
for m,f in files:
    p=os.path.join(LOGD,f)
    if os.path.getsize(p)<500: continue
    raw=open(p,"rb").read(4)
    enc="utf-16" if raw[:2] in (b"\xff\xfe",b"\xfe\xff") else "utf-8"
    try: txt=open(p,encoding=enc,errors="replace").read()
    except Exception: continue
    h=re.findall(r".*ORION TRIGX CADJPY (SWEEPHI|BIGBEAR|BRKLL20).*", txt)
    if h:
        print(f"--- {f} ---")
        for x in re.findall(r".*ORION TRIGX CADJPY .*", txt):
            print("  ", x.split("Core")[-1].strip()[:80])
        break
