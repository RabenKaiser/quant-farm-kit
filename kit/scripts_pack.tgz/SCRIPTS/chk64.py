﻿import pandas as pd, numpy as np
p = r"C:\EAFarm\HISTORY - Copy\research\m1_pos\CADJPY_M1.csv"
df = pd.read_csv(p, usecols=["time","spread"])
df["ts"] = pd.to_datetime(df["time"], unit="s", utc=True)
s5 = df.set_index("ts")["spread"].resample("5min").mean()
med = np.nanmedian(s5.to_numpy())
print(f"CADJPY spread M5 : median={med:.1f}  p50={np.nanpercentile(s5,50):.1f}  p90={np.nanpercentile(s5,90):.1f}")
print(f"  seuil 2.5x = {2.5*med:.1f}")
print(f"  part des barres > seuil : {100*(s5.to_numpy() > 2.5*med).mean():.2f} %")
print()
print("Or l'EA mesure le spread AUTREMENT : il lit le spread INSTANTANE")
print("(SymbolInfoTick ask-bid) et le compare a la MEDIANE calculee par")
print("SpreadMedian() sur 200 barres M5. Verifions cette fonction :")
