# -*- coding: utf-8 -*-
"""diag_eurusd.py — pourquoi EURUSD BRKROUNDUP donne 19 au lieu de 69 ?

DIAGNOSTIC EA (log) :
    tries=19 | rejets has=23099 bar=8058993 npos=0 side=0 hedge=0
    spread=215447 filtre=207893 trigger=8744
    rejets par filtre : VOLCLX=207893

LECTURE
-------
- le filtre VOLCLX est evalue AVANT le trigger (ligne 1604 puis 1621) ;
- 207 893 barres rejetees par VOLCLX, 8 744 rejets par le trigger ;
- donc le trigger n'a ete teste que sur ~8 763+19 barres (celles qui passent VOLCLX).

VERIFICATION : est-ce que VOLCLX laisse passer le bon nombre de barres ?
  Python vol_clx taux = 3.90 %  ->  sur 448 030 barres M5
  EA : 8 744 / (207 893 + 8 744 + 19) = ?
"""
import sys
import numpy as np

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT

TRY, REJ_FILT, REJ_TRIG = 19, 207893, 8744
tot = TRY + REJ_FILT + REJ_TRIG
print("=== TAUX VOLCLX ===")
print(f"  EA   : {REJ_TRIG+TRY} barres passent VOLCLX sur {tot} = "
      f"{100*(REJ_TRIG+TRY)/tot:.2f} %")
G._cache.clear()
F = G.get_frames("EURUSD")
m5, m1 = F["m5"], F["m1"]
h1z, hh, ll, a1, gb, gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd, zlo, zhi = MT.project(m5.index, h1z, hh, ll, gb, gr, max_age_h=48)
M = NL.build(m5, F, zd, zlo, zhi); M.update(FE.more(m5, F, m1))
print(f"  PY   : vol_clx taux = {100*M['vol_clx'].mean():.2f} % "
      f"sur {len(m5)} barres")

print("\n=== TAUX BRK_ROUND_UP ===")
c = m5["close"].to_numpy()
mult = 10.0 ** np.floor(np.log10(np.maximum(c, 1e-9)))
step = mult / 10.0
r1 = np.round(c / step) * step
b = (c > r1) & (np.roll(c, 1) <= np.roll(r1, 1))
print(f"  PY   : brk_round_up taux = {100*b.mean():.4f} %  ({int(b.sum())} barres)")
print(f"  PY   : brk_round_up & vol_clx = {int((b & M['vol_clx']).sum())} barres")

print("\n=== CONCLUSION ===")
print("  Si le taux VOLCLX de l'EA correspond au Python (~3.9 %), alors le")
print("  filtre est FIDELE et la perte vient du TRIGGER brk_round_up.")
print("  8744 rejets trigger est BEAUCOUP trop faible pour 74 signaux python :")
print("  python evalue brk_round_up sur 448 030 barres, l'EA seulement sur ~8 763")
print("  (car le filtre est teste AVANT).")
print()
print("  -> Le nombre de signaux attendus cote EA est donc au plus ~4 % de 74,")
print("     soit ~3. L'EA en trouve 19 : il en trouve MEME PLUS que prevu.")
print()
print("  ATTENTION : cela signifie que la comparaison 'MT5 vs Python' n'est PAS")
print("  pomme a pomme : le Python applique le trigger ET le filtre sur TOUTES")
print("  les barres, l'EA applique le filtre d'abord. Le resultat final devrait")
print("  etre le meme (intersection), mais l'ORDRE change les compteurs de rejet.")
print()
print("  La difference reelle 69 vs 19 doit donc venir d'ailleurs :")
print("  probablement le filtre de SPREAD, applique avant tout le reste")
print("  (spread=215447 rejets, soit plus que les 207893 du filtre VOLCLX !).")
