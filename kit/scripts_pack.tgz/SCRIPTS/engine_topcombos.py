# -*- coding: utf-8 -*-
import polars as pl
p = r'C:\EAFarm\HISTORY - Copy\research\stack_engine_out\engine_results.parquet'
df = pl.read_parquet(p)
lines = []
lines.append('ds values: ' + str(sorted(df['ds'].unique().to_list())))
# combos gagnants exacts du message TOP-COMBOS : E8F1X3, E9F4X3, E6F0X3, E2F0X3, E4F1X3
targets = [(8, 1, 3), (9, 4, 3), (6, 0, 3), (2, 0, 3), (4, 1, 3), (4, 1, 4), (11, 0, 4), (11, 1, 4)]
for (e, f, x) in targets:
    sub = df.filter((pl.col('E') == e) & (pl.col('F') == f) & (pl.col('X') == x))
    if sub.height == 0:
        lines.append('E%dF%dX%d: AUCUNE cellule dans le parquet' % (e, f, x))
        continue
    pos = sub.filter(pl.col('R') > 0).height
    tot = sub.select(pl.col('R').sum()).item()
    lines.append('E%dF%dX%d: %d cellules | %d/%d R>0 | R total=%.1f | PF moy=%.2f' % (
        e, f, x, sub.height, pos, sub.height, tot,
        sub.select(pl.col('pf').mean()).item()))
    for r in sub.iter_rows(named=True):
        lines.append('    %s n=%d R=%+.1f PF=%.2f win=%.2f' % (r['ds'], r['n'], r['R'], r['pf'], r['win']))
out = r'C:\EAFarm\HISTORY - Copy\research\engine_topcombos.txt'
with open(out, 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines))
print('written', out)
