"""contender : meilleur candidat de portefeuille AUJOURD'HUI.

Ne lit que les cellules du moteur de la nuit (par_farm_r*.jsonl,
par_mt5_r*.jsonl), donc uniquement des ordres reels avec attribution par ligne,
geometries variees (12), trames M5/M15/M30, 5 paires.

Pour chaque ligne de jeu (id) on agrege par paire : PnL, nombre de fenetres,
part de fenetres positives, hostile (2024Q1, 2024Q2, 2025Q2-Q4), bon
(2024Q3-Q4). Une ligne est retenue comme CONTENDER si elle est positive sur au
moins 3 paires ET si sa somme hostile est positive.
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
OUT = B / "contender.md"
HOSTILE = ("2024Q1", "2024Q2", "2025Q2", "2025Q3", "2025Q4")


def main():
    par = defaultdict(lambda: defaultdict(lambda: [0.0, 0, 0, 0.0, 0]))
    nf = 0
    for f in list(B.glob("par_farm_r*.jsonl")) + list(B.glob("par_mt5_r*.jsonl")):
        nf += 1
        for ln in f.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                o = json.loads(ln)
            except ValueError:
                continue
            sym, quart = o.get("sym"), o.get("quarter")
            for c in o.get("combos") or []:
                n = c.get("n") or 0
                if not n:
                    continue
                a = par[c["id"]][sym]
                a[0] += c.get("pnl") or 0
                a[1] += n
                if (c.get("pnl") or 0) > 0:
                    a[2] += 1
                a[3] += 1
                if quart in HOSTILE:
                    a[4] += c.get("pnl") or 0
    print("fichiers %d | lignes %d" % (nf, len(par)), flush=True)

    res = []
    for cid, ps in par.items():
        paires = {s: v for s, v in ps.items() if v[1] >= 100}
        if len(paires) < 2:
            continue
        pos = [s for s, v in paires.items() if v[0] > 0]
        host = sum(v[4] for v in paires.values())
        res.append(dict(id=cid, n_paires=len(paires), pos=len(pos),
                        host=host,
                        part=sum(v[2] for v in paires.values()) /
                             max(1, sum(v[3] for v in paires.values())),
                        detail={s: (round(v[0]), v[1]) for s, v in paires.items()}))
    res.sort(key=lambda d: (-d["pos"], -d["part"]))
    out = ["# Meilleur candidat de portefeuille (cellules de la nuit, ordres reels)", "",
           "Fichiers de cellules : %d | lignes mesurees : %d" % (nf, len(par)), "",
           "| ligne | paires | paires + | fenetres + | hostile (somme) | detail |",
           "|---|---|---|---|---|---|"]
    for d in res[:25]:
        det = ", ".join("%s:%+d(%dtx)" % (s, v[0], v[1]) for s, v in
                        sorted(d["detail"].items(), key=lambda kv: -kv[1][0]))
        out.append("| %s | %d | %d | %.0f%% | %+d | %s |"
                   % (d["id"], d["n_paires"], d["pos"], 100 * d["part"],
                      round(d["host"]), det))
    elig = [d for d in res if d["pos"] >= 3 and d["host"] > 0]
    out += ["", "**Candidats avec >= 3 paires positives ET hostile > 0 : %d**"
            % len(elig), ""]
    for d in elig[:10]:
        out.append("- `%s` : %d/%d paires positives, hostile %+d"
                   % (d["id"], d["pos"], d["n_paires"], round(d["host"])))
    OUT.write_text("\n".join(out), encoding="utf-8")
    print("\n".join(out[:16]), flush=True)
    print("candidats eligibles : %d" % len(elig), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
