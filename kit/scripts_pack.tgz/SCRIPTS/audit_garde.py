﻿"""Deep audit of G13/G14 GARDE candidates: n, t, monthly decomposition, robustness."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import json, datetime as _dt
from pathlib import Path
import numpy as np
import polars as pl

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research")
from edge_correct import (load_m1, to_tf, seg_of, backtest_m1, summarize,
                          POINT, COMMISSION_RT, TICK_VALUE_PER_PT)
from edge_correct import make_signals as ms_base
from alpha_loop_gen import add_costs, apply_filters

def E(d):
    return int(_dt.datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=_dt.timezone.utc).timestamp())

def monthly(sym, tf_sec, kind, cfg):
    m1 = load_m1(sym)
    tf = to_tf(m1, tf_sec)
    f = ms_base(apply_filters(tf, sym, cfg), kind, cfg)
    tr = backtest_m1(m1, tf, f, sym, add_costs(sym, cfg))
    res = pl.DataFrame(tr)
    res = res.with_columns((pl.col("ts") // 86400 * 86400 * 1000).cast(pl.Datetime("ms")).dt.strftime("%Y-%m").alias("ym"))
    g = res.group_by("ym").agg(
        pl.col("r").mean().alias("gross"),
        (pl.col("r") - pl.col("cost_r")).mean().alias("net"),
        pl.len().alias("n")).sort("ym")
    print(f"\n=== {sym} M{tf_sec//60} {kind} {cfg} monthly ===")
    pos = 0
    for r in g.iter_rows(named=True):
        if r["net"] > 0:
            pos += 1
        print(f"  {r['ym']}: n={int(r['n'])} gross={r['gross']:.4f} net={r['net']:.4f}")
    print(f"  positive months: {pos}/{len(g)}")
    # overall
    if len(res):
        rmean = float(res["r"].mean()); cmean = float(res["cost_r"].mean())
        std = float(res["r"].std())
        n = len(res)
        t = rmean / (std / np.sqrt(n)) if std > 0 else 0
        print(f"  TOTAL: n={n} gross={rmean:.4f} net={rmean-cmean:.4f} t={t:.2f}")

# --- G13: USDJPY M30 range_break lb=40 sl=2.5 rr=2.5 ---
cfg = {"slippage_pts": 0.5, "lookback": 40, "sl_atr": 2.5, "rr": 2.5}
monthly("USDJPY", 1800, "range_break", cfg)

# --- G14: US100 M5 range_fade lb=40 sl=4 rr=4 ---
cfg2 = {"slippage_pts": 0.5, "lookback": 40, "sl_atr": 4.0, "rr": 4.0}
monthly("USATECHIDXUSD", 300, "range_fade", cfg2)
