﻿import sys, numpy as np, gc
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT
G._cache.clear(); gc.collect()
F = G.get_frames("AUDJPY"); m5,m1=F["m5"],F["m1"]
h1z,hh,ll,a1,gb,gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
zd,zlo,zhi = MT.project(m5.index,h1z,hh,ll,gb,gr,max_age_h=48)
M = NL.build(m5,F,zd,zlo,zhi); M.update(FE.more(m5,F,m1))
n=len(m5)
r = np.asarray(M["rsi_xup"]); f1 = np.asarray(M["in_fvgB_1.0"]); f2 = np.asarray(M["in_fibM"])
print(f"barres M5            : {n:,}")
print(f"rsi_xup seul         : {r.sum():>8,}  ({100*r.mean():5.2f} %)")
print(f"in_fvgB_1.0 seul     : {f1.sum():>8,}  ({100*f1.mean():5.2f} %)")
print(f"in_fibM seul         : {f2.sum():>8,}  ({100*f2.mean():5.2f} %)")
print(f"rsi_xup ET fvgB      : {(r&f1).sum():>8,}")
print(f"rsi_xup ET fvgB ET fibM : {(r&f1&f2).sum():>8,}   <- signaux de la jambe")
print()
s = NL.sig(M, "rsi_xup", ["in_fvgB_1.0","in_fibM"])
print(f"NL.sig               : {int((s!=0).sum())}")
