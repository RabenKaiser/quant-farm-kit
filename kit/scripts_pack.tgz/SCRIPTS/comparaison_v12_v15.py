# -*- coding: utf-8 -*-
r"""comparaison_v12_v15.py -- COMPARAISON PROPRE V12 CONTRE V15 (meme chargeur,
memes fenetres, memes regles, meme grille).

POURQUOI CE SCRIPT. Les chiffres des derniers jours venaient de chargeurs
differents (textes bruts melangeant les symboles, pool automatique pollue par des
jambes legacy, series de R du corpus) : impossible de comparer honnetement. Ici
TOUT passe par le meme chemin :
  - charge_propre.transactions_propres() : transactions REELLES filtrees sur le
    marche de la campagne (correctif du 15/10) ;
  - une jambe par marche (regle prop : une direction a la fois) ;
  - fenetre commune 2024-01 -> 2026-03, memes regles prop (coupe -1 %, arret
    -5 %, cible +4,5 %) et meme grille (plafond 4/8/12 x risque 0,20/0,35 %).

LES DEUX PORTEFEUILLES (source : AUDIT_V12.md et PORTEFEUILLE_15.md) :
  V12 = les 7 jambes admises par la regle des deux etages (ferme ET juge).
  V15 = les jambes documentees ; seules celles qui ONT des ordres reels sont
        mesurables aujourd'hui (les T3 attendent leur premiere campagne).

Le script dit aussi EXPLICITEMENT quelles jambes manquent a chaque panier : une
comparaison sans cette liste serait trompeuse.
"""
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE / "SCRIPTS"))
os.environ.setdefault("CORPUS", "m1_ext")
import simu_prop_15 as SP
import charge_propre as CH

D0 = datetime(2024, 1, 2)
D1 = datetime(2026, 4, 1)

# --- V12 : les 7 jambes admises (audit du 28/09). Tag = campagne de la ferme.
V12 = {
    "XAU kelt32 (or)":        "g3_kelt32xau_slr6",
    "DEU kelt32 (Dax)":       "g3_kelt32deu_slr6",
    "JPN kelt32 (Nikkei)":    "g3_kelt32jpn_slr6",
    "USA30 sr100 (Dow)":      "g3_sr100_usa30idx_4",
    "FRA rsi_div (CAC)":      "g3_v12_fra_rsidiv",
    "EUS sr100 (EuroStoxx)":  "g3_v12_eus_sr100",
}
# --- V15 : les jambes documentees qui ont des ordres reels.
V15 = {
    "XAU kelt16h":            "g3_kelt16h_xauusd",
    "DEU kelt32":             "g3_kelt32deu_slr6",
    "JPN kelt32":             "g3_kelt32jpn_slr6",
    "USA30 sr100":            "g3_sr100_usa30idx_4",
    "EURJPY keltbrk":         "g3_scr_keltbrk_ej",
}
SERIE_HF = BASE / "SERIE_R_XAUUSD.json"


def charge(panier, etiquette):
    garde = {}
    manquants = []
    for nom, tag in panier.items():
        tx = [x for x in CH.transactions_propres(tag) if D0 <= x["t_in"] < D1]
        if len(tx) < 20:
            manquants.append(nom)
            continue
        R = np.array([x["R"] for x in tx], dtype=float)
        garde[nom] = dict(tag=tag, tx=tx, n=len(R), mu=float(R.mean()),
                          total=float(R.sum()), sym=CH.symboles_du_tag(tag) or CH.symbole_du_tag(tag))
    print("--- %s ---" % etiquette)
    if not garde:
        print("   (aucune jambe mesurable)")
    for nom, d in sorted(garde.items(), key=lambda x: -x[1]["mu"]):
        print("   %-24s %-10s %5d tx  mu %+.4f  total %+8.1f" %
              (nom, (d["sym"][0] if d["sym"] else "?"), d["n"], d["mu"], d["total"]))
    if manquants:
        print("   MANQUANTES (pas encore d'ordres reels) : %s" % ", ".join(manquants))
    tous = sorted([x for d in garde.values() for x in d["tx"]], key=lambda x: x["t_in"])
    if tous:
        R = np.array([x["R"] for x in tous])
        jours = len({x["t_in"].date() for x in tous})
        print("   PANIER : %d jambes, %d tx, mu %+.4f, %d jours de bourse, %.2f tx/jour"
              % (len(garde), len(R), R.mean(), jours, len(R) / max(jours, 1)))
    return tous


def charge_hf():
    if not SERIE_HF.exists():
        return []
    import json
    out = []
    for d, r in json.loads(SERIE_HF.read_text(encoding="utf-8")):
        t = datetime.fromisoformat(str(d)[:19])
        if D0 <= t < D1:
            out.append(dict(t_in=t, R=float(r), tag="HF"))
    return sorted(out, key=lambda x: x["t_in"])


def grille(trades, nom):
    if not trades:
        return
    fens = []
    d = D0
    while d + timedelta(days=30) <= D1:
        fens.append((d.date(), (d + timedelta(days=30)).date()))
        d += timedelta(days=5)
    print()
    print("%-16s %5s %7s %9s %9s %9s %7s" %
          (nom, "plaf", "risq %", "P(cible)", "P(-5 %)", "mediane", "tx/j"))
    for cap in (4, 8, 12):
        for risque in (0.20, 0.35):
            fin, ok, ar, ntx = [], 0, 0, 0
            for deb, finw in fens:
                r, c, a, x = SP.simule_fenetre(trades, risque, deb, finw, 4.5, cap, coupe=1.0)
                fin.append(r)
                ok += 1 if c else 0
                ar += 1 if a else 0
                ntx += x
            k = len(fin)
            print("%-16s %5d %7.2f %8.0f %% %8.0f %% %+9.2f %7.2f" %
                  (nom if cap == 4 and risque == 0.20 else "", cap, risque,
                   100.0 * ok / k, 100.0 * ar / k, float(np.median(fin)), ntx / (k * 30)))


def main():
    print("=" * 78)
    print("COMPARAISON V12 / V15 -- ordres reels, chargeur corrige, fenetres identiques")
    print("=" * 78)
    t12 = charge(V12, "V12 (jambes admises par la regle des deux etages)")
    t15 = charge(V15, "V15 (jambes documentees ayant des ordres reels)")
    hf = charge_hf()
    print()
    print("--- jambe haute frequence (serie de R du corpus) ---")
    if hf:
        R = np.array([x["R"] for x in hf])
        print("   %d tx, mu %+.4f" % (len(R), R.mean()))
    grille(t12, "V12 mesurable")
    grille(t15, "V15 mesurable")
    if hf:
        grille(sorted(t15 + hf, key=lambda x: x["t_in"]), "V15 + HF")


if __name__ == "__main__":
    main()