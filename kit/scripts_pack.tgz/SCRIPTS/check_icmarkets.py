"""Tester l'accès au compte ICMarketsEU-Demo pour valider MFR sur le bon broker.
Le Farm (CF0B997) a ICMarketsEU-Demo en 2e base. Si on peut y backtester,
MFR_FORGE2 devrait se répliquer correctement (count ~29 au lieu de 2310 Alpari)."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner as m

# Le testeur MT5 utilise le compte par défaut. Pour ICMarkets, il faut que le
# compte soit le compte actif du terminal. Vérifions ce qui est dispo.
print("=== bases du terminal (CF0B997) ===")
import os
bases = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\bases"
if os.path.isdir(bases):
    for d in os.listdir(bases):
        p = os.path.join(bases, d)
        n = len([f for f in os.listdir(p)]) if os.path.isdir(p) else 0
        print(f"  {d}: {n} fichiers" if os.path.isdir(p) else f"  {d}: fichier")

# le compte actif est Alpari (53103102). Le backtest MFR sur ICMarkets nécessite
# de basculer le compte actif du terminal — action manuelle.
print("\n=== ÉTAT : le compte actif du terminal est Alpari ===")
print("Pour tester sur ICMarketsEU-Demo, il faut connecter CE compte dans le")
print("terminal (login GUI une fois), puis le runner l'utilisera.")
print("\nEn attendant, on peut vérifier si les DONNÉES ICMarkets sont déjà")
print("dans le terminal (pour un backtest offline).")
