# -*- coding: utf-8 -*-
"""depth.py — mesure la profondeur REELLE de chaque marche, par timeframe.

PIEGE : copy_rates_from_pos(s, tf, 0, N) echoue si N est trop grand (renvoie
None). Il faut demander par paliers et s'arreter au dernier N qui repond.
Meme famille de bug que copy_rates_range (0 barre) et que le testeur MT5.
"""
import MetaTrader5 as mt5
import pandas as pd
import time

PATH = r"C:\EAFarm\MT5\Farm\terminal64.exe"
ok = mt5.initialize(path=PATH)
print("terminal :", mt5.terminal_info().name)

SYMS = ["EURUSD", "EURGBP", "XAUUSD", "AUDJPY", "XAGUSD",
        "USA500.IDX", "DEU.IDX", "GBR.IDX", "JPN.IDX", "EUS.IDX",
        "BRENT.CMD", "GAS.CMD", "XPT.CMD",
        "COFFEE.CMD", "COPPER.CMD", "BTCUSD", "ETHUSD",
        "BUND.TR", "USTBOND.TR", "DOLLAR.IDX", "VOL.IDX"]

PALIERS = (10_000, 50_000, 100_000, 200_000, 400_000, 800_000)


def depth(sym, tf):
    """dernier palier qui repond."""
    best, arr = 0, None
    for N in PALIERS:
        r = mt5.copy_rates_from_pos(sym, tf, 0, N)
        n = 0 if r is None else len(r)
        if n == 0:
            break
        best, arr = n, r
        if n < N * 0.9:      # le serveur a rendu tout ce qu'il a
            break
        time.sleep(0.2)
    if arr is None:
        return 0, None, None
    d0 = pd.to_datetime(arr[0]["time"], unit="s").date()
    d1 = pd.to_datetime(arr[-1]["time"], unit="s").date()
    return best, d0, d1


print(f"\n{'marche':<14}{'M1':>10}{'depuis':>12}   {'M5':>9}{'depuis':>12}")
for s in SYMS:
    info = mt5.symbol_info(s)
    if info is None:
        print(f"{s:<14} ABSENT"); continue
    if not info.visible:
        mt5.symbol_select(s, True); time.sleep(0.2)
    n1, d01, _ = depth(s, mt5.TIMEFRAME_M1)
    n5, d05, _ = depth(s, mt5.TIMEFRAME_M5)
    print(f"{s:<14}{n1:>10}{str(d01):>12}   {n5:>9}{str(d05):>12}")

mt5.shutdown()
