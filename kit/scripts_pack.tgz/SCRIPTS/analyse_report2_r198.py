# -*- coding: utf-8 -*-
"""analyse_report2_r198.py — lire les trades + le solde du rapport challenge."""
import sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import openpyxl

P = r"C:\EAFarm\SHARED\ReportHistory-1416865.xlsx"
wb = openpyxl.load_workbook(P, data_only=True)
ws = wb["Sheet1"]

# trouver les lignes de donnees: chercher '#' ou en-tete de colonnes de trades
for i, row in enumerate(ws.iter_rows(values_only=True), 1):
    txt = " | ".join(str(v) for v in row if v is not None)
    if txt.strip():
        print(f"{i:3d}: {txt[:180]}")
