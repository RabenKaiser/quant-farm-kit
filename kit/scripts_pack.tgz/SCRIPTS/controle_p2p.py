# -*- coding: utf-8 -*-
r"""controle_p2p.py -- falsification du resultat P2P (10/12).

Le crible P2P affiche +0.6..+0.85 R/tx SUR LES DEUX COTES de toutes les
paires (6/6 ans). Avant d'y croire : le TEMOIN. Meme moteur, memes barrieres
(SLR 3, TPR 2, hold 64 M30), memes creneaux de 32 h, mais la DIRECTION du
signal est tiree au hasard au lieu de venir de la regle SMA20.

  - si le temoin fait aussi ~+0.7 : le moteur (barrieres/expiry/derive du
    corpus) gonfle le R et le P2P ne dit rien. RESULTAT MORT.
  - si le temoin fait ~0 : la regle SMA20 porte vraiment l'information, et
    P2P est un edge tendanciel a passer au gate WF puis a la ferme.

Le tirage est fixe (seed) pour etre reproductible.
"""
import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nuit_motifs as NM
import crible_p2p as P

JAMBES = P.JAMBES
HOLD = P.HOLD


def main():
    rng = np.random.default_rng(42)
    print("TEMOIN : direction aleatoire, creneaux 32 h identiques, "
          "SLR=3 TPR=2 hold=%d M30" % HOLD)
    mus = []
    for p in JAMBES:
        D = NM.charge(p, "m1_pos")
        if D is None:
            continue
        c, h, l, o, a = D["c"], D["h"], D["l"], D["o"], D["a"]
        n = len(c)
        st = P.p2p_signaux(D)[2]
        # les creneaux : meme disposition que le garde P2P (un toutes les
        # 32 h), mais a partir d'un offset aleatoire fixe
        off0 = int(rng.integers(0, 30 * HOLD))
        sig = np.arange(60, n - HOLD - 3)
        sig = sig[(((D["idx"][sig].asi8 // 10 ** 9) // (30 * HOLD))
                   % 2 == 0)]  # un creneau sur deux, periode 32 h
        sig = sig[(sig - off0) % (30 * HOLD // 30) == 0]
        sig = sig[np.isfinite(st[sig]) & (st[sig] > 0)
                  & np.isfinite(a[sig]) & (a[sig] > 0)]
        if len(sig) < 30:
            continue
        sens = rng.integers(0, 2, size=len(sig))  # 0 = L, 1 = S
        ent = sig + 1
        ent = ent[ent < n - HOLD - 2]
        e = o[ent]
        s = st[sig[:len(ent)]]
        sens = sens[:len(ent)]
        sp = D["cout"]
        tp_l, sl_l = e + (P.TPR * 3 + sp) * s, e - max(3 - sp, 0.1) * s
        tp_s, sl_s = e - (P.TPR * 3 + sp) * s, e + max(3 - sp, 0.1) * s
        off = np.arange(1, HOLD + 1)
        Hh, Ll = h[ent[:, None] + off], l[ent[:, None] + off]
        htp_l, hsl_l = Hh >= tp_l[:, None], Ll <= sl_l[:, None]
        htp_s, hsl_s = Ll <= tp_s[:, None], Hh >= sl_s[:, None]
        kind_l = np.where(htp_l.any(1) & (~hsl_l.any(1)
                          | (htp_l.argmax(1) < hsl_l.argmax(1))), 0,
                          np.where(hsl_l.any(1), 1, 2))
        kind_s = np.where(htp_s.any(1) & (~hsl_s.any(1)
                          | (htp_s.argmax(1) < hsl_s.argmax(1))), 0,
                          np.where(hsl_s.any(1), 1, 2))
        fin_l = (c[ent + HOLD] - e) / s
        fin_s = (e - c[ent + HOLD]) / s
        R_l = np.where(kind_l == 0, P.TPR, np.where(kind_l == 1, -1.0,
                                                    fin_l + sp))
        R_s = np.where(kind_s == 0, P.TPR, np.where(kind_s == 1, -1.0,
                                                    fin_s - sp))
        R = np.where(sens == 0, R_l, R_s)
        mu = float(np.mean(R))
        mus.append(mu)
        print("  %-8s n=%4.0f mu=%+.3f" % (p, len(R), mu))
    print("TEMOIN AGREGAT : mu=%+.4f sur %d jambes" %
          (float(np.mean(mus)), len(mus)))
    print("verdict : %s" % (
        "MOTEUR GONFLE (le P2P ne dit rien)" if np.mean(mus) > 0.3
        else "le P2P porte une vraie information" if np.mean(mus) > -0.05
        else "les barrieres mangent le temoin, P2P a un vrai surplus"))


if __name__ == "__main__":
    main()
