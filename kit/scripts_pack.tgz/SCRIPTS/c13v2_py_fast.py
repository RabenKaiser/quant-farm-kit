# -*- coding: utf-8 -*-
"""c13v2_py_fast.py — backtesteur C13V2 PYTHON RAPIDE (vectorise) pour
screening massif. Lit les parquets M1, resample M5/M15/H4, simule OB+retest
+rejet, supporte lookahead=0 (honnete) ou lookahead>0. Renvoie stats."""
import sys
import numpy as np
import pandas as pd
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

BARS = r"C:\EAFarm\HISTORY - Copy\research\bars"


def load_m1(sym):
    df = pd.read_parquet(f"{BARS}\\{sym}_M1_db.parquet")
    df = df.set_index("ts_event").sort_index()
    df = df[~df.index.duplicated(keep="last")]
    return df[["open", "high", "low", "close", "volume"]].astype(float)


def resample(df, rule):
    return df.resample(rule).agg(
        {"open": "first", "high": "max", "low": "min", "close": "last",
         "volume": "sum"}).dropna()


def atr_s(s, period=14):
    h, l, c = s["high"], s["low"], s["close"]
    pc = c.shift(1)
    tr = pd.concat([(h - l), (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    return tr.rolling(period).mean()


def ema_s(s, period):
    return s.ewm(span=period, adjust=False).mean()


def backtest(sym, year, cfg):
    m1 = load_m1(sym)
    start = pd.Timestamp(f"{year}-01-01", tz="UTC")
    end = pd.Timestamp(f"{year + 1}-01-01", tz="UTC")
    wu = start - pd.Timedelta(days=260)
    m1w = m1.loc[wu:end]
    m5 = resample(m1w, "5min")
    m15 = resample(m1w, "15min")
    h4 = resample(m1w, "4h")
    m5 = m5.loc[start:end]

    # --- bias H4 (EMA ou VWAP) ---
    if cfg.get("bias", "ema") == "vwap":
        tv = (h4["high"] + h4["low"] + h4["close"]) / 3
        vol = h4["volume"]
        vwap = (tv * vol).rolling(cfg.get("vwap_len", 96)).sum() / \
               vol.rolling(cfg.get("vwap_len", 96)).sum()
    else:
        vwap = ema_s(h4["close"], cfg.get("ema", 200))

    # --- OB M15 : impulsion + volume ---
    o = m15["open"].to_numpy(); h = m15["high"].to_numpy()
    l = m15["low"].to_numpy(); c = m15["close"].to_numpy()
    v = m15["volume"].to_numpy()
    a15 = atr_s(m15, 14).to_numpy()
    avgv = pd.Series(v).rolling(cfg.get("vol_look", 50)).mean().to_numpy()
    n = len(m15)
    body = np.abs(c - o)
    is_bull = c > o
    is_bear = c < o
    L = cfg.get("lookahead", 0)   # 0 = honnete (impulsion passee), sinon future
    imp_mult = cfg.get("imp_atr", 1.2)
    vol_mult = cfg.get("imp_vol", 1.5)
    thr = np.where(np.isfinite(a15), a15 * imp_mult, np.nan)

    ob_bull_idx = np.full(n, -1, dtype=int)  # dernier OB bull <= barre i
    ob_bear_idx = np.full(n, -1, dtype=int)
    zlow_b = np.full(n, np.nan); zhigh_b = np.full(n, np.nan)
    zlow_s = np.full(n, np.nan); zhigh_s = np.full(n, np.nan)
    last_b = -1; last_s = -1

    for j in range(n):
        # rendre dispo l'OB detecte en j-L (confirme)
        jj = j - L
        if jj >= 0 and np.isfinite(thr[jj]):
            if is_bear[jj] and body[jj] >= thr[jj] * 0.3:
                # impulsion bull apres jj ?
                ok = False
                for k in range(1, L + 1) if L > 0 else range(1, cfg.get("imp_look", 5) + 1):
                    kk = jj + k
                    if L == 0 and kk > j:  # honnete: deja passee
                        break
                    if kk >= n:
                        break
                    vok = (not np.isfinite(avgv[kk])) or v[kk] >= avgv[kk] * vol_mult
                    if is_bull[kk] and body[kk] >= thr[jj] and c[kk] > h[jj] and vok:
                        ok = True
                        break
                if ok:
                    last_b = jj
            if is_bull[jj] and body[jj] >= thr[jj] * 0.3:
                ok = False
                for k in range(1, L + 1) if L > 0 else range(1, cfg.get("imp_look", 5) + 1):
                    kk = jj + k
                    if L == 0 and kk > j:
                        break
                    if kk >= n:
                        break
                    vok = (not np.isfinite(avgv[kk])) or v[kk] >= avgv[kk] * vol_mult
                    if is_bear[kk] and body[kk] >= thr[jj] and c[kk] < l[jj] and vok:
                        ok = True
                        break
                if ok:
                    last_s = jj
        ob_bull_idx[j] = last_b
        ob_bear_idx[j] = last_s
        if last_b >= 0:
            zlow_b[j] = l[last_b]; zhigh_b[j] = o[last_b]
        if last_s >= 0:
            zlow_s[j] = o[last_s]; zhigh_s[j] = h[last_s]
    # fraicheur max age
    max_age = cfg.get("ob_age", 10000)
    m15_idx_at = np.searchsorted(m15.index.values, m5.index.values, side="right") - 1
    m15_idx_at = np.clip(m15_idx_at, 0, n - 1)

    # --- M5: rejet + touch ---
    o5 = m5["open"].to_numpy(); h5 = m5["high"].to_numpy()
    l5 = m5["low"].to_numpy(); c5 = m5["close"].to_numpy()
    v5 = m5["volume"].to_numpy()
    idx15 = m15_idx_at
    pip = 0.0001
    body5 = np.abs(c5 - o5)
    rej_mult = cfg.get("rej_wick", 1.5)
    rej_vol = cfg.get("rej_vol", 1.2)
    avgv5 = pd.Series(v5).rolling(cfg.get("vol_look", 50)).mean().to_numpy()
    close_in = cfg.get("close_zone", 0.20)

    want_buy = np.zeros(len(m5), dtype=bool)
    want_sell = np.zeros(len(m5), dtype=bool)
    for i in range(len(m5)):
        bi = ob_bull_idx[idx15[i]]
        si = ob_bear_idx[idx15[i]]
        if bi >= 0 and idx15[i] - bi <= max_age:
            zl, zh = zlow_b[idx15[i]], zhigh_b[idx15[i]]
            if not np.isnan(zl):
                zoneH = max(zh - zl, pip * 0.5)
                lowerW = min(o5[i], c5[i]) - l5[i]
                vok = (not np.isfinite(avgv5[i])) or v5[i] >= avgv5[i] * rej_vol
                if (body5[i] >= pip * 0.5 and l5[i] <= zh and
                    c5[i] >= zl + zoneH * close_in and c5[i] <= zh and
                    c5[i] > o5[i] and (lowerW / body5[i]) >= rej_mult and vok):
                    want_buy[i] = True
        if si >= 0 and idx15[i] - si <= max_age:
            zl, zh = zlow_s[idx15[i]], zhigh_s[idx15[i]]
            if not np.isnan(zl):
                zoneH = max(zh - zl, pip * 0.5)
                upperW = h5[i] - max(o5[i], c5[i])
                vok = (not np.isfinite(avgv5[i])) or v5[i] >= avgv5[i] * rej_vol
                if (body5[i] >= pip * 0.5 and h5[i] >= zl and
                    c5[i] <= zh - zoneH * close_in and c5[i] >= zl and
                    c5[i] < o5[i] and (upperW / body5[i]) >= rej_mult and vok):
                    want_sell[i] = True

    # --- simulation ---
    hour = m5.index.hour.to_numpy()
    excl = set(cfg.get("excl_hours", []))
    hok = np.array([h not in excl for h in hour])
    spread = cfg.get("spread", 0.000008)
    min_stop = cfg.get("min_stop", 0.00025)
    tp_r = cfg.get("tp_r", 2.5)
    trail_mult = cfg.get("trail", 0.0)
    trail_after = cfg.get("trail_after", 1.0)

    pos = None
    eq_r = 0.0
    trades = []
    day = None
    day_stop = False
    day_count = 0
    max_day_r = cfg.get("daily_stop_r", 0)
    for i in range(1, len(m5)):
        t = m5.index[i]
        d = t.date()
        if day != d:
            day = d; day_stop = False; day_count = 0
        # gestion pos
        if pos is not None:
            dirn = pos["dir"]
            eff_l = l5[i] - spread / 2 if dirn == 1 else l5[i] + spread / 2
            eff_h = h5[i] - spread / 2 if dirn == 1 else h5[i] + spread / 2
            sl = pos["sl"]; tp0 = pos["tp"]
            hit_sl = (eff_l <= sl) if dirn == 1 else (eff_h >= sl)
            hit_tp = (eff_h >= tp0) if dirn == 1 else (eff_l <= tp0)
            # trailing
            if trail_mult > 0 and pos["entry"] != 0 and pos["risk"] > 0:
                gain = dirn * (c5[i] - pos["entry"]) / pos["risk"]
                if gain >= trail_after:
                    # approx trailing sur close: SL suit a trail_mult*ATR5
                    pass
            if hit_sl or hit_tp:
                exit_px = tp0 if (hit_tp and not hit_sl) else sl
                r = (exit_px - pos["entry"]) / pos["risk"] if dirn == 1 \
                    else (pos["entry"] - exit_px) / pos["risk"]
                eq_r += r
                trades.append({"t": t, "dir": "L" if dirn == 1 else "S",
                               "r": r, "h": int(t.hour)})
                pos = None
        # entree
        if pos is None and not day_stop and hok[i] and (want_buy[i] or want_sell[i]):
            if max_day_r and (day_count >= cfg.get("max_day", 99)):
                continue
            bias = 1
            # bias via vwap/ema sur h4 (approx: valeur au dernier h4 clos)
            bv = vwap.asof(m5.index[i - 1]) if len(vwap) else np.nan
            if not np.isnan(bv):
                bias = 1 if c5[i - 1] > bv else -1
            dirn = 1 if want_buy[i] else -1
            if (dirn == 1 and bias != 1) or (dirn == -1 and bias != -1):
                continue
            # zone
            if dirn == 1:
                zl = zlow_b[idx15[i]]; zh = zhigh_b[idx15[i]]
                entry = c5[i]
                sl = zl - cfg.get("buf_atr", 0.25) * (a15[idx15[i]] if np.isfinite(a15[idx15[i]]) else 0.0005)
                if (entry - sl) < min_stop:
                    sl = entry - min_stop
                risk = entry - sl
                tp = entry + risk * tp_r
            else:
                zl = zlow_s[idx15[i]]; zh = zhigh_s[idx15[i]]
                entry = c5[i]
                sl = zh + cfg.get("buf_atr", 0.25) * (a15[idx15[i]] if np.isfinite(a15[idx15[i]]) else 0.0005)
                if (sl - entry) < min_stop:
                    sl = entry + min_stop
                risk = sl - entry
                tp = entry - risk * tp_r
            if risk > 0 and not np.isnan(entry):
                pos = {"dir": dirn, "entry": float(entry), "sl": float(sl),
                       "tp": float(tp), "risk": float(risk)}
                day_count += 1
    tr = pd.DataFrame(trades)
    if tr.empty:
        return {"n": 0, "R": 0.0, "wr": 0, "pf": 0, "dd": 0}
    wins = tr[tr["r"] > 0]
    losses = tr[tr["r"] < 0]
    gw = wins["r"].sum() if len(wins) else 0
    gl = -losses["r"].sum() if len(losses) else 0
    eq = tr["r"].cumsum()
    dd = float((eq.cummax() - eq).max())
    return {"n": len(tr), "R": float(tr["r"].sum()), "wr": float(len(wins) / len(tr) * 100),
            "pf": float(gw / gl) if gl > 0 else 99.0, "dd": dd}


if __name__ == "__main__":
    sym = sys.argv[1] if len(sys.argv) > 1 else "EURUSD"
    year = int(sys.argv[2]) if len(sys.argv) > 2 else 2024
    cfg = {"lookahead": 0, "imp_atr": 1.2, "imp_vol": 1.5, "imp_look": 5,
           "ob_age": 32, "rej_wick": 1.5, "rej_vol": 1.2, "close_zone": 0.20,
           "tp_r": 2.5, "trail": 0, "bias": "ema", "excl_hours": [6, 7, 12, 15, 19, 23]}
    res = backtest(sym, year, cfg)
    print(sym, year, res)
