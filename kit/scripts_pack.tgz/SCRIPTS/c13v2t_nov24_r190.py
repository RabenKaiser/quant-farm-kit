# -*- coding: utf-8 -*-
"""c13v2t_nov24_r190.py — relancer EURUSD 2024 config T25-A10-TR15-W15
(pf1.22) avec verbose pour inspecter les trades autour du 24/11 (grosse
perte signalee par le boss). Cherche lots anormaux / SL gap."""
import sys, json, time
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_farm as RF

OUT = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\c13v2t_nov24_r190.jsonl"
c = dict(InpMagic=756001, InpLots=0.10, InpRiskPct=0.0, InpTpR=2.5,
         InpMagLookbackH4=60, InpTrailAtrMult=1.5, InpTrailAfterR=1.0,
         InpImpulseAtrMult=0.9, InpImpulseLook=6, InpAtrPeriod=14,
         InpHtfEmaPeriod=200, InpPinWickRatio=1.5, InpCloseInZoneMin=0.15,
         InpMinStopPips=2.5, InpBufferAtrFrac=0.25, InpMaxSpreadPts=80,
         InpUseHourFilter=True, InpExcludedHoursCSV="6,7,12,15,19,23",
         InpUseDailyStop=True, InpDailyStopR=3.0, InpMaxTradesDay=0,
         InpUtcOffset=2, InpVerbose=True)
print("[r190 EURUSD 2024 verbose]", flush=True)
r = RF.run_backtest("C13V2T_EA", symbol="EURUSD", tf="M5",
                    from_d="2024.01.01", to_d="2025.01.01",
                    deposit=10000, max_wait=3600, inputs=c)
with open(OUT, "a", encoding="utf-8") as fo:
    fo.write(json.dumps({"tag": "EURUSD-2024-VERBOSE", "r": r}, default=str) + "\n")
print(json.dumps(r, default=str), flush=True)
print("FIN", flush=True)
