# -*- coding: utf-8 -*-
"""analyse_ratio_r155.py — verdict grille TP/SL (Duka 2017-2024):
classe les 10 ratios par profit pour EURUSD et GBPJPY, identifie le meilleur
EV + le risque par trade (SL en $ = 2x... non SL en xATR -> perte = SL*ATR*pip$)."""
import json, sys
import pandas as pd
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

P = r"C:\EAFarm\HISTORY - Copy\research\night_results\fix\ratio_sweep_r150.jsonl"
rows = {}
with open(P, encoding="utf-8") as f:
    for line in f:
        o = json.loads(line)
        if o["r"]:
            rows[o["tag"]] = o["r"]

for sym in ["EURUSD", "GBPJPY"]:
    print(f"===== {sym} 2017-2024 (0.1 lot) — classe par profit =====")
    tags = [(t, r) for t, r in rows.items() if t.startswith(sym)]
    tags.sort(key=lambda x: -(x[1].get("profit") or -1e9))
    for t, r in tags:
        tp = t.split("-TP")[1].split("-SL")[0]
        sl = t.split("-SL")[1]
        print(f"  TP{tp:>4}/SL{sl:>4}  p={r.get('profit'):+8.1f}  "
              f"n={r.get('trades'):4d}  pf={r.get('pf'):.2f}  "
              f"wr={r.get('wr'):5.1f}%")
print("""
LECTURE:
- EURUSD: ~0 ou negatif partout -> l'edge EURUSD Duka n'existe pas en agrege
  7 ans (quel que soit le ratio). C'etait deja vrai en carte fenetree.
- GBPJPY: TP2.0/SL1.0 = +489 (le MEILLEUR) vs TP1.0/SL2.0 actuel = +53.
  => ratio inversé (TP loin x2, SL serré x1) = 9x mieux + SL 2x plus serré
  = MOITIE MOINS de risque $ par trade. A retenir.
- Mais le VRAI fix du burn = sizing RISQUE-FIXE (InpRiskPct): quel que soit
  le ratio, la perte au SL doit etre ~1% du compte, pas x ATR x lots fixes.
""")
print("FIN", flush=True)
