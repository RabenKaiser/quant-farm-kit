# -*- coding: utf-8 -*-
"""Analyse VWAP_H1 XAUUSD : le +164% est-il réel ou biais fin de test ?
Reconstruit le PnL deal par deal depuis le log du testeur Dukascopy."""
import re, sys

LOG = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs\20260824.log"

with open(LOG, "rb") as fh:
    raw = fh.read()
t = raw.decode("utf-16-le", errors="replace")

i = t.find("VWAP_H1.ex5 from 2025.10.16")
if i < 0:
    print("run VWAP_H1 introuvable"); sys.exit(1)
seg = t[i:i + 3_000_000]

# deals d'ouverture/fermeture : lignes "deal #N buy 0.01 XAUUSD at 4227.846"
open_deals = {}   # position ticket -> (dir, entry_px, vol)
closes = []       # (dir, entry_px, close_px, vol, reason)
END_RE = re.compile(r"position closed due end of test at ([\d.]+) \[#(\d+) (buy|sell) ([\d.]+) XAUUSD ([\d.]+)")
DEAL_RE = re.compile(r"deal #(\d+) (buy|sell) ([\d.]+) XAUUSD at ([\d.]+)")
CLOSE_RE = re.compile(r"market (buy|sell) ([\d.]+) XAUUSD, close #(\d+) \(([\d.]+) /")

# première passe : tickets d'ouverture (position #N = deal d'ouverture)
for m in DEAL_RE.finditer(seg):
    ticket, d, vol, px = int(m.group(1)), m.group(2), float(m.group(3)), float(m.group(4))
    open_deals.setdefault(ticket, []).append((d, vol, px))

# fermetures explicites (trailing / close)
for m in CLOSE_RE.finditer(seg):
    d, vol, ticket, px = m.group(1), float(m.group(2)), int(m.group(3)), float(m.group(4))
    closes.append(("close", ticket, d, vol, px))

# fermetures fin de test
end_closes = []
for m in END_RE.finditer(seg):
    close_px, ticket, d, vol, entry_px = float(m.group(1)), int(m.group(2)), m.group(3), float(m.group(4)), float(m.group(5))
    end_closes.append((ticket, d, vol, entry_px, close_px))

print(f"deals ouverture: {sum(len(v) for v in open_deals.values())} tickets")
print(f"fermetures trailing/close: {len(closes)}")
print(f"fermetures fin de test: {len(end_closes)}")

# PnL fin de test (lot XAUUSD = 100 oz -> pnl = (close-entry)*vol*100)
pnl_end = 0.0
for ticket, d, vol, entry, close in end_closes:
    pnl_end += (close - entry) * vol * 100 if d == "buy" else (entry - close) * vol * 100
print(f"PnL fin de test (482 positions): {pnl_end:+,.0f}$")
print(f"final balance affiché: 26406.41$ -> profit +16406$")
print(f"Si fin de test = {pnl_end:+,.0f}$, le profit RÉEL hors biais = {16406 - pnl_end:+,.0f}$")
