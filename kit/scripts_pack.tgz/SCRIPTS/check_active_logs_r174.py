# -*- coding: utf-8 -*-
"""check_active_logs_r174.py — lister les runs dans le log actif Farm."""
import sys, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
lp = os.path.join(LOGD, "20260908.log")
print("taille:", os.path.getsize(lp))
runs = F.parse_stream(lp, "V3INT")
for key, data in runs.items():
    closed = [t for t in data["trades"].values() if t["close"] is not None]
    print(f"n={len(closed):4d} bal={data.get('balance'):8.0f} | {key[:70]}")
print("FIN", flush=True)
