# -*- coding: utf-8 -*-
"""DIVERGENCE RSI MULTI-TRAME -- le point 3 de l'objectif, applique a la meilleure famille.

POURQUOI. L'objectif exige que la famille mesuree soit aussi testee EN MULTI-TRAME : « filtre de
tendance sur une trame, entree sur une autre ». Le multi-trame avait ete teste sur la VWAP et rejete
(les trois filtres degradaient le signal : -0,2719 sans filtre, -0,2890 en tendance, -0,4275 en
z-score, -0,3792 en range). Il n'avait jamais ete teste sur la divergence RSI, qui est aujourd'hui la
famille au meilleur attendu (HKG.IDX M30 vente +0,4961 au stop de 1,5 ATR, six annees positives sur
six) et la plus grosse pourvoyeuse de volume.

CE QUI EST MESURE. Le signal reste la divergence RSI sur la trame d'ENTREE ; on ajoute une condition
de tendance lue sur la trame LENTE (facteur 2 ou 4), sur la DERNIERE BARRE LENTE FERMEE -- la regle
de causalite du round 470 : prendre la barre lente qui contient l'instant du signal revient a lire un
prix futur (cela avait rendu 84 % de gagnantes a 1 R, une impossibilite). Trois modes :
  aucun    : reference, aucune condition supplementaire ;
  tendance : le prix de la trame lente est du bon cote de son EMA200 (vente seulement sous l'EMA,
             achat seulement au-dessus) ;
  contre   : l'inverse du precedent -- on verifie aussi que le filtre n'est pas simplement un
             retournement de signe.

Env : PAIRES, TF_MIN, FACTEUR, STOPS, RRS, TENUE, SORTIE.
"""
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

B = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
import barrieres_m1 as BM                      # noqa: E402
import crible_indicateurs as CI                # noqa: E402
import crible_payoff as CP                     # noqa: E402
import geometrie_candidats as GC               # noqa: E402

SORTIE = B / os.environ.get("SORTIE", "DIVERGENCE_MTF.csv")
PAIRES = [x for x in os.environ.get("PAIRES", "HKG.IDX,USA30.IDX,DEU.IDX").split(",") if x]
TF_MIN = int(os.environ.get("TF_MIN", "30"))
FACTEURS = [int(x) for x in os.environ.get("FACTEURS", "2,4").split(",")]
STOPS = [float(x) for x in os.environ.get("STOPS", "1.5,3").split(",")]
TENUE = int(os.environ.get("TENUE", "64"))


def tendance_lente(M, Mf, minutes_base, minutes_filtre):
    """Pour chaque barre de M : (prix de la derniere barre lente fermee, son EMA200)."""
    k = CP._derniere_barre_fermee(M, Mf, minutes_base, minutes_filtre)
    cl = Mf["c"]
    e200 = CI.ema(cl, 200)
    prix = np.where(k >= 0, np.where(k < len(cl), cl[np.clip(k, 0, len(cl) - 1)], np.nan), np.nan)
    ema_l = np.where(k >= 0, np.where(k < len(e200), e200[np.clip(k, 0, len(e200) - 1)], np.nan), np.nan)
    return prix, ema_l


def main():
    print("DIVERGENCE RSI MULTI-TRAME | entree M%d | trame lente x%s | tenue %d | stops %s"
          % (TF_MIN, FACTEURS, TENUE, STOPS))
    lignes = []
    for p in PAIRES:
        corpus = "m1_ext" if p in CI.CORPUS_EXT else "m1_pos"
        M = BM.charge_tf(p, corpus, minutes=TF_MIN)
        if M is None:
            print("  %-10s corpus absent" % p)
            continue
        base = [s for s in CI.signaux(M, p) if s[0] == "RSI_DIV"]
        if not base:
            continue
        for facteur in FACTEURS:
            mf_min = TF_MIN * facteur
            Mf = BM.charge_tf(p, corpus, minutes=mf_min)
            if Mf is None:
                continue
            prix, ema_l = tendance_lente(M, Mf, TF_MIN, mf_min)
            for stop_atr in STOPS:
                for tag, idx_sig, sens in base:
                    variantes = {"aucun": idx_sig}
                    if sens == "S":
                        variantes["tendance"] = np.array([i for i in idx_sig
                                                          if np.isfinite(ema_l[i]) and prix[i] < ema_l[i]])
                        variantes["contre"] = np.array([i for i in idx_sig
                                                        if np.isfinite(ema_l[i]) and prix[i] > ema_l[i]])
                    else:
                        variantes["tendance"] = np.array([i for i in idx_sig
                                                          if np.isfinite(ema_l[i]) and prix[i] > ema_l[i]])
                        variantes["contre"] = np.array([i for i in idx_sig
                                                        if np.isfinite(ema_l[i]) and prix[i] < ema_l[i]])
                    for mode, idx_v in variantes.items():
                        if len(idx_v) < 40:
                            continue
                        m = GC.mesure_geo(M, idx_v, sens, stop_atr, 2.0)
                        if m is None:
                            continue
                        lignes.append(dict(paire=p, entree=TF_MIN, lente=mf_min, sens=sens, mode=mode,
                                           stop=stop_atr, n=m["n"], R=m["R"], cout=m["cout"],
                                           attendu=m["attendu"], gagn=m["gagn"],
                                           annees=" ".join("%d %+.3f" % (y, v) for y, v in m["ans"].items())))
    if not lignes:
        print("  aucune mesure")
        return 1
    df = pd.DataFrame(lignes).sort_values("attendu", ascending=False)
    df.to_csv(SORTIE, index=False, encoding="utf-8")
    print("\n  %d mesures -> %s" % (len(df), SORTIE.name))
    print("\n  === EFFET DU FILTRE (attendu moyen, n >= 40) ===")
    g = df[df.n >= 40].groupby("mode").agg(mesures=("attendu", "size"), attendu=("attendu", "mean"),
                                           positifs=("attendu", lambda s: int((s > 0).sum())))
    for mode, row in g.sort_values("attendu", ascending=False).iterrows():
        print("  %-9s %3d mesures | attendu moyen %+.4f | positifs %d" % (mode, row.mesures, row.attendu, row.positifs))
    print("\n  === MEILLEURES JAMBES (n >= 40) ===")
    for _, x in df[df.n >= 40].head(12).iterrows():
        print("  %-10s M%-3d lente M%-4d %s %-8s stop %.1f n=%4d attendu=%+.4f | %s"
              % (x.paire, x.entree, x.lente, x.sens, x.mode, x.stop, x.n, x.attendu, x.annees[:80]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
