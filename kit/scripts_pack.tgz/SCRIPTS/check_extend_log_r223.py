# -*- coding: utf-8 -*-
"""check_extend_log_r223.py — verifier ce que le parser voit sur le run
MT5 extend: les fermetures par l EA sont-elles comptees comme pertes ?"""
import sys, os, glob
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
lp = os.path.join(LOGD, "20260909.log")
if not os.path.exists(lp):
    logs = sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime, reverse=True)
    lp = logs[0]
print("log:", os.path.basename(lp), os.path.getsize(lp))
runs = F.parse_stream(lp, "C13V2")
for key, data in runs.items():
    closed = [t for t in data["trades"].values() if t["close"] is not None]
    if len(closed) < 20:
        continue
    cats = {}
    for t in closed:
        c = F.categorize(t)
        cats[c] = cats.get(c, 0) + 1
    print(f"{key[:60]} n={len(closed)} bal={data.get('balance'):.0f}")
    print(f"   categories: {cats}")
    # quelques pnl
    pnls = [round(F.pnl_usd(t), 1) for t in closed[:10]]
    print(f"   pnl 10 premiers: {pnls}")
    # champs d'un trade
    t0 = closed[0]
    print(f"   champs: {sorted(t0.keys())}")
    print(f"   ex: {t0}")
