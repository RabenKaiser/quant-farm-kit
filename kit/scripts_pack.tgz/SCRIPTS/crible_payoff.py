"""crible_payoff : chercher un MEILLEUR edge, pas seulement plus de paires.

Round 469. La piste « plus de paires avec le meme signal » plafonne a x3,4 de volume (roadmap du round
467). L'objectif demande 4 a 5 %/mois avec 70 % de chances de passer, et la formulation qui y mene
naturellement est celle de l'utilisateur : **peu de transactions, gros rapports** -- trois transactions par
jour a 1:3 ou 1:5. Le critere de composition n'est ni le R/tx ni le taux de gagnantes, c'est

    theta  ∝  (mu / sigma^2) x n        (mu = R/tx, n = transactions par mois)

Un signal qui ne paie qu'a 1 R a besoin d'enormement de transactions pour le meme theta ; un signal qui
paie a 4 R en a besoin de seize fois moins a mu egal. Ce script mesure donc, sur le corpus et avec le
moteur honnete, DEUX familles et QUATRE rapports risque/rendement :

  1. RETOUR A LA MOYENNE (le creneau SR97 de la session) : vendre au sommet du range, acheter au fond ;
  2. MOMENTUM (le MIROIR, jamais mesure jusqu'ici) : acheter la cassure du sommet, vendre la cassure du
     fond. C'est la famille des 1:5 -- taux de gagnantes faible, gains gros -- et elle est structurellement
     DECORRELEE du retour a la moyenne : quand l'une perd, l'autre gagne souvent.

Sortie : CRIBLE_PAYOFF.csv + classement par theta (mu/sigma2 x n), en R/tx, avec les annees positives.
Env : SLR=3 TPRS=3,6,9,12 SEUIL=0.97 HOLD=64 PAIRES=... CORPUS=m1_pos
"""
import csv
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import barrieres_m1 as BM  # noqa: E402
import spread_barrieres as SB  # noqa: E402

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
CORPUS = os.environ.get("CORPUS", "m1_pos")
SORTIE = B / os.environ.get("SORTIE", "CRIBLE_PAYOFF.csv")
SLR = float(os.environ.get("SLR", "3"))
TPRS = [float(x) for x in os.environ.get("TPRS", "3,6,9,12").split(",")]
SEUIL = float(os.environ.get("SEUIL", "0.97"))
HOLD = int(os.environ.get("HOLD", "64"))
# ROUND 493 : LA TRAME DEVIENT UN PARAMETRE. Tout le crible etait en M30 (charge_m30 en dur) : les familles
# n'ont donc jamais ete vues en M15 ni en H1, alors que le cout en R vaut spread / (stop x ATR DE LA TRAME)
# et que l'ATR change d'un facteur 2 entre M15 et M30 -- donc le classement des couples change avec la
# trame. TF_MIN=15 avec HOLD=128 donne la meme detention que M30/HOLD=64 (32 h), ce qui rend les deux
# cribles comparables.
TF_MIN = int(os.environ.get("TF_MIN", "30"))
RANGE = int(os.environ.get("RANGE", "50"))
PAIRES = [x for x in os.environ.get("PAIRES", "").split(",") if x]
BIAIS = os.environ.get("BIAIS", "aucun")           # aucun | vwap | ema200 | h4
FACTEUR_BIAS = float(os.environ.get("FACTEUR_BIAS", "8"))   # 8 x 30 min = H4
SEUIL_BIAIS = float(os.environ.get("SEUIL_BIAIS", "0"))
CLASSE = {"XAUUSD": "OR", "XAGUSD": "OR", "SPXUSD": "INDICE", "NSXUSD": "INDICE", "UDXUSD": "INDICE",
          "USA500.IDX": "INDICE", "USATECH.IDX": "INDICE", "DOLLAR.IDX": "INDICE"}
OFFSETS = {"FX": (0.0602, 0.1360), "OR": (0.0, 0.0), "INDICE": (0.0, 0.0)}


def mesure_dir(M, sig, sens, tpr, slr=SLR):
    """Mesure honnete d'une liste de signaux dans une direction donnee.

    ROUND 541 : filtre horaire OPTIONNEL via l'env HOUR_SCOPE ("13-15,15-17", heures serveur) --
    la Market Map (MARKET_MAP_15.md) a mesure OU le marche deplace ; ce filtre permet aux cribles
    qui partagent cet evaluateur de tester leurs familles scopees aux fenetres de deplacement
    (tendance) ou aux marches morts (mean-reversion), sans modification de chaque crible.
    """
    if sig is None or len(sig) < 12:
        return None
    scope = os.environ.get("HOUR_SCOPE", "")
    if scope:
        if M.get("idx") is not None:
            hrs = np.asarray(M["idx"].hour)
        else:
            hrs = pd.to_datetime(pd.Series(M["t"]), unit="s").dt.hour.values
        msk = np.zeros(len(hrs), dtype=bool)
        for bloc in scope.split(","):
            a_, _, b_ = bloc.partition("-")
            msk |= (hrs >= int(a_)) & (hrs < int(b_))
        sig = sig[msk[sig]]
        if sig is None or len(sig) < 12:
            return None
    idx, o, a = M["idx"], M["o"], M["a"]
    ent = sig + 1
    ent = ent[ent < len(idx) - HOLD - 2]
    res = []
    for k in ent:
        st = float(a[k - 1])
        if not np.isfinite(st) or st <= 0:
            continue
        r = BM.issue(M["m1"], int(pd.Timestamp(idx[k]).timestamp()), float(o[k]),
                     st, tpr, slr, HOLD * TF_MIN, sens, par_barres=True)
        if r is not None:
            res.append((k, r))
    if len(res) < 12:
        return None
    ent = np.array([k for k, _ in res])
    kind = np.array([r[0] for _, r in res])
    R = np.array([r[1] for _, r in res])
    garde = SB.bloque(idx, ent, R, kind)
    if len(garde) < 12:
        return None
    R, kind = R[garde], kind[garde]
    ans = defaultdict(list)
    for k, r_ in zip(garde, R):
        ans[idx[ent[k]].year].append(r_)
    aok = a[np.isfinite(a) & (a > 0)]
    cout = float(np.median(M["spr"][np.isfinite(M["spr"])]) / np.median(aok)) / slr if len(aok) else np.nan
    return dict(n=len(R), R=float(np.mean(R)), sd=float(np.std(R, ddof=1)),
                gagn=100.0 * float(np.mean(kind == 0)), cout=cout,
                n_an=len(ans), n_pos=sum(1 for v in ans.values() if np.mean(v) > 0),
                ans={y: round(float(np.mean(v)), 4) for y, v in sorted(ans.items())})


def _derniere_barre_fermee(M, Mf, minutes_base, minutes_filtre):
    """Pour chaque barre de M, l'index de la derniere barre de Mf DEJA CLOTUREE a sa cloture.

    Regle de causalite du projet (round 470) : prendre la barre lente qui CONTIENT l'instant du signal
    revient a lire un prix futur -- cela avait rendu 84 % de gagnantes a 1 R, une impossibilite.
    """
    clos = Mf["idx"].values + np.timedelta64(int(minutes_filtre), "m")
    t = M["idx"].values + np.timedelta64(int(minutes_base), "m")
    return np.searchsorted(clos, t, side="right") - 1


def familles(M, Mf=None):
    """Les quatre combinaisons : (retour a la moyenne, momentum) x (sommet, fond).

    BIAIS choisit le filtre de contexte, parmi ceux que l'EA SAIT DEJA appliquer (champ BIAIS de la ligne
    de jeu) :
      aucun  : reference ;
      vwap   : signe de l'ecart a la VWAP de session M30 -- mesure au round 471 : REDONDANT avec le
               declencheur CREST (un sommet de range est au-dessus de la VWAP du jour par construction) ;
      ema200 : signe du prix par rapport a l'EMA200 de la MEME trame (biais EMA200 de l'EA) ;
      h4     : tendance de la trame HAUTE (close H4 vs son EMA50, biaise Gaussien H4 de l'EA), lue sur la
               derniere barre H4 FERMEE -- c'est le multi-trame qui n'est PAS redondant avec le signal.
    """
    SB.RANGE, SB.HOLD, SB.SEUIL, SB.MOM = RANGE, HOLD, SEUIL, 2.0
    haut = SB.signaux(M)          # sommet du range
    bas = SB.signaux_long(M)      # fond du range
    if BIAIS != "aucun":
        c, h, l, idx = M["c"], M["h"], M["l"], M["idx"]
        if BIAIS == "vwap":
            tp = (h + l + c) / 3.0
            jour = pd.Series(idx.date).values
            cum = pd.Series(tp).groupby(jour).cumsum().values
            cnt = pd.Series(tp).groupby(jour).cumcount().values + 1.0
            etat = np.where(c - cum / cnt > SEUIL_BIAIS, 1, -1)
        elif BIAIS == "ema200":
            ema = pd.Series(c).ewm(span=200, min_periods=50).mean().values
            etat = np.where(c > ema, 1, -1)
        elif BIAIS == "h4" and Mf is not None:
            ema = pd.Series(Mf["c"]).ewm(span=50, min_periods=20).mean().values
            etat_f = np.where(Mf["c"] > ema, 1, -1)
            pos = _derniere_barre_fermee(M, Mf, 30, int(FACTEUR_BIAS * 30))
            etat = np.where((pos >= 0) & (pos < len(etat_f)), etat_f[np.clip(pos, 0, len(etat_f) - 1)], 0)
            print("      (biais H4 : %d barres lentes)" % len(Mf["idx"]))
        else:
            etat = np.zeros(len(c), dtype=int)
        # VENTE au sommet si le contexte est baissier (-1) ; ACHAT au fond si haussier (+1).
        haut = haut[etat[haut] < 0]
        bas = bas[etat[bas] > 0]
    return {"MR-S": (haut, "S"), "MR-L": (bas, "L"), "MOM-L": (haut, "L"), "MOM-S": (bas, "S")}


def main():
    pairs = PAIRES or sorted(p.name[:-7] for p in (B / CORPUS).glob("*_M1.csv"))
    print("%s : %d paires | range %d | seuil %.2f | stop %.1f ATR | cibles %s ATR (=%s R)"
          % (CORPUS, len(pairs), RANGE, SEUIL, SLR, TPRS, ["%.0f" % (t / SLR) for t in TPRS]))
    print("%-9s %6s %3s %5s %5s %8s %8s %7s %8s %8s | %9s %9s" %
          ("paire", "famille", "s", "tpr", "n", "R/tx", "sigma", "gagn%", "mu/s2", "coutR",
           "attendu", "theta/an"))
    lignes = []
    for p in pairs:
        M = BM.charge_m30(p, CORPUS) if TF_MIN == 30 else BM.charge_tf(p, CORPUS, minutes=TF_MIN)
        if M is None:
            print("  %-9s corpus absent" % p)
            continue
        Mf_biais = BM.charge_tf(p, CORPUS, minutes=int(FACTEUR_BIAS * 30)) if BIAIS == "h4" else None
        if BIAIS == "h4" and Mf_biais is None:
            print("  %-9s trame lente indisponible" % p)
            continue
        fam = familles(M, Mf_biais)
        # ROUND 471 : le corpus etendu porte les noms du COURTIER (USA500.IDX...), pas ceux du corpus
        # d'origine : tout symbole en .IDX est un indice, et les indices se mesurent sans decote (le
        # corpus ne porte aucun spread CFD pour eux -- l'or, ou le spread est renseigne, a lui aussi un
        # offset mesure NUL sur ordres reels).
        cls = "INDICE" if p.endswith(".IDX") else CLASSE.get(p, "FX")
        for nom, (sig, sens) in fam.items():
            for tpr in TPRS:
                m = mesure_dir(M, sig, sens, tpr)
                if m is None or m["sd"] <= 0:
                    continue
                off = OFFSETS[cls][0 if sens == "S" else 1]
                att = m["R"] - off
                theta = max(att, 0.0) ** 2 * m["n"] / m["sd"] ** 2 / 6.0   # par an
                lignes.append(dict(paire=p, famille=nom, sens=sens, tpr=tpr, n=m["n"], R=m["R"],
                                   sigma=m["sd"], gagn=m["gagn"], mus2=m["R"] / m["sd"] ** 2,
                                   cout=m["cout"], attendu=att, theta=theta,
                                   npos=m["n_pos"], nan=m["n_an"],
                                   annees=" ".join("%d %+.2f" % (y, v) for y, v in m["ans"].items())))
                print("  %-9s %6s %s %5.0f %5d %+8.4f %8.2f %6.1f %8.3f %8.3f | %+9.4f %9.2f"
                      % (p, nom, sens, tpr / SLR, m["n"], m["R"], m["sd"], m["gagn"],
                         m["R"] / m["sd"] ** 2, m["cout"], att, theta), flush=True)
        del M
    if not lignes:
        print("  aucun resultat")
        return 1
    with SORTIE.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(lignes[0].keys()))
        w.writeheader()
        w.writerows(lignes)
    bon = [x for x in lignes if x["attendu"] > 0 and x["npos"] >= 2 * x["nan"] / 3.0]
    print("\n=== %d mesures | %d a attendu > 0 ET >= 2/3 annees positives ===" % (len(lignes), len(bon)))
    print("  MEILLEUR APPORT DE CHEMIN (theta = mu^2 x n / sigma^2 par an) :")
    for x in sorted(bon, key=lambda z: -z["theta"])[:15]:
        print("    %-9s %-6s %s %4.0fR n=%4d | attendu %+.4f | mu/s2 %6.3f | gagn %4.1f %% | annees %s"
              % (x["paire"], x["famille"], x["sens"], x["tpr"] / SLR, x["n"], x["attendu"],
                 x["mus2"], x["gagn"], "%d/%d" % (x["npos"], x["nan"])))
    print("\n  PAR FAMILLE (theta cumule, puis meilleur couple) :")
    for nom in ("MR-S", "MR-L", "MOM-L", "MOM-S"):
        g = [x for x in bon if x["famille"] == nom]
        if not g:
            print("    %-6s : aucun couple retenu" % nom)
            continue
        best = max(g, key=lambda z: z["theta"])
        print("    %-6s : %2d couples | theta cumule %7.2f | meilleur %s %s %3.0fR theta %6.2f"
              % (nom, len(g), sum(x["theta"] for x in g), best["paire"], best["sens"],
                 best["tpr"] / SLR, best["theta"]))
    print("\n  -> %s" % SORTIE.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
