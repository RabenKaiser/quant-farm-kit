# -*- coding: utf-8 -*-
"""bilan_nuit.py — LES LOTS DE LA NUIT MT5, RAMENES EN R PAR TRANSACTION.

POURQUOI CE SCRIPT (18/09, 17 h)
--------------------------------
La boucle de nuit lance des tests en ORDRES REELS sur MT5 et ecrit, pour chaque
test, un fichier par_farm_<tag>.jsonl contenant le PnL total et le nombre de
transactions. Mais un PnL en dollars ne se compare PAS a un R de laboratoire :
il depend de la taille du lot, de la valeur du pip et du nombre de
combinaisons actives en meme temps.

Ce script convertit, pour chaque lot :
    R par transaction = PnL / transactions / (1R en USD)
ou 1R = InpSLatr x ATR x valeur du pip pour 0.10 lot -- c'est-a-dire la perte
theorique d'un stop touche. C'est la seule unite comparable entre le labo
Python et les ordres reels.

Il rapproche ensuite ces valeurs des chiffres de la simulation Python pour la
meme mecanique, ce qui donne l'ECART PYTHON/REEL -- le chiffre que l'utilisateur
soupconne d'etre trop grand, et qui decide si une piste est exploitable.

USAGE : python bilan_nuit.py
"""
import collections
import json
import statistics
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")

# 1R en USD pour 0.10 lot = SL(ATR) x ATR en pips x valeur du pip
ATR_PIPS = {"EURUSD": 3.1, "EURJPY": 7.6, "USDJPY": 7.3, "GBPJPY": 9.4,
            "AUDJPY": 5.4, "USDCAD": 3.5, "NZDUSD": 2.6, "CADJPY": 5.3}
PIP_USD = {"EURUSD": 1.0, "EURJPY": 0.68, "USDJPY": 0.68, "GBPJPY": 0.68,
           "AUDJPY": 0.68, "USDCAD": 0.73, "NZDUSD": 0.60, "CADJPY": 0.73}
# lots de la nuit : tag -> (jeu, stop ATR, duree, paire)
LOTS = {
    "bbmini": ("bb_mini (Bollinger 2 sigma)", 2.0, 48, "EURUSD"),
    "bb2": ("bb_mini, stop large / objectif proche", 3.0, 48, "EURUSD"),
    "bb3": ("bb_mini, detention 8 h", 2.0, 96, "EURUSD"),
    "bb4": ("bb_extreme (3 et 4 sigma)", 2.0, 48, "EURUSD"),
    "bb5": ("bb_mini sur EURJPY", 2.0, 48, "EURJPY"),
}
# ce que la SIMULATION PYTHON annoncait pour la meme mecanique
PYTHON = {"bbmini": 0.0183, "bb2": None, "bb3": None, "bb4": None, "bb5": -0.0159}


def main():
    print("=" * 100)
    print("LES LOTS DE LA NUIT MT5 — R PAR TRANSACTION EN ORDRES REELS")
    print("=" * 100)
    print("   %-8s %-36s %9s %8s %10s %9s %9s"
          % ("tag", "jeu", "trans.", "PnL USD", "R/tx reel", "R/tx py", "ecart"))
    print("   " + "-" * 94)
    tous = []
    for tag, (nom, sl, hold, sym) in LOTS.items():
        p = BASE / ("par_farm_%s.jsonl" % tag)
        if not p.exists():
            print("   %-8s %-36s  (pas encore de resultat)" % (tag, nom[:36]))
            continue
        lignes = []
        for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.strip().startswith("{"):
                try:
                    lignes.append(json.loads(line))
                except ValueError:
                    pass
        if not lignes:
            continue
        tx = sum(x.get("trades", 0) for x in lignes)
        pnl = sum(x.get("total", 0.0) for x in lignes)
        if not tx:
            continue
        un_r = sl * ATR_PIPS.get(sym, 3.0) * PIP_USD.get(sym, 1.0)
        r = pnl / tx / un_r if un_r else 0
        py = PYTHON.get(tag)
        ec = ("%+.4f" % (r - py)) if py is not None else "-"
        tous.append((tag, nom, tx, pnl, r, py))
        print("   %-8s %-36s %9d %+8.0f %+10.4f %9s %9s"
              % (tag, nom[:36], tx, pnl, r,
                 ("%+.4f" % py) if py is not None else "-", ec))
    print()
    if tous:
        r_tot = sum(t[4] * t[2] for t in tous)
        tx_tot = sum(t[2] for t in tous)
        print("   AGREGAT DES LOTS : %+.4f R par transaction sur %d transactions"
              % (r_tot / tx_tot, tx_tot))
        print()
    print("   LECTURE")
    print("   Le chiffre qui compte est la colonne R/tx reel : c'est le seul")
    print("   comparable au laboratoire. Si la simulation Python annoncait")
    print("   +0.018 et que le reel donne -0.02, l'ecart mesure vaut -0.04 R")
    print("   par transaction : c'est le prix de l'execution (spread paye,")
    print("   glissement, swap), et aucun reglage ne le supprime.")
    print()
    print("   DETAIL PAR PERIODE")
    for tag, (nom, sl, hold, sym) in LOTS.items():
        p = BASE / ("par_farm_%s.jsonl" % tag)
        if not p.exists():
            continue
        lignes = []
        for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.strip().startswith("{"):
                try:
                    lignes.append(json.loads(line))
                except ValueError:
                    pass
        if not lignes:
            continue
        un_r = sl * ATR_PIPS.get(sym, 3.0) * PIP_USD.get(sym, 1.0)
        print("   --- %s (%s) ---" % (tag, nom))
        for x in lignes:
            tx = x.get("trades", 0)
            if not tx:
                continue
            print("      %-8s %6d tx  %+9.0f USD  ->  %+.4f R/tx"
                  % (x.get("quarter"), tx, x.get("total", 0),
                     x.get("total", 0) / tx / un_r))


if __name__ == "__main__":
    main()
