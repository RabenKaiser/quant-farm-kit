# -*- coding: utf-8 -*-
"""CORRÉLATION CROISÉE entre mécanismes DISTINCTS + portfolio combiné.
Extrait les courbes mensuelles :
  - PTRAIL long (GBPUSD+EURUSD+USDJPY25) : déjà dans ptrail_curve.json
  - MFR short GBPUSD (R4VA7, 2023-2026) : depuis le log Dukascopy
  - edge_6E EURUSD (2024/2025 + oct-dec 2025)
Puis : matrice de corrélation + DD du portefeuille combiné avec poids."""
import re, json
import numpy as np
from collections import defaultdict

LOG = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs\20260824.log"
with open(LOG, "rb") as fh:
    t = fh.read().decode("utf-16-le", errors="replace")

LOT = {"EURUSD": 100000, "GBPUSD": 100000, "USDJPY": 100000}
def pnl_usd(sym, dir_, vol, entry, close):
    delta = (close - entry) if dir_ == "buy" else (entry - close)
    if sym == "USDJPY":
        return delta * vol * LOT[sym] / 150.0
    return delta * vol * LOT[sym]

def extract_curve(sym, ea, y0, y1, quality_ok=True):
    """Extrait la courbe mensuelle d'un run (dernière exécution)."""
    pat = re.compile(rf"{sym},\w+[^\r\n]*?testing of Experts\\{ea}\.ex5 from {y0}\.01\.01 00:00 to {y1}\.01\.01 00:00")
    hits = [m.start() for m in pat.finditer(t)]
    if not hits:
        return None
    idx = hits[-1]
    nxt = t.find("testing of", idx + len(f"testing of Experts\\{ea}.ex5 from {y0}.01.01 00:00 to {y1}.01.01 00:00"))
    seg_end = nxt if nxt > idx else min(idx + 6_000_000, len(t))
    seg = t[idx:seg_end]
    # qualité
    qm = re.search(r"quality of analyzed history is (\d+)%", seg[:4000])
    qq = int(qm.group(1)) if qm else -1
    entries = {}
    for mm in re.finditer(r"(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s+deal #(\d+) (buy|sell) ([\d.]+) " + sym +
                          r" at ([\d.]+) done", seg):
        entries[int(mm.group(2))] = (mm.group(3), float(mm.group(4)), float(mm.group(5)))
    closes = []
    for mm in re.finditer(r"(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s+(?:stop loss|take profit) triggered #(\d+) [^\r\n]*?\[#\d+ (buy|sell) ([\d.]+) " + sym +
                          r" at ([\d.]+)\]", seg):
        closes.append((mm.group(1), int(mm.group(2)), mm.group(3), float(mm.group(4)), float(mm.group(5))))
    ends = re.findall(r"position closed due end of test at ([\d.]+) \[#(\d+) (buy|sell) ([\d.]+) " + sym +
                      r" ([\d.]+)\]", seg)
    monthly = defaultdict(float)
    for tm, tk, cdir, cvol, cpx in closes:
        if tk in entries:
            edir, evol, eprice = entries[tk]
            monthly[tm[:7].replace(".", "-")] += pnl_usd(sym, edir, evol, eprice, cpx)
    # fin de test -> dernier mois (biais, on le signale)
    for cpx, tk, dir_, vol, eprice in ends:
        monthly["END"] += pnl_usd(sym, dir_, float(vol), float(eprice), float(cpx))
    return {"quality": qq, "monthly": dict(monthly)}

print("Extraction des courbes...", flush=True)

# 1. PTRAIL long (déjà calculé) — normaliser les clés en "YYYY-MM"
pc = json.load(open(r"C:\EAFarm\HISTORY - Copy\research\night_results\ptrail_curve.json"))
ptrail_monthly = {}
for ym, p, e, d in pc["curve"]:
    # ym = ['2023', '2023.01'] -> clé '2023-01'
    mm = ym[1].split(".")[1]
    ptrail_monthly[f"{ym[0]}-{mm}"] = p

# 2. MFR short GBPUSD 2023-2026 — normaliser "2023-01" -> "2023-01"
mfr = extract_curve("GBPUSD", "MFR_FORGE2_R4VA7", "2023", "2026")
if mfr:
    print(f"MFR GBPUSD: qualité={mfr['quality']}% mois={len(mfr['monthly'])}", flush=True)
    mfr_monthly = {}
    for k, v in mfr["monthly"].items():
        if k != "END":
            mfr_monthly[k] = v   # k est déjà "2023-01"
else:
    mfr_monthly = {}

# 3. edge_6E EURUSD (runs annuels 2024, 2025) — normaliser "2024-01" -> "2024-01"
e6 = {}
for y in ["2024", "2025"]:
    r = extract_curve("EURUSD", "EDGE_6E", y, str(int(y) + 1))
    if r:
        for k, v in r["monthly"].items():
            if k != "END":
                e6[k] = v   # k déjà "2024-01"
print(f"edge_6E: mois={len(e6)}", flush=True)

# matrice de corrélation sur les mois communs
def corr(d1, d2):
    keys = sorted(set(d1) & set(d2))
    if len(keys) < 5:
        return None, len(keys)
    a = np.array([d1[k] for k in keys]); b = np.array([d2[k] for k in keys])
    if a.std() == 0 or b.std() == 0:
        return 0.0, len(keys)
    return float(np.corrcoef(a, b)[0, 1]), len(keys)

print("\n=== MATRICE DE CORRÉLATION MENSUELLE ===")
for name, d in [("PTRAIL-long", ptrail_monthly), ("MFR-short", mfr_monthly), ("edge_6E", e6)]:
    print(f"\n{name}: {len(d)} mois")
    for name2, d2 in [("PTRAIL-long", ptrail_monthly), ("MFR-short", mfr_monthly), ("edge_6E", e6)]:
        if name < name2:
            c, n = corr(d, d2)
            cs = "n/a" if c is None else f"{c:+.2f}"
            print(f"  {name} vs {name2}: r={cs} (n={n} mois)")

# portfolio combiné (mêmes poids, mois communs)
all_keys = sorted(set(ptrail_monthly) | set(mfr_monthly) | set(e6))
print(f"\n=== PORTFOLIO COMBINÉ (PTRAIL + MFR + edge_6E, poids égaux normalisés) ===")
combined = {}
for k in all_keys:
    vals = []
    if k in ptrail_monthly: vals.append(ptrail_monthly[k])
    if k in mfr_monthly: vals.append(mfr_monthly[k] * 0.3)   # MFR petit poids (edge faible)
    if k in e6: vals.append(e6[k] * 0.3)
    if vals:
        combined[k] = sum(vals)
keys = sorted(combined)
eq, peak, maxdd = 0, 0, 0
for k in keys:
    eq += combined[k]; peak = max(peak, eq); maxdd = max(maxdd, peak - eq)
print(f"mois: {len(keys)} | total: {sum(combined.values()):+,.0f}$ | DD: {maxdd:+,.0f}$ | R/DD: {sum(combined.values())/maxdd:.2f}")
print(f"(DD portfolio PTRAIL seul était 4203$ -> combiné {maxdd:.0f}$)")
json.dump({"ptrail": ptrail_monthly, "mfr": mfr_monthly, "e6": e6, "combined": combined},
          open(r"C:\EAFarm\HISTORY - Copy\research\night_results\correlation_matrix.json", "w"), indent=1)
print("sauvé: correlation_matrix.json")
