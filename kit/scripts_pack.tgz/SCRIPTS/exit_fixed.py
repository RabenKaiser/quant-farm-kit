# -*- coding: utf-8 -*-
"""exit_fixed.py — le resultat POS survit-il SANS optimisation de sortie ?

PROBLEME (round 26, point 3)
----------------------------
`pos_build_fast.py` choisit, pour chaque signal, la MEILLEURE des 8 variantes
de sortie **en l'evaluant sur s1**. Le cache POS n'est donc pas neutre : meme
si la selection de portefeuille n'utilise pas s3, la GRILLE DE SORTIES a ete
optimisee sur s1.

Le test de nullite (round 26) tire des jambes DANS ce cache : il valide le
TRI, pas la construction des jambes.

TEST
----
On refait la mesure du portefeuille retenu en remplacant, pour chaque jambe,
la sortie optimisee par une sortie FIXEE A PRIORI. Si le R/DD tient, le
resultat ne doit rien a l'optimisation de sortie. S'il s'effondre, il faut
le dire.

Deux variantes fixees :
  - SL 1.5 / TP 99 / hold 960 / pas de trail   (la plus "neutre")
  - SL 1.0 / TP 20 / hold 192 / pas de trail   (sortie rapide)
"""
import os, sys, json, pickle, gc
import numpy as np, pandas as pd

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT, deep_lib as D

BASE = r"C:\EAFarm\HISTORY - Copy\research"
J = json.load(open(os.path.join(BASE, "honest_test.json")))
SEL = J["A"]["legs"]

FIXED = [
    ("neutral", dict(sl=1.5, trail=None, tp=99.0, hold=960)),
    ("rapide",  dict(sl=1.0, trail=None, tp=20.0, hold=192)),
]

# ---------- index du cache POS (sortie optimisee) ----------
legs_cache = {}
for f in os.listdir(os.path.join(BASE, "pos_cache")):
    if f.endswith(".pkl"):
        legs_cache.update(pickle.load(open(os.path.join(BASE, "pos_cache", f), "rb")))
print(f"{len(legs_cache)} jambes POS en cache")

# ---------- par marche : reconstruire les signaux une fois ----------
bysym = {}
for L in SEL:
    bysym.setdefault(L["sym"], []).append(L)
print(f"{len(SEL)} jambes retenues sur {len(bysym)} marches : {sorted(bysym)}")

results = {}
for name, ex in FIXED:
    print(f"\n{'='*64}")
    print(f"SORTIE FIXE : {name}  {ex}")
    print("=" * 64)
    sers = {}
    for sym, Ls in sorted(bysym.items()):
        G._cache.clear(); gc.collect()
        try:
            F = G.get_frames(sym)
        except Exception as e:
            print(f"  {sym}: frames KO {e}"); continue
        m5, m1 = F["m5"], F["m1"]
        h1z, hh, ll, a1, gb, gr = MT.h1_zones(m1, min_gap_atr=2.0, max_age_h=48)
        zd, zlo, zhi = MT.project(m5.index, h1z, hh, ll, gb, gr, max_age_h=48)
        M = NL.build(m5, F, zd, zlo, zhi); M.update(FE.more(m5, F, m1))
        T0, T3 = m5.index[0], m5.index[-1]
        for L in Ls:
            trig = L.get("trig") or L["k"].split("|")[1]
            filt = L.get("filt") or []
            try:
                s = NL.sig(M, trig, filt)
            except Exception:
                s = None
            if s is None or int((s != 0).sum()) == 0:
                print(f"  {sym}/{trig}: signal nul"); continue
            try:
                st = D.run_ex(sym, s, ex["sl"], ex["tp"], ex["hold"],
                              trail_atr=ex["trail"], t0=T0, t1=T3,
                              use_m1=False, collect=True)
            except Exception as e:
                print(f"  {sym}/{trig}: run_ex KO {e}"); continue
            if not st.get("tse"):
                continue
            ts = pd.to_datetime(st["tse"], unit="s", utc=True).normalize()
            ser = pd.Series(st["rets"], index=ts).groupby(level=0).sum()
            sers[L["k"]] = ser
            print(f"  {sym:<8}{trig:<14} n={st.get('n',0):<5} R={st.get('R',0):+8.1f}")
    results[name] = sers
    print(f"  -> {len(sers)}/{len(SEL)} jambes reconstruites")

# ---------- mesure ----------
print(f"\n{'='*64}")
print("MESURE s3 (poids egal) — comparaison")
print("=" * 64)

def measure(keys, sers, tag):
    keys = [k for k in keys if k in sers]
    if not keys:
        print(f"  {tag}: aucune jambe"); return
    DF = pd.DataFrame({k: sers[k] for k in keys}).sort_index()
    x = DF.fillna(0.0).mean(axis=1)
    n = len(x); third = n // 3
    for lab, seg in (("s1", x.iloc[:third]), ("s2", x.iloc[third:2*third]),
                     ("s3", x.iloc[2*third:])):
        eq = np.cumsum(seg); R = float(seg.sum())
        dd = float((np.maximum.accumulate(eq) - eq).max())
        mo = seg.groupby([seg.index.year, seg.index.month]).sum()
        print(f"  {tag:<26} {lab}: R={R:+8.2f} DD={dd:7.4f} "
              f"R/DD={(R/dd if dd>0 else 0):7.2f} mois+={(mo>0).mean():5.1%}")

opt = {}
for L in SEL:
    if L["k"] in legs_cache:
        opt[L["k"]] = legs_cache[L["k"]]["ser"]
measure(list(opt), opt, "CACHE (sortie optimisee)")
for name, _ in FIXED:
    measure([L["k"] for L in SEL], results[name], f"FIXE {name}")

print(f"\n{'='*64}")
print("VERDICT")
print("=" * 64)
print("  Si les sorties fixees donnent un R/DD du meme ordre que le cache,")
print("  le resultat NE DOIT RIEN a l'optimisation de sortie.")
print("  Si elles s'effondrent, l'optimisation de sortie sur s1 est le")
print("  moteur du resultat -> a signaler comme faiblesse majeure.")
