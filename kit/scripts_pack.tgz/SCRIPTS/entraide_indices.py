# -*- coding: utf-8 -*-
"""ENTRAIDE : mes mécanismes validés sur les paires du cousin (USATECH.IDX).
Le VWAP_MOMENTUM (t=4-16 sur FX) et FTR_SESS (6/6 FX) marchent-ils sur les indices ?
Si oui -> on partage les EAs avec le cousin pour renforcer son portfolio 2."""
import sys
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner as m

# VWAP_MOMENTUM sur USATECH.IDX (le symbole Farm pour US100)
for sym in ["USATECHIDXUSD"]:
    for y0, y1 in [("2024.01.01", "2025.01.01"), ("2025.01.01", "2026.01.01")]:
        r = m.run_backtest("VWAP_MOMENTUM", sym, "H1", y0, y1, 10000, max_wait=300)
        if r:
            print(f"VWAP_MOMENTUM {sym} {y0[:4]}: profit=${r.get('profit')} n={r.get('trades')} "
                  f"wr={r.get('wr')}")
        else:
            print(f"{sym} {y0[:4]}: None")
