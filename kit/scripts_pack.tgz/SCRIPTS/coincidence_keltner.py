"""LE CRIBLE KELTNER MESURE-T-IL LA MEME REGLE QUE L'EA ? (controle de coincidence, famille Keltner)

POURQUOI (28/09, 14 h). La nouvelle regle du laboratoire (`PROCESSUS_LAB.md`) dit qu'un resultat d'etage 1
ne vaut rien tant qu'on n'a pas verifie que ses **signaux sont ceux de l'etage 2**. Le controle a deja
tranche pour la divergence : le crible et l'EA ne partageaient que 13 a 21 % des entrees, et le « +0,21 du
corpus » decrivait donc une AUTRE strategie. Or la meilleure jambe du portefeuille V12 est un Keltner : il
faut savoir si les mesures Keltner du corpus parlent de la meme regle que la ligne `KELTHIGH` de l'EA.

Methode : on recalcule la regle du crible (EMA(20) +/- k x ATR(14), cassure de la bande haute pour l'achat)
sur le corpus Dukascopy de la ferme, et on la confronte aux entrees reelles de la campagne
`g3_kelt32_deu` (et de l'or), horodatage par horodatage, en cherchant le decalage horaire serveur.

Aucun terminal n'est utilise : lecture de fichiers seulement.
"""
import re
import sys
import pathlib
from datetime import datetime

import numpy as np
import pandas as pd

B = pathlib.Path(r"C:\EAFarm\HISTORY - Copy\research")
sys.path.insert(0, str(B / "SCRIPTS"))


def charge(sym, corpus, trame="15min"):
    d = pd.read_csv(B / corpus / ("%s_M1.csv" % sym))
    col = "time" if "time" in d.columns else d.columns[0]
    t = d[col]
    if t.dtype == object:
        t = pd.to_datetime(t, utc=True, errors="coerce").dt.tz_localize(None)
    else:
        t = pd.to_datetime(t, unit="s")
    df = pd.DataFrame({"t": t, "h": d["high"].values, "l": d["low"].values, "c": d["close"].values})
    df = df.set_index("t").sort_index()
    m = pd.DataFrame({"h": df["h"].resample(trame).max(), "l": df["l"].resample(trame).min(),
                      "c": df["c"].resample(trame).last()}).dropna()
    return m


def signaux_keltner(m, k=2.0, ema_n=20, atr_n=14, sens="haut"):
    c, h, l = m["c"].values, m["h"].values, m["l"].values
    ema = pd.Series(c).ewm(span=ema_n, min_periods=ema_n).mean().values
    pc = np.roll(c, 1)
    pc[0] = c[0]
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    atr = pd.Series(tr).rolling(atr_n, min_periods=atr_n).mean().values
    if sens == "haut":
        bande = ema + k * atr
        franchit = (c > bande) & (np.roll(c, 1) <= np.roll(bande, 1))
    else:
        bande = ema - k * atr
        franchit = (c < bande) & (np.roll(c, 1) >= np.roll(bande, 1))
    idx = np.flatnonzero(franchit)
    return [m.index[i] for i in idx]


def entrees_ea(fichier, sym, ligne="KELTHIGH"):
    f = B / fichier
    if not f.exists():
        return []
    out = []
    for m in re.finditer(r"(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}):\d{2}\s+ENT %s (\S+?) entree=" % re.escape(sym),
                         f.read_text(encoding="utf-8", errors="replace")):
        if m.group(2).split("|")[0] == ligne:
            out.append(datetime.strptime(m.group(1), "%Y.%m.%d %H:%M"))
    return out


def meilleure_coincidence(sig, ent, fenetre="15min"):
    """Part des entrees reelles qui tombent sur un signal du crible, decalage horaire serveur recherche."""
    best = (0, 0.0, 0)
    for dec in range(-4, 7):
        bars = {s + pd.Timedelta(hours=dec) for s in sig}
        # on tolere une barre de chaque cote (l'EA peut entrer a la cloture suivante)
        delta = pd.Timedelta(pd.Timedelta(fenetre).total_seconds(), unit="s")
        touche = 0
        for e in ent:
            t = pd.Timestamp(e)
            if any((t + k * delta).floor(fenetre) in bars for k in (-1, 0, 1)):
                touche += 1
        part = touche / len(ent)
        if part > best[1]:
            best = (dec, part, touche)
    return best


def main():
    print("=" * 118)
    print("LE CRIBLE KELTNER CONTRE LES ENTREES REELLES DE L'EA")
    print("=" * 118)
    L = ["# CONTRÔLE DE COÏNCIDENCE — FAMILLE KELTNER", "",
         "Le crible calcule EMA(20) ± k × ATR(14) et entre à la cassure de la bande haute ; l'EA a sa propre",
         "définition. On compare les horodatages, avec recherche du décalage horaire serveur et tolérance",
         "d'une barre. Sans ce contrôle, un chiffre de corpus ne décrit pas la règle qu'on déploie.", "",
         "| instrument | trame | k | signaux du crible | entrées de l'EA | coïncidence |", "|---|---|---|---|---|---|"]
    for sym, corpus, lot, sym_ea in (("DEU.IDX", "m1_ext", "raw_farm_g3_kelt32_deu.txt", "DEU.IDX"),
                                     ("XAUUSD", "m1_real", "raw_farm_g3_kelt32_xauusd.txt", "XAUUSD")):
        ent = entrees_ea(lot, sym_ea)
        ent = [e for e in ent if e.year >= 2024]
        if not ent:
            print("  %-10s aucune entree reelle trouvee" % sym)
            continue
        for trame in ("15min", "30min"):
            try:
                m = charge(sym, corpus, trame)
            except (OSError, ValueError, KeyError) as e:
                print("  %-10s corpus illisible : %s" % (sym, e))
                continue
            for k in (1.5, 2.0, 3.0):
                sig = [s for s in signaux_keltner(m, k=k) if s >= pd.Timestamp("2024-01-01")]
                if len(sig) < 20:
                    continue
                dec, part, touche = meilleure_coincidence(sig, ent, trame)
                print("  %-10s %-6s k=%.1f : %4d signaux crible | %4d entrees EA | coincidence %5.1f %% (decalage %+d h)"
                      % (sym, trame, k, len(sig), len(ent), 100 * part, dec))
                L.append("| %s | %s | %.1f | %d | %d | **%.1f %%** (décalage %+d h) |"
                         % (sym, trame, k, len(sig), len(ent), 100 * part, dec))
    L += ["", "## Ce que cela change", "",
          "Si la coïncidence est élevée (proche de 100 %), les mesures Keltner du corpus décrivent bien la",
          "règle de l'EA et peuvent servir d'étage 1. Si elle est faible, comme pour la divergence (13-21 %),",
          "alors seules les mesures en ordres réels font foi — et la meilleure jambe de V12, l'or en Keltner,",
          "ne doit sa place qu'à ses 483 transactions réelles, ce qui est de toute façon le cas."]
    (B / "COINCIDENCE_KELTNER.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n  rapport ecrit dans COINCIDENCE_KELTNER.md")


if __name__ == "__main__":
    main()
