﻿import sys, numpy as np
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import giga_lib as G, feat2 as FE, gc
for sym in ("XAUUSD","AUDUSD"):
    G._cache.clear(); gc.collect()
    F = G.get_frames(sym); m5 = F["m5"]
    M = FE.more(m5, F, F["m1"])
    n=len(m5)
    print(f"--- {sym} ({n} barres) ---")
    for k in ("at_PDH","at_PDL","at_PP","fade_PDH","fade_PDL","three_up","three_dn"):
        if k in M:
            v=np.asarray(M[k])
            if v.dtype==bool and len(v)==n:
                print(f"   {k:<10} vrai sur {100*v.mean():6.2f} %")
