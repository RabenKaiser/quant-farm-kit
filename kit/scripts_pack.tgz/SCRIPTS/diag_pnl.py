# -*- coding: utf-8 -*-
"""diag_pnl.py — D'OU VIENT LA PERTE MT5 ? (CADJPY : 144 sorties, -641.87)

CE QU'ON SAIT (mesure directe, mt5_winrate.py + diag_sl.py)
----------------------------------------------------------
  reason=3 EXPERT (maxhold) n=53  win= 81.1%  pnl=  +316.12  moy=  +5.96
  reason=4 SL              n=89  win=  0.0%  pnl= -1028.07  moy= -11.55
  reason=5 TP              n=2   win=100.0%  pnl=   +70.08  moy= +35.04
  TOTAL                                             -641.87

LECTURE CRUCIALE : les 89 SL coutent -1028, soit -11.55 chacun.
Or l'EA dimensionne les lots pour risquer ~1 R par trade
(LotsFor(sym, risk, risk)). A 0.10 lot sur CADJPY, 1 R devrait valoir
une fraction CONSTANTE du capital.

-11.55 par SL sur un compte de 100 000 = 0.0116 % par trade. C'est PETIT.
Donc ce n'est pas un probleme de sizing.

LE VRAI DESEQUILIBRE EST AILLEURS :
  89 SL x (-11.55) = -1028
  53 maxhold x (+5.96) = +316
  2 TP x (+35.04) = +70

Le ratio gain/perte est 5.96/11.55 = 0.52 ALORS QU'IL DEVRAIT ETRE
3.0/1.0 = 3.0 (TP=3R, SL=1R). Autrement dit : les trades qui finissent en
maxhold ne rapportent que 0.52 R en moyenne au lieu des 3 R attendus.

POURQUOI ? Parce que le maxhold ferme au BOUT de 4 h, au prix du marche.
Si le prix n'a pas atteint le TP, on encaisse le residuel — qui est souvent
proche de zero ou negatif. En python, le meme maxhold rend une valeur
residuelle PLUS ELEVEE... ou pas.

CE SCRIPT quantifie : sur les vraies bougies, apres un signal fvg_dn,
quelle est la distribution du R realise selon la raison de sortie ?
Et surtout : combien vaut le residuel au maxhold ?
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")


def m5(sym):
    p = BASE / "m1_pos" / f"{sym}_M1.csv"
    if not p.exists():
        return None
    df = pd.read_csv(p, usecols=["time", "open", "high", "low", "close"])
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df = df.set_index("time").sort_index()
    return pd.DataFrame({
        "open": df["open"].resample("5min").first(),
        "high": df["high"].resample("5min").max(),
        "low": df["low"].resample("5min").min(),
        "close": df["close"].resample("5min").last()}).dropna()


def atr_ewm(h, l, c, n=14):
    pc = np.roll(c, 1); pc[0] = c[0]
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    return pd.Series(tr).ewm(alpha=1/n, adjust=False).mean().to_numpy()


def detail(sym, sl_atr=2.0, tp_r=3.0, hold=48):
    d = m5(sym)
    if d is None:
        return None
    h = d["high"].to_numpy(float); l = d["low"].to_numpy(float)
    o = d["open"].to_numpy(float); c = d["close"].to_numpy(float)
    a = atr_ewm(h, l, c)
    sig = h < (np.roll(l, 2) - 1.0 * a)
    sig[:5] = False
    N = len(c)
    res = []
    last = -1
    for i in np.where(sig)[0]:
        if i <= last or i + 2 >= N:
            continue
        e = i + 1
        if not np.isfinite(a[i]) or a[i] <= 0:
            continue
        entry = o[e]
        risk = sl_atr * a[i]
        sl = entry - risk; tp = entry + tp_r * risk
        out = None
        for k in range(e, min(e + hold, N)):
            if l[k] <= sl:
                out = ("SL", -1.0); last = k; break
            if h[k] >= tp:
                out = ("TP", tp_r); last = k; break
        if out is None:
            k = min(e + hold - 1, N - 1)
            out = ("MAXHOLD", (c[k] - entry) / risk); last = k
        res.append(out)
    return res


print("=" * 92)
print("DISTRIBUTION DU R PAR RAISON DE SORTIE — python sur vraies bougies")
print("=" * 92)
print(f"{'marche':<9}{'n':>6}{'SL n':>6}{'SL R':>8}{'TP n':>6}{'TP R':>8}"
      f"{'MAX n':>7}{'MAX R':>8}{'MAX moy':>9}{'TOTAL R':>9}")
print("-" * 92)

tot = dict(n=0, sln=0, slR=0.0, tpn=0, tpR=0.0, mxn=0, mxR=0.0, R=0.0)
for sym in sorted(json.load(open(BASE / "portfolio_v2.json", encoding="utf-8"))):
    r = detail(sym)
    if not r:
        continue
    arr = np.array([(x[1]) for x in r])
    kinds = [x[0] for x in r]
    sln = kinds.count("SL"); tpn = kinds.count("TP"); mxn = kinds.count("MAXHOLD")
    slR = sum(v for k, v in r if k == "SL")
    tpR = sum(v for k, v in r if k == "TP")
    mxR = sum(v for k, v in r if k == "MAXHOLD")
    print(f"{sym:<9}{len(r):>6}{sln:>6}{slR:>8.0f}{tpn:>6}{tpR:>8.0f}"
          f"{mxn:>7}{mxR:>8.0f}{(mxR/max(1,mxn)):>9.2f}{arr.sum():>9.0f}")
    tot["n"] += len(r); tot["sln"] += sln; tot["slR"] += slR
    tot["tpn"] += tpn; tot["tpR"] += tpR; tot["mxn"] += mxn
    tot["mxR"] += mxR; tot["R"] += arr.sum()

print("-" * 92)
print(f"{'TOTAL':<9}{tot['n']:>6}{tot['sln']:>6}{tot['slR']:>8.0f}"
      f"{tot['tpn']:>6}{tot['tpR']:>8.0f}{tot['mxn']:>7}{tot['mxR']:>8.0f}"
      f"{(tot['mxR']/max(1,tot['mxn'])):>9.2f}{tot['R']:>9.0f}")
print()
print("=" * 92)
print("COMPARAISON AVEC MT5 (CADJPY)")
print("=" * 92)
print("  python (ce script)     : voir ligne CADJPY ci-dessus")
print("  MT5 (ORION BILAN)      : 144 sorties | SL 89 (-1028) | TP 2 (+70)")
print("                           | MAXHOLD 53 (+316) | TOTAL -642")
print()
print("  POINT CLE A COMPARER : le NOMBRE de TP.")
print("  Si python fait beaucoup plus de TP que MT5 (2), alors l'ecart vient")
print("  de l'execution (SL/TP places differemment), pas de la structure.")
