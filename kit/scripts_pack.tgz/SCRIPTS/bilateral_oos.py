# -*- coding: utf-8 -*-
"""bilateral_oos.py — test OOS 2025 des candidats BILATERAUX (figes avant OOS).
Les zones Dc25/R480 et Dc20/R360 sont 100% positives sur GBPUSD + EURUSD en
IS 2022-24. Configs a tester en OOS 2025 (figees, pas de tuning) :
  1. BILAT_M3F6 : Dc25/M3/F6/R480/L10 (GBPUSD + EURUSD)
  2. BILAT_M3F4 : Dc25/M3/F4/R480/L12 (best GBPUSD)
  3. HOT_DC20 : Dc20/M2/F8/R360/L6 (best GBPUSD zone chaude)
  4. V11_BASE : Dc25/M2/F6/R240/L10 (config V11.1 actuelle, reference)
  5. V10_BASE : Dc25/M4/F6/R480/L10 (pack V10 actuel, reference)
"""
import sys, json, time
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
from pathlib import Path
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import mt5_runner_duka as D

OUT = Path(r"C:\EAFarm\HISTORY - Copy\research\night_results\bilateral_oos.jsonl")
EA = "V45G_EA"
TF = "M15"

def cfg(name, sym, dc, m, f, ret, lad):
    return {"name": name, "sym": sym,
            "inputs": {"InpDcDelta": dc, "InpMaxTradesDay": m, "InpFvgMinPts": f,
                       "InpRetestBars": ret, "InpLadderMax": lad,
                       "InpStartHour": 7, "InpEndHour": 15}}

CONFIGS = []
for sym in ["GBPUSD", "EURUSD"]:
    CONFIGS.append(cfg("BILAT_M3F6", sym, 25, 3, 6, 480, 10))
    CONFIGS.append(cfg("BILAT_M3F4", sym, 25, 3, 4, 480, 12))
    CONFIGS.append(cfg("HOT_DC20", sym, 20, 2, 8, 360, 6))
    CONFIGS.append(cfg("V11_BASE", sym, 25, 2, 6, 240, 10))
    CONFIGS.append(cfg("V10_BASE", sym, 25, 4, 6, 480, 10))

PERIODS = [
    ("IS-2", "2023.01.01", "2024.01.01"),
    ("IS-3", "2024.01.01", "2025.01.01"),
    ("OOS", "2025.01.01", "2026.01.01"),
]

def main():
    total = len(CONFIGS) * len(PERIODS)
    print(f"{len(CONFIGS)} configs × {len(PERIODS)} = {total} runs "
          f"(~{total*30//60} min)", flush=True)
    done = set()
    if OUT.exists():
        for line in OUT.open(encoding="utf-8"):
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
                done.add((rec["name"], rec["tag"]))
            except Exception:
                continue
    t0 = time.time()
    with open(OUT, "a", encoding="utf-8") as fo:
        for c in CONFIGS:
            for tag, frm, to in PERIODS:
                if (c["name"], tag) in done:
                    continue
                r = D.run_backtest(EA, c["sym"], TF, frm, to, 10000, max_wait=420,
                                   inputs=c["inputs"])
                rec = {"name": c["name"], "sym": c["sym"], "tag": tag,
                       "inputs": c["inputs"], "result": r}
                fo.write(json.dumps(rec, default=str) + "\n")
                fo.flush()
                if r and not r.get("error"):
                    print(f"  {c['name']:<10} {c['sym']:<7} {tag}: "
                          f"{r.get('profit',0):>9.2f}$ PF={r.get('pf','?')} "
                          f"WR={r.get('wr','?')}% n={r.get('trades','?')}", flush=True)
                else:
                    print(f"  {c['name']:<10} {c['sym']:<7} {tag}: {r}", flush=True)
    print(f"\nTERMINÉ → {OUT} ({(time.time()-t0)/60:.0f}min)", flush=True)

if __name__ == "__main__":
    main()
