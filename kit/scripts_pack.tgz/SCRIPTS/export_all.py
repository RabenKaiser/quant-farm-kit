# -*- coding: utf-8 -*-
"""export_all.py — exporte 6 ans de M1 pour tous les symboles vises.

Methode : EXPORT_BY_POS.mq5 (pagination par POSITION, cf. piege n21) avec
6 passes (une par annee), le testeur etant lance sur annee+1 car son cache M1
est charge avec un an de decalage.

~25-50 s par annee et par symbole => ~3-5 min par symbole sur 6 ans.

Sortie : research\\m1_pos\\<SYM>_M1.csv  (format m1_real, accumule)
"""
import sys, os, time, json
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
from export_pos import export, OUT
import pandas as pd
from pathlib import Path

# symboles vises : les 5 marches duka existent deja ; on vise 15 marches
# tradables chez ce broker (verifies presents dans Market Watch).
SYMS = [
    "EURUSD", "GBPUSD", "USDJPY", "USDCHF", "EURJPY", "GBPJPY",
    "EURGBP", "EURAUD", "EURNZD", "AUDJPY", "CADJPY", "NZDJPY",
    "AUDNZD", "EURCAD", "GBPCAD", "AUDCAD", "NZDUSD", "AUDUSD",
    "USDCAD", "XAUUSD", "XAGUSD", "USOIL", "UKOIL",
]
YEARS = [2021, 2022, 2023, 2024, 2025, 2026]   # testeur -> cache annee-1 = 2020..2025

only = sys.argv[1].split(",") if len(sys.argv) > 1 else None
syms = [s for s in SYMS if (only is None or s in only)]

rep_path = r"C:\EAFarm\HISTORY - Copy\research\export_all_report.json"
rep = json.load(open(rep_path)) if os.path.exists(rep_path) else {}

print(f"{len(syms)} symboles x {len(YEARS)} annees")
print("=" * 88, flush=True)
for si, sym in enumerate(syms, 1):
    dst = OUT / f"{sym}_M1.csv"
    if dst.exists():
        try:
            df = pd.read_csv(dst, usecols=["time"])
            yrs = pd.to_datetime(df["time"], unit="s", utc=True).dt.year.nunique()
            if yrs >= 6 and len(df) > 2_000_000:
                print(f"[{si}/{len(syms)}] {sym:<8} deja complet "
                      f"({len(df):,} barres, {yrs} annees)", flush=True)
                rep[sym] = dict(bars=int(len(df)), years=int(yrs), status="cache")
                continue
        except Exception:
            pass
    t0 = time.time()
    print(f"\n[{si}/{len(syms)}] {sym} ...", flush=True)
    for y in YEARS:
        try:
            f, w = export(sym, y)
        except Exception as e:
            print(f"    {y}: ERREUR {e}", flush=True); continue
        if f:
            try:
                df = pd.read_csv(f, usecols=["time"])
                n = len(df)
                print(f"    {y} -> {n:,} barres (cumul fichier)", flush=True)
            except Exception:
                n = 0
        else:
            print(f"    {y}: echec ({w}s)", flush=True)
    dst = OUT / f"{sym}_M1.csv"
    if dst.exists():
        df = pd.read_csv(dst, usecols=["time"])
        yrs = int(pd.to_datetime(df["time"], unit="s", utc=True).dt.year.nunique())
        mb = dst.stat().st_size / 1e6
        print(f"  => {sym} : {len(df):,} barres, {yrs} annees, {mb:.1f} Mo "
              f"({time.time()-t0:.0f}s)", flush=True)
        rep[sym] = dict(bars=int(len(df)), years=yrs, mb=round(mb, 1),
                        status="ok")
    else:
        rep[sym] = dict(status="echec")
    json.dump(rep, open(rep_path, "w"), indent=1)

print("\n" + "=" * 88)
ok = [s for s, v in rep.items() if v and v.get("status") in ("ok", "cache")]
print(f"RESUME : {len(ok)} symboles exportes")
for s in sorted(rep):
    v = rep[s]
    if v and v.get("bars"):
        print(f"  {s:<8} {v['bars']:>10,} barres  {v.get('years','?')} ans")
    else:
        print(f"  {s:<8} ECHEC")
