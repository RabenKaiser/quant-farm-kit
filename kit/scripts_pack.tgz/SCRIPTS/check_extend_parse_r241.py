# -*- coding: utf-8 -*-
"""check_extend_parse_r241.py — verifier comment le parser classe les
fermetures par l EA (extend) dans le log MT5."""
import sys, os, glob
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs"
logs = sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime, reverse=True)
lp = logs[0]
print("log:", os.path.basename(lp))
# lire les lignes brutes autour des trades C13V2
txt = open(lp, encoding="utf-8", errors="replace").read()
lines = txt.splitlines()
hits = [l for l in lines if "C13V2" in l][:12]
print("--- lignes C13V2 ---")
for h in hits:
    print("  ", h[:170])
print("--- lignes 'EXTEND' (mes prints) ---")
ext = [l for l in lines if "EXTEND" in l][:8]
for h in ext:
    print("  ", h[:170])
print("--- lignes 'deal' / 'position closed' ---")
dc = [l for l in lines if "closed" in l.lower() or "deal" in l.lower()][:8]
for h in dc:
    print("  ", h[:170])
print("--- parse_stream categories ---")
runs = F.parse_stream(lp, "C13V2")
for key, data in runs.items():
    closed = [t for t in data["trades"].values() if t["close"] is not None]
    if not closed:
        continue
    cats = {}
    for t in closed:
        c = F.categorize(t)
        cats[c] = cats.get(c, 0) + 1
    print(f"  {key[:45]} n={len(closed)} cats={cats} bal={data.get('balance'):.0f}")
