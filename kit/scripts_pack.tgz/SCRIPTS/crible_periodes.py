"""LE CRIBLE PAR PERIODE : L'EFFET VIT-IL ENCORE SUR 2024-2026 ?

POURQUOI (26/09, 03 h 50). Le crible contre-courant donnait +0,2215 sur le Dax (t +8,4) ; la MEME famille
mesuree sur les ordres reels de la ferme, sur 2024 -> 2026Q1, donne **-0,2450 sur 777 transactions**
(t -5,14). Avant de conclure « le corpus ment », il faut ecarter une explication plus banale : le crible
portait sur 2020-2026, et la ferme sur 2024-2026. Si l'effet vit en 2020-2023 et meurt ensuite, alors ce
n'est pas le harnais qui est en cause, c'est **notre facon de cribler** : un etage 1 mesure sur six ans
dont quatre annees anciennes selectionne des edges morts.

On decoupe donc le crible par periode, instrument par instrument, pour voir ou vit l'effet. C'est la meme
mecanique que `controle_crible.py`, avec une borne de dates en plus.
"""
import sys
import pathlib

import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import barrieres_m1 as BM  # noqa: E402
import crible_contre_courant as C  # noqa: E402

B = pathlib.Path(r"C:\EAFarm\HISTORY - Copy\research")
SYMS = [("m1_ext", "DEU.IDX"), ("m1_ext", "HKG.IDX"), ("m1_ext", "JPN.IDX"), ("m1_ext", "AUS.IDX"),
        ("m1_ext", "GBR.IDX"), ("m1_real", "XAUUSD")]
PERIODES = [("2020-01-01", "2024-01-01"), ("2024-01-01", "2026-04-01")]
MINUTES, SEUIL = 180, 2.0


def joue(D, debut, fin):
    """Meme boucle que le crible, restreinte a [debut, fin)."""
    import pandas as pd
    t0 = int(pd.Timestamp(debut, tz="UTC").timestamp())
    t1 = int(pd.Timestamp(fin, tz="UTC").timestamp())
    t, c, atr = D["t"], D["c30"], D["atr"]
    n = len(t)
    pas = max(1, int(MINUTES / 30))
    idx30 = [i for i in range(n) if i % 30 == 29 or (i + 1 < n and t[i + 1] - t[i] > 60)]
    out, bloque = [], -1
    for k in range(pas, len(idx30)):
        i, j = idx30[k], idx30[k - pas]
        if not (t0 <= t[i] < t1) or i <= bloque:
            continue
        if not np.isfinite(atr[i]) or atr[i] <= 0 or not np.isfinite(c[j]):
            continue
        move = c[i] - c[j]
        if abs(move) < SEUIL * atr[i]:
            continue
        sens = "S" if move > 0 else "L"
        r = BM.issue(D, int(t[i]), float(c[i]), float(atr[i]), tpr=C.TPR, slr=C.SLR,
                     hold_min=C.HOLD, sens=sens, r_en_risque=True, par_barres=True)
        if r is None:
            continue
        _k, R, _p, t_sortie = r
        out.append(R)
        bloque = int(np.searchsorted(t, t_sortie))
    return out


def resume(R):
    if len(R) < 20:
        return "n=%4d  (trop peu)" % len(R)
    a = np.array(R)
    mu = float(a.mean())
    sd = float(a.std(ddof=1)) if len(a) > 1 else 0.0
    return "n=%5d  mu %+.4f  t %+.2f  queue %.0f%%" % (
        len(a), mu, mu / (sd / np.sqrt(len(a))) if sd > 0 else 0.0, 100 * float((a < -1.5).mean()))


def main():
    print("=" * 118)
    print("CRIBLE CONTRE-COURANT PAR PERIODE — l'effet vit-il encore sur 2024-2026 ?")
    print("=" * 118)
    L = ["# LE CRIBLE CONTRE-COURANT, PAR PERIODE", "",
         "Le crible complet (2020-2026) donnait +0,2215 sur le Dax ; les ordres reels de la ferme sur",
         "2024-2026Q1 donnent -0,2450 sur 777 transactions. On separe donc les deux epoques.", "",
         "| instrument | 2020-2023 | 2024-2026Q1 |", "|---|---|---|"]
    for src, sym in SYMS:
        D = C.prepare(sym, src)
        if D is None:
            continue
        res = [resume(joue(D, d, f)) for d, f in PERIODES]
        print("  %-22s %s   |   %s" % ("%s (%s)" % (sym, src), res[0], res[1]))
        L.append("| %s (%s) | %s | %s |" % (sym, src, res[0], res[1]))
    L.append("\n## Ce que cela implique pour le processus")
    L.append("\nSi l'effet est concentre sur 2020-2023, alors **l'etage 1 doit se lire sur la periode "
             "recente**, celle que l'etage 2 mesurera -- sinon il selectionne des edges deja morts et "
             "consomme le banc pour rien. C'est le meme piege que « un reglage qui ne vit que sur une "
             "annee », mais a l'envers : un reglage qui ne vit que sur les annees anciennes.")
    (B / "CRIBLE_PERIODES.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n  rapport ecrit dans CRIBLE_PERIODES.md")


if __name__ == "__main__":
    main()
