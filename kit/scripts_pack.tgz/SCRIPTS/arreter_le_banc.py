"""ARRETER TOUT CE QUI TOUCHE LA FERME, POUR LAISSER LE TERMINAL AU TEST VIVANT.

POURQUOI (28/09, 13 h). L'utilisateur attache les robots V12 sur les graphiques du terminal Dukascopy et
part pour une semaine. Or l'automate du laboratoire FERAIT EXACTEMENT LE CONTRAIRE de ce qu'il faut :

  * `usine_9h.py` appelle `arreter_tout()` a 03:00 et a 12:00, qui **tue les terminaux identifies par leur
    fichier de configuration** -- dont celui de la ferme, donc le terminal du test vivant ;
  * `boucle_nuit.py` lance des campagnes de test qui, elles aussi, tuent le terminal de la ferme avant
    chaque fenetre (`kill_terminal` sur `C:\\EAFarm\\MT5\\Farm\\Config\\lab_par.ini`) ;
  * la tache planifiee `DSH_UsineKeepAlive` relance l'usine toutes les 5 minutes : tuer l'usine sans
    desactiver cette tache ne servirait a rien.

Ce script arrete les trois et VERIFIE qu'aucun processus restant ne peut toucher le terminal de la ferme.
Il ne touche PAS au terminal lui-meme (l'utilisateur y a ses graphiques) et laisse la voie du juge, qui
travaille sur l'AUTRE terminal (`C:\\MT5`), sauf demande contraire.
"""
import pathlib
import subprocess
import sys
import time

SHELL = "powershell.exe"


def ps(commande):
    r = subprocess.run([SHELL, "-NoProfile", "-NonInteractive", "-Command", commande],
                       capture_output=True, text=True)
    return (r.stdout or "") + (r.stderr or "")


def tuer(motif, nom="'python.exe'"):
    out = ps("Get-CimInstance Win32_Process -Filter \"Name=%s\" | Where-Object { %s } | "
             "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue; "
             "$_.ProcessId }" % (nom, motif))
    return [x for x in out.split() if x.strip().isdigit()]


def main():
    print("=" * 100)
    print("ARRET DE L'AUTOMATE COTE FERME")
    print("=" * 100)
    total = []
    for nom, motif in (("boucle de nuit (ferme)", "$_.CommandLine -like '*boucle_nuit*'"),
                       ("usine 9 h", "$_.CommandLine -like '*usine_9h*'"),
                       ("lanceurs lab_parallel cote ferme",
                        "$_.CommandLine -like '*lab_parallel.py*' -and $_.CommandLine -like '*--only farm*'")):
        pids = tuer(motif)
        print("  %-38s %s" % (nom, ("arretes : " + ", ".join(pids)) if pids else "aucun en cours"))
        total += pids

    # LES TACHES PLANIFIEES DOIVENT ETRE DESACTIVEES, SINON L'USINE REVIENT EN 5 MINUTES.
    for tache in ("DSH_UsineKeepAlive", "DSH_LabKeepAlive"):
        out = ps("Disable-ScheduledTask -TaskName '%s' | "
                 "Select-Object -ExpandProperty State" % tache)
        etat = out.strip().splitlines()[-1].strip() if out.strip() else "?"
        print("  tache planifiee %-22s -> %s" % (tache, etat or "desactivee"))

    time.sleep(5)
    vivants = ps("Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
                 "ForEach-Object { $_.ProcessId.ToString() + ' ' + $_.CommandLine }")
    dangereux = [l for l in vivants.splitlines()
                 if ("usine_9h" in l or "boucle_nuit" in l or "--only farm" in l)]
    terminaux = ps("Get-CimInstance Win32_Process -Filter \"Name='terminal64.exe'\" | "
                   "ForEach-Object { $_.CommandLine }")
    ferme = [l for l in terminaux.splitlines() if "EAFarm" in l or "lab_par.ini" in l and "MT5\\Config" not in l]
    print("\n  VERIFICATION")
    print("    processus dangereux restants : %s" % (", ".join(dangereux) if dangereux else "aucun"))
    print("    terminal de la ferme en cours : %s" % (", ".join(ferme) if ferme else "aucun"))
    restants = ps("Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
                  "ForEach-Object { $_.ProcessId.ToString() + ' ' + $_.CommandLine }")
    for l in restants.splitlines():
        if l.strip():
            print("    encore actif : %s" % l.strip()[:110])
    print("\n  Ce qui reste actif ne touche PAS la ferme : la voie du juge travaille sur l'autre terminal")
    print("  (`C:\\MT5`), et `gardien_disque.py` ne surveille que l'espace disque et les temporaires.")
    print("  Pour tout arreter y compris le juge : ajouter `--tout` (non implemente volontairement :")
    print("  la voie du juge continue ses mesures tant que l'utilisateur ne demande pas l'arret).")


if __name__ == "__main__":
    sys.exit(main())
