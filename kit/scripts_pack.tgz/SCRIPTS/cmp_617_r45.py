# -*- coding: utf-8 -*-
"""cmp_617_r45.py — TREND XAU sess 6-17 c17 (bal~21695 n=105) vs win24 7-20 c20:
corr + risque + contribution si remplace/ajoute."""
import sys, glob, os
import pandas as pd
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
import fix_v45g_parse as F

LOGD = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\E23367DD11DBEB0EF97D08185EAB7295\Tester\logs"
TARGETS = {"s617": (105, 21695), "s720": (118, 19800)}
found = {}
for lp in sorted(glob.glob(LOGD + r"\*.log"), key=os.path.getmtime)[-80:]:
    try:
        runs = F.parse_stream(lp, "VWAPTREND")
    except Exception:
        continue
    for key, data in runs.items():
        if "XAUUSD" not in key or "H1" not in key:
            continue
        closed = [t for t in data["trades"].values() if t["close"] is not None]
        b = data.get("balance") or 0.0
        for tag, (nt, bt) in TARGETS.items():
            if tag in found:
                continue
            if len(closed) == nt and abs(b - bt) < 8:
                found[tag] = {"trades": closed, "bal": b, "lp": lp}
for tag in TARGETS:
    if tag not in found:
        print(f"{tag}: introuvable")
        continue
    tr = found[tag]["trades"]
    reel = found[tag]["bal"] - 10000
    rows = []
    for t in tr:
        try:
            rows.append((str(t["ts_entry"])[:10], F.pnl_usd(t)))
        except Exception:
            pass
    s = pd.Series([r[1] for r in rows], index=pd.DatetimeIndex([r[0] for r in rows]))
    ds = s.groupby(s.index).sum()
    k = reel / ds.sum() if ds.sum() != 0 else 1.0
    ds = ds * k
    losses = [F.pnl_usd(t) * k for t in tr if F.pnl_usd(t) < 0]
    wins = [F.pnl_usd(t) * k for t in tr if F.pnl_usd(t) > 0]
    found[tag]["eq"] = ds
    # heures d'entree
    hrs = pd.Series([int(str(t["ts_entry"])[11:13]) for t in tr])
    print(f"{tag}: n={len(tr)} reel={reel:+.0f} | SLmoy {sum(losses)/len(losses):+.0f} "
          f"pireSL {min(losses):+.0f} | wr {len(wins)/len(tr)*100:.0f}% | "
          f"h entree mode {hrs.mode().values[:4]}")
if len(found) == 2:
    a = pd.concat([found["s617"]["eq"].rename("s617"),
                   found["s720"]["eq"].rename("s720")], axis=1,
                  join="outer").fillna(0.0)
    a = a.reindex(pd.bdate_range("2026-01-02", "2026-09-01")).fillna(0.0)
    print(f"corr s617-s720 = {a['s617'].corr(a['s720']):.2f}")
    print(f"s617 sum {a['s617'].sum():+.0f} std {a['s617'].std():.1f} | "
          f"s720 sum {a['s720'].sum():+.0f} std {a['s720'].std():.1f}")
    both = a.sum(axis=1)
    bd = both.groupby(both.index.date).sum()
    print(f"combine: sum {both.sum():+.0f} std {both.std():.1f} | "
          f"pire jour {bd.min():+.0f}")
print("FIN", flush=True)
