"""construire_corpus_ext : etendre le corpus aux instruments que le feed porte et que personne n'a cribles.

Round 468. Le feed Dukascopy du farm porte **70 symboles** avec historique ; le corpus `m1_pos` n'en a que
**26**. Les 30 instruments jamais cribles sont 16 indices, 4 cryptos et 10 croises FX. Au taux observe au
crible (9 couples a esperance positive sur 156, soit ~6 %), ces instruments valent de l'ordre de 1 000 a
2 000 transactions de volume supplementaire -- sans inventer de nouveau signal.

Les donnees sont **deja sur le disque** : l'historique M1 du terminal est dans
`bases/Dukascopy-demo-mt5-1/history/<SYM>/<annee>.hcc`, au format MT5 (enregistrements de 60 octets,
epoch + 4 doubles + volumes + spread). On les decode hors du terminal, donc SANS mobiliser le banc, et on
ecrit le meme format de CSV que `m1_pos` pour que toute la chaine de mesure existante s'applique telle
quelle (`barrieres_m1.charge_m1` -> `charge_m30` -> `table_honnete.mesure`).

Le decodeur `hcc_to_m1.py` faisait ce travail mais UNIQUEMENT sur le fichier 2026 : ici on prend toutes
les annees et on borne a la fenetre du corpus (2020-2025).

Verification obligatoire : USA500.IDX est decode ALORS QUE le corpus porte deja SPXUSD, le meme indice.
La comparaison des deux series au meme instant est le controle de bout en bout du decodage, du nommage et
de l'alignement temporel -- elle est faite automatiquement a la fin.

Usage : python SCRIPTS\\construire_corpus_ext.py [SYMBOLE ...]
Sortie : research\\m1_ext\\<SYM>_M1.csv
"""
import os
import struct
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

B = Path(r"C:\EAFarm\HISTORY - Copy\research")
SRC = Path(r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal"
           r"\CF0B997454318B475CF01419AFE2BBF3\bases\Dukascopy-demo-mt5-1\history")
OUT = B / "m1_ext"
R = 60                      # pas des enregistrements : 60 s (M1)
T0, T1 = 1_546_300_800, 1_800_000_000        # 2019-01-01 .. 2027 : detection large
D0, D1 = 1_577_836_800, 1_767_225_600         # 2020-01-01 .. 2026-01-01 : fenetre du corpus
# ROUND 468 : LES DEUX SOURCES NE SONT PAS SUR LA MEME BASE HORAIRE. Les epochs des .hcc sont en UTC,
# l'export MQL qui a construit `m1_pos` portait l'heure du serveur : mesure faite sur USA500.IDX contre le
# SPXUSD deja present dans le corpus (verif_alignement.py), l'ecart relatif median vaut 0,104 % a decalage
# nul et **exactement 0,00000 %** a -120 minutes. Les deux series sont donc IDENTIQUES barre pour barre
# apres correction : le decodeur est juste, seule la base horaire change. -7200 s aligne le corpus etendu
# sur celui qui existe, sans quoi les barrieres seraient resolues deux heures a cote.
OFFSET = int(os.environ.get("OFFSET_S", "-7200"))
COLS = ["time", "open", "high", "low", "close", "spread"]
# ROUND 468 : on n'ecrit que les colonnes que la chaine de mesure LIT (`barrieres_m1.COLS`). Les volumes
# tick et reel ne sont utilises nulle part dans la mesure honnete, et 30 instruments x 2 M de barres font
# 3,2 Go avec eux contre 2,2 Go sans : le disque est a 9,8 Go libres, et les .hcc d'origine restent sur le
# disque si une autre analyse a besoin des volumes.

# Les 30 instruments que le feed porte et que le corpus n'a pas.
NOUVEAUX = [
    # indices (17 dans le feed, USA500 et USATECH sont deja dans le corpus sous SPXUSD/NSXUSD)
    "AUS.IDX", "CHE.IDX", "CHI.IDX", "DEU.IDX", "DOLLAR.IDX", "ESP.IDX", "EUS.IDX", "FRA.IDX",
    "GBR.IDX", "HKG.IDX", "JPN.IDX", "NLD.IDX", "USA30.IDX", "USSC2000.IDX", "VOL.IDX",
    # cryptos
    "BTCUSD", "ETHUSD", "LTCUSD", "ADAUSD",
    # croises FX absents du corpus
    "CHFJPY", "EURNOK", "EURPLN", "EURTRY", "GBPAUD", "NOKSEK", "USDCNH", "USDJPY", "USDNOK", "USDPLN",
]


def decode_fichier(p):
    """Decode UN fichier .hcc : detection des blocs par triple point (epoch a i, i+60, i+120).

    ROUND 468 : le terminal GARDE OUVERTS les .hcc des symboles qu'il utilise ; une lecture pendant un test
    leve PermissionError et faisait avorter tout le lot (constat : USDJPY/2026.hcc pendant la campagne
    EURCHF). Un fichier verrouille est desormais SIGNALE et saute, pas fatal -- les autres instruments
    passent, et le symbole sera repris quand le banc sera libre.
    """
    try:
        raw = p.read_bytes()
    except (PermissionError, OSError) as e:
        return None, "verrouille (%s)" % type(e).__name__
    n = len(raw)
    if n < 10000:
        return None
    q = np.lib.stride_tricks.as_strided(
        np.frombuffer(raw[: (n // 8) * 8], dtype="<i8"),
        shape=((n // 8) * 8 - 7,), strides=(1,))
    ok = (q > T0) & (q < T1)
    m = n - 8
    ok = ok[:m]
    good = ok[:-2 * R] & ok[R:-R] & ok[2 * R:]
    idx = np.nonzero(good)[0]
    if len(idx) == 0:
        return None
    recs, k = [], 0
    while k < len(idx):
        s = idx[k]
        e = s
        while e + R < m and ok[e + R] and q[e + R] > q[e]:
            e += R
        cnt = (e - s) // R + 1
        if cnt >= 100:
            recs.append((s, cnt))
        while k < len(idx) and idx[k] <= e:
            k += 1
    if not recs:
        return None
    parts = []
    for s, cnt in recs:
        a = np.frombuffer(raw, dtype=np.uint8, count=cnt * R, offset=s).reshape(cnt, R)
        parts.append(pd.DataFrame({
            "time": a[:, 0:8].copy().view("<i8").ravel(),
            "open": a[:, 8:16].copy().view("<f8").ravel(),
            "high": a[:, 16:24].copy().view("<f8").ravel(),
            "low": a[:, 24:32].copy().view("<f8").ravel(),
            "close": a[:, 32:40].copy().view("<f8").ravel(),
            "tick_volume": a[:, 40:48].copy().view("<i8").ravel(),
            "spread": a[:, 48:56].copy().view("<i8").ravel(),
            "real_volume": a[:, 56:60].copy().view("<i4").ravel(),
        }))
    return pd.concat(parts, ignore_index=True)


def decode_sym(sym):
    d = SRC / sym
    if not d.is_dir():
        return None, "dossier absent"
    fichiers = sorted(d.glob("*.hcc"))
    if not fichiers:
        return None, "aucun .hcc"
    parts, verrous = [], 0
    for f in fichiers:
        df, note = decode_fichier(f)
        if df is None:
            if note and "verrouille" in note:
                verrous += 1
            continue
        if len(df):
            parts.append(df)
    if not parts:
        return None, "%d fichier(s) verrouille(s), aucun bloc decode" % verrous if verrous else "aucun bloc decode"
    df = pd.concat(parts, ignore_index=True)
    df["time"] = df["time"].astype("int64") + OFFSET
    df = df[(df["time"] >= D0) & (df["time"] < D1)]
    df = df[(df["close"] > 0) & (df["high"] >= df["low"]) & (df["low"] > 0)]
    df = df.drop_duplicates("time").sort_values("time").reset_index(drop=True)
    if not len(df):
        return None, "aucune barre dans la fenetre 2020-2025"
    return df, "%d fichiers" % len(fichiers)


def controle_spx(df):
    """Controle de bout en bout : USA500.IDX doit coller au SPXUSD deja present dans le corpus."""
    f = B / "m1_pos" / "SPXUSD_M1.csv"
    if not f.exists():
        return "SPXUSD absent du corpus : controle impossible"
    ref = pd.read_csv(f, usecols=["time", "close"])
    j = df[["time", "close"]].merge(ref, on="time", suffixes=("", "_ref"))
    if len(j) < 100:
        return "moins de 100 instants communs avec SPXUSD (%d)" % len(j)
    e = (j["close"] - j["close_ref"]).abs() / j["close_ref"]
    return ("%d instants communs avec SPXUSD | ecart relatif median %.5f %% | p95 %.5f %% | max %.5f %%"
            % (len(j), 100 * e.median(), 100 * e.quantile(0.95), 100 * e.max()))


def main():
    syms = sys.argv[1:] or NOUVEAUX
    OUT.mkdir(parents=True, exist_ok=True)
    print("=" * 100)
    print("CORPUS ETENDU : %d instruments a decoder depuis %s" % (len(syms), SRC))
    print("=" * 100)
    for sym in syms:
        df, note = decode_sym(sym)
        if df is None:
            print("  %-14s ECHEC : %s" % (sym, note), flush=True)
            continue
        dst = OUT / ("%s_M1.csv" % sym)
        df[COLS].to_csv(dst, index=False)
        t0 = pd.to_datetime(df["time"].iloc[0], unit="s")
        t1 = pd.to_datetime(df["time"].iloc[-1], unit="s")
        ecart = (df["close"].diff().abs())
        ecart = ecart[ecart > 0]
        pt = float(ecart.min()) if len(ecart) else 0.0
        print("  %-14s %7d barres | %s -> %s | %s | point %.6g | spread median %.1f"
              % (sym, len(df), t0.date(), t1.date(), note, pt, df["spread"].median()), flush=True)
        if sym == "USA500.IDX":
            print("      CONTROLE : %s" % controle_spx(df), flush=True)
    print("\n  -> %s" % OUT)
    return 0


if __name__ == "__main__":
    sys.exit(main())
