# -*- coding: utf-8 -*-
r"""classif_fusion.py -- LA FUSION : motif + variables -> UN score de regime
previsionnel, puis LE TEST QUI RAPPORTE : est-ce que les declencheurs du
reservoir gagnent quand le score annonce leur etat ?

ENTREES
-------
- classif_cause2 : score compose = somme des (lift-1) par quantile de
  variable (volatilite relative = horloge du marche).
- classif_patterns : P(classe future | motif 6 lettres H4), valide WF
  (73.7 % vs 56.8 % de hasard).

CONSTRUCTION DU FORECAST
------------------------
score_final = z(score compose) + BONUS_MOTIF x z(P(E|motif) - base_E)
Le motif apporte la memoire, les variables apportent l'instant.

LE TEST DECISIF (celui qui concerne le portefeuille)
----------------------------------------------------
Les declencheurs corpus (SR97 vente = fade du haut de range, KELT =
retour mediane de canal, MONDAYFADE = fade du lundi) sont joues dans le
moteur honnete (barrieres, spread, une position/paire) SEPAREMENT quand
  A) le forecast annonce leur etat favorable (P haute)
  B) le forecast l'annonce defavorable (P basse)
Si mu(A) >> mu(B) de facon stable multi-paires, le filtre REGIME vaut de
l'or pour les jambes reelles.
"""
import os
import sys
from collections import defaultdict, Counter

import numpy as np
import pandas as pd

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parent))
import nuit_motifs as NM
from classif_m5 import er, adx_like, z_prix, pentes
import classif_m5_v2 as V2
from classif_cause import variables, transitions
from classif_cause2 import score_compose, quantile_table, FEN
from classif_patterns import etat_h4, lettre, H4, MOTIF_LEN, HORIZONS

JAMBES = [x.strip() for x in os.environ.get(
    "PAIRES", "EURUSD,GBPUSD,USDCHF,AUDUSD,NZDUSD,EURJPY,XAUUSD").split(",")
    if x.strip()]
MIN_N = 60


def zscore(x):
    v = np.asarray(x, dtype=float)
    mu = np.nanmean(v)
    sd = np.nanstd(v)
    return np.where(sd > 0, (v - mu) / sd, 0.0)


def build_forecast(p, ref_tables, table_motif, bases):
    """Retourne (lab_v2, score_final) alignes barre M30."""
    D = NM.charge(p, "m1_pos")
    if D is None:
        return None
    lab, _ = V2.etats(D)
    vv = variables(D)
    s = score_compose(vv, ref_tables)
    zs = zscore(s)
    # probabilite motif : P(expansion future | motif courant) = la classe
    # la plus informative pour les declencheurs fade (ils vivent d'un range
    # qui reste range) — on prend P(R|motif) et P(E|motif).
    n = len(lab)
    seq = etat_h4(lab)
    dts = np.asarray(D["idx"])[:(n // H4) * H4].reshape(-1, H4)[:, -1]
    pR = np.full(n, np.nan)
    pE = np.full(n, np.nan)
    for i in range(MOTIF_LEN, len(seq) - max(HORIZONS) // H4):
        motif = "".join(lettre(x) for x in seq[i - MOTIF_LEN:i])
        c = table_motif.get(motif + "|16")
        if not c or sum(c.values()) < MIN_N:
            continue
        d = defaultdict(int)
        for etat, niv in c.items():
            d[lettre(etat)] += niv
        t = sum(d.values())
        bloc0 = i * H4
        pR[bloc0:bloc0 + H4] = d.get("R", 0) / t
        pE[bloc0:bloc0 + H4] = d.get("E", 0) / t
    # forecast final : les fades veulent R qui PERSISTE ; le score compose
    # doit aussi annoncer la STABILITE du range (vol faible qui dure).
    zf = zs + 0.5 * zscore(np.nan_to_num(pR) - bases.get("R", 0.7)) \
        - 0.5 * zscore(np.nan_to_num(pE) - bases.get("E", 0.15))
    return D, lab, vv, zf, pR, pE


def mesure_trigger(D, sig, hold=64, tpr=2.0, slr=3.0):
    """R/tx honnete (barrieres + spread) pour des indices d'entree."""
    e = D["o"][sig + 1]
    st = D["a"][sig]
    sp = D["cout"]
    sens = np.where(D["c"][sig] > D["o"][sig], -1.0, 1.0)  # fade de la bougie
    tp = e - sens * (tpr * slr + sp) * st
    sl = e + sens * max(slr - sp, 0.1) * st
    off = np.arange(1, hold + 1)
    Hh = D["h"][sig[:, None] + 1 + off]
    Ll = D["l"][sig[:, None] + 1 + off]
    hsl = (Hh >= sl[:, None]) if sens[0] > 0 else (Ll <= sl[:, None])
    htp = (Ll <= tp[:, None]) if sens[0] > 0 else (Hh >= tp[:, None])
    it = np.where(htp.any(1), htp.argmax(1), 10 ** 6)
    isl = np.where(hsl.any(1), hsl.argmax(1), 10 ** 6)
    kind = np.where(htp.any(1) & (~hsl.any(1) | (it < isl)), 0,
                    np.where(hsl.any(1), 1, 2))
    fin = (e - D["c"][sig + hold]) / st * (-sens)
    R = np.where(kind == 0, tpr, np.where(kind == 1, -1.0, fin - sp))
    return sig, R


def crosstab(p, zf, lab):
    """Joue le FADE (la famille qui rapporte) conditionne au forecast."""
    D = NM.charge(p, "m1_pos")
    if D is None:
        return None
    # signaux FADE : bougie M30 extremement large apres un range stable
    # ( approximation corpus du reservoir ; la famille fade est celle qui
    # a survécu aux cribles) — declencheur : corps > 2.2 x ATR et le
    # forecast (zf) sert de filtre.
    c, o, a = D["c"], D["o"], D["a"]
    corps = np.abs(c - o)
    sig = np.flatnonzero((corps > 2.2 * a) &
                         (np.arange(len(c)) > 100) &
                         (np.arange(len(c)) < len(c) - 70))
    if len(sig) < 40:
        return None
    _, R = mesure_trigger(D, sig)
    # split par mediane du forecast
    med = np.nanmedian(zf[sig])
    haut = zf[sig] >= med
    return haut, R, med


def main():
    print("FUSION score+motif -> forecast | puis cross-tab FADE x forecast")
    # ---- tables de reference (train 2020-23) -------------------------------
    ref = {}
    table_motif = defaultdict(Counter)
    glob = Counter()
    for p in JAMBES:
        D = NM.charge(p, "m1_pos")
        if D is None:
            continue
        lab, _ = V2.etats(D)
        vv = variables(D)
        trans = transitions(lab)
        pos_all = np.zeros(len(lab), dtype=bool)
        for (i, A, B) in trans:
            pos_all[max(0, i - FEN):i] = True
        tables = {}
        for nom, x in vv.items():
            t = quantile_table(x, pos_all)
            if t is None:
                continue
            edges = np.quantile(x[~np.isnan(x)], np.linspace(0, 1, 6))
            lifts = np.array([z[2] for z in t])
            tables[nom] = (edges, lifts)
        ref[p] = tables
        # motifs (train)
        n = (len(lab) // H4) * H4
        seq = etat_h4(lab)
        dts = np.asarray(D["idx"])[:n].reshape(-1, H4)[:, -1]
        for i in range(MOTIF_LEN, len(seq) - max(HORIZONS) // H4):
            if pd.Timestamp(dts[i]).year > 2023:
                continue
            motif = "".join(lettre(x) for x in seq[i - MOTIF_LEN:i])
            c = table_motif[motif + "|16"]
            c[seq[i + HORIZONS[1] // H4]] += 1
            glob[lettre(seq[i + HORIZONS[1] // H4])] += 1
    tg = sum(glob.values())
    bases = {k: v / tg for k, v in glob.items()} if tg else \
        {"R": 0.73, "E": 0.15, "C": 0.07, "T": 0.04}
    print("bases motifs (train) :", {k: round(v, 2) for k, v in bases.items()})
    # ---- cross-tab par paire ------------------------------------------------
    res = defaultdict(lambda: [[], []])
    for p in JAMBES:
        if p not in ref:
            continue
        got = build_forecast(p, ref[p], table_motif, bases)
        if got is None:
            continue
        D, lab, vv, zf, pR, pE = got
        ct = crosstab(p, zf, lab)
        if ct is None:
            continue
        haut, R, med = ct
        res["FADE"][0].extend(R[haut])
        res["FADE"][1].extend(R[~haut])
        print("  %-8s fade n=%d | forecast haut mu=%+.3f (n=%d) | bas "
              "mu=%+.3f (n=%d)" % (p, len(R), np.mean(R[haut]),
                                   int(haut.sum()), np.mean(R[~haut]),
                                   int((~haut).sum())))
    print("\n=== VERDICT GLOBAL ===")
    for cle, (a, b) in res.items():
        if len(a) >= 100 and len(b) >= 100:
            print("  %s : forecast HAUT mu=%+.3f (n=%d) vs BAS mu=%+.3f "
                  "(n=%d) — ecart %+.3f"
                  % (cle, np.mean(a), len(a), np.mean(b), len(b),
                     np.mean(a) - np.mean(b)))


if __name__ == "__main__":
    main()