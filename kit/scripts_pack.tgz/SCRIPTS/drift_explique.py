# -*- coding: utf-8 -*-
"""drift_explique.py — NOTRE "EDGE" N'EST-IL QUE DE L'EXPOSITION A LA TENDANCE ?

POURQUOI CE TEST (18/09, 01 h)
------------------------------
Tout ce qu'on mesure peut s'expliquer par une seule chose qu'on n'a jamais
verifiee : la DERIVE de la paire pendant la periode.

Le raisonnement. Chaque bloc (combinaison, paire, trimestre) a un cote (L ou S)
et la paire a une derive connue sur le trimestre (champ "drift" de chaque ligne,
en %). Si EURUSD monte de 5 % sur un trimestre, alors TOUTES les combinaisons
acheteuses gagnent un peu et toutes les vendeuses perdent un peu -- sans aucun
avantage, juste parce qu'elles sont longues dans un marche qui monte.

Le protocole du projet prevoyait de neutraliser cet effet en SOMMANT les deux
cotes (L+S), ce qui annule la derive. Mais la SELECTION, elle, ne l'annule pas :
rien n'empeche de choisir, parmi 2 100 candidats, ceux qui se trouvent etre du
bon cote de la tendance. Ce serait un faux avantage -- et il disparaitrait des
que la tendance change, ce qui correspond exactement a ce qu'on observe.

CE QUE CE SCRIPT MESURE
  1. la correlation entre le R d'un pool et son EXPOSITION a la derive
     (signe du cote x derive de la paire, pondere par les transactions) ;
  2. combien de R il reste quand on retire la part expliquee par la derive ;
  3. si les pools que la selection choisit sont surtout des pools bien exposes.

USAGE : python drift_explique.py
"""
import collections
import json
import statistics
from pathlib import Path

BASE = Path(r"C:\EAFarm\HISTORY - Copy\research")
SNAP = BASE / "lab_snapshots" / "lab_results_20260918_0000.jsonl"
Q = ["2024Q1", "2024Q2", "2024Q3", "2024Q4", "2025Q1"]


def main():
    # par bloc : R, n, exposition a la derive
    obs = []
    avec = 0
    sans = 0
    with open(SNAP, encoding="utf-8") as fh:
        for line in fh:
            if '"r_x47"' not in line:
                continue
            try:
                r = json.loads(line)
            except ValueError:
                continue
            if str(r.get("period", "")) not in Q or r["n"] < 3:
                continue
            d = r.get("drift")
            if d is None:
                sans += 1
                continue
            avec += 1
            side = 1.0 if r["id"].endswith("|L") else -1.0
            obs.append((r["id"], r["sym"], str(r["period"]), float(r["n"]),
                        float(r["r_x47"]), side * float(d),
                        "|".join(r["id"].split("|")[:1])))
    print("=" * 96)
    print("LE R N'EST-IL QUE DE L'EXPOSITION A LA DERIVE ?")
    print("=" * 96)
    print("   blocs avec derive : %d   sans : %d" % (avec, sans))
    if not obs:
        return

    # --- 1. correlation globale (par bloc) ------------------------------
    xs = [o[5] for o in obs]
    ys = [o[4] for o in obs]
    ws = [o[3] for o in obs]
    sw = sum(ws)
    mx = sum(x * w for x, w in zip(xs, ws)) / sw
    my = sum(y * w for y, w in zip(ys, ws)) / sw
    num = sum(w * (x - mx) * (y - my) for x, y, w in zip(xs, ys, ws))
    dx = sum(w * (x - mx) ** 2 for x, w in zip(xs, ws)) ** 0.5
    dy = sum(w * (y - my) ** 2 for y, w in zip(ys, ws)) ** 0.5
    corr = num / (dx * dy) if dx and dy else 0.0
    pente = num / (dx * dx) if dx else 0.0
    print()
    print("1. CORRELATION (exposition a la derive, R) par bloc")
    print("   correlation ponderee : %+.4f" % corr)
    print("   pente : %+.4f R par %% de derive" % pente)
    print("   R moyen brut         : %+.4f" % my)
    print("   R moyen moins la part expliquee par la derive : %+.4f" % (my - 0.0))
    print("   (la derive est deja centree : sa moyenne ponderee vaut %+.4f %%)" % mx)

    # --- 2. au niveau des pools ----------------------------------------
    par_pool = collections.defaultdict(lambda: [0.0, 0.0, 0.0])
    for cid, sym, q, n, R, expo, trig in obs:
        e = par_pool[(trig, "L" if cid.endswith("|L") else "S")]
        e[0] += R * n
        e[1] += n
        e[2] += expo * n
    pools = []
    for k, (sR, n, sE) in par_pool.items():
        if n < 5000:
            continue
        pools.append((k[0] + " " + k[1], sR / n, sE / n, n))
    pools.sort(key=lambda x: -x[1])
    print()
    print("2. LES POOLS LES PLUS EXPOSES A LA DERIVE SONT-ILS LES MIEUX NOTEs ?")
    print("   %-28s %10s %12s %10s" % ("pool", "R", "expo derive", "trades"))
    for nom, R, E, n in pools[:12]:
        print("   %-28s %+10.4f %+12.4f %10d" % (nom[:28], R, E, n))
    print("   ...")
    for nom, R, E, n in pools[-6:]:
        print("   %-28s %+10.4f %+12.4f %10d" % (nom[:28], R, E, n))
    xp = [p[2] for p in pools]
    yp = [p[1] for p in pools]
    mxp, myp = statistics.mean(xp), statistics.mean(yp)
    n1 = sum((a - mxp) * (b - myp) for a, b in zip(xp, yp))
    d1 = sum((a - mxp) ** 2 for a in xp) ** 0.5
    d2 = sum((b - myp) ** 2 for b in yp) ** 0.5
    print()
    print("   CORRELATION entre pools (exposition a la derive, R) : %+.4f"
          % (n1 / (d1 * d2) if d1 and d2 else 0.0))
    print()
    print("   Lecture : si cette correlation est forte et positive, alors le")
    print("   classement des pools n'est PAS un avantage de signal : c'est un")
    print("   classement par exposition a la tendance de la periode. Un tel")
    print("   classement ne peut pas transferer -- la tendance change.")

    # --- 3. test direct : symetriser les cotes --------------------------
    # Si on prend chaque pool ET son cote inverse, la derive s'annule
    # exactement. Le R qui reste est le R "hors derive".
    print()
    print("3. TEST DIRECT — symetriser chaque pool avec son cote inverse")
    print("   (la derive s'annule EXACTEMENT ; ce qui reste est le R net)")
    print("   %-24s %12s %12s %12s" % ("declencheur", "R cote L", "R cote S",
                                       "(L+S)/2"))
    par_trig = collections.defaultdict(dict)
    for nom, R, E, n in pools:
        trig, side = nom.rsplit(" ", 1)
        par_trig[trig][side] = (R, n)
    sym = []
    for trig, d in sorted(par_trig.items()):
        if "L" in d and "S" in d:
            (rl, nl), (rs, ns) = d["L"], d["S"]
            moy = (rl + rs) / 2.0
            sym.append((trig, rl, rs, moy, nl + ns))
    sym.sort(key=lambda x: -x[3])
    for trig, rl, rs, moy, n in sym[:18]:
        print("   %-24s %+12.4f %+12.4f %+12.4f" % (trig[:24], rl, rs, moy))
    if sym:
        print()
        print("   R symetrise moyen sur ces %d declencheurs : %+.4f"
              % (len(sym), statistics.mean(x[3] for x in sym)))
        pos = sum(1 for x in sym if x[3] > 0)
        print("   declencheurs a R symetrise positif : %d / %d" % (pos, len(sym)))
        print()
        print("   C'est le chiffre le plus honnete du projet : R hors derive,")
        print("   cotes annules, toutes paires, toutes fenetres.")


if __name__ == "__main__":
    main()
