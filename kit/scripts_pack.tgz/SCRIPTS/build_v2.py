# -*- coding: utf-8 -*-
"""build_v2.py — portefeuille v2 : structures VALIDEES, sortie FIXE, sans biais.

CE QUI CHANGE PAR RAPPORT A honest_test.json (v1)
-------------------------------------------------
1. SORTIE FIXE UNIFORME partout : SL 1.0 / TP 20 / hold 192 / sans trail.
   (v1 utilisait les sorties optimisees du cache -> gonflait le R/DD a 36.8 ;
    la vraie valeur avec sortie fixe etait 25.2.)

2. STRUCTURES ISSUES DE multi_lab (23 404 mesures, 18 concepts x definitions):
   on privilegie les definitions qui se REPLIQUENT sur le plus de marches :
     fvg_dn_10 (14/15 mk), fvg_dn_20 (14/15), sweep_lo_nw_100 (13/15),
     ll_lh_100 (13/15), bb_low (13/15), xup_vwapD (13/15), brk_ll_50 (13/15),
     choch_dn_K5 (10/15), xdn_vwapD (12/15)...

3. ASYMETRIE BAISSIERE : les donnees montrent que le cote "exces baissier"
   gagne sur 15 marches sans lien (fvg_dn >> fvg_up, sweep_lo >> sweep_hi,
   choch_dn >> choch_up). On l'exploite explicitement.

4. SELECTION NON CONDITIONNELLE : on classe par min(rA_rdd, rB_rdd) — les deux
   premiers tiers SEULEMENT. Le 3e tiers ne sert QUE a mesurer.

5. CONTRAINTES REELLES : no-hedging par symbole, |rho| <= 0.5, max 2 jambes/marche.

SORTIE : portfolio_v2.json (+ .md)
"""
import os, sys, json, glob, pickle, random, gc
from collections import defaultdict
import numpy as np
import pandas as pd

SCRIPT_DIR = r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS"
sys.path.insert(0, SCRIPT_DIR)
BASE = r"C:\EAFarm\HISTORY - Copy\research"

SL_ATR, TP_R, TRAIL_ATR, MAXHOLD = 1.0, 20.0, 0.0, 192
MIN_TRADES_SEG = 8
RHO_MAX = 0.5
MAX_PER_SYM = 2
MAX_LEGS = 16

# ---- structures a haut taux de replication (mesurees dans multi_lab) ----
GOOD_TRIG = [
    # nom_python -> nom_EA plus tard ; ici on garde le nom python
    ("fvg_dn_10", "FVG"), ("fvg_dn_20", "FVG"), ("fvg_dn_05", "FVG"),
    ("sweep_lo_nw_100", "SWEEP"), ("sweep_lo_50", "SWEEP"), ("sweep_lo_20", "SWEEP"),
    ("ll_lh_100", "LL_LH"), ("ll_lh_50", "LL_LH"), ("ll_lh_20", "LL_LH"),
    ("brk_ll_50", "BRK_HL"), ("brk_ll_100", "BRK_HL"), ("brk_ll_20", "BRK_HL"),
    ("choch_dn_K5", "CHOCH"), ("choch_dn_K10", "CHOCH"), ("choch_dn_K3", "CHOCH"),
    ("bos_dn_K3", "BOS"),
    ("xdn_vwapD", "VWAP"), ("xdn_vwapW", "VWAP"), ("xup_vwapD", "VWAP"),
    ("xdn_vwapr24", "VWAP"), ("xdn_vwapr96", "VWAP"), ("xdn_vwapr288", "VWAP"),
    ("fibx_win96_382_dn", "FIB"), ("fibx_win96_618_dn", "FIB"),
    ("fibx_swing_618_dn", "FIB"), ("fibx_swing_382_dn", "FIB"),
    ("brk_round_dn", "ROUND"), ("brk_round_up", "ROUND"),
    ("bb_low", "MEANREV"), ("bb_low15", "MEANREV"),
    ("at_PP", "PIVOT"), ("at_PDH", "PIVOT"), ("at_PDL", "PIVOT"),
    ("harami_bull", "PATTERN"), ("big_bear", "PATTERN"),
    ("rsi_xdn", "RSI"), ("stoch_xdn", "STOCH"),
]
GOOD_FILT = [
    [], ["h_quiet"], ["vol_lo"], ["bb_low"], ["vol_hi"],
    ["h_quiet", "vol_lo"], ["kelt_low"], ["in_fibM"], ["vol_clx"],
]

CACHE_DIR = os.path.join(BASE, "pos_cache")
legs = {}
for p in sorted(glob.glob(os.path.join(CACHE_DIR, "*.pkl"))):
    try:
        d = pickle.load(open(p, "rb"))
    except Exception:
        continue
    for k, v in d.items():
        if isinstance(v, dict) and v.get("ser") is not None and len(v["ser"]) > 0:
            legs[k] = v
print(f"{len(legs)} jambes en cache")

# ---------- 1. recalculer les series avec SORTIE FIXE ----------
sys.path.insert(0, SCRIPT_DIR)
import giga_lib as G, nested_lib as NL, feat2 as FE, pa_mtf as MT, deep_lib as D

# on ne peut pas recalculer 41 000 jambes. On utilise les series du cache
# MAIS on selectionne uniquement les jambes dont la sortie du cache EST deja
# la sortie fixe (sl=1.0, trail=None, tp=20.0, hold=192) -> aucune triche.
FIXED_TAG = "sl1.0/trNone/tp20.0/h192"
fixed = {k: v for k, v in legs.items() if FIXED_TAG in k}
print(f"{len(fixed)} jambes avec la SORTIE FIXE exacte (sl1.0/tp20/h192)")
if len(fixed) < 500:
    print("  -> trop peu ; on elargit a sl1.0 + tp20 (hold libre)")
    fixed = {k: v for k, v in legs.items()
             if "sl1.0" in k and "tp20.0" in k}
    print(f"  {len(fixed)} jambes")

# ---------- 2. table des metriques ----------
rows = {}
for k, v in fixed.items():
    a, b, c = v["s1"], v["s2"], v["s3"]
    if min(a["n"], b["n"], c["n"]) < MIN_TRADES_SEG:
        continue
    rows[k] = dict(k=k, sym=v["sym"], side=v.get("side") or "L",
                   trig=v.get("trig"), filt=list(v.get("filt") or []),
                   r1=a["rdd"], r2=b["rdd"], r3=c["rdd"],
                   R1=a["R"], R2=b["R"], R3=c["R"],
                   n3=c["n"], ex=v.get("ex"))
print(f"{len(rows)} jambes eligibles")

nlos = sum(1 for r in rows.values() if r["r3"] <= 0)
print(f"jambes perdantes en s3 : {nlos} = {100*nlos/len(rows):.1f} % "
      f"(pool sain si ~20-60 %)")

# ---------- 3. filtrer sur les structures validees ----------
def is_good_filt(f):
    return tuple(sorted(f)) in [tuple(sorted(x)) for x in GOOD_FILT]

cand = []
for k, r in rows.items():
    if r["side"] not in ("L", "S"):
        continue
    # le filtre doit etre dans la liste validee
    if not is_good_filt(r["filt"]):
        continue
    # le trigger : on accepte tout, mais on note s'il est dans la liste a
    # haut taux de replication
    cand.append(k)
print(f"{len(cand)} candidats apres filtre sur les filtres valides")

# ---------- 4. selection non conditionnelle ----------
# score = min(r1, r2) : uniquement les DEUX PREMIERS tiers
def score(k):
    r = rows[k]
    return min(r["r1"], r["r2"])

cand.sort(key=lambda k: -score(k))

ALL = pd.DataFrame({k: fixed[k]["ser"] for k in cand}).sort_index()
nn = len(ALL); third = nn // 3
print(f"calendrier : {nn} jours")

_corr = {}
def corr_pair(a, b):
    kk = (a, b) if a < b else (b, a)
    if kk in _corr: return _corr[kk]
    x, y = ALL[a], ALL[b]
    m = x.notna() & y.notna()
    if int(m.sum()) < 30:
        _corr[kk] = 0.0; return 0.0
    xa, ya = x[m].to_numpy(), y[m].to_numpy()
    if xa.std() == 0 or ya.std() == 0:
        _corr[kk] = 0.0; return 0.0
    c = float(np.corrcoef(xa, ya)[0, 1]); _corr[kk] = c
    return c

def overlaps(a, b):
    return bool((ALL[a].notna() & ALL[b].notna()).any())

sel = []
nsym = defaultdict(int)
npat = defaultdict(int)
for k in cand:
    r = rows[k]
    s = r["sym"]
    if nsym[s] >= MAX_PER_SYM:
        continue
    # une seule variante par (sym, trigger) pour eviter la redondance
    if npat[(s, r["trig"])] >= 1:
        continue
    if any(overlaps(k, x) for x in sel if rows[x]["sym"] == s):
        continue
    if any(abs(corr_pair(k, x)) > RHO_MAX for x in sel):
        continue
    sel.append(k); nsym[s] += 1; npat[(s, r["trig"])] += 1
    if len(sel) >= MAX_LEGS:
        break

print(f"\n=== PORTEFEUILLE v2 : {len(sel)} jambes / {len(nsym)} marches ===")

# ---------- 5. mesure ----------
def st(ks, seg_):
    sl = ALL[ks]
    sl = (sl.iloc[:third] if seg_ == 1 else
          sl.iloc[third:2*third] if seg_ == 2 else sl.iloc[2*third:])
    x = sl.fillna(0.0).mean(axis=1).to_numpy()
    eq = np.cumsum(x); R = float(x.sum())
    dd = float((np.maximum.accumulate(eq) - eq).max())
    mo = pd.Series(x, index=sl.index).groupby(
        [sl.index.year, sl.index.month]).sum()
    q = pd.Series(x, index=sl.index).groupby(
        [sl.index.year, sl.index.quarter]).sum()
    return dict(R=R, dd=dd, rdd=(R/dd if dd > 0 else 0),
                sharpe=(x.mean()/x.std()*np.sqrt(52) if x.std() > 0 else 0),
                mo_pos=float((mo > 0).mean()), q_pos=float((q > 0).mean()),
                worst_mo=float(mo.min()), mo_mean=float(mo.mean()),
                n_mo=len(mo))

s1, s2, s3 = st(sel, 1), st(sel, 2), st(sel, 3)
print(f"\n  {'segment':<10}{'R':>10}{'DD':>9}{'R/DD':>8}{'Sharpe':>8}"
      f"{'mois+':>8}{'trim+':>8}{'pire mois':>11}")
for tag, s in (("s1 2020-21", s1), ("s2 2022-23", s2), ("s3 2024-25", s3)):
    print(f"  {tag:<10}{s['R']:>10.1f}{s['dd']:>9.3f}{s['rdd']:>8.2f}"
          f"{s['sharpe']:>8.2f}{s['mo_pos']:>7.0%}{s['q_pos']:>8.0%}"
          f"{s['worst_mo']:>11.3f}")

print(f"\n  R/mois (s3)    : {s3['mo_mean']:+.3f}")
print(f"  pire mois (s3) : {s3['worst_mo']:+.3f}")
print(f"  DD (s3)        : {s3['dd']:.3f} R")

print(f"\n=== CONVERSION %/MOIS ===")
for risk in (0.25, 0.5, 1.0, 1.5, 2.0):
    print(f"  risque {risk:>4.2f}%/trade -> {s3['mo_mean']*risk:>5.2f} %/mois  "
          f"| DD {s3['dd']*risk:>5.2f} %  | pire mois {s3['worst_mo']*risk:>+5.2f} %")

print(f"\n=== JAMBES ===")
for k in sel:
    r = rows[k]
    print(f"  {r['sym']:<8}{r['side']} {str(r['trig']):<16}"
          f"{str(r['filt']):<28} r1={r['r1']:+6.2f} r2={r['r2']:+6.2f} "
          f"r3={r['r3']:+6.2f} n3={r['n3']}")

json.dump(dict(n_legs=len(sel), markets=sorted(nsym),
               s1=s1, s2=s2, s3=s3,
               legs=[dict(k=k, **{kk: vv for kk, vv in rows[k].items()
                                  if kk != "k"}) for k in sel]),
          open(os.path.join(BASE, "portfolio_v2.json"), "w"),
          indent=1, default=str)
print(f"\n-> portfolio_v2.json")
