"""compile_farm_seul : recompiler UNIQUEMENT le profil Dukascopy.

`compile_trigger_lab.py` recompile les deux profils ; quand la campagne du feed cible tourne, cela
remplacerait son ex5 sous ses pieds. Ce lanceur ne touche que le dossier Dukascopy, et seulement
quand sa propre campagne est terminee.

Usage : python SCRIPTS\\compile_farm_seul.py
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compile_trigger_lab as C


def main():
    ok, ex5, texte = C.compile_in("farm", Path(r"C:\EAFarm\MT5\Farm\MetaEditor64.exe"))
    err = len(re.findall(r":\s*(error|erreur)\s", texte, re.I))
    warn = len(re.findall(r":\s*(warning|avertissement)\s", texte, re.I))
    if not texte.strip() and not ok:
        # ROUND 386 : « erreurs=0 » sur un journal ABSENT n est PAS une compilation
        # reussie -- c est ainsi qu un .ex5 a disparu sans alerte. On le dit.
        print("farm : JOURNAL ABSENT et aucun .ex5 -- compilation NON CONCLUANTE")
        return 1
    print("farm : ex5=%s | erreurs=%d | avertissements=%d" % (ok, err, warn))
    if texte:
        for ln in texte.splitlines():
            if re.search(r"\b(error|erreur)\b", ln, re.I):
                print("    %s" % ln.strip())
    return 0 if (ok and err == 0) else 1


if __name__ == "__main__":
    sys.exit(main())
