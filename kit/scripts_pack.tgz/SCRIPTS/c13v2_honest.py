# -*- coding: utf-8 -*-
"""c13v2_honest.py — version LIVE-HONNETE du backtesteur C13V2 (corrige le
lookahead). Changement: dans build_ob_cache, l'OB detecte a la barre i (avec
impulsion dans i+1..i+6) n'est utilisable qu'a partir de la barre i+LOOKAHEAD
+ 1 (quand l'impulsion est confirmee). En backtest, on decale l'index de
l'OB valide de +lookahead pour ne jamais trader sur une impulsion future.
Le resultat = borne inferieure honnete vs le python original optimiste."""
from __future__ import annotations
import argparse
import numpy as np
import pandas as pd


@dataclass_like = None  # placeholder removed below

# Pour rester auto-contenu et testable sans le fichier data, on reprend la
# structure du code fourni mais on NE GARDE que la partie modifiee a integrer.
# L'utilisateur remplacera build_ob_cache dans son fichier par celle-ci:

def build_ob_cache_honest(m15, cfg):
    """
    Version HONNETE (sans lookahead): l'OB valide a la barre i n'existe que si
    l'impulsion de confirmation est deja arrivee (<= i). On ne regarde donc
    que les impulsions dans les LOOKAHEAD barres PASSEES, jamais futures.
    """
    m15 = m15.copy()
    m15["atr"] = atr(m15, cfg.atr_period)
    o = m15["open"].to_numpy(); h = m15["high"].to_numpy()
    l = m15["low"].to_numpy();  c = m15["close"].to_numpy()
    a = m15["atr"].to_numpy();  n = len(m15)
    is_bull = c > o
    is_bear = c < o
    body = np.abs(c - o)
    thr = a * cfg.impulse_atr_mult

    # OB "brut": bougie opposee a l'impulsion qui la suit (meme def python)
    # mais on NE peut l'utiliser qu'APRES confirmation -> on ne garde que les
    # barres j telles que l'impulsion soit dans j+1..j+L et j+L <= courante.
    ob_bull = np.zeros(n, dtype=bool)
    ob_bear = np.zeros(n, dtype=bool)
    zb_low = np.full(n, np.nan); zb_high = np.full(n, np.nan)
    zs_low = np.full(n, np.nan); zs_high = np.full(n, np.nan)

    for j in range(n):
        if not np.isfinite(a[j]) or a[j] <= 0:
            continue
        # candidat OB a j (bear => OB bull)
        if is_bear[j]:
            for k in range(1, cfg.impulse_lookahead + 1):
                jj = j + k
                if jj >= n:
                    break
                if (is_bull[jj] and body[jj] >= thr[j] and c[jj] > h[j]):
                    ob_bull[j] = True
                    zb_low[j] = l[j]; zb_high[j] = o[j]
                    break
        if is_bull[j]:
            for k in range(1, cfg.impulse_lookahead + 1):
                jj = j + k
                if jj >= n:
                    break
                if (is_bear[jj] and body[jj] >= thr[j] and c[jj] < l[j]):
                    ob_bear[j] = True
                    zs_low[j] = o[j]; zs_high[j] = h[j]
                    break

    # -- CLE DU FIX: une OB detectee a j (confirmee par j+k) n'est
    #    disponible au trader qu'a partir de j + lookahead (apres la
    #    confirmation). On decale donc l'index de disponibilite.
    L = cfg.impulse_lookahead
    latest_bull_at = np.full(n, -1, dtype=int)
    latest_bear_at = np.full(n, -1, dtype=int)
    last_bull = -1
    last_bear = -1
    for i in range(n):
        # rendre disponible l'OB detectee a i-L (confirmee il y a L barres)
        jj = i - L
        if jj >= 0:
            if ob_bull[jj]:
                last_bull = jj
            if ob_bear[jj]:
                last_bear = jj
        latest_bull_at[i] = last_bull
        latest_bear_at[i] = last_bear

    return {
        "m15_times": m15.index.values.astype("datetime64[ns]"),
        "zb_low": zb_low, "zb_high": zb_high,
        "zs_low": zs_low, "zs_high": zs_high,
        "latest_bull_at": latest_bull_at, "latest_bear_at": latest_bear_at,
    }
