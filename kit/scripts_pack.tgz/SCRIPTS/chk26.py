﻿import os, re
p = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\Tester\logs\20260912.log.old20260912_210358"
raw=open(p,"rb").read(4)
enc="utf-16" if raw[:2] in (b"\xff\xfe",b"\xfe\xff") else "utf-8"
txt=open(p,encoding=enc,errors="replace").read()
print(f"taille texte : {len(txt):,}")
print(f"ORION OPEN total   : {txt.count('ORION OPEN')}")
print(f"ORION OPEN XAUUSD  : {txt.count('ORION OPEN XAUUSD')}")
for mm in re.findall(r".*ORION OPEN XAUUSD.*", txt)[:3]:
    print("  ", mm.split("Core")[-1].strip()[:100])
