# -*- coding: utf-8 -*-
"""crypto_exo.py — nouveaux marches Upcomers : crypto et exotiques.

OBJECTIF : casser la concentration. Le portefeuille actuel a 75 % de son R sur
EURGBP, et ~65 % d'exposition EUR. Les marches qui n'ont AUCUN lien avec l'EUR :
  - CRYPTO : BTCUSD.nx, ETHUSD.nx, SOLUSD.nx, XRPUSD.nx, ADAUSD.nx, DOGEUSD.nx
  - EXOTIQUES : USDTRY, USDZAR, USDMXN, USDPLN, USDHUF, USDCZK, USDSEK,
                USDNOK, USDCNH, USDSGD, USDHKD
  - INDICES : DJCUSD.c, SPCUSD.c, NACUSD.c, RUSS2000.c, SWI20...

QUESTION : les structures robustes (brk_ll, ll_lh, fvg_dn, xdn_vwap) marchent-elles
sur ces marches-la ?

METHODE
  - charger les CSV M5 de up_new/
  - construire les masques robustes
  - mesurer R et le taux de marches positifs
  - comparer au FX (les structures doivent se comporter pareil)

SORTIE : nouveau_marches.json
"""
import os, sys, glob
from collections import defaultdict
import numpy as np
import pandas as pd

sys.path.insert(0, r"C:\EAFarm\HISTORY - Copy\research\SCRIPTS")
BASE = r"C:\EAFarm\HISTORY - Copy\research"
SL, TP, HOLD = 1.0, 20.0, 192

import robust_structures as RS

NOUVEAUX = {
    "CRYPTO": ["BTCUSD.nx", "ETHUSD.nx", "LTCUSD.nx", "XRPUSD.nx",
               "SOLUSD.nx", "ADAUSD.nx", "DOGEUSD.nx"],
    "EXOTIQUE": ["USDTRY", "USDZAR", "USDMXN", "USDPLN", "USDHUF",
                 "USDCZK", "USDSEK", "USDNOK", "USDCNH", "USDSGD", "USDHKD"],
    "INDICE": ["DJCUSD.c", "SPCUSD.c", "NACUSD.c", "RUSS2000.c",
               "SWI20", "ES35", "N25", "GECEUR.c", "FRCEUR.c",
               "UKCGBP.c", "JPCJPY.c", "HKCHKD.c", "AXCAUD.c"],
    "METAUX": ["XPTUSD", "XPDUSD", "XAUEUR", "XAUGBP"],
    "ENERGIE": ["USOIL.c", "UKOIL.c", "XNGUSD"],
    "FX_MAJEUR": ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCHF",
                  "USDCAD", "NZDUSD", "EURGBP", "EURJPY", "GBPJPY"],
}

STRUCTS = ["brk_ll_20", "brk_ll_50", "brk_ll_100", "ll_lh_50", "ll_lh_100",
           "fvg_dn_10", "fvg_dn_20", "xdn_vwapD", "xdn_vwapW",
           "sweep_lo_50", "sweep_lo_100"]
FILTS = ["h_quiet", "bb_low", "kelt_low", "vol_lo"]

resultats = {}
print("=" * 92)
print("STRUCTURES ROBUSTES SUR LES NOUVEAUX MARCHES (Upcomers)")
print("=" * 92)
print(f"{'categorie':<11}{'marche':<13}{'structure':<14}{'filtre':<10}"
      f"{'n':>6}{'R':>9}{'pos':>5}")
for cat, syms in NOUVEAUX.items():
    print(f"\n--- {cat} ---")
    for sym in syms:
        d5 = RS.load_up(sym)
        if d5 is None or len(d5) < 5000:
            continue
        M = RS.masks(d5)
        cat_res = resultats.setdefault(cat, defaultdict(list))
        meilleur = None
        for st in STRUCTS:
            if st not in M:
                continue
            for f in FILTS:
                if f not in M:
                    continue
                m = M[st] & M[f]
                if m.sum() < 30:
                    continue
                R, n = RS.runR(d5, m)
                cat_res[st].append((R, n, f, sym))
                if meilleur is None or R > meilleur[0]:
                    meilleur = (R, n, st, f)
        if meilleur:
            print(f"{'':<11}{sym:<13}{meilleur[2]:<14}{meilleur[3]:<10}"
                  f"{meilleur[1]:>6}{meilleur[0]:>9.1f}")

# ---------- synthese par categorie ----------
print()
print("=" * 92)
print("SYNTHESE : la structure marche-t-elle sur cette CATEGORIE ?")
print("=" * 92)
print(f"{'categorie':<11}{'struct':<14}{'mk':>4}{'pos':>5}{'%pos':>7}{'R moy':>9}")
synth = []
for cat, byst in resultats.items():
    for st, lst in byst.items():
        bysym = defaultdict(list)
        for R, n, f, s in lst:
            bysym[s].append(R)
        if len(bysym) < 3:
            continue
        best = {s: max(v) for s, v in bysym.items()}
        pos = sum(1 for v in best.values() if v > 0)
        synth.append(dict(cat=cat, struct=st, mk=len(best), pos=pos,
                          frac=pos/len(best),
                          Rmoy=float(np.mean(list(best.values())))))
synth.sort(key=lambda d: (d["cat"], -d["frac"]))
for d in synth:
    print(f"{d['cat']:<11}{d['struct']:<14}{d['mk']:>4}{d['pos']:>5}"
          f"{100*d['frac']:>6.0f}%{d['Rmoy']:>9.1f}")

import json
json.dump(synth, open(os.path.join(BASE, "nouveaux_marches.json"), "w"),
          indent=1, default=str)
print(f"\n-> nouveaux_marches.json")

print()
print("=" * 92)
print("LECTURE")
print("=" * 92)
print("  Une structure ROBUSTE doit donner un %pos eleve sur TOUTES les")
print("  categories. Si elle ne marche que sur FX_MAJEUR, elle est specifique")
print("  au FX et n'apporte pas de diversification.")
print("  Si elle marche aussi sur CRYPTO/INDICE, on peut casser la")
print("  concentration EUR avec des marches sans lien.")
