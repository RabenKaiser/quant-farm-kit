# -*- coding: utf-8 -*-
"""est_sl_r151.py — estimer ATR14 H1 GBPJPY autour du 2026-09-08 + niveau SL
pour sell 3.6 lots entree 208.460 (SL=2xATR au-dessus, TP=1xATR en dessous).
Lit les barres H1 depuis le cache Farm (Dukascopy) — pas de backtest, pas de
terminal Upcomers touche."""
import sys, os, glob, struct
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HIST = r"C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\CF0B997454318B475CF01419AFE2BBF3\bases\Dukascopy-demo-mt5-1\history\GBPJPY"
# tenter de lire un .hcc (format MT5 history) - complexe; alternative: le cache
# H1 genere par le terminal (historique telecharge) sous history\GBPJPY\cache\H1.hc
cache = os.path.join(HIST, "cache", "H1.hc")
print("cache H1 existe:", os.path.exists(cache), cache)

# fallback: les .hcc 2026 (fichier de ticks compressés?) -> parser vite fait si header connu
f2026 = os.path.join(HIST, "2026.hcc")
print("2026.hcc:", os.path.exists(f2026), os.path.getsize(f2026) if os.path.exists(f2026) else 0)
