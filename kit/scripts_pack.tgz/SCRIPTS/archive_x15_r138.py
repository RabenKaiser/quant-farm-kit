# -*- coding: utf-8 -*-
"""archive_x15_r138.py — maj DEPLOIEMENT + REGISTRE round 138 (x1.5)."""
DEP = r"C:\MT5\DEPLOIEMENT_UPCOMERS.txt"

dep_txt = """DEPLOIEMENT UPCOMERS (C:\\MT5) - 2026-09-07 v7 x1.5 RISQUE (round 138)
================================================
EAs: V3INT_EA (dossier MQL5\\Experts\\UPCOMERS) + VWAPFADE_EA/VWAPTREND_EA
(XAU H1). V45G/RVWAP/V3 = DUKASCOPY ONLY (feed-sensible).

LOTS DEPLOY x1.5 (boss OK round 138 - risque ~1.5-1.8%/trade, pire SL <=2.2%):
  V3INT_EA/EURUSD_H1.set              2.85   (15t, 6-20 UTC)
  V3INT_EA/GBPJPY_H1.set              3.6    (8t, 6-20)
  V3INT_EA/NZDJPY_H1.set              1.65   (9t, 6-20)
  V3INT_EA/AUDUSD_H1.set              3.45   (8t, 8-17)
  V3INT_EA/NZDUSD_H1.set              3.6    (7t, 8-17)
  V3INT_EA/EURGBP_H1.set              7.5    (15t, 6-20)
  V3INT_EA/GBPUSD_H1.set              1.65   (24t c055, 6-20)
  V3INT_EA/DJCUSD_H1_INDICE_DOW.set   0.52   (16t, 8-17)
  V3INT_EA/SPCUSD_H1_INDICE_SPX.set   1.65   (18t, 8-17)
  V3INT_EA/FRCEUR_H1_INDICE_FR40.set  1.8    (9t, 8-17)
  VWAPFADE_EA/XAUUSD_H1.set           0.15   (110t win24, 7-20 close-20)
  VWAPTREND_EA/XAUUSD_H1.set          0.09   (128t win24, 7-20 close-20)
Magics: EURUSD 713101 | GBPJPY 713601 | NZDJPY 713401 | AUDUSD 714402 |
NZDUSD 714401 | EURGBP 718901 | GBPUSD620 719505 | DOW 715503 | SPX 715502 |
FR40 715703 | XAU-FADE 718202 | XAU-TREND 718401. 1 magic/chart, tout H1.

VERIF x1.5 (equities = balances reels, 173 jours 2026):
sigma 1.37%/jour | mean +0.49%/jour | pire jour -2.06% (0 kill -4%, jamais
stop -5%) | net +42.7k/8 mois | ~+8.3%/mois. Pire SL single <= 2.13% (FRCEUR)
=> marge ~0.9% sous le kill EA -3% interne, ~1.9% sous le -4% firme. OK.
CAVEATS: sample 2026 seul; XAU VWAP = Upcomers-only regime 2026 (echoue
Duka 2024-25, round 135); si regime change les 10 legs V3INT restent.

RAPPELS:
- Sessions: EURUSD/GBPJPY/NZDJPY/EURGBP/GBPUSD620 6-20; AUDUSD/NZDUSD/DOW/
  SPX/FR40 8-17; XAU VWAP 7-20 flat 20:00 = 0 swap.
- Flat 20:00-20:30 UTC, kill interne -3%/jour.
"""
with open(DEP, "w", encoding="utf-8") as f:
    f.write(dep_txt)

REG = r"C:\EAFarm\SHARED\REGISTRE_MEILLEURES_STRATEGIES.md"
blk = """
================================================================================
ROUND 138 - BOSS CHOISIT x1.5 RISQUE (deploy live Upcomers)
- Scan risque x1.0..x2.5 sur la serie reelle (equities balances reels):
  x1.5 => +8.3%/mois sim, sigma 1.37%/j, pire jour -2.06%, 0 kill, pire SL
  single <= 2.13%. x2.0 => +10.4% mais pire SL ~2.9% colle au kill -3%.
- DECISION BOSS: x1.5 (tranquille). Presets mis a jour avec les lots x1.5
  (arrondis): EURUSD 2.85 GBPJPY 3.6 NZDJPY 1.65 AUDUSD 3.45 NZDUSD 3.6
  EURGBP 7.5 GBPUSD620 1.65 DOW 0.52 SPX 1.65 FRCEUR 1.8 VWAPF-XAU 0.15
  VWAPT-XAU 0.09. DEPLOIEMENT_UPCOMERS.txt maj. GO LIVE.
================================================================================
"""
with open(REG, "ab") as f:
    f.write(blk.encode("utf-8"))
print("DEPLOIEMENT + REGISTRE x1.5 ok")
