# -*- coding: utf-8 -*-
"""corr_final_r176.py — corr GBPUSD-M15-duka7y vs EURUSD/NZDJPY H1 duka7y."""
import sys, os
import pandas as pd
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TEAM = r"C:\EAFarm\HISTORY - Copy\research\prop_team\equities"
files = {
    "GBPUSD-M15": "equity_V3INT-GBPUSD-M15-duka7y.csv",
    "EURUSD-H1": "equity_V3INT-EURUSD-H1-duka7y.csv",
    "NZDJPY-H1": "equity_V3INT-NZDJPY-H1-duka7y.csv",
    "GBPJPY-H1": "equity_V3INT-GBPJPY-H1-duka7y.csv",
}
S = {}
for k, f in files.items():
    p = os.path.join(TEAM, f)
    if os.path.exists(p):
        S[k] = pd.read_csv(p, index_col=0, parse_dates=True).iloc[:, 0]
        print(f"{k}: n={len(S[k])} sum={S[k].sum():+.1f}")
idx = sorted(set().union(*[set(x.index) for x in S.values()]))
A = pd.DataFrame({k: S[k].reindex(idx).fillna(0.0) for k in S})
if "GBPUSD-M15" in A:
    print("\ncorr GBPUSD-M15 vs:")
    for k in A:
        if k == "GBPUSD-M15":
            continue
        print(f"  {k:12s} {A['GBPUSD-M15'].corr(A[k]):+.2f}")
# portfolio simple: equal-vol des 3-4 legs dispo
import numpy as np
cols = [c for c in A.columns]
sub = A[cols]
vols = sub.std()
w = (1 / vols) / (1 / vols).sum()
pnl = (sub * w).sum(axis=1)
print(f"\ncombine equal-vol {cols}: mean/j {pnl.mean():+.2f}$ "
      f"std {pnl.std():.2f}$ sum {pnl.sum():+.0f}$")
print("FIN", flush=True)
