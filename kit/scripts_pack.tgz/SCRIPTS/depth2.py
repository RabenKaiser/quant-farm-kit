# -*- coding: utf-8 -*-
"""depth2.py — depasser la limite de 50 000 barres.

PROBLEME : copy_rates_from_pos(s, tf, 0, N) plafonne a 50 000 barres.
Pour obtenir 6 ans de M1 il faut demander par TRANCHES successives en
utilisant copy_rates_from(s, tf, start_time, count) ou copy_rates_range,
en partant de la date la plus ancienne disponible.

METHODE : on descend dans le temps par bonds, en demandant a chaque fois
50 000 barres a partir de la date la plus ancienne connue.

MAIS : le vrai limiteur peut etre le SERVEUR (Dukascopy demo). Si le serveur
ne conserve que ~2 mois de M1, aucune methode ne les fera apparaitre.
C'est ce qu'on teste ici : on regarde jusqu'ou remonte une demande en 2019.
"""
import MetaTrader5 as mt5
import pandas as pd
from datetime import datetime, timedelta

PATH = r"C:\EAFarm\MT5\Farm\terminal64.exe"
ok = mt5.initialize(path=PATH)
print("terminal :", mt5.terminal_info().name)

print("\n=== test : demande explicite depuis 2019 ===")
for s in ("EURUSD", "USA500.IDX", "DEU.IDX", "BRENT.CMD", "BTCUSD"):
    info = mt5.symbol_info(s)
    if info is None:
        print(f"  {s:<14} ABSENT"); continue
    if not info.visible:
        mt5.symbol_select(s, True)
    r = mt5.copy_rates_range(s, mt5.TIMEFRAME_M1,
                             datetime(2019, 1, 1), datetime(2026, 9, 1))
    n = 0 if r is None else len(r)
    if n:
        d0 = pd.to_datetime(r[0]["time"], unit="s").date()
        d1 = pd.to_datetime(r[-1]["time"], unit="s").date()
        print(f"  {s:<14} {n:>9} barres  {d0} -> {d1}")
    else:
        print(f"  {s:<14} 0 barre (err={mt5.last_error()})")

print("\n=== test : M5 depuis 2019 (plus profond ?) ===")
for s in ("EURUSD", "USA500.IDX", "DEU.IDX", "BRENT.CMD"):
    r = mt5.copy_rates_range(s, mt5.TIMEFRAME_M5,
                             datetime(2019, 1, 1), datetime(2026, 9, 1))
    n = 0 if r is None else len(r)
    if n:
        d0 = pd.to_datetime(r[0]["time"], unit="s").date()
        d1 = pd.to_datetime(r[-1]["time"], unit="s").date()
        print(f"  {s:<14} {n:>9} barres  {d0} -> {d1}")
    else:
        print(f"  {s:<14} 0 barre")

print("\n=== test : H1 depuis 2019 ===")
for s in ("EURUSD", "USA500.IDX", "DEU.IDX", "BRENT.CMD"):
    r = mt5.copy_rates_range(s, mt5.TIMEFRAME_H1,
                             datetime(2019, 1, 1), datetime(2026, 9, 1))
    n = 0 if r is None else len(r)
    if n:
        d0 = pd.to_datetime(r[0]["time"], unit="s").date()
        d1 = pd.to_datetime(r[-1]["time"], unit="s").date()
        print(f"  {s:<14} {n:>9} barres  {d0} -> {d1}")
    else:
        print(f"  {s:<14} 0 barre")

mt5.shutdown()
